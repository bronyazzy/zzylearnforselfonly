"""Add PDF mode without replacing the existing EPUB renderer or dictionary."""
from __future__ import annotations

from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QFileDialog,
                               QInputDialog, QLabel, QLineEdit, QMessageBox,
                               QSpinBox, QStackedWidget, QToolBar, QTreeWidgetItem)

from dictionary_core import valid_query
from pdf_core import PdfBook, PdfError, PdfPasswordRequired, PdfPosition, finite_number, page_index, page_path
from pdf_ui import PdfView


class PdfReaderMixin:
    def __init__(self, state):
        self.pdf_book: PdfBook | None = None
        self._pdf_search_key = None
        self._pdf_search_matches = []
        self._pdf_match_index = -1
        self._pdf_paper_tint = state.data["preferences"].get("pdf_paper_tint", False) is True
        super().__init__(state)
        self.setWindowTitle("墨读 · EPUB / PDF 金融英语阅读器 6.0")

    def _build_ui(self):
        super()._build_ui()
        reading_panel = self.browser.parentWidget()
        reading_layout = reading_panel.layout()
        reading_layout.removeWidget(self.browser)
        self.document_stack = QStackedWidget(reading_panel)
        self.document_stack.addWidget(self.browser)
        self.pdf_view = PdfView()
        self.document_stack.addWidget(self.pdf_view)
        reading_layout.addWidget(self.document_stack, 1)
        self.pdf_view.pageRequested.connect(lambda direction: self.change_chapter(direction, from_end=direction < 0))
        self.pdf_view.lookupRequested.connect(self.lookup_text)
        self.pdf_view.selectionReleased.connect(self.lookup_automatic)
        self.pdf_view.positionChanged.connect(self.scrolled)
        self.pdf_view.zoomChanged.connect(self._pdf_zoom_changed)
        self.pdf_view.message.connect(lambda text: self.statusBar().showMessage(text, 9000))

        self.addToolBarBreak()
        self.pdf_toolbar = QToolBar("PDF 页面工具", self)
        self.pdf_toolbar.setObjectName("pdfToolbar")
        self.pdf_toolbar.setMovable(False)
        self.addToolBar(self.pdf_toolbar)
        self.pdf_toolbar.addWidget(QLabel("PDF · 页码 "))
        self.pdf_page_spin = QSpinBox()
        self.pdf_page_spin.setRange(1, 1)
        self.pdf_page_spin.setKeyboardTracking(False)
        self.pdf_page_spin.setMinimumWidth(86)
        self.pdf_page_spin.setToolTip("物理页码，从 1 开始；回车跳转（Ctrl+G）")
        self.pdf_page_spin.valueChanged.connect(lambda value: self._goto_pdf(value - 1))
        self.pdf_toolbar.addWidget(self.pdf_page_spin)
        self.pdf_total_label = QLabel(" / 0 页 ")
        self.pdf_toolbar.addWidget(self.pdf_total_label)
        self.pdf_toolbar.addSeparator()
        self.pdf_zoom_combo = QComboBox()
        self.pdf_zoom_combo.setPlaceholderText("自定义缩放")
        self.pdf_zoom_combo.addItem("适合宽度", "width")
        self.pdf_zoom_combo.addItem("适合整页", "page")
        for value in (.25, .5, .75, 1, 1.25, 1.5, 2, 3, 4):
            self.pdf_zoom_combo.addItem(f"{value:.0%}", value)
        self.pdf_zoom_combo.activated.connect(self._pdf_zoom_selected)
        self.pdf_toolbar.addWidget(self.pdf_zoom_combo)
        self.pdf_toolbar.addAction(self._action("旋转 90°", self._rotate_pdf))
        self.pdf_toolbar.addSeparator()
        self.pdf_tint_check = QCheckBox("纸张护眼着色")
        self.pdf_tint_check.setChecked(self._pdf_paper_tint)
        self.pdf_tint_check.setToolTip("显示滤镜，不修改文件；同时改变图片/图表颜色。取消可看原色。")
        self.pdf_tint_check.toggled.connect(self._set_pdf_tint)
        self.pdf_toolbar.addWidget(self.pdf_tint_check)
        self.pdf_toolbar.addWidget(QLabel("  双击/划选查词 · Ctrl+滚轮缩放"))
        self.pdf_toolbar.hide()
        self._action("跳转 PDF 页码", self._focus_pdf_page, "Ctrl+G")
        for menu_action in self.menuBar().actions():
            menu = menu_action.menu()
            if menu is not None and menu.title() == "阅读":
                for action in menu.actions():
                    if action.text() == "回到本章开头":
                        action.setText("回到本章 / 本页开头")

    def show_welcome(self):
        super().show_welcome()
        # Update only the local welcome document, never EPUB or PDF content.
        self.browser.setHtml(self.browser.toHtml().replace("EPUB 文件拖入窗口", "EPUB 或 PDF 文件拖入窗口")
                             .replace("finance_demo.epub 和 image_test.epub", "finance_demo.epub、image_test.epub 和 pdf_demo.pdf")
                             .replace("支持未加密 EPUB 的简化阅读排版。", "EPUB 使用阅读排版；PDF 保留原页面、图片和图表。"))

    def choose_book(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "打开 EPUB / PDF", str(Path.home()),
            "电子书 (*.epub *.EPUB *.pdf *.PDF);;EPUB (*.epub *.EPUB);;PDF (*.pdf *.PDF);;所有文件 (*)")
        if filename:
            self.open_book(filename)

    def open_book(self, filename: str) -> bool:
        suffix = Path(filename).suffix.lower()
        if suffix == ".pdf":
            return self._open_pdf(filename)
        if suffix != ".epub":
            QMessageBox.warning(self, "不支持的格式", "请选择 .epub 或 .pdf 文件。")
            return False
        # Validate/load EPUB through the unchanged implementation. Keep the old PDF
        # alive until success, so cancel/parse failure does not destroy the open book.
        old_pdf = self.pdf_book
        if old_pdf is not None:
            self.save_state()
        self.pdf_book = None
        try:
            opened = super().open_book(filename)
        except Exception:
            self.pdf_book = old_pdf
            raise
        if not opened:
            self.pdf_book = old_pdf
            return False
        self.pdf_view.clear()
        if old_pdf is not None:
            old_pdf.close()
        self.document_stack.setCurrentWidget(self.browser)
        self.pdf_toolbar.hide()
        self.search_edit.setPlaceholderText("搜索当前章节…")
        self._reset_pdf_search()
        self.update_controls()
        return True

    def _load_pdf_with_password(self, filename: str) -> PdfBook | None:
        password = None
        for attempt in range(4):
            failure = None
            needs_password = False
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            try:
                return PdfBook(filename, password)
            except PdfPasswordRequired:
                needs_password = True
            except (PdfError, OSError) as exc:
                failure = str(exc)
            finally:
                QApplication.restoreOverrideCursor()
            if failure is not None:
                QMessageBox.warning(self, "无法打开 PDF", failure)
                return None
            if needs_password:
                if attempt == 3:
                    QMessageBox.warning(self, "无法打开 PDF", "密码未通过验证。请确认密码后重新打开；未修改文件。")
                    return None
                password, accepted = QInputDialog.getText(
                    self, "PDF 打开密码", "请输入你有权使用的 PDF 打开密码（不会保存）：" if attempt == 0
                    else "密码不正确，请重新输入：", QLineEdit.EchoMode.Password)
                if not accepted:
                    return None
        return None

    def _open_pdf(self, filename: str) -> bool:
        self.save_state()
        new_book = self._load_pdf_with_password(filename)
        if new_book is None:
            return False
        record = self.store.data["books"].get(new_book.book_id, {})
        record = record if isinstance(record, dict) else {}
        position = PdfPosition.from_record(record, new_book.page_count, self.restore_position)
        # Preflight the first target page before touching the currently open book.
        try:
            new_book.render(position.page, .5, position.rotation)
        except PdfError as exc:
            new_book.close()
            QMessageBox.warning(self, "PDF 页面无法显示", str(exc))
            return False
        self._save_timer.stop()
        self._resize_timer.stop()
        self._restore_timer.stop()
        self.save_state()
        previous = self.pdf_book
        previous_epub = self.book
        previous_pdf_settings = (self.pdf_view.zoom_mode, self.pdf_view.zoom, self.pdf_view.rotation)
        self.document_stack.setCurrentWidget(self.pdf_view)
        self.pdf_toolbar.show()
        self.pdf_view.zoom_mode, self.pdf_view.zoom, self.pdf_view.rotation = position.zoom_mode, position.zoom, position.rotation
        try:
            self.pdf_view.set_book(new_book, position.page, position.ratio, position.horizontal)
        except PdfError as exc:
            self.pdf_view.clear()
            new_book.close()
            self.pdf_view.zoom_mode, self.pdf_view.zoom, self.pdf_view.rotation = previous_pdf_settings
            if previous is not None:
                old = PdfPosition.from_record(self.store.data["books"].get(previous.book_id), previous.page_count, True)
                self.pdf_view.set_book(previous, old.page, old.ratio, old.horizontal)
            else:
                self.document_stack.setCurrentWidget(self.browser)
                self.pdf_toolbar.hide()
            QMessageBox.warning(self, "PDF 页面无法显示", str(exc))
            return False
        if previous_epub is not None:
            previous_epub.close()
        if previous is not None:
            previous.close()
        self.book = None
        self.browser.book = None
        self.browser.images = None
        self.pdf_book = new_book
        self._generation += 1
        self._pending_target = self._reflow_anchor = None
        self._loading = False
        self.current_path = page_path(position.page)
        self.chapter_index = position.page
        self.history.clear()
        self.bookmarks = []
        raw_marks = record.get("bookmarks", [])
        for mark in raw_marks[:200] if isinstance(raw_marks, list) else []:
            if isinstance(mark, dict) and new_book.is_document(mark.get("path")):
                self.bookmarks.append({"path": mark["path"], "ratio": finite_number(mark.get("ratio"), 0, 0, 1),
                                       "label": str(mark.get("label", "书签"))[:200]})
        self.book_title.setText(new_book.title)
        self.book_author.setText(new_book.author + "\nPDF · 保留原始页面")
        self.setWindowTitle(f"{new_book.title} — 墨读 · PDF 金融英语")
        self.pdf_page_spin.blockSignals(True)
        self.pdf_page_spin.setRange(1, new_book.page_count)
        self.pdf_page_spin.setValue(position.page + 1)
        self.pdf_page_spin.blockSignals(False)
        self.pdf_total_label.setText(f" / {new_book.page_count} 页 ")
        self.populate_toc()
        self.populate_bookmarks()
        self.search_edit.clear()
        self.search_edit.setPlaceholderText("搜索当前 PDF 页…")
        self._reset_pdf_search()
        recent = [str(new_book.filename)] + [item for item in self.store.data["recent"]
                                           if isinstance(item, str) and item != str(new_book.filename)]
        self.store.data["recent"] = recent[:10]
        self._pdf_page_changed()
        self.apply_theme()
        if new_book.warnings:
            self.statusBar().showMessage("；".join(new_book.warnings), 16000)
        else:
            self.statusBar().showMessage("PDF 已打开。文字层可划词查询；扫描图片页不启用 OCR。", 8000)
        self._save_timer.start()
        return True

    def populate_toc(self):
        if self.pdf_book is None:
            return super().populate_toc()
        self.toc_tree.clear()
        self._toc_items = {}
        def append(parent, entries):
            for entry in entries:
                item = QTreeWidgetItem(parent, [entry.title])
                item.setData(0, Qt.ItemDataRole.UserRole, (entry.path, ""))
                self._toc_items.setdefault(entry.path, []).append(item)
                append(item, entry.children)
        if self.pdf_book.toc:
            append(self.toc_tree, self.pdf_book.toc)
        else:
            hint = QTreeWidgetItem(self.toc_tree, ["此 PDF 没有内置目录\n请用上方页码框跳转（Ctrl+G）"])
            hint.setFlags(hint.flags() & ~Qt.ItemFlag.ItemIsSelectable)
        self.toc_tree.expandToDepth(1)

    def navigate(self, path, fragment="", ratio=0.0, record_history=True, prepared_html=None, view=None):
        if self.pdf_book is None:
            if hasattr(self, "document_stack"):
                self.document_stack.setCurrentWidget(self.browser)
            return super().navigate(path, fragment, ratio, record_history, prepared_html, view)
        index = page_index(path, self.pdf_book.page_count)
        if index is None:
            self.statusBar().showMessage("PDF 页码无效。", 5000)
            return
        previous = (self.current_path, self.current_ratio()) if self.current_path else None
        try:
            self.pdf_view.show_page(index, ratio)
        except PdfError as exc:
            self.pdf_page_spin.blockSignals(True)
            self.pdf_page_spin.setValue(self.pdf_view.page_index + 1)
            self.pdf_page_spin.blockSignals(False)
            QMessageBox.warning(self, "无法显示页面", str(exc))
            return
        if record_history and previous:
            self.history.append(previous)
            self.history = self.history[-128:]
        self.current_path, self.chapter_index = page_path(index), index
        self._reset_pdf_search()
        self._pdf_page_changed()

    def _goto_pdf(self, index):
        if self.pdf_book is not None and index != self.pdf_view.page_index:
            self.navigate(page_path(index))

    def _pdf_page_changed(self):
        if self.pdf_book is None:
            return
        self.chapter_label.setText(self.pdf_book.page_label(self.pdf_view.page_index))
        self.chapter_label.setToolTip(str(self.pdf_book.filename))
        self.pdf_page_spin.blockSignals(True)
        self.pdf_page_spin.setValue(self.pdf_view.page_index + 1)
        self.pdf_page_spin.blockSignals(False)
        items = self._toc_items.get(self.current_path, [])
        if items:
            self.toc_tree.setCurrentItem(items[0])
            self.toc_tree.scrollToItem(items[0])
        self.update_controls()
        self.scrolled()

    def title_for(self, path):
        if self.pdf_book is None:
            return super().title_for(path)
        index = page_index(path, self.pdf_book.page_count)
        return self.pdf_book.page_label(index) if index is not None else "PDF"

    def current_ratio(self):
        return self.pdf_view.current_ratio() if self.pdf_book is not None else super().current_ratio()

    def change_chapter(self, direction: int, from_end=False):
        if self.pdf_book is None:
            return super().change_chapter(direction, from_end)
        target = self.pdf_view.page_index + direction
        if 0 <= target < self.pdf_book.page_count:
            self.navigate(page_path(target), ratio=1 if from_end else 0)
        else:
            self.statusBar().showMessage("已经是第一页。" if direction < 0 else "已经是最后一页。", 3500)

    def turn_page(self, direction):
        if self.pdf_book is not None:
            self.pdf_view.turn_screen(direction)
        else:
            super().turn_page(direction)

    def change_font(self, delta):
        if self.pdf_book is not None:
            self.pdf_view.set_zoom(self.pdf_view.effective_zoom * (1.15 if delta > 0 else 1 / 1.15))
        else:
            super().change_font(delta)

    def go_to_chapter_start(self):
        if self.pdf_book is not None:
            self.pdf_view.scroll_to_top()
        else:
            super().go_to_chapter_start()

    def restart_book(self):
        if self.pdf_book is not None:
            self.navigate(page_path(0))
        else:
            super().restart_book()

    def lookup_selection(self):
        if self.pdf_book is None:
            return super().lookup_selection()
        text = self.pdf_view.selected_text()
        if valid_query(text):
            self.lookup_text(text)
        elif self.dictionary_dock is not None:
            self.dictionary_dock.show()
            self.dictionary_dock.query_edit.setFocus()
            self.dictionary_dock.query_edit.selectAll()

    def lookup_text(self, text):
        if self.pdf_book is None:
            return super().lookup_text(text)
        if self.dictionary_dock is not None and valid_query(text):
            self.dictionary_dock.show()
            self.dictionary_dock.raise_()
            self.dictionary_dock.lookup(text, self.pdf_view.selected_context(),
                                        f"{self.pdf_book.title} · 第 {self.pdf_view.page_index + 1} 页")
            self.pdf_view.canvas.setFocus(Qt.FocusReason.OtherFocusReason)

    def _reset_pdf_search(self):
        self._pdf_search_key = None
        self._pdf_search_matches = []
        self._pdf_match_index = -1

    def find_text(self, backward=False):
        if self.pdf_book is None:
            return super().find_text(backward)
        query = self.search_edit.text().strip()
        if not query:
            return
        try:
            key = (self.pdf_book.book_id, self.pdf_view.page_index, query)
            if key != self._pdf_search_key:
                self._pdf_search_matches = self.pdf_book.find_matches(self.pdf_view.page_index, query)
                self._pdf_search_key = key
                self._pdf_match_index = 0 if backward else -1
            matches = self._pdf_search_matches
            if not matches:
                self.statusBar().showMessage("当前页没有找到文字。扫描页没有可用文字层时无法搜索。", 7000)
                return
            self._pdf_match_index = (self._pdf_match_index + (-1 if backward else 1)) % len(matches)
            self.pdf_view.select(matches[self._pdf_match_index])
            self.pdf_view.reveal_selection()
            self.statusBar().showMessage(f"本页匹配 {self._pdf_match_index + 1}/{len(matches)}；搜索仅限当前 PDF 页。", 6500)
        except PdfError as exc:
            self.statusBar().showMessage(str(exc), 8000)

    def add_bookmark(self):
        if self.pdf_book is None:
            return super().add_bookmark()
        ratio = self.current_ratio()
        if any(mark["path"] == self.current_path and abs(mark["ratio"] - ratio) < .005 for mark in self.bookmarks):
            self.statusBar().showMessage("此处已经有书签。", 3500)
            return
        if len(self.bookmarks) >= 200:
            self.statusBar().showMessage("每本书最多保存 200 个书签。", 3500)
            return
        label = f"{self.title_for(self.current_path)} · 页内 {ratio:.0%}"
        selection = self.pdf_view.selected_text()
        if selection:
            label += "\n" + selection[:45]
        self.bookmarks.append({"path": self.current_path, "ratio": ratio, "label": label})
        self.populate_bookmarks()
        self.save_state()
        self.statusBar().showMessage("PDF 书签已添加。", 3500)

    def scrolled(self, _value=0):
        if self.pdf_book is None:
            return super().scrolled(_value)
        self.progress_label.setText(f"PDF 第 {self.pdf_view.page_index + 1}/{self.pdf_book.page_count} 页 · 页内 {self.current_ratio():.0%}")
        self._save_timer.start()

    def update_controls(self):
        super().update_controls()
        pdf = self.pdf_book is not None
        self.prev_action.setText("上一页" if pdf else "上一章")
        self.next_action.setText("下一页" if pdf else "下一章")
        if pdf:
            self.prev_action.setEnabled(self.pdf_view.page_index > 0)
            self.next_action.setEnabled(self.pdf_view.page_index < self.pdf_book.page_count - 1)
            self.bookmark_action.setEnabled(True)
            self.search_edit.setEnabled(self.pdf_book.can_extract)
        self._pdf_zoom_changed()

    def _pdf_zoom_changed(self):
        if self.pdf_book is not None:
            self.font_label.setText(f"{self.pdf_view.effective_zoom:.0%}")
            data = self.pdf_view.zoom_mode if self.pdf_view.zoom_mode != "custom" else self.pdf_view.zoom
            index = self.pdf_zoom_combo.findData(data)
            self.pdf_zoom_combo.blockSignals(True)
            self.pdf_zoom_combo.setCurrentIndex(index)
            self.pdf_zoom_combo.blockSignals(False)
            self._save_timer.start()
        else:
            self.font_label.setText(f"{self.font_size} pt")

    def _pdf_zoom_selected(self, index):
        value = self.pdf_zoom_combo.itemData(index)
        if isinstance(value, str):
            self.pdf_view.set_zoom_mode(value)
        elif isinstance(value, (int, float)):
            self.pdf_view.set_zoom(value)

    def _rotate_pdf(self):
        if self.pdf_book is not None:
            self.pdf_view.rotate()

    def _focus_pdf_page(self):
        if self.pdf_book is not None:
            self.pdf_page_spin.setFocus()
            self.pdf_page_spin.selectAll()

    def _set_pdf_tint(self, enabled):
        self._pdf_paper_tint = bool(enabled)
        self.apply_theme()
        self.save_state()

    def apply_theme(self):
        super().apply_theme()
        if hasattr(self, "pdf_view"):
            bg, _panel, fg, _muted, _border, accent = self._colors
            self.pdf_view.set_colors(bg, fg, accent, self._pdf_paper_tint)
            self._pdf_zoom_changed()

    def save_state(self):
        self.store.data["preferences"]["pdf_paper_tint"] = self._pdf_paper_tint
        if self.pdf_book is not None:
            self.store.data["books"][self.pdf_book.book_id] = {
                "format": "pdf", "title": self.pdf_book.title,
                "path": page_path(self.pdf_view.page_index), "page": self.pdf_view.page_index,
                "ratio": self.pdf_view.current_ratio(), "horizontal": self.pdf_view.horizontal_ratio(),
                "zoom_mode": self.pdf_view.zoom_mode, "zoom": self.pdf_view.zoom,
                "rotation": self.pdf_view.rotation, "bookmarks": self.bookmarks,
            }
        return super().save_state()

    def dragEnterEvent(self, event):
        if any(url.isLocalFile() and Path(url.toLocalFile()).suffix.lower() in {".pdf", ".epub"}
               for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if url.isLocalFile() and Path(url.toLocalFile()).suffix.lower() in {".pdf", ".epub"}:
                self.open_book(url.toLocalFile())
                event.acceptProposedAction()
                break

    def closeEvent(self, event):
        super().closeEvent(event)
        if event.isAccepted():
            previous = self.pdf_book
            self.pdf_book = None
            self.pdf_view.clear()
            if previous is not None:
                previous.close()
