#!/usr/bin/env python3
"""Build small original MDX/MDD fixtures with the documented 1.2/2.0 wire layout.

This independent fixture encoder deliberately splits *record bytes* across
blocks to exercise readers. It is not a production publisher/converter tool.
No third-party dictionaries, voices or fonts are bundled. Audio is a test tone.
"""
from __future__ import annotations

import html
import io
import math
from pathlib import Path
import struct
import wave
import zlib
from mdict_hash import ripemd128


def _mask(block: bytes) -> bytes:
    key = ripemd128(block[4:8] + b'\x95\x36\0\0')
    encrypted = bytearray()
    previous = 0x36
    for i, value in enumerate(block[8:]):
        mixed = value ^ (i & 255) ^ key[i % 16] ^ previous
        previous = ((mixed << 4) | (mixed >> 4)) & 255
        encrypted.append(previous)
    return block[:8] + encrypted


def encode_mdict(entries: list[tuple[str, str | bytes]], *, kind: str = 'mdx',
                 version: str = '2.0', encoding: str = 'UTF-8', title: str = 'MDict test',
                 block_size: int = 4096, key_batch: int = 100, mask: bool = False,
                 compression: int = 2, attributes: dict[str, str] | None = None) -> bytes:
    modern = float(version) >= 2
    width = 8 if modern else 4
    number = lambda n: int(n).to_bytes(width, 'big')
    if kind == 'mdd':
        encoding = 'UTF-16'
    codec = {'UTF-16': 'utf-16le', 'UTF-8': 'utf-8', 'GBK': 'gbk', 'BIG5': 'big5'}[encoding]
    unit = 2 if codec == 'utf-16le' else 1
    def pack(raw):
        if compression == 0:
            data = raw
        elif compression == 2:
            data = zlib.compress(raw)
        elif compression == 1:
            # Fixture-only LZO encoder using a system library; not needed to
            # regenerate the bundled zlib examples.
            import ctypes
            import ctypes.util
            name = ctypes.util.find_library('lzo2')
            if not name:
                raise RuntimeError('LZO fixture encoder unavailable')
            lib = ctypes.CDLL(name)
            encoder = lib.lzo1x_1_compress
            encoder.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p,
                                ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p]
            encoder.restype = ctypes.c_int
            source = ctypes.create_string_buffer(raw)
            target = ctypes.create_string_buffer(len(raw) + len(raw)//16 + 128)
            length = ctypes.c_size_t(len(target))
            workspace = ctypes.create_string_buffer(1024 * 1024)
            status = encoder(source, len(raw), target, ctypes.byref(length), workspace)
            if status:
                raise RuntimeError('LZO fixture encoding failed')
            data = target.raw[:length.value]
        else:
            raise ValueError('compression must be 0, 1 or 2')
        return struct.pack('<I', compression) + struct.pack('>I', zlib.adler32(raw) & 0xffffffff) + data
    attrs = {'GeneratedByEngineVersion': version, 'RequiredEngineVersion': version,
             'Encrypted': '2' if mask else '0', 'Encoding': encoding,
             'Format': 'Html' if kind == 'mdx' else '', 'KeyCaseSensitive': 'No',
             'Title': title, 'Description': 'Original MoDu test dictionary. Not a commercial dictionary.',
             'StyleSheet': ''}
    attrs.update(attributes or {})
    tag = 'Dictionary' if kind == 'mdx' else 'Library_Data'
    xml = '<' + tag + ''.join(' ' + k + '="' + html.escape(v, quote=True) + '"' for k, v in attrs.items()) + '/>\0'
    header = xml.encode('utf-16le')
    output = struct.pack('>I', len(header)) + header + struct.pack('<I', zlib.adler32(header) & 0xffffffff)
    items = sorted(entries, key=lambda pair: pair[0])
    raw_records = bytearray()
    keys = []
    for word, value in items:
        key = word.encode(codec)
        keys.append((key, len(raw_records)))
        raw_records.extend((str(value) + '\0').encode(codec) if kind == 'mdx' else bytes(value))
    key_info = bytearray()
    key_blocks = bytearray()
    for start in range(0, len(keys), key_batch):
        group = keys[start:start+key_batch]
        raw = b''.join(number(offset) + key + b'\0'*unit for key, offset in group)
        block = pack(raw)
        key_info.extend(number(len(group)))
        for key in (group[0][0], group[-1][0]):
            key_info.extend((len(key)//unit).to_bytes(2 if modern else 1, 'big'))
            key_info.extend(key)
            if modern:
                key_info.extend(b'\0'*unit)
        key_info.extend(number(len(block)) + number(len(raw)))
        key_blocks.extend(block)
    if modern:
        # Key-info always uses zlib, even when keys/records use LZO or no compression.
        packed_info = struct.pack('<I', 2) + struct.pack('>I', zlib.adler32(key_info) & 0xffffffff) + zlib.compress(key_info)
        if mask:
            packed_info = _mask(packed_info)
        info_header = b''.join(number(x) for x in ((len(keys)+key_batch-1)//key_batch, len(keys), len(key_info), len(packed_info), len(key_blocks)))
        output += info_header + struct.pack('>I', zlib.adler32(info_header) & 0xffffffff) + packed_info + key_blocks
    else:
        info_header = b''.join(number(x) for x in ((len(keys)+key_batch-1)//key_batch, len(keys), len(key_info), len(key_blocks)))
        output += info_header + key_info + key_blocks
    blocks = []
    info = bytearray()
    for start in range(0, len(raw_records), block_size):
        raw = bytes(raw_records[start:start+block_size])
        block = pack(raw)
        blocks.append(block)
        info.extend(number(len(block)) + number(len(raw)))
    output += b''.join(number(x) for x in (len(blocks), len(keys), len(info), sum(map(len, blocks))))
    return bytes(output + info + b''.join(blocks))


def demo_png() -> bytes:
    width, height = 420, 140
    rows = []
    for y in range(height):
        row = bytearray()
        for x in range(width):
            if (x < 140 and y > 90) or (160 < x < 270 and y > 60) or (290 < x < 410 and y > 25):
                pixel = (46, 113, 132)
            elif y == 120:
                pixel = (30, 40, 50)
            else:
                pixel = (244, 247, 248)
            row.extend(pixel)
        rows.append(b'\0' + row)
    def chunk(name, data):
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', zlib.crc32(name + data) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(b''.join(rows))) + chunk(b'IEND', b'')


def demo_tone() -> bytes:
    stream = io.BytesIO()
    with wave.open(stream, 'wb') as sound:
        sound.setnchannels(1)
        sound.setsampwidth(2)
        sound.setframerate(16000)
        samples = [int(3000 * math.sin(2*math.pi*440*i/16000) * min(1, i/600, (6400-i)/600)) for i in range(6400)]
        sound.writeframes(struct.pack('<' + 'h'*len(samples), *samples))
    return stream.getvalue()


def write_demo(directory: Path) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    css = '.phonetic { color: #156f82; font-size: 15pt; } .meaning { font-size: 12pt; }'
    words = [
        ('cash flow', '<link rel="stylesheet" href="FinanceDemo.css"><p class="phonetic">/kæʃ floʊ/</p><p class="meaning">现金流：一定时期内现金流入与流出。</p><p>Positive cash flow does not always imply accounting profit.</p><p>现金流为正不一定意味着会计利润为正。</p>'),
        ('duration', '<p class="phonetic">/dʊˈreɪʃən/</p><p>久期；也有持续时间之义。债券分析中的具体含义需区分麦考利久期和修正久期。</p>'),
        ('equities', '@@@LINK=equity'),
        ('equity', '<link rel="stylesheet" href="FinanceDemo.css"><p class="phonetic">/ˈekwɪti/</p><p class="meaning">股权；所有者权益。普通义：公平、公正。</p><p>Related term: <a href="entry://cash%20flow">cash flow</a></p><img src="images/finance.png" alt="原创示意图，非真实市场数据"><p>示意图片用于验证 MDD 图片读取。</p><p><a href="sound://audio/test.wav">播放音频测试（提示音，不是真人发音）</a></p>'),
        ('leverage', '<p class="phonetic">/ˈlevərɪdʒ/</p><p>杠杆；利用借款等方式扩大资产或头寸。杠杆可能放大收益与损失。</p>'),
        ('mdx test', '<h3>MDX / MDD 兼容测试</h3><p>词条来自原创新增测试库；测试音频只是一段提示音。</p><a href="entry://equity">查看 equity：音标、中文、图片、音频</a>'),
    ]
    path = directory / 'FinanceDemo.mdx'
    path.write_bytes(encode_mdict(words, title='金融示例 MDX · 原创', mask=True, block_size=521, key_batch=2))
    (directory / 'FinanceDemo.mdd').write_bytes(encode_mdict([
        ('\\FinanceDemo.css', css.encode()), ('\\images\\finance.png', demo_png())
    ], kind='mdd', title='图片与样式示例', block_size=191, key_batch=1))
    (directory / 'FinanceDemo.1.mdd').write_bytes(encode_mdict([
        ('\\audio\\test.wav', demo_tone())
    ], kind='mdd', title='提示音资源示例', block_size=2048))
    (directory / 'README.txt').write_text('先导入 FinanceDemo.mdx，同目录两个 MDD 会自动关联。\n查询 equity 检查图片、音标、中文和音频；equities 检查内部跳转。\n音频为原创提示音，不是单词发音。图像为示意图，不是真实市场数据。\n请保留这三个文件的位置；移动后需重新导入。\n', encoding='utf-8')
    return path


if __name__ == '__main__':
    path = write_demo(Path(__file__).resolve().parent / 'examples' / 'mdict_demo')
    print('已生成原创 MDX / MDD 示例：', path)
