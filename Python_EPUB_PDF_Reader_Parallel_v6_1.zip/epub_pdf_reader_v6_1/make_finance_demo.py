"""Generate an original finance-reading EPUB with standard-library code."""
from pathlib import Path
import html
import json
from make_demo import write_epub, xhtml

ROOT = Path(__file__).resolve().parent


def finance_files():
    chapters = [
        ("Reading finance in English", "金融英语：开始查词", '''
        <h1>Reading finance in English</h1>
        <p>这本短篇试读书为墨读金融词典版编写，不是投资建议。双击英文单词，或者划选完整短语试试。</p>
        <h2>One word, more than one meaning</h2>
        <p>An investor builds a portfolio of stocks and bonds. The goal is to balance expected return and risk.</p>
        <p>The company raised capital by issuing equity. Its management used part of the cash to repay debt.</p>
        <p>In this context, equity means ownership or shareholders' equity, not simply fairness. A bond is a debt security, not a social connection.</p>
        <p>Financial leverage can amplify both gains and losses. Liquidity describes how easily an asset can be traded, or how readily a borrower can obtain cash.</p>
        <h2>Try these terms</h2>
        <p><b>leverage</b> · <b>equity</b> · <b>liquidity</b> · <b>yield</b> · <b>duration</b> · <b>default</b></p>
        <p>双击查询单词。拖动选中 <b>cash flow</b>、<b>credit spread</b> 或 <b>net present value</b>，松开鼠标即可查短语。</p>
        <p>关闭“划词即查”后，可选中英文再按 Ctrl+E，也可以右键查词。Ctrl+J 可收起或重新打开词典。</p>
        <p>点击“加入生词本”，保存词条和所在段落。生词本可以导出为含音标、中文释义、上下文和书名的 CSV。</p>
        '''),
        ("Reading financial statements", "财务报表与现金流", '''
        <h1>Reading financial statements</h1>
        <p>The balance sheet reports assets, liabilities, and equity at a specific date. The income statement reports revenue and expenses over a period.</p>
        <p>A cash flow statement explains cash movements. Accounting profit and operating cash flow can differ because of accruals, inventory, receivables, and other items.</p>
        <h2>An illustrative company</h2>
        <p>以下数字仅为教学示例，无货币单位，不对应任何真实公司。</p>
        <table border="1"><tr><th>Metric</th><th>Illustrative amount</th></tr>
        <tr><td>Revenue</td><td>120</td></tr><tr><td>Cost of sales</td><td>70</td></tr>
        <tr><td>Gross profit</td><td>50</td></tr><tr><td>Operating expenses</td><td>20</td></tr>
        <tr><td>Operating income</td><td>30</td></tr></table>
        <p>For this simplified example, gross margin is 50 / 120, or approximately 41.7 percent. Operating margin is 30 / 120, or 25 percent.</p>
        <p>The table does not include interest or tax, so it does not report net income.</p>
        <h2>Useful phrases</h2><p>working capital · accounts receivable · accounts payable · free cash flow · capital expenditure · return on equity</p>
        <p>比较 revenue、income、earnings 和 cash flow；它们在报告中并不总是同义词。</p>
        '''),
        ("Bonds, interest rates and risk", "债券、利率与风险", '''
        <h1>Bonds, interest rates and risk</h1>
        <p>A bond issuer promises payments under the terms of the bond. Investors still face credit risk, interest rate risk, and liquidity risk.</p>
        <p>The coupon rate is not necessarily the same as the yield. Suppose an illustrative bond has a face value of 100, pays an annual coupon of 5, and trades at 95. Its current yield is about 5.26 percent. This is not its yield to maturity.</p>
        <p>Yield to maturity also considers the timing of payments and repayment at maturity. Actual returns can differ if the issuer defaults, the bond is sold early, or reinvestment conditions change.</p>
        <p>Duration and convexity help describe sensitivity to interest rate changes. A credit spread compares a credit-sensitive yield with an appropriate benchmark.</p>
        <p>A rate increase from 3.00 percent to 3.25 percent is an increase of 25 basis points, or 0.25 percentage points.</p>
        <h2>Hedging and derivatives</h2>
        <p>An exporter may use a forward contract to hedge currency risk. An option gives its holder a right, not an obligation, to exercise. A margin call may require additional collateral.</p>
        <p>Risk measures have limitations. Value at risk is not the maximum possible loss. Diversification does not eliminate all investment risk.</p>
        '''),
        ("Acronyms and vocabulary practice", "缩写与离线词库练习", '''
        <h1>Acronyms and vocabulary practice</h1>
        <p>ETF · NAV · EPS · P/E · P/B · ROE · ROA · ROI · NPV · IRR · WACC · AUM · YTM · VaR · GDP · CPI · EBITDA</p>
        <p>选择上述缩写查词时，词典会显示匹配的全称及全称的参考音标；不把全称读音假装成缩写本身的读音。</p>
        <h2>Known word forms</h2><p>assets · liabilities · equities · derivatives · hedging · invested · bought · sold · indices · interest rates</p>
        <p>已知的词形变化可匹配到词条原形。其余词尾还原只作为推测，并会在结果中标明。</p>
        <h2>Adding a larger dictionary</h2>
        <p>内置词库是精选小词库。可以点击“导入词库 CSV”，导入你有权使用的 ECDICT 数据或自建词表。</p>
        <p>导入是离线操作；不会自动下载第三方词典。扩展词条缺少音标时会明确提示，不生成猜测音标。</p>
        <p>本包附 examples/custom_dictionary.csv，用于测试扩展词库导入。</p>
        '''),
    ]
    files = {
        "mimetype": "application/epub+zip",
        "META-INF/container.xml": '''<?xml version="1.0"?><container xmlns="urn:oasis:names:tc:opendocument:xmlns:container" version="1.0"><rootfiles><rootfile full-path="OPS/package.opf" media-type="application/oebps-package+xml"/></rootfiles></container>''',
    }
    manifest = '<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>'
    spine, nav = "", ""
    for number, (title, label, body) in enumerate(chapters, 1):
        name = f"Text/chapter{number}.xhtml"
        files["OPS/" + name] = xhtml(title, body)
        manifest += f'<item id="c{number}" href="{name}" media-type="application/xhtml+xml"/>'
        spine += f'<itemref idref="c{number}"/>'
        nav += f'<li><a href="{name}">{html.escape(label)}</a></li>'
    files["OPS/package.opf"] = f'''<?xml version="1.0" encoding="utf-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="id"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="id">urn:uuid:b077842f-3f7d-4ab3-859c-1830b63c98b1</dc:identifier><dc:title>金融英语阅读与查词试读</dc:title><dc:creator>墨读金融词典版</dc:creator><dc:language>en</dc:language><meta property="dcterms:modified">2026-09-09T00:00:00Z</meta></metadata><manifest>{manifest}</manifest><spine>{spine}</spine></package>'''
    files["OPS/nav.xhtml"] = f'''<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"><head><title>目录</title></head><body><nav epub:type="toc"><ol>{nav}</ol></nav></body></html>'''
    return files


if __name__ == "__main__":
    destination = ROOT / "finance_demo.epub"
    write_epub(destination, finance_files())
    print(destination)
