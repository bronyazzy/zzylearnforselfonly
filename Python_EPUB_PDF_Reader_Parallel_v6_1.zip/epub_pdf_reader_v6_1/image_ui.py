"""Synchronous, bounded image loading and pre-sized HTML for the Qt reader."""
from __future__ import annotations

from dataclasses import dataclass
import html
from html.parser import HTMLParser
import math
from urllib.parse import urlsplit

from PySide6.QtCore import QBuffer, QByteArray, QIODevice, QRectF, QSize, Qt, QUrl
from PySide6.QtGui import QColor, QImage, QImageReader, QImageIOHandler, QPainter, QTextDocument, QTextCursor
try:
    from PySide6.QtSvg import QSvgRenderer
except ImportError:
    QSvgRenderer = None

from epub_core import EpubError
from image_support import (ImageError, fit_image_size, raster_mime, sanitize_svg,
                           ImageColumnContext, image_column_width)

MAX_PIXELS = 40_000_000
MAX_CACHE_BYTES = 96 * 1024 * 1024
MAX_DECODE_SIDE = 4096
MAX_DECODE_PIXELS = 8_000_000


@dataclass
class Picture:
    image: QImage
    width: int
    height: int
    error: str = ''


@dataclass
class ImageSpec:
    url: str
    width_hint: str = ''
    height_hint: str = ''
    column_fraction: float = 1.0
    column_inset: float = 0.0


def encoded(url: QUrl) -> str:
    return bytes(url.toEncoded()).decode('ascii')


class ChapterImages:
    """Only the current EPUB's validated in-memory resources; never Qt fallback."""
    def __init__(self, book, chapter: str):
        self.book, self.chapter = book, chapter
        self.cache: dict[str, Picture] = {}
        self.warnings: set[str] = set()
        self.cache_bytes = 0
        self.specs: list[ImageSpec] = []
        self._placeholder: QImage | None = None

    def _read(self, url: str) -> tuple[bytes, str]:
        if url in self.book.embedded_images:
            return self.book.embedded_images[url], self.chapter
        if urlsplit(url).scheme == 'epubimg':
            raise ImageError('图片不属于当前书籍')
        path, _ = self.book.resolve(self.chapter, url)
        if not self.book.is_image(path):
            raise ImageError('图片不存在或格式不支持')
        return self.book.read(path), path

    def _decode(self, url: str) -> Picture:
        data, base = self._read(url)
        if not raster_mime(data):
            safe = sanitize_svg(data, lambda src: self.book.local_image_bytes(base, src))
            if QSvgRenderer is None:
                raise ImageError('缺少 QtSvg 模块，请重新安装运行依赖')
            renderer = QSvgRenderer(QByteArray(safe))
            if not renderer.isValid():
                raise ImageError('SVG 无法渲染')
            box = renderer.viewBoxF()
            size = renderer.defaultSize()
            width = size.width() if size.width() > 0 else box.width()
            height = size.height() if size.height() > 0 else box.height()
            if not (math.isfinite(width) and math.isfinite(height) and width > 0 and height > 0):
                raise ImageError('SVG 缺少有效尺寸')
            if width * height > MAX_PIXELS or max(width, height) > 100_000:
                raise ImageError('SVG 尺寸过大')
            scale = min(1.0, MAX_DECODE_SIDE / max(width, height),
                        math.sqrt(MAX_DECODE_PIXELS / (width * height)))
            target = QSize(max(1, round(width * scale)), max(1, round(height * scale)))
            image = QImage(target, QImage.Format.Format_ARGB32_Premultiplied)
            if image.isNull():
                raise ImageError('SVG 图片内存不足')
            image.fill(Qt.GlobalColor.transparent)
            painter = QPainter(image)
            try:
                renderer.render(painter, QRectF(0, 0, target.width(), target.height()))
            finally:
                painter.end()
            return Picture(image, round(width), round(height))
        buffer = QBuffer()
        buffer.setData(QByteArray(data))
        buffer.open(QIODevice.OpenModeFlag.ReadOnly)
        reader = QImageReader(buffer)
        reader.setDecideFormatFromContent(True)
        reader.setAutoTransform(True)
        if bytes(reader.format()).lower() not in {b'png', b'jpeg', b'jpg', b'gif', b'webp', b'bmp'}:
            raise ImageError('此 Qt 环境不支持该位图格式')
        size = reader.size()
        if not size.isValid() or size.width() * size.height() > MAX_PIXELS:
            raise ImageError('图片损坏或超过 4000 万像素')
        width, height = size.width(), size.height()
        scale = min(1.0, MAX_DECODE_SIDE / max(width, height),
                    math.sqrt(MAX_DECODE_PIXELS / (width * height)))
        if scale < 1:
            reader.setScaledSize(QSize(max(1, round(width * scale)), max(1, round(height * scale))))
        transformation = reader.transformation()
        image = reader.read()
        if image.isNull():
            raise ImageError('图片解码失败：' + reader.errorString())
        # AutoTransform may rotate portrait JPEGs. Keep their displayed ratio.
        if transformation.value & QImageIOHandler.Transformation.TransformationRotate90.value:
            width, height = height, width
        return Picture(image, width, height)

    def get(self, url: str) -> Picture:
        if url in self.cache:
            return self.cache[url]
        try:
            picture = self._decode(url)
            if self.cache_bytes + picture.image.sizeInBytes() > MAX_CACHE_BYTES:
                raise ImageError('本章图片缓存超过 96 MiB')
            self.cache_bytes += picture.image.sizeInBytes()
        except (ImageError, EpubError, UnicodeError, OSError, ValueError) as exc:
            message = str(exc)[:160]
            self.warnings.add(message)
            if self._placeholder is None:
                self._placeholder = QImage(280, 70, QImage.Format.Format_ARGB32_Premultiplied)
                self._placeholder.fill(QColor('#ececec'))
                painter = QPainter(self._placeholder)
                try:
                    painter.setPen(QColor('#555555'))
                    painter.drawRect(0, 0, 279, 69)
                    painter.drawText(self._placeholder.rect(), Qt.AlignmentFlag.AlignCenter, '图片暂不可用 / Image unavailable')
                finally:
                    painter.end()
            picture = Picture(self._placeholder, 280, 70, message)
        self.cache[url] = picture
        return picture

    def resource(self, url: str, available: int) -> QImage:
        picture = self.get(url)
        image = picture.image
        return (image.scaledToWidth(max(1, available), Qt.TransformationMode.SmoothTransformation)
                if image.width() > available else image)

    def prepare(self, content: str, document: QTextDocument, available: int) -> str:
        loader = self
        self.specs = []

        class PrepareHTML(HTMLParser):
            def __init__(self):
                super().__init__(convert_charrefs=True)
                self.output: list[str] = []
                self.columns = ImageColumnContext()

            def handle_starttag(self, tag, attrs):
                if tag != 'img':
                    self.columns.start(tag, dict(attrs))
                    self.output.append(self.get_starttag_text())
                    return
                values = dict(attrs)
                spec = ImageSpec(values.get('src') or '', values.get('width') or '', values.get('height') or '', *self.columns.current())
                loader.specs.append(spec)
                picture = loader.get(spec.url)
                column = image_column_width(available, spec.column_fraction, spec.column_inset)
                width, height = fit_image_size(picture.width, picture.height, column,
                                              spec.width_hint, spec.height_hint)
                document.addResource(QTextDocument.ResourceType.ImageResource.value, QUrl(spec.url),
                                     loader.resource(spec.url, available))
                values['width'], values['height'] = str(width), str(height)
                if picture.error:
                    values['title'] = picture.error
                safe = ''.join(f' {key}="{html.escape(value or "", quote=True)}"' for key, value in values.items())
                self.output.append(f'<img{safe} />')

            def handle_startendtag(self, tag, attrs):
                self.handle_starttag(tag, attrs)

            def handle_endtag(self, tag):
                self.columns.end(tag)
                self.output.append(f'</{tag}>')

            def handle_data(self, data):
                self.output.append(html.escape(data))

        parser = PrepareHTML()
        parser.feed(content)
        parser.close()
        return ''.join(parser.output)

    def resize_in_place(self, document: QTextDocument, available: int):
        """Resize only image formats, not the whole document; don't move its cursor."""
        occurrences = []
        block = document.begin()
        while block.isValid():
            iterator = block.begin()
            while not iterator.atEnd():
                fragment = iterator.fragment()
                if fragment.isValid() and fragment.charFormat().isImageFormat():
                    occurrences.append((fragment.position(), fragment.length(), fragment.charFormat().toImageFormat()))
                iterator += 1
            block = block.next()
        for index, (position, length, fmt) in enumerate(occurrences):
            url = fmt.name()
            picture = self.get(url)
            spec = self.specs[index] if index < len(self.specs) and self.specs[index].url == url else ImageSpec(url)
            column = image_column_width(available, spec.column_fraction, spec.column_inset)
            width, height = fit_image_size(picture.width, picture.height, column, spec.width_hint, spec.height_hint)
            document.addResource(QTextDocument.ResourceType.ImageResource.value, QUrl(url), self.resource(url, available))
            if abs(fmt.width() - width) < 1 and abs(fmt.height() - height) < 1:
                continue
            fmt.setWidth(width)
            fmt.setHeight(height)
            cursor = QTextCursor(document)
            cursor.setPosition(position)
            cursor.setPosition(position + length, QTextCursor.MoveMode.KeepAnchor)
            cursor.setCharFormat(fmt)
        document.markContentsDirty(0, document.characterCount())
