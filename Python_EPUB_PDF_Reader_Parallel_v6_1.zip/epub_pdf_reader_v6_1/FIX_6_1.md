# 6.1 空白正文修复说明

日期：2026-09-22。修复的对象是阅读器，不是用户 EPUB 的中英内容。

## 根因与原验证遗漏

6.0 将完整 64 字符十六进制 SHA-256 文本作为 `epub://` URL 的**单个主机标签**，图片虚拟地址也采用相同写法。Qt 的主机校验限制每个标签最多 63 个字符，因此地址在进入 QUrl 后不可用。64 个十六进制字符对应完整 256 bit 摘要。

依据：Qt 官方 6.8 分支 `qurlidna.cpp` 的 `MaxDomainLabelLength = 63`、`validateAsciiLabel` 和 `checkAsciiDomainName`；`qurl.cpp` 的主机解析调用该校验，并在失败时标为 `InvalidRegNameError`。

- https://raw.githubusercontent.com/qt/qtbase/6.8/src/corelib/io/qurlidna.cpp
- https://raw.githubusercontent.com/qt/qtbase/6.8/src/corelib/io/qurl.cpp

以往生产 HTML/CSS/JS 的浏览器测试采用内联资源，在 about:blank 中运行；没有经过 Qt 自定义地址处理器。这验证了双栏排版，但漏掉了桌面实际使用的页面地址。6.0 的失败回调又只更新状态栏，没有生成替代正文，因此用户看到空白。

本次通过 Python IDNA 编码器验证旧标签超限、新标签有效。额外使用当前系统已经安装的 **Qt 5.15 Core** 做独立原生 QUrl ABI 探针，结果为旧地址 invalid、新地址 valid；这是 Qt5 Core 的交叉验证，不是 Qt6/PySide6 或完整桌面测试，原始输出见 `diagnostics/QT5_URL_PROBE.txt`。Qt6 原生 QUrl / 窗口回归已加入测试，但因没有 PySide6 仍明确跳过。

## 修复措施

新地址的主机标签形式为 `b<摘要前32字符>.b<摘要后32字符>.epub`。保留整个摘要而不是截短；各标签短于 63 字符。存储中区分书籍的 `book_id` **不变**，不是把书重新登记成另一份。正文、CSS、插图、虚拟图片和书内链接统一迁移；旧同书内部地址仍可被核心解析，不接受其他书籍来源。

在真正调用 `view.load()` 前使用 `QUrl.isValid()`、`isEmpty()` 和 `host()` 检查。读取资源时保留每个 QBuffer 和原生请求对象直到请求销毁，用递增编号避免短生命周期对象 id 重用；异常会明确终止请求并写日志，不让 Qt 回调抛出后留下未完成页面。

原书显示失败、渲染子进程退出、正文控制初始化失败、检测为空，或 15 秒内未完成时，自动切换“兼容双栏”。明确取消的书内/外链导航不会当作正文失败；旧页面迟到回调与清理期间事件被忽略。

备用正文从 EPUB **重新生成**，不使用原书引擎加载阶段的空 `_cached_html`。明确中英配对转换为真实 `<table><tr><td>`；保留基本标题、链接、图像，按比例分栏且顶端对齐。没有配对不猜测；原书不修改。表格中图片按单元格宽度缩放。源码保留原书排版模式，不把所有书永久压成简化文本。

兼容双栏使用 QTextDocument 支持的 HTML 表格子集，而不是承诺完整 CSS 兼容：
https://doc.qt.io/qt-6/richtext-html-subset.html

## 更新方法

退出旧版，完整解压本包至新目录，正常运行 `start_windows.bat`。为快速恢复阅读，可直接运行 `start_windows_compatible.bat`；macOS/Linux 使用 `sh start_macos_linux_compatible.sh`。

首次安装依赖需要网络；阅读本地书籍、金融词库、MDX/MDD 不主动联网。兼容启动不载入 WebEngine，但不是免 Python/Qt 的版本。该次会话需要原书内核时，退出并用正常脚本重启。

保留既有数据目录。不要删除 `state.json`、`vocabulary.json`、CSV 词库或 `mdict/`；先前使用 `--data-dir` 时继续使用相同路径。

菜单“排版 → 显示诊断”可查看/复制日志，或读取应用数据目录 `logs/reader_display.log`。没有日志可读也给出说明；最多轮转保留当前文件和一个历史文件。日志可能含路径，不主动收集正文、图像字节、音频或密码，分享前请检查私有信息。

## 限制

15 秒超时需要 Qt 主线程事件循环正常运转。主进程崩溃、显卡驱动直接异常、系统缺失运行库，不是同进程定时器能保证恢复的情况；使用不启动浏览器的兼容脚本是另一条入口。

兼容双栏不支持所有出版方 CSS/交互/字体，MathML 及复杂版式也不能保证复刻。两种引擎均无法整理的损坏章节会显示具体错误与诊断入口，而不是宣称已修复内容。没有完成 Windows/macOS 实机验证；准确测试数量及用户书检查见 `TEST_REPORT.md`。
