"""Recognize audio containers before handing user-clicked bytes to QtMultimedia."""
from mdict_format import MdictError


def validate_audio(data: bytes, suffix: str) -> None:
    suffix = suffix.lower()
    if suffix not in {'.wav', '.mp3', '.ogg', '.oga', '.spx', '.m4a', '.aac', '.flac'}:
        raise MdictError('不支持此音频扩展名。')
    if len(data) < 12 or len(data) > 16 * 1024**2:
        raise MdictError('音频为空、损坏或超过 16 MiB。')
    valid = (data[:4] == b'RIFF' and data[8:12] == b'WAVE'
             or data[:4] in {b'OggS', b'fLaC'} or data[:3] == b'ID3'
             or data[0] == 0xff and data[1] & 0xe0 == 0xe0
             or data[4:8] == b'ftyp')
    if not valid:
        raise MdictError('资源不是可识别的音频文件；不会打开播放列表、网页或外部链接。')
