"""Persistent multi-dictionary library and random-access MDX/MDD record retrieval.

All source files stay in place and read-only. SQLite indexes contain offsets,
not uncompressed copies of whole MDD bundles. Imports are staged atomically and
cancelled/failed imports never replace a working dictionary.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
import hashlib
import html
import json
import os
from pathlib import Path
import re
import sqlite3
import tempfile
from typing import Callable
from urllib.parse import unquote, urlsplit
import uuid

from dictionary_core import Entry, word_candidates, valid_query
from mdict_format import (
    MdictError, MdictCancelled, MAX_RECORD, MAX_ARTICLE, check_cancel,
    file_signature, scan_archive, unpack_block, read_exact, word_key, resource_key,
)

MAX_DICTIONARIES = 64
MAX_MDD = 128
MAX_HITS = 32
MAX_CACHE = 64 * 1024**2
MAX_REGISTRY = 2 * 1024**2


@dataclass
class ImportPlan:
    staged_path: Path
    dictionary_id: str
    title: str
    mdx_path: str
    mdd_paths: list[str]
    count: int
    resource_count: int


def dictionary_id(path: Path) -> str:
    name = os.path.normcase(str(Path(path).expanduser().resolve()))
    return hashlib.sha256(name.encode('utf-8')).hexdigest()[:24]


def discover_mdd(path: Path) -> list[Path]:
    """Match name.mdd, name.1.mdd, name.2.mdd, ... (case-insensitive)."""
    path = Path(path).expanduser().resolve()
    expression = re.compile(r'^' + re.escape(path.stem) + r'(?:\.(\d+))?\.mdd$', re.I)
    found = []
    for item in path.parent.iterdir():
        match = expression.fullmatch(item.name)
        if match and item.is_file():
            found.append((int(match.group(1)) if match.group(1) else -1, item))
    return [p for _, p in sorted(found, key=lambda pair: (pair[0], pair[1].name.casefold()))]


def build_index(mdx_path: Path, destination_dir: Path, mdd_paths: list[Path] | None = None,
                progress: Callable[[str], None] | None = None,
                cancelled: Callable[[], bool] | None = None) -> ImportPlan:
    """Build a new immutable index. The caller must commit or discard the plan."""
    mdx_path = Path(mdx_path).expanduser().resolve()
    if mdx_path.suffix.lower() != '.mdx':
        raise MdictError('请先选择 MDX 词典正文；MDD 需绑定到对应的 MDX。')
    resources = discover_mdd(mdx_path) if mdd_paths is None else list(mdd_paths)
    resources = list(dict.fromkeys(Path(p).expanduser().resolve() for p in resources))
    if len(resources) > MAX_MDD or any(p.suffix.lower() != '.mdd' for p in resources):
        raise MdictError('资源包列表无效；每部词典最多绑定 128 个 MDD。')
    destination_dir = Path(destination_dir)
    destination_dir.mkdir(parents=True, exist_ok=True)
    fd, filename = tempfile.mkstemp(prefix='.mdict-import-', suffix='.sqlite', dir=destination_dir)
    os.close(fd)
    staged = Path(filename)
    db = None
    try:
        db = sqlite3.connect(staged)
        db.executescript('''
            PRAGMA user_version=1;
            PRAGMA journal_mode=DELETE;
            PRAGMA temp_store=FILE;
            PRAGMA cache_size=-8192;
            CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE keys(source INTEGER NOT NULL,key TEXT NOT NULL,norm TEXT NOT NULL,start INTEGER NOT NULL);
            CREATE TABLE blocks(source INTEGER NOT NULL,raw_start INTEGER NOT NULL,raw_size INTEGER NOT NULL,
                                file_offset INTEGER NOT NULL,packed_size INTEGER NOT NULL,
                                PRIMARY KEY(source,raw_start)) WITHOUT ROWID;
        ''')
        # Abort a long SQLite CREATE INDEX too, rather than waiting for the next key.
        db.set_progress_handler(lambda: 1 if cancelled and cancelled() else 0, 5000)
        sources = {}
        for source, path in enumerate([mdx_path, *resources]):
            check_cancel(cancelled)
            if progress:
                progress(f'正在读取 {path.name} 的目录索引…')
            sources[str(source)] = scan_archive(path, db, source, progress, cancelled)
        if progress:
            progress('正在建立查询索引…')
        db.executescript('''
            CREATE INDEX keys_lookup ON keys(source,norm);
            CREATE INDEX keys_offset ON keys(source,start);
        ''')
        db.execute('INSERT INTO metadata VALUES (?,?)', ('sources', json.dumps(sources, ensure_ascii=False)))
        db.commit()
        db.close()
        db = None
        # Validate one record from each archive now; remaining record checksums
        # are checked lazily when queried, not claimed as fully checked at import.
        if progress:
            progress('正在验证词条及资源索引…')
        index = MdictIndex(staged)
        try:
            for source in range(len(sources)):
                check_cancel(cancelled)
                row = index.db.execute('SELECT rowid AS key_id,start FROM keys WHERE source=? ORDER BY start LIMIT 1', (source,)).fetchone()
                if row:
                    index.record(source, row['start'], MAX_RECORD, row['key_id'])
        finally:
            index.close()
        check_cancel(cancelled)
        if progress:
            progress('正在同步索引文件…')
        # Windows _commit/FlushFileBuffers requires a writable handle. This is
        # only our staged SQLite index, NEVER an original MDX/MDD source. r+b
        # opens the existing file without creating or truncating it. Keep the
        # handle alive until flush/fsync completes and close before publication.
        with staged.open('r+b') as stream:
            stream.flush()
            os.fsync(stream.fileno())
        check_cancel(cancelled)
        title = sources['0']['attributes'].get('Title', '').strip() or mdx_path.stem
        # Strip title markup before using it in window labels and registry.
        title = re.sub('<[^>]*>', '', title)[:160] or mdx_path.stem
        return ImportPlan(staged, dictionary_id(mdx_path), title, str(mdx_path),
                          [str(p) for p in resources], sources['0']['count'],
                          sum(meta['count'] for key, meta in sources.items() if key != '0'))
    except Exception as exc:
        if db is not None:
            db.close()
        staged.unlink(missing_ok=True)
        if cancelled and cancelled():
            raise MdictCancelled('已取消导入，原词库保持不变。') from exc
        if isinstance(exc, MdictError):
            raise
        raise MdictError(f'词典导入失败：{exc}') from exc


class MdictIndex:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.db = sqlite3.connect(self.path.resolve().as_uri() + '?mode=ro', uri=True)
        self.db.row_factory = sqlite3.Row
        self.cache: OrderedDict[tuple[int, int], bytes] = OrderedDict()
        self.cache_bytes = 0
        self._verified: set[int] = set()
        try:
            self.db.execute('PRAGMA query_only=ON')
            self.db.execute('PRAGMA trusted_schema=OFF')
            if self.db.execute('PRAGMA user_version').fetchone()[0] != 1:
                raise MdictError('MDX 索引版本不支持，请重新导入。')
            value = self.db.execute("SELECT value FROM metadata WHERE key='sources'").fetchone()[0]
            if len(value) > MAX_REGISTRY:
                raise MdictError('MDX 索引元数据过大。')
            self.sources = json.loads(value)
            if '0' not in self.sources or len(self.sources) > MAX_MDD + 1:
                raise MdictError('MDX 索引元数据无效。')
        except Exception:
            self.db.close()
            raise

    def close(self):
        self.cache.clear()
        self.cache_bytes = 0
        self.db.close()

    def _source(self, source: int) -> tuple[Path, dict]:
        meta = self.sources[str(source)]
        path = Path(meta['path'])
        try:
            stat = path.stat()
            if stat.st_size != meta['size'] or stat.st_mtime_ns != meta['mtime_ns']:
                raise MdictError(f'{path.name} 已改变，请重新导入该词典。')
            if source not in self._verified:
                if file_signature(path) != {k: meta[k] for k in ('path', 'size', 'mtime_ns', 'sample')}:
                    raise MdictError(f'{path.name} 内容已改变，请重新导入。')
                self._verified.add(source)
        except OSError as exc:
            raise MdictError(f'找不到或无法读取 {path.name}；请保留原文件位置，或重新导入。') from exc
        return path, meta

    def record(self, source: int, start: int, maximum: int = MAX_ARTICLE, key_id: int | None = None) -> bytes:
        path, meta = self._source(source)
        if key_id is not None:
            # In file order, duplicate offsets describe an empty preceding record.
            # MDD files legitimately contain empty resources: do not substitute
            # the contents of the next resource for them.
            next_row = self.db.execute('SELECT start FROM keys WHERE rowid=? AND source=?',
                                       (key_id + 1, source)).fetchone()
        else:
            next_row = self.db.execute('SELECT start FROM keys WHERE source=? AND start>? ORDER BY start LIMIT 1',
                                       (source, start)).fetchone()
        end = next_row['start'] if next_row else meta['raw_size']
        if end < start or end - start > maximum:
            raise MdictError(f'词条/资源超过 {maximum // (1024*1024)} MiB 单项限制。')
        if end == start:
            return b''
        row = self.db.execute('SELECT * FROM blocks WHERE source=? AND raw_start<=? ORDER BY raw_start DESC LIMIT 1',
                              (source, start)).fetchone()
        if row is None:
            raise MdictError('记录偏移没有对应的压缩块。')
        # Start at the containing block and collect as many following blocks as
        # needed. Records can cross block boundaries (including UTF-16 code units).
        blocks = self.db.execute('SELECT * FROM blocks WHERE source=? AND raw_start>=? AND raw_start<? ORDER BY raw_start',
                                 (source, row['raw_start'], end))
        chunks = []
        position = start
        with path.open('rb') as stream:
            for block in blocks:
                raw_start, raw_size = block['raw_start'], block['raw_size']
                if raw_start > position or raw_start + raw_size <= position:
                    raise MdictError('词典记录块不连续。')
                key = (source, raw_start)
                if key in self.cache:
                    data = self.cache.pop(key)
                    self.cache[key] = data
                else:
                    stream.seek(block['file_offset'])
                    data = unpack_block(read_exact(stream, block['packed_size']), raw_size)
                    while self.cache and self.cache_bytes + len(data) > MAX_CACHE:
                        _, removed = self.cache.popitem(last=False)
                        self.cache_bytes -= len(removed)
                    if len(data) <= MAX_CACHE:
                        self.cache[key] = data
                        self.cache_bytes += len(data)
                stop = min(end, raw_start + raw_size)
                chunks.append(data[position-raw_start:stop-raw_start])
                position = stop
        if position != end:
            raise MdictError('词条/资源记录不完整。')
        return b''.join(chunks)

    def lookup_rows(self, query: str, maximum: int = 6):
        # Exact case spelling wins when a dictionary has distinct US/us entries.
        return self.db.execute('SELECT rowid AS key_id,key,start FROM keys WHERE source=0 AND norm=? ORDER BY (key=?) DESC LIMIT ?',
                               (word_key(query), query, maximum)).fetchall()

    def article(self, row, visited: set[str] | None = None) -> tuple[str, str]:
        visited = set() if visited is None else visited
        target_key = word_key(row['key'])
        if target_key in visited or len(visited) >= 16:
            raise MdictError('MDX 词条跳转形成循环或超过 16 层。')
        visited.add(target_key)
        raw = self.record(0, row['start'], MAX_ARTICLE, row['key_id'])
        meta = self.sources['0']
        try:
            text = raw.decode(meta['encoding']).rstrip('\0').lstrip('\ufeff')
        except UnicodeError as exc:
            raise MdictError('MDX 词条正文编码错误。') from exc
        if text.strip().startswith('@@@LINK='):
            target = text.strip()[8:].strip()
            rows = self.lookup_rows(target)
            if not rows:
                raise MdictError(f'词条跳转目标未找到：{target[:160]}')
            return self.article(rows[0], visited)
        attributes = meta['attributes']
        lines = attributes.get('StyleSheet', '').splitlines()
        styles = {lines[i].strip(): (lines[i+1], lines[i+2]) for i in range(0, len(lines)-2, 3)}
        if styles:
            parts = re.split(r'`(\d+)`', text)
            output = [parts[0]]
            for i in range(1, len(parts), 2):
                before, after = styles.get(parts[i], ('', ''))
                output.extend((before, parts[i+1], after))
            text = ''.join(output)
        if attributes.get('Format', 'Html').casefold() == 'text':
            text = '<pre>' + html.escape(text) + '</pre>'
        return row['key'], text

    def resource(self, key: str, maximum: int = MAX_RECORD) -> bytes | None:
        key = resource_key(key)
        for source in range(1, len(self.sources)):
            row = self.db.execute('SELECT rowid AS key_id,start FROM keys WHERE source=? AND norm=? LIMIT 1', (source, key)).fetchone()
            if row:
                return self.record(source, row['start'], maximum, row['key_id'])
        return None


@dataclass
class MdictArticle:
    dictionary_id: str
    title: str
    query: str
    word: str
    body: str
    match_note: str = '精确匹配'

    def as_entry(self) -> Entry:
        from mdict_html import text_snapshot
        text, phonetic = text_snapshot(self.body)
        return Entry(word=self.word, translation=text[:12000], phonetic=phonetic,
                     phonetic_label='原 MDX 词条中的音标', category='MDX 词典快照',
                     source=f'MDX：{self.title}')


@dataclass
class MdictResults:
    articles: list[MdictArticle] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class MdictLibrary:
    def __init__(self, data_dir: Path):
        self.directory = Path(data_dir) / 'mdict'
        self.registry_path = Path(data_dir) / 'mdict_library.json'
        self.items: list[dict] = []
        self.warning = ''
        self.read_only = False
        self._indexes: dict[str, MdictIndex] = {}
        if not self.registry_path.exists():
            return
        try:
            if self.registry_path.stat().st_size > MAX_REGISTRY:
                raise ValueError('词典清单过大')
            data = json.loads(self.registry_path.read_text(encoding='utf-8'))
            if data.get('version') != 1 or not isinstance(data.get('dictionaries'), list):
                raise ValueError('词典清单格式无效')
            if len(data['dictionaries']) > MAX_DICTIONARIES:
                raise ValueError('词典数量超过限制')
            seen = set()
            for item in data['dictionaries']:
                if (not isinstance(item, dict) or not re.fullmatch('[0-9a-f]{24}', item.get('id', ''))
                        or not re.fullmatch(r'[0-9a-f]{24}-[0-9a-f]{32}\.sqlite', item.get('index', ''))
                        or not item['index'].startswith(item['id'] + '-') or item['id'] in seen
                        or not isinstance(item.get('mdd_paths'), list)
                        or len(item['mdd_paths']) > MAX_MDD
                        or not all(isinstance(path, str) and path and '\0' not in path
                                   for path in item['mdd_paths'])
                        or not isinstance(item.get('mdx_path'), str) or not item['mdx_path']
                        or '\0' in item['mdx_path']
                        or not isinstance(item.get('title'), str) or len(item['title']) > 1024
                        or type(item.get('enabled', True)) is not bool
                        or type(item.get('count')) is not int or not 0 <= item['count'] <= 5_000_000
                        or type(item.get('resources')) is not int
                        or not 0 <= item['resources'] <= MAX_MDD * 5_000_000):
                    raise ValueError('词典条目无效')
                seen.add(item['id'])
            self.items = data['dictionaries']
        except (OSError, ValueError, TypeError, AttributeError) as exc:
            self.read_only = True
            self.warning = f'MDX 清单损坏，已保护原文件并停用写入：{exc}'

    def _save(self, items: list[dict]):
        if self.read_only:
            raise MdictError(self.warning)
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        text = json.dumps({'version': 1, 'dictionaries': items}, ensure_ascii=False, indent=2)
        if len(text.encode()) > MAX_REGISTRY:
            raise MdictError('MDX 清单超过大小限制。')
        fd, temp = tempfile.mkstemp(prefix='.mdict-registry-', suffix='.json', dir=self.registry_path.parent)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                stream.write(text)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, self.registry_path)
        finally:
            Path(temp).unlink(missing_ok=True)
        self.items = items

    def commit(self, plan: ImportPlan):
        if self.read_only:
            raise MdictError(self.warning)
        old = next((item for item in self.items if item['id'] == plan.dictionary_id), None)
        if old is None and len(self.items) >= MAX_DICTIONARIES:
            raise MdictError('最多导入 64 部 MDX 词典。')
        filename = plan.dictionary_id + '-' + uuid.uuid4().hex + '.sqlite'
        destination = self.directory / filename
        self.directory.mkdir(parents=True, exist_ok=True)
        item = {'id': plan.dictionary_id, 'index': filename, 'title': plan.title,
                'mdx_path': plan.mdx_path, 'mdd_paths': plan.mdd_paths,
                'count': plan.count, 'resources': plan.resource_count,
                'enabled': old.get('enabled', True) if old else True}
        items = [item if x['id'] == item['id'] else dict(x) for x in self.items]
        if old is None:
            items.append(item)
        os.replace(plan.staged_path, destination)
        try:
            self._save(items)
        except Exception:
            destination.unlink(missing_ok=True)
            raise
        if old:
            self.close_index(old['id'])
            try:
                (self.directory / old['index']).unlink(missing_ok=True)
            except OSError:
                self.warning = '旧索引未能清理，不影响使用；原 MDX/MDD 文件未改动。'

    def close_index(self, identifier: str):
        index = self._indexes.pop(identifier, None)
        if index:
            index.close()

    def close(self):
        for identifier in list(self._indexes):
            self.close_index(identifier)

    def set_enabled(self, identifier: str, enabled: bool):
        items = [dict(item, enabled=bool(enabled)) if item['id'] == identifier else dict(item) for item in self.items]
        self._save(items)

    def remove(self, identifier: str):
        old = next((x for x in self.items if x['id'] == identifier), None)
        if old is None:
            return
        self._save([dict(x) for x in self.items if x['id'] != identifier])
        self.close_index(identifier)
        try:
            (self.directory / old['index']).unlink(missing_ok=True)
        except OSError:
            self.warning = '词典已移除，但旧索引未能删除；原 MDX/MDD 文件未改动。'

    def index(self, identifier: str) -> MdictIndex:
        item = next((x for x in self.items if x['id'] == identifier), None)
        if not item:
            raise MdictError('未找到对应的 MDX 词典。')
        if identifier not in self._indexes:
            # Bound decompressed block caches across dictionaries, not just per file.
            while len(self._indexes) >= 4:
                self.close_index(next(iter(self._indexes)))
            self._indexes[identifier] = MdictIndex(self.directory / item['index'])
        return self._indexes[identifier]

    def lookup(self, query: str, selected: str = '') -> MdictResults:
        result = MdictResults()
        if not isinstance(query, str) or not query.strip() or len(query) > 160:
            return result
        candidates = word_candidates(query) if valid_query(query) else [(query.strip(), '精确匹配')]
        for item in self.items:
            if item.get('enabled', True) is not True or (selected and item['id'] != selected):
                continue
            try:
                index = self.index(item['id'])
                for candidate, note in candidates:
                    rows = index.lookup_rows(candidate)
                    if not rows:
                        continue
                    for row in rows:
                        word, text = index.article(row)
                        if word_key(word) != word_key(row['key']):
                            note = 'MDX 内部词条跳转'
                        result.articles.append(MdictArticle(item['id'], item['title'], query, word, text, note))
                        if len(result.articles) >= MAX_HITS:
                            result.warnings.append('匹配结果较多，最多显示 32 条；可选择单部词典。')
                            return result
                    break
            except (MdictError, OSError, sqlite3.Error, ValueError, KeyError, TypeError) as exc:
                result.warnings.append(f'{item["title"]}：{exc}')
        return result

    def resource(self, identifier: str, path: str, maximum: int = MAX_RECORD) -> bytes | None:
        index = self.index(identifier)
        key = resource_key(path)
        data = index.resource(key, maximum)
        if data is not None:
            return data
        # Explicitly local fallback for sidecar CSS/images/audio. No fonts, JS,
        # executables, network requests, path traversal or escaping symlinks.
        allowed = {'.css', '.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.svg',
                   '.wav', '.mp3', '.ogg', '.oga', '.m4a', '.aac', '.flac', '.spx'}
        if Path(path).suffix.lower() not in allowed:
            return None
        root = Path(index.sources['0']['path']).parent.resolve()
        parts = path.replace('\\', '/').lstrip('/').split('/')
        current = root
        for part in parts:
            if part in ('', '.'):
                continue
            candidate = current / part
            if not candidate.exists():
                # MDD paths are commonly case-insensitive, even on Linux.
                try:
                    matches = [p for p in current.iterdir() if p.name.casefold() == part.casefold()]
                except OSError:
                    return None
                if len(matches) != 1:
                    return None
                candidate = matches[0]
            current = candidate.resolve()
            if root not in current.parents:
                raise MdictError('资源文件越出词典目录。')
        if current.is_file():
            if current.stat().st_size > maximum:
                raise MdictError('配套资源超过大小限制。')
            with current.open('rb') as stream:
                data = stream.read(maximum + 1)
            if len(data) > maximum:
                raise MdictError('配套资源超过大小限制。')
            return data
        return None

    def default_css(self, identifier: str) -> bytes | None:
        item = next((x for x in self.items if x['id'] == identifier), None)
        if item:
            return self.resource(identifier, Path(item['mdx_path']).stem + '.css', 512 * 1024)
        return None
