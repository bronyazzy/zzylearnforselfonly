"""Original-layout EPUB mode layered over the established EPUB/PDF reader."""
from __future__ import annotations

import os
import sys
from dataclasses import replace
from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QLabel, QSlider,
    QToolBar, QMessageBox, QWidget, QHBoxLayout, QVBoxLayout, QPushButton,
    QDialog, QPlainTextEdit)

from dictionary_core import valid_query
from epub_core import EpubBook, EpubError
from publisher_core import LayoutSettings, MODE_NAMES, PublisherResources, appearance_payload, clean_anchor
from compatible_layout import compatible_chapter
from display_diagnostics import write_display_log
try:
    if (os.environ.get('MODU_COMPATIBLE_EPUB') == '1' or os.environ.get('MODU_SIMPLE_EPUB') == '1'
            or '--compatible-epub' in sys.argv or '--simple-epub' in sys.argv):
        raise ImportError('本次以兼容/简化启动，未载入原书内核；需要原书模式时请正常重启。')
    from publisher_ui import PublicationView, register_epub_scheme
    from PySide6.QtWebEngineCore import QWebEnginePage
    WEBENGINE_ERROR = ''
except (ImportError, OSError, RuntimeError) as exc:
    # A missing WebEngine DLL must not take EPUB/PDF/MDX reading down with it.
    PublicationView = None
    WEBENGINE_ERROR = f'{type(exc).__name__}: {exc}'
    def register_epub_scheme():
        pass
from reader_settings import ViewPosition, normalize_background, theme_colors

register_epub_scheme()


class PublisherReaderMixin:
    def __init__(self, state):
        self.publication_view=None
        self.layout_settings=LayoutSettings.from_dict(state.data['preferences'].get('epub_layout'))
        self._layout_book_id=''
        self._publication_resources=None
        self._opening_publication=False
        self._next_web_anchor=None
        self._focus_states=None
        self._force_simple=os.environ.get('MODU_SIMPLE_EPUB')=='1'
        self._force_compatible=os.environ.get('MODU_COMPATIBLE_EPUB')=='1'
        self._recovering=False
        self._display_note=''
        self._display_log_path=''
        self._compatible_pairs=0
        self._web_recovery_target=(0.0,'')
        super().__init__(state)
        self.setWindowTitle('墨读 6.1 · 原书排版 / 双语对照 / EPUB / PDF')

    def _build_ui(self):
        super()._build_ui()
        # WebEngine is created lazily: compatible mode does not start Chromium.
        self._display_banner=QWidget(self.document_stack.parentWidget())
        banner=QHBoxLayout(self._display_banner);banner.setContentsMargins(8,6,8,6)
        self._display_label=QLabel();self._display_label.setWordWrap(True)
        self._display_label.setTextFormat(Qt.TextFormat.PlainText)
        banner.addWidget(self._display_label,1)
        for label, callback in [('兼容双栏',self.use_compatible),('重试原书',self.retry_original),('诊断',self.show_display_diagnostics)]:
            button=QPushButton(label);button.clicked.connect(callback);banner.addWidget(button)
        layout=self.document_stack.parentWidget().layout()
        layout.insertWidget(layout.indexOf(self.document_stack),self._display_banner)
        self._display_banner.hide()
        self.addToolBarBreak()
        self.layout_toolbar=QToolBar('EPUB 排版',self)
        self.layout_toolbar.setObjectName('publicationLayoutToolbar')
        self.layout_toolbar.setMovable(False);self.addToolBar(self.layout_toolbar)
        self.layout_toolbar.addWidget(QLabel('EPUB 排版 '))
        self.layout_combo=QComboBox()
        for mode,label in MODE_NAMES.items():self.layout_combo.addItem(label,mode)
        self.layout_combo.setToolTip('原书排版保留 CSS；兼容双栏不启动浏览器，仅转换明确配对。不生成翻译。')
        self.layout_combo.activated.connect(lambda i:self.set_layout(mode=self.layout_combo.itemData(i)))
        self.layout_toolbar.addWidget(self.layout_combo)
        self.layout_toolbar.addSeparator()
        self.ratio_label=QLabel('英文 50% ');self.layout_toolbar.addWidget(self.ratio_label)
        self.ratio_slider=QSlider(Qt.Orientation.Horizontal)
        self.ratio_slider.setRange(30,70);self.ratio_slider.setFixedWidth(100)
        self.ratio_slider.setToolTip('左右对照/兼容双栏的英文宽度，中文使用剩余宽度；原书其他宽度规则可能优先。')
        self.ratio_slider.valueChanged.connect(self._ratio_changed)
        self.layout_toolbar.addWidget(self.ratio_slider)
        self.width_combo=QComboBox()
        for text,value in [('铺满阅读区',0),('舒适宽度 960',960),('宽幅 1280',1280),('宽幅 1600',1600)]:self.width_combo.addItem(text,value)
        self.width_combo.activated.connect(lambda i:self.set_layout(content_width=self.width_combo.itemData(i)))
        self.layout_toolbar.addWidget(self.width_combo)
        self.line_combo=QComboBox()
        for text,value in [('原书行距',0),('行距 1.5',1.5),('行距 1.8',1.8),('行距 2.1',2.1)]:self.line_combo.addItem(text,value)
        self.line_combo.activated.connect(lambda i:self.set_layout(line_height=self.line_combo.itemData(i)))
        self.layout_toolbar.addWidget(self.line_combo)
        self.theme_check=QCheckBox('应用阅读背景')
        self.theme_check.setToolTip('取消时保留原书文字/底色；不对图片执行反色。')
        self.theme_check.toggled.connect(lambda v:self.set_layout(use_theme=v))
        self.layout_toolbar.addWidget(self.theme_check)
        self.layout_toolbar.addAction(self._action('重载本章',self.reload_chapter,'F5'))
        self.layout_toolbar.addAction(self._action('修复显示',self.use_compatible))
        self.layout_toolbar.addAction(self._action('专注阅读',self.toggle_focus,'F11'))
        menu=self.menuBar().addMenu('排版')
        for mode,label in MODE_NAMES.items():
            action=menu.addAction(label)
            action.triggered.connect(lambda _c=False,m=mode:self.set_layout(mode=m))
        menu.addSeparator()
        menu.addAction(self._action('显示诊断',self.show_display_diagnostics))
        menu.addAction(self._action('重试原书排版',self.retry_original))
        menu.addAction(self._action('专注阅读 / 退出专注',self.toggle_focus))
        self._focus_exit_action=self._action('退出专注阅读',self.exit_focus,'Esc')
        self._focus_exit_action.setEnabled(False)
        self._ratio_timer=QTimer(self);self._ratio_timer.setSingleShot(True);self._ratio_timer.setInterval(180)
        self._ratio_timer.timeout.connect(lambda:self.set_layout(english_percent=self.ratio_slider.value()))
        self._sync_layout_controls();self.layout_toolbar.hide()

    def show_welcome(self):
        super().show_welcome()
        text=self.browser.toHtml().replace('EPUB 使用阅读排版；PDF 保留原页面、图片和图表。',
            'EPUB 默认保留原书排版，支持中英左右对照；PDF 保留原页面。')
        text=text.replace('finance_demo.epub、image_test.epub 和 pdf_demo.pdf',
            'parallel_demo.epub、finance_demo.epub、image_test.epub 和 pdf_demo.pdf')
        self.browser.setHtml(text)

    def _using_publication(self):
        return (self.publication_view is not None and self.book is not None and self.pdf_book is None
                and self.layout_settings.mode not in {'simple','compatible'}
                and not self._force_simple and not self._force_compatible)


    def _ensure_publication(self):
        if self.publication_view is not None:return True
        if PublicationView is None:
            self._display_note='原书内核不可用，已改用兼容双栏。'+WEBENGINE_ERROR
            self._record_display('webengine-import',WEBENGINE_ERROR)
            return False
        try:
            self.publication_view=PublicationView(self)
            self.document_stack.addWidget(self.publication_view)
            self.publication_view.loaded.connect(self._publication_loaded)
            self.publication_view.positionChanged.connect(self.scrolled)
            self.publication_view.lookupRequested.connect(self._publication_lookup)
            self.publication_view.linkRequested.connect(self.link_activated)
            self.publication_view.pageRequested.connect(lambda d:self.change_chapter(d,from_end=d<0))
            self.publication_view.message.connect(lambda t:self.statusBar().showMessage(t,8000))
            self.publication_view.userInteracted.connect(self._publication_interacted)
            self.publication_view.diagnostic.connect(self._record_display)
            return True
        except Exception as exc:
            self.publication_view=None
            self._display_note='原书内核初始化失败，已改用兼容双栏：'+str(exc)
            self._record_display('webengine-create',str(exc),exc)
            return False

    def _record_display(self,phase,message,error=None):
        self._display_log_path=write_display_log(self.store.filename.parent,phase,message,error=error)

    def _show_display_status(self,message):
        self._display_label.setText(str(message)[:600])
        self._display_label.setToolTip(str(message))
        self._display_banner.setVisible(bool(message))

    def _activate_compatible(self,reason):
        if self._recovering or self.book is None or self.pdf_book is not None:return
        self._recovering=True
        try:
            path=self.current_path
            ratio=self.current_ratio()
            fragment=self._web_recovery_target[1] if self._loading else ''
            self._record_display('compatible-fallback',reason)
            self.layout_settings=replace(self.layout_settings,mode='compatible')
            self._force_simple=False;self._force_compatible=False
            self._next_web_anchor=None
            if self.publication_view is not None:self.publication_view.clear_publication()
            self.cancel_pending_position();self._sync_layout_controls()
            self._display_note='已切换兼容双栏，原书文件未修改。原因：'+str(reason)
            self.navigate(path,fragment=fragment,ratio=ratio,record_history=False)
            self._show_display_status(self._display_note)
        except Exception as exc:
            self._record_display('fallback-failed',str(exc),exc)
            self._loading=False
            self.document_stack.setCurrentWidget(self.browser)
            # A native status document is visible even when both parser paths fail.
            from html import escape
            self.browser.setHtml('<h2>本章暂时无法显示</h2><p>'+escape(str(exc))+
                                 '</p><p>请尝试目录中的其他章节，或点击“诊断”查看原因。原文件没有修改。</p>')
            self._show_display_status('两种显示方式均失败，请查看诊断；未删除书籍或阅读数据。')
        finally:
            self._recovering=False

    def use_compatible(self):
        if self.book is not None and self.pdf_book is None:
            self._activate_compatible('手动选择兼容显示。')
        else:
            self.set_layout(mode='compatible')

    def reload_chapter(self):
        if self.book is None or self.pdf_book is not None:return
        ratio=self.current_ratio()
        if self.publication_view is not None:self.publication_view.clear_publication()
        self._publication_resources=None
        self.navigate(self.current_path,ratio=ratio,record_history=False)

    def retry_original(self):
        self._display_note=''
        if self.publication_view is not None:self.publication_view.clear_publication()
        self._publication_resources=None
        self.set_layout(mode='publisher')
        # set_layout may use same-engine settings updates. An explicit retry must load.
        if self.book is not None and self._using_publication() and not self.publication_view.active_path:
            self.reload_chapter()

    def show_display_diagnostics(self):
        path=self.store.filename.parent/'logs'/'reader_display.log'
        try:
            data=path.read_text(encoding='utf-8', errors='replace')[-128000:]
        except OSError as exc:
            data='尚无可读的显示日志。'+str(exc)
        dialog=QDialog(self);dialog.setWindowTitle('显示诊断 · 日志只保存在本机');dialog.resize(850,600)
        layout=QVBoxLayout(dialog)
        label=QLabel('日志可能含本机路径，分享前可遮去用户名。\n'+str(path));label.setWordWrap(True);layout.addWidget(label)
        edit=QPlainTextEdit();edit.setReadOnly(True);edit.setPlainText(data);layout.addWidget(edit,1)
        row=QHBoxLayout();layout.addLayout(row)
        copy=QPushButton('复制诊断');copy.clicked.connect(lambda:QApplication.clipboard().setText(edit.toPlainText()));row.addWidget(copy)
        close=QPushButton('关闭');close.clicked.connect(dialog.accept);row.addWidget(close)
        dialog.exec()

    def _payload(self):
        return appearance_payload(self.layout_settings,self.background,self.font_size)

    def _sync_layout_controls(self):
        if not hasattr(self,'layout_combo'):return
        for widget,value in [(self.layout_combo,self.layout_settings.mode),(self.width_combo,self.layout_settings.content_width),
                             (self.line_combo,self.layout_settings.line_height)]:
            widget.blockSignals(True);widget.setCurrentIndex(widget.findData(value));widget.blockSignals(False)
        self.ratio_slider.blockSignals(True);self.ratio_slider.setValue(self.layout_settings.english_percent);self.ratio_slider.blockSignals(False)
        self.ratio_label.setText(f'英文 {self.layout_settings.english_percent}% ')
        self.ratio_slider.setEnabled(self.layout_settings.mode in {'parallel','compatible'})
        native=self.layout_settings.mode in {'simple','compatible'}
        self.width_combo.setEnabled(not native);self.line_combo.setEnabled(not native)
        self.theme_check.setEnabled(not native)
        self.theme_check.blockSignals(True);self.theme_check.setChecked(self.layout_settings.use_theme);self.theme_check.blockSignals(False)

    def _ratio_changed(self,value):
        self.ratio_label.setText(f'英文 {value}% ')
        self._ratio_timer.start()

    def set_layout(self,**values):
        if hasattr(self,'_ratio_timer'):self._ratio_timer.stop()
        old=self._using_publication()
        ratio=self.current_ratio() if self.book else 0
        native_view=self.capture_view() if self.book and not old else None
        self.layout_settings=LayoutSettings.from_dict({**self.layout_settings.as_dict(),**values})
        self._force_simple=False;self._force_compatible=False
        self._sync_layout_controls()
        self._display_note=''
        if self.book:
            new=self._using_publication()
            if new and old:
                self.publication_view.apply_settings(self._payload())
                self._layout_notice()
            else:
                self.cancel_pending_position()
                if old and not new:self.publication_view.clear_publication()
                self.navigate(self.current_path,ratio=ratio,record_history=False,
                              view=native_view if not old else None)
        self._save_timer.start()

    def _layout_notice(self):
        if self._publication_resources is None:return
        n=self._publication_resources.pair_counts.get(self.current_path,0)
        if self.layout_settings.mode in {'parallel','stack','en','zh'}:
            text=f'本章识别到 {n} 组明确中英配对。' if n else '本章未识别到明确的中英配对；保留原文，不猜测左右对应关系。可用“原书排版”。'
            self.statusBar().showMessage(text,8000)

    def open_book(self,filename):
        # The base opener preflights EPUB/PDF bytes before replacing the book.
        # Publication-only failures are handled after open by the native fallback.
        previous_note=self._display_note
        self._display_note=''
        self._opening_publication=True
        try:
            success=super().open_book(filename)
        finally:
            self._opening_publication=False
        if success:
            self.layout_toolbar.setVisible(self.book is not None and self._focus_states is None)
            if self._using_publication():
                self.document_stack.setCurrentWidget(self.publication_view)
                self.publication_view.setFocus()
            elif self.pdf_book is not None:
                if self.publication_view is not None:self.publication_view.clear_publication()
                self._publication_resources=None
                self._show_display_status('')
        else:
            self._display_note=previous_note
            self._show_display_status(previous_note)
            if self._using_publication():self.document_stack.setCurrentWidget(self.publication_view)
        return success

    def navigate(self,path,fragment='',ratio=0.0,record_history=True,prepared_html=None,view=None):
        if self.book is not None and self.pdf_book is None:
            if self._layout_book_id!=self.book.book_id:
                self._layout_book_id=self.book.book_id
                record=self.store.data['books'].get(self.book.book_id,{})
                self.layout_settings=LayoutSettings.from_dict(record.get('epub_layout',self.layout_settings.as_dict()) if isinstance(record,dict) else None)
                if self._force_simple:self.layout_settings=replace(self.layout_settings,mode='simple')
                elif self._force_compatible:self.layout_settings=replace(self.layout_settings,mode='compatible')
                self._sync_layout_controls()
            if self.layout_settings.mode not in {'simple','compatible'} and not self._ensure_publication():
                self.layout_settings=replace(self.layout_settings,mode='compatible')
                self._sync_layout_controls()
            if self._using_publication():
                if self._publication_resources is None or self._publication_resources.book is not self.book:
                    self._publication_resources=PublisherResources(self.book)
                try:
                    self._publication_resources.chapter(path)
                except Exception as exc:
                    self._record_display('publication-prepare',str(exc),exc)
                    self._display_note='原书排版准备失败，已改用兼容双栏：'+str(exc)
                    self.layout_settings=replace(self.layout_settings,mode='compatible')
                    self.publication_view.clear_publication();self._sync_layout_controls()
                if self._using_publication():
                    if (self.publication_view.ready and self.publication_view.resources is self._publication_resources
                            and self.publication_view.active_path==path and self.current_path==path):
                        if record_history:
                            self.history.append((path,self.current_ratio()));self.history=self.history[-128:]
                        anchor,self._next_web_anchor=self._next_web_anchor,None
                        self.publication_view.go_to(fragment,ratio,anchor)
                        self.update_controls();self.publication_view.setFocus()
                        return
                    prepared_html=''  # only while a monitored WebEngine load is pending
            if self.layout_settings.mode=='compatible':
                try:
                    content=compatible_chapter(self.book,path,self.layout_settings.english_percent)
                    prepared_html=content.html;self._compatible_pairs=content.pairs
                except Exception as exc:
                    self._record_display('compatible-prepare',str(exc),exc)
                    self._display_note='兼容双栏无法整理本章，改用基础文字显示：'+str(exc)
                    self.layout_settings=replace(self.layout_settings,mode='simple')
                    self._sync_layout_controls();prepared_html=None
        result=super().navigate(path,fragment,ratio,record_history,prepared_html,view)
        if self._using_publication():
            self.document_stack.setCurrentWidget(self.publication_view)
            self.publication_view.setFocus()
        elif self.book is not None and self.pdf_book is None:
            self.document_stack.setCurrentWidget(self.browser);self.browser.setFocus()
            self._show_display_status(self._display_note)
            if self.layout_settings.mode=='compatible':
                self.statusBar().showMessage(f'兼容双栏：本章 {self._compatible_pairs} 组明确中英配对；不使用浏览器内核。',8000)
        return result

    def render(self,ratio,fragment='',view=None):
        if not self._using_publication():return super().render(ratio,fragment,view)
        self._restore_timer.stop();self._resize_timer.stop();self._pending_target=None;self._reflow_anchor=None
        self._generation+=1;self._loading=True;self._ready_ratio=ratio
        if self._publication_resources is None or self._publication_resources.book is not self.book:
            self._publication_resources=PublisherResources(self.book)
        anchor,self._next_web_anchor=self._next_web_anchor,None
        if self._opening_publication and self.restore_position:
            record=self.store.data['books'].get(self.book.book_id,{})
            if isinstance(record,dict):anchor=clean_anchor(record.get('epub_web_anchor'))
        self._web_recovery_target=(ratio,fragment)
        self._show_display_status('正在载入原书排版… 超时或失败会自动转为兼容双栏。')
        try:
            self.publication_view.set_chapter(self._publication_resources,self.current_path,self._payload(),ratio,fragment,anchor)
            self.document_stack.setCurrentWidget(self.publication_view)
        except Exception as exc:
            self._record_display('publication-load',str(exc),exc)
            self._publication_loaded(False,str(exc))

    def _publication_loaded(self,success,message):
        if not self._using_publication():return
        if not success:
            self._activate_compatible(message)
            return
        self._loading=False
        self._display_note='';self._show_display_status('')
        self._layout_notice();self.scrolled()

    def _publication_interacted(self):
        if self._using_publication():
            self._restore_timer.stop();self._pending_target=None;self._reflow_anchor=None

    def remember_view_before_resize(self):
        if not self._using_publication():return super().remember_view_before_resize()

    def schedule_reflow(self):
        if not self._using_publication():return super().schedule_reflow()

    def reflow(self):
        if not self._using_publication():return super().reflow()

    def current_ratio(self):
        if self._using_publication():
            return self._ready_ratio if self._loading else self.publication_view.current_ratio()
        return super().current_ratio()

    def capture_view(self):
        if self._using_publication():
            a=self.publication_view.anchor or {};r=self.current_ratio()
            return ViewPosition(0,0,r,a.get('top',r==0),a.get('bottom',r==1))
        return super().capture_view()

    def turn_page(self,direction):
        if self._using_publication():return self.publication_view.turn(direction)
        return super().turn_page(direction)

    def go_to_chapter_start(self):
        if self._using_publication():return self.publication_view.go_to()
        return super().go_to_chapter_start()

    def change_font(self,delta):
        if not self._using_publication():return super().change_font(delta)
        self.font_size=max(12,min(36,self.font_size+delta));self.font_label.setText(f'{self.font_size} pt')
        self.publication_view.apply_settings(self._payload());self._save_timer.start()

    def set_background(self,color):
        if not self._using_publication():return super().set_background(color)
        normalized=normalize_background(color,'')
        if not normalized:return
        self.background=normalized;self.night=theme_colors(normalized)[2]=='#ffffff'
        if not self.night:self.day_background=normalized
        self.apply_theme();self.publication_view.apply_settings(self._payload());self.save_state()

    def lookup_selection(self):
        if not self._using_publication():return super().lookup_selection()
        if valid_query(self.publication_view.selectedText()):self.publication_view.lookup(True)
        elif self.dictionary_dock is not None:
            self.dictionary_dock.show();self.dictionary_dock.query_edit.setFocus()

    def _publication_lookup(self,text,context,explicit):
        if not self._using_publication() or self.dictionary_dock is None or not valid_query(text):return
        if not explicit and not self.dictionary_dock.auto_check.isChecked():return
        self.dictionary_dock.show();self.dictionary_dock.raise_()
        self.dictionary_dock.lookup(text,context,self.book.title)
        self.publication_view.setFocus(Qt.FocusReason.OtherFocusReason)

    def lookup_text(self,text):
        if self._using_publication():
            self._publication_lookup(text,self.publication_view._context,True)
        else:super().lookup_text(text)

    def find_text(self,backward=False):
        if not self._using_publication():return super().find_text(backward)
        query=self.search_edit.text().strip()
        flags=QWebEnginePage.FindFlag.FindBackward if backward else QWebEnginePage.FindFlag(0)
        generation=self.publication_view._generation
        def done(result):
            if not self._using_publication() or generation!=self.publication_view._generation:return
            # PySide callback is QWebEngineFindTextResult in Qt 6.
            if hasattr(result,'numberOfMatches'):
                count=result.numberOfMatches();index=result.activeMatch()
                text=f'本章匹配 {index}/{count}' if count else '当前章节没有找到。'
            else:text='已定位本章匹配。' if result else '当前章节没有找到。'
            self.statusBar().showMessage(text,4500)
        self.publication_view.page().findText(query,flags,done)

    def add_bookmark(self):
        if not self._using_publication():return super().add_bookmark()
        generation=self.publication_view._generation;book_id=self.book.book_id
        def add(value):
            if not self._using_publication() or book_id!=self.book.book_id or generation!=self.publication_view._generation:return
            anchor=clean_anchor(value);ratio=anchor['ratio'] if anchor else self.current_ratio()
            if len(self.bookmarks)>=200:
                self.statusBar().showMessage('每本书最多 200 个书签。',5000);return
            if any(x['path']==self.current_path and abs(x['ratio']-ratio)<.005 for x in self.bookmarks):
                self.statusBar().showMessage('此处已有书签。',3500);return
            label=f'{self.title_for(self.current_path)} · {ratio:.0%}'
            selection=self.publication_view.selectedText().strip()
            if selection:label+='\n'+selection[:45]
            self.bookmarks.append({'path':self.current_path,'ratio':ratio,'label':label,'web_anchor':anchor})
            self.populate_bookmarks();self.save_state();self.statusBar().showMessage('段落书签已保存。',3500)
        self.publication_view.js('window.__modu.snapshot()',add)

    def open_bookmark(self,item):
        mark=item.data(Qt.ItemDataRole.UserRole)
        self._next_web_anchor=clean_anchor(mark.get('web_anchor')) if isinstance(mark,dict) else None
        return super().open_bookmark(item)

    def scrolled(self,_value=0):
        if not self._using_publication():return super().scrolled(_value)
        if self._loading or not self.current_path:return
        count=len(self.book.chapters);r=self.current_ratio()
        self.progress_label.setText(f'章节 {self.chapter_index+1}/{count} · 本章 {r:.0%} · {MODE_NAMES[self.layout_settings.mode]}')
        self._save_timer.start()

    def _extend_saved_state(self):
        self.store.data['preferences']['epub_layout']=self.layout_settings.as_dict()
        if self.book is not None and self.current_path:
            record=self.store.data['books'].get(self.book.book_id)
            if isinstance(record,dict):
                record['epub_layout']=self.layout_settings.as_dict()
                if self._using_publication():
                    record['epub_web_anchor']=clean_anchor(self.publication_view.anchor)
                    record.pop('viewport',None)  # not a QTextDocument cursor location

    def toggle_focus(self):
        if self._focus_states is not None:return self.exit_focus()
        widgets=[self.sidebar,*self.findChildren(QToolBar)]
        if self.dictionary_dock is not None:widgets.append(self.dictionary_dock)
        self._focus_states=(self.isFullScreen(),[(w,w.isVisible()) for w in widgets])
        for w in widgets:w.hide()
        self._focus_exit_action.setEnabled(True)
        self.showFullScreen()
        self.statusBar().showMessage('专注阅读：F11 或 Esc 退出；Ctrl+J 临时打开词典。',8000)

    def exit_focus(self):
        if self._focus_states is None:return
        was_full,states=self._focus_states;self._focus_states=None
        self._focus_exit_action.setEnabled(False)
        if not was_full:self.showNormal()
        for w,visible in states:w.setVisible(visible)
        self.layout_toolbar.setVisible(self.book is not None)
        self.pdf_toolbar.setVisible(self.pdf_book is not None)

    def closeEvent(self,event):
        if hasattr(self,'_ratio_timer'):self._ratio_timer.stop()
        super().closeEvent(event)
        if event.isAccepted() and self.publication_view is not None:self.publication_view.shutdown()
