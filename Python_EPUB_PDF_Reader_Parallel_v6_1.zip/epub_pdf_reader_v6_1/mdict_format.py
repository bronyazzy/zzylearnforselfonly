"""Bounded, streaming MDict 1.x/2.x index reader; original archives stay read-only.

Indexes keys and compressed-record block coordinates, not every decompressed
resource. No package paths are extracted to the filesystem. See SOURCES.md for
the independently documented format; see MDX_GUIDE.md for supported variants.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import html
import io
import re
import sqlite3
import struct
from pathlib import Path
from typing import Callable, BinaryIO
import unicodedata
import zlib

from mdict_hash import decode_index_mask

MAX_ARCHIVE = 32 * 1024**3
MAX_BLOCK = 64 * 1024**2
MAX_HEADER = 2 * 1024**2
MAX_KEYS = 5_000_000
MAX_BLOCKS = 1_000_000
MAX_KEY_BYTES = 8192
MAX_TOTAL_RAW = 128 * 1024**3
MAX_RECORD = 32 * 1024**2
MAX_ARTICLE = 2 * 1024**2


class MdictError(Exception):
    """User-facing invalid/unsupported dictionary error."""


class MdictCancelled(MdictError):
    pass


def check_cancel(cancelled: Callable[[], bool] | None):
    if cancelled and cancelled():
        raise MdictCancelled('已取消导入，原词库保持不变。')


def word_key(word: str) -> str:
    return ' '.join(unicodedata.normalize('NFKC', word).replace('\u200b', '').replace('\u00ad', '').split()).casefold()


def resource_key(value: str) -> str:
    """Normalize a literal archive path, not a URL: percent signs stay literal."""
    if not isinstance(value, str) or len(value) > 4096 or any(ord(c) < 32 for c in value):
        raise MdictError('资源路径无效。')
    value = value.replace('\\', '/')
    parts = []
    for part in value.lstrip('/').split('/'):
        if not part or part == '.':
            continue
        if part == '..' or ':' in part:
            raise MdictError('不允许资源路径跳出词典目录。')
        parts.append(part)
    if not parts:
        raise MdictError('资源路径为空。')
    return '/'.join(parts).casefold()


def read_exact(stream: BinaryIO, size: int, maximum: int = MAX_BLOCK) -> bytes:
    if size < 0 or size > maximum:
        raise MdictError('词典中的块长度超过安全限制。')
    value = stream.read(size)
    if len(value) != size:
        raise MdictError('词典文件不完整，或块长度声明错误。')
    return value


def _lzo_decode(payload: bytes, expected: int) -> bytes:
    """Use a bounded LZO decoder, either python-lzo or a system liblzo2."""
    try:
        import lzo
    except ImportError:
        lzo = None
    if lzo is not None:
        try:
            return lzo.decompress(b'\xf0' + struct.pack('>I', expected) + payload)
        except Exception as exc:
            raise MdictError(f'LZO 数据无法解码：{exc}') from exc
    # Standard Linux installations may already supply liblzo2. No library is
    # downloaded or searched in the dictionary directory.
    import ctypes
    import ctypes.util
    import os
    if os.name == 'nt':
        raise MdictError('此词库使用 LZO 压缩。当前环境缺少 python-lzo；请使用可安装该依赖的环境，或取得 zlib 版本词库。')
    library = ctypes.util.find_library('lzo2')
    if not library:
        raise MdictError('此词库使用 LZO 压缩，需要 python-lzo 或系统 liblzo2。')
    try:
        lib = ctypes.CDLL(library)
        decoder = lib.lzo1x_decompress_safe
        decoder.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p,
                            ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p]
        decoder.restype = ctypes.c_int
        source = ctypes.create_string_buffer(payload)
        target = ctypes.create_string_buffer(max(1, expected))
        size = ctypes.c_size_t(expected)
        code = decoder(source, len(payload), target, ctypes.byref(size), None)
        if code != 0 or size.value != expected:
            raise MdictError(f'LZO 块无效（错误 {code}）。')
        return target.raw[:size.value]
    except (OSError, AttributeError) as exc:
        raise MdictError('无法加载系统 LZO 解码器。') from exc


def unpack_block(block: bytes, expected: int) -> bytes:
    if not 0 <= expected <= MAX_BLOCK or not 8 <= len(block) <= MAX_BLOCK:
        raise MdictError('压缩块尺寸超出限制。')
    method = struct.unpack_from('<I', block)[0]
    checksum = struct.unpack_from('>I', block, 4)[0]
    payload = block[8:]
    if method == 0:
        result = payload
    elif method == 2:
        try:
            decoder = zlib.decompressobj()
            result = decoder.decompress(payload, expected + 1)
            if len(result) != expected or not decoder.eof or decoder.unconsumed_tail or decoder.unused_data:
                raise MdictError('zlib 块长度不符或包含多余数据。')
        except zlib.error as exc:
            raise MdictError(f'zlib 压缩数据损坏：{exc}') from exc
    elif method == 1:
        result = _lzo_decode(payload, expected)
    else:
        raise MdictError(f'不支持的压缩/块加密标识：{method}。')
    if len(result) != expected or zlib.adler32(result) & 0xffffffff != checksum:
        raise MdictError('词典块校验失败；请检查文件是否损坏。')
    return result


@dataclass(frozen=True)
class Header:
    attributes: dict[str, str]
    encoding: str
    version: float
    masked_index: bool
    key_start: int

    @property
    def title(self):
        return self.attributes.get('Title', '')


def read_header(stream: BinaryIO, kind: str) -> Header:
    size = struct.unpack('>I', read_exact(stream, 4))[0]
    raw = read_exact(stream, size, MAX_HEADER)
    checksum = struct.unpack('<I', read_exact(stream, 4))[0]
    if zlib.adler32(raw) & 0xffffffff != checksum:
        raise MdictError('MDX/MDD 文件头校验失败。')
    try:
        # Some old v1 exports used UTF-8 headers instead of UTF-16LE.
        if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
            text = raw.decode('utf-16').rstrip('\0')
        elif b'\0' in raw[:32]:
            text = raw.decode('utf-16le').rstrip('\0')
        else:
            text = raw.decode('utf-8-sig').rstrip('\0')
    except UnicodeError as exc:
        raise MdictError('无法解码词典文件头。') from exc
    if '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper():
        raise MdictError('词典文件头包含不允许的实体声明。')
    # Real-world MDict headers often place raw HTML in XML attributes. Parse only
    # quoted attributes, never interpret external entities or executable content.
    attributes = {name: html.unescape(value) for name, _, value in
                  re.findall(r'([A-Za-z][\w]*)\s*=\s*([\'\"])(.*?)\2', text, flags=re.S)}
    root = re.match(r'\s*<([\w]+)\b', text)
    if root is None or root.group(1).casefold() not in {'dictionary', 'library_data'}:
        raise MdictError('不是可识别的 MDict 词典/资源包。')
    if (kind == 'mdx') != (root.group(1).casefold() == 'dictionary'):
        raise MdictError('文件内容与 MDX/MDD 扩展名不符。')
    try:
        version = float(attributes.get('GeneratedByEngineVersion', '0'))
        flag = attributes.get('Encrypted', '0')
        flag = {'no': '0', 'yes': '1'}.get(flag.casefold(), flag)
        encrypted = int(flag)
    except (ValueError, OverflowError) as exc:
        raise MdictError('词典版本或加密标记无效。') from exc
    if not 1 <= version < 3:
        raise MdictError(f'当前支持 MDict 1.x / 2.x；此文件声明版本 {version}。不支持 MDict 3.x。')
    if encrypted not in (0, 2):
        raise MdictError('此词典需要注册密钥/设备绑定或使用不支持的加密；请使用已授权的兼容版本。')
    name = attributes.get('Encoding', 'UTF-8').upper().replace('_', '-').replace(' ', '')
    encodings = {'UTF8': 'utf-8', 'UTF-8': 'utf-8', 'UTF-16': 'utf-16le',
                 'UTF16': 'utf-16le', 'UTF-16LE': 'utf-16le', 'GBK': 'gb18030',
                 'GB2312': 'gb18030', 'GB18030': 'gb18030', 'BIG5': 'big5', 'BIG-5': 'big5'}
    if kind == 'mdd':
        encoding = 'utf-16le'
    elif name in encodings:
        encoding = encodings[name]
    else:
        raise MdictError(f'不支持的词典编码：{name}。')
    return Header(attributes, encoding, version, bool(encrypted & 2), stream.tell())


def file_signature(path: Path) -> dict:
    """Detect normal replacements using stat and a sampled fingerprint, not identity proof."""
    stat = path.stat()
    if not path.is_file() or stat.st_size > MAX_ARCHIVE:
        raise MdictError('词典文件无效或超过 32 GiB。')
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for offset in sorted({0, max(0, stat.st_size//2 - 32768), max(0, stat.st_size - 65536)}):
            stream.seek(offset)
            h.update(stream.read(65536))
    return {'path': str(path), 'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns, 'sample': h.hexdigest()}


def scan_archive(path: Path, db: sqlite3.Connection, source_id: int,
                 progress: Callable[[str], None] | None = None,
                 cancelled: Callable[[], bool] | None = None) -> dict:
    """Stream keys and record coordinates into an importer's transaction.

    Caller creates keys(source,key,norm,start), blocks(source,raw_start,raw_size,
    file_offset,packed_size) tables. Only key blocks, not record blocks, decode now.
    """
    path = Path(path).expanduser().resolve()
    kind = path.suffix.lower().lstrip('.')
    if kind not in {'mdx', 'mdd'}:
        raise MdictError('只接受 .mdx 或 .mdd 文件。')
    before = file_signature(path)
    with path.open('rb') as stream:
        header = read_header(stream, kind)
        width = 8 if header.version >= 2 else 4
        fmt = '>Q' if width == 8 else '>I'
        def number(f=stream):
            return struct.unpack(fmt, read_exact(f, width))[0]
        raw_numbers = read_exact(stream, width * (5 if width == 8 else 4))
        values = struct.unpack('>' + ('Q' if width == 8 else 'I') * (5 if width == 8 else 4), raw_numbers)
        if width == 8:
            nblocks, nkeys, info_raw_size, info_size, key_size = values
            checksum = struct.unpack('>I', read_exact(stream, 4))[0]
            if zlib.adler32(raw_numbers) & 0xffffffff != checksum:
                raise MdictError('词头索引头部校验失败。')
        else:
            nblocks, nkeys, info_size, key_size = values
            info_raw_size = info_size
        if not (0 <= nblocks <= MAX_BLOCKS and 0 < nkeys <= MAX_KEYS):
            raise MdictError('词条/资源数量无效或超过 500 万项限制。')
        if stream.tell() + info_size + key_size > before['size']:
            raise MdictError('词头索引长度超过文件边界。')
        check_cancel(cancelled)
        packed_info = read_exact(stream, info_size)
        if width == 8:
            if header.masked_index:
                packed_info = decode_index_mask(packed_info)
            key_info = unpack_block(packed_info, info_raw_size)
        else:
            if header.masked_index:
                raise MdictError('不支持 v1 的带掩码索引。')
            key_info = packed_info
        info = io.BytesIO(key_info)
        lengths = []
        total_keys = total_packed = 0
        unit = 2 if header.encoding == 'utf-16le' else 1
        for _ in range(nblocks):
            check_cancel(cancelled)
            count = number(info)
            for _ in range(2):
                n = struct.unpack('>H' if width == 8 else '>B', read_exact(info, 2 if width == 8 else 1))[0]
                read_exact(info, (n + (1 if width == 8 else 0)) * unit, MAX_KEY_BYTES)
            packed, raw = number(info), number(info)
            if not 8 <= packed <= MAX_BLOCK or not 0 < raw <= MAX_BLOCK:
                raise MdictError('词头块尺寸无效或超过 64 MiB。')
            total_keys += count
            total_packed += packed
            lengths.append((count, packed, raw))
        if info.tell() != len(key_info) or total_keys != nkeys or total_packed != key_size:
            raise MdictError('词头块索引计数不一致。')
        count = 0
        previous_offset = -1
        for expected_count, packed, raw_size in lengths:
            check_cancel(cancelled)
            raw = unpack_block(read_exact(stream, packed), raw_size)
            position = 0
            batch = []
            for _ in range(expected_count):
                if position + width > len(raw):
                    raise MdictError('词头块不完整。')
                offset = struct.unpack_from(fmt, raw, position)[0]
                position += width
                end = position
                while end + unit <= len(raw) and raw[end:end+unit] != b'\0' * unit:
                    end += unit
                    if end - position > MAX_KEY_BYTES:
                        raise MdictError('词头长度超过限制。')
                if end + unit > len(raw):
                    raise MdictError('词头缺少结束标记。')
                try:
                    text = raw[position:end].decode(header.encoding)
                except UnicodeError as exc:
                    raise MdictError(f'词头无法按 {header.encoding} 解码。') from exc
                if offset < previous_offset or offset > MAX_TOTAL_RAW:
                    raise MdictError('词条记录偏移无效或不是递增顺序。')
                previous_offset = offset
                if not text:
                    raise MdictError('词典包含空词头。')
                if kind == 'mdd':
                    # Bad resource names cannot escape to the OS; ignore lookup but
                    # retain offsets so neighboring records remain correctly bounded.
                    try:
                        norm = resource_key(text)
                    except MdictError:
                        norm = ''
                else:
                    norm = word_key(text)
                batch.append((source_id, text, norm, offset))
                position = end + unit
                count += 1
                if len(batch) >= 2000:
                    db.executemany('INSERT INTO keys VALUES (?,?,?,?)', batch)
                    batch.clear()
                    check_cancel(cancelled)
            if position != len(raw):
                raise MdictError('词头块包含多余字节。')
            db.executemany('INSERT INTO keys VALUES (?,?,?,?)', batch)
            if progress:
                progress(f'{path.name}：已索引 {count:,} / {nkeys:,} 项')
        nrecords, record_keys, record_info_size, record_size = [number() for _ in range(4)]
        if nrecords > MAX_BLOCKS or record_keys != nkeys or record_info_size != nrecords * width * 2:
            raise MdictError('记录块索引计数不一致。')
        record_start = stream.tell() + record_info_size
        if record_start + record_size != before['size']:
            raise MdictError('记录区域长度与文件长度不符。')
        raw_start = 0
        file_offset = record_start
        records = []
        for _ in range(nrecords):
            packed, raw_size = number(), number()
            if not 8 <= packed <= MAX_BLOCK or not 0 < raw_size <= MAX_BLOCK:
                raise MdictError('记录块尺寸无效或超过 64 MiB。')
            records.append((source_id, raw_start, raw_size, file_offset, packed))
            raw_start += raw_size
            file_offset += packed
            if len(records) >= 2000:
                db.executemany('INSERT INTO blocks VALUES (?,?,?,?,?)', records)
                records.clear()
                check_cancel(cancelled)
        db.executemany('INSERT INTO blocks VALUES (?,?,?,?,?)', records)
        if file_offset != before['size'] or raw_start > MAX_TOTAL_RAW or previous_offset > raw_start:
            raise MdictError('记录块长度/偏移超出有效范围。')
    check_cancel(cancelled)
    if file_signature(path) != before:
        raise MdictError('词典在导入过程中发生变化，请重新导入。')
    return {**before, 'kind': kind, 'encoding': header.encoding, 'version': header.version,
            'attributes': header.attributes, 'count': count, 'raw_size': raw_start}
