"""Single-page PDF canvas with text-layer selection; no conversion to EPUB/HTML."""
from __future__ import annotations

from dataclasses import replace
from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QImage, QKeySequence, QPainter, QPalette, QPen
from PySide6.QtWidgets import QApplication, QFrame, QMenu, QScrollArea, QWidget

from dictionary_core import valid_query
from pdf_core import (MAX_SELECTION_CHARS, PdfBook, PdfError, PdfMatch, RenderedPage,
                      finite_number, render_scale)

MARGIN = 16
BASE_SCALE = 96 / 72  # At 100%, one PDF inch is 96 logical screen pixels.


class PdfCanvas(QWidget):
    def __init__(self, reader: 'PdfView'):
        super().__init__()
        self.reader = reader
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.IBeamCursor)
        self.anchor: int | None = None

    def paintEvent(self, event):
        view = self.reader
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(view.background))
        if not view.image.isNull():
            target = QRectF(MARGIN, MARGIN, view.logical_width, view.logical_height)
            painter.drawImage(target, view.image)
            painter.setPen(QPen(QColor(view.accent), 1))
            highlight = QColor(view.accent)
            highlight.setAlpha(75)
            painter.setBrush(highlight)
            for box in view.highlight_rects:
                painter.drawRect(box)
        painter.end()

    def mousePressEvent(self, event):
        self.reader.cancel_restore()
        self.setFocus()
        if event.button() == Qt.MouseButton.LeftButton:
            self.anchor = self.reader.hit(event.position())
            self.reader.select(None)
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.MouseButton.LeftButton and self.anchor is not None:
            end = self.reader.hit(event.position())
            if end is not None:
                first, last = sorted((self.anchor, end))
                self.reader.select(PdfMatch(first, min(MAX_SELECTION_CHARS, last - first + 1)))
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.anchor = None
            text = self.reader.selected_text()
            if valid_query(text):
                self.reader.selectionReleased.emit(text)
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton:
            return super().mouseDoubleClickEvent(event)
        index = self.reader.hit(event.position())
        if index is not None:
            try:
                self.reader.select(self.reader.book.word_at(self.reader.page_index, index))
                text = self.reader.selected_text()
                if valid_query(text):
                    self.reader.lookupRequested.emit(text)
            except PdfError as exc:
                self.reader.message.emit(str(exc))
        self.anchor = None
        event.accept()

    def contextMenuEvent(self, event):
        view = self.reader
        if not view.selected_text():
            index = view.hit(QPointF(event.pos()))
            if index is not None:
                try:
                    view.select(view.book.word_at(view.page_index, index))
                except PdfError as exc:
                    view.message.emit(str(exc))
        text = view.selected_text()
        menu = QMenu(self)
        action = menu.addAction("复制所选文字")
        action.setEnabled(bool(text))
        action.triggered.connect(view.copy_selection)
        action = menu.addAction(f"英汉金融词典：{text[:28]}" if valid_query(text) else "请先选中英文单词或短语")
        action.setEnabled(valid_query(text))
        action.triggered.connect(lambda _checked=False: view.lookupRequested.emit(text))
        menu.addSeparator()
        menu.addAction("适合宽度", lambda: view.set_zoom_mode("width"))
        menu.addAction("适合整页", lambda: view.set_zoom_mode("page"))
        menu.exec(event.globalPos())
        menu.deleteLater()

    def keyPressEvent(self, event):
        self.reader.keyPressEvent(event)


class PdfView(QScrollArea):
    pageRequested = Signal(int)
    lookupRequested = Signal(str)
    selectionReleased = Signal(str)
    positionChanged = Signal()
    zoomChanged = Signal()
    message = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("pdfArea")
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setWidgetResizable(False)
        self.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setAcceptDrops(False)
        self.background = "#f6f1e7"
        self.foreground = "#222222"
        self.accent = "#346878"
        self.paper_tint = False
        self.book: PdfBook | None = None
        self.page_index = 0
        self.zoom_mode = "width"
        self.zoom = 1.0
        self.rotation = 0
        self.logical_width = self.logical_height = 1
        self.effective_zoom = 1.0
        self.rendered: RenderedPage | None = None
        self.original_image = QImage()
        self.image = QImage()
        self.selection: PdfMatch | None = None
        self._selected_text = ""
        self.highlight_rects: list[QRectF] = []
        self._selection_boxes = []
        self._rendering = False
        self._pending_scroll: tuple[float, float] | None = None
        self._resize_anchor: tuple[float, float] | None = None
        self.canvas = PdfCanvas(self)
        self.canvas.resize(1, 1)
        self.setWidget(self.canvas)
        self._reflow_timer = QTimer(self)
        self._reflow_timer.setSingleShot(True)
        self._reflow_timer.setInterval(80)
        self._reflow_timer.timeout.connect(self._resize_render)
        self._position_timer = QTimer(self)
        self._position_timer.setSingleShot(True)
        self._position_timer.timeout.connect(self._restore_once)
        self.verticalScrollBar().valueChanged.connect(self._scroll_changed)
        self.horizontalScrollBar().valueChanged.connect(self._scroll_changed)
        self.verticalScrollBar().sliderPressed.connect(self.cancel_restore)
        self.horizontalScrollBar().sliderPressed.connect(self.cancel_restore)

    def clear(self):
        self._reflow_timer.stop()
        self._position_timer.stop()
        self._pending_scroll = self._resize_anchor = None
        self.book = None
        self.rendered = None
        self.image = QImage()
        self.original_image = QImage()
        self.select(None)
        self.canvas.resize(1, 1)
        self.canvas.update()

    def set_book(self, book: PdfBook, index=0, ratio=0.0, horizontal=0.0):
        self._reflow_timer.stop()
        self.cancel_restore()
        self.book = book
        self.show_page(index, ratio, horizontal)

    def show_page(self, index: int, ratio=0.0, horizontal=0.0):
        if self.book is None:
            return
        previous = self.page_index
        self.page_index = index
        try:
            self._render_page(ratio, horizontal)
        except PdfError:
            self.page_index = previous
            raise
        self.select(None)
        self.canvas.setFocus(Qt.FocusReason.OtherFocusReason)

    def current_ratio(self) -> float:
        if self._pending_scroll is not None:
            return self._pending_scroll[0]
        bar = self.verticalScrollBar()
        return bar.value() / bar.maximum() if bar.maximum() > 0 else 0.0

    def horizontal_ratio(self) -> float:
        if self._pending_scroll is not None:
            return self._pending_scroll[1]
        bar = self.horizontalScrollBar()
        return bar.value() / bar.maximum() if bar.maximum() > 0 else 0.0

    def cancel_restore(self):
        self._position_timer.stop()
        self._pending_scroll = None
        # A resize is still allowed, but its anchor must reflect the user's new position.
        self._resize_anchor = None

    def _scroll_changed(self, _value):
        if not self._rendering and self._pending_scroll is None and self._resize_anchor is None:
            self.positionChanged.emit()

    def _restore_once(self):
        target = self._pending_scroll
        if target is None:
            return
        ratio, horizontal = target
        self._rendering = True
        try:
            self.verticalScrollBar().setValue(round(self.verticalScrollBar().maximum() * ratio))
            self.horizontalScrollBar().setValue(round(self.horizontalScrollBar().maximum() * horizontal))
        finally:
            self._pending_scroll = None
            self._rendering = False
        self.positionChanged.emit()

    def scroll_to_top(self):
        self.cancel_restore()
        self.verticalScrollBar().setValue(0)
        self.horizontalScrollBar().setValue(0)
        self.positionChanged.emit()

    def _scale(self):
        width, height = self.book.page_size(self.page_index, self.rotation)
        available_w = max(100, self.viewport().width() - 2 * MARGIN - 2)
        available_h = max(100, self.viewport().height() - 2 * MARGIN - 2)
        scale = self.zoom * BASE_SCALE
        if self.zoom_mode == "width":
            scale = available_w / width
        elif self.zoom_mode == "page":
            scale = min(available_w / width, available_h / height)
        return width, height, render_scale(width, height, max(.001, scale))

    def _render_page(self, ratio=None, horizontal=None):
        if self.book is None:
            return
        ratio = self.current_ratio() if ratio is None else finite_number(ratio, 0, 0, 1)
        horizontal = self.horizontal_ratio() if horizontal is None else finite_number(horizontal, 0, 0, 1)
        width, height, scale = self._scale()
        dpr = max(1.0, self.devicePixelRatioF())
        rendered = self.book.render(self.page_index, scale * dpr, self.rotation)
        # Detach QImage from Python/native bytes before the next native page is loaded.
        image = QImage(rendered.pixels, rendered.width, rendered.height, rendered.stride,
                       QImage.Format.Format_RGBA8888).copy()
        if image.isNull():
            raise PdfError("无法创建 PDF 页面图像，请降低缩放。")
        self._rendering = True
        try:
            self.logical_width = max(1, round(width * scale))
            self.logical_height = max(1, round(height * scale))
            self.effective_zoom = scale / BASE_SCALE
            self.rendered = replace(rendered, pixels=b"")
            self.original_image = image
            self._recolor()
            self._update_highlights()
            self._pending_scroll = ratio, horizontal
            self.canvas.setFixedSize(self.logical_width + 2 * MARGIN, self.logical_height + 2 * MARGIN)
            # Opening at top must stay at top even before the deferred geometry settles.
            if ratio == 0:
                self.verticalScrollBar().setValue(0)
            if horizontal == 0:
                self.horizontalScrollBar().setValue(0)
            self._position_timer.start(0)
        finally:
            self._rendering = False
        self.zoomChanged.emit()
        self.canvas.update()
        if rendered.limited:
            self.message.emit("本页分辨率已受内存保护限制；放大可能略模糊。")

    def resizeEvent(self, event):
        if self.book is not None and self._resize_anchor is None:
            self._resize_anchor = self.current_ratio(), self.horizontal_ratio()
        super().resizeEvent(event)
        if self.book is not None and self.zoom_mode in {"width", "page"}:
            self._reflow_timer.start()
        else:
            self._resize_anchor = None

    def _resize_render(self):
        target = self._resize_anchor or (self.current_ratio(), self.horizontal_ratio())
        self._resize_anchor = None
        if self.book is not None:
            try:
                self._render_page(*target)
            except PdfError as exc:
                self.message.emit(str(exc))

    def set_zoom_mode(self, mode: str):
        if mode not in {"width", "page", "custom"}:
            return
        previous = self.zoom_mode
        self.zoom_mode = mode
        try:
            self._render_page()
        except PdfError as exc:
            self.zoom_mode = previous
            self.message.emit(str(exc))

    def set_zoom(self, value: float):
        previous = self.zoom, self.zoom_mode
        self.zoom = finite_number(value, 1, .25, 4)
        self.zoom_mode = "custom"
        try:
            self._render_page()
        except PdfError as exc:
            self.zoom, self.zoom_mode = previous
            self.message.emit(str(exc))

    def rotate(self):
        previous = self.rotation
        self.rotation = (self.rotation + 90) % 360
        try:
            self._render_page(0, 0)
        except PdfError as exc:
            self.rotation = previous
            self.message.emit(str(exc))

    def set_colors(self, background: str, foreground: str, accent: str, paper_tint: bool):
        self.background, self.foreground, self.accent = background, foreground, accent
        self.paper_tint = paper_tint
        palette = self.palette()
        palette.setColor(QPalette.ColorRole.Window, QColor(background))
        palette.setColor(QPalette.ColorRole.Base, QColor(background))
        self.setPalette(palette)
        self.viewport().setPalette(palette)
        self.viewport().setAutoFillBackground(True)
        self.setStyleSheet(f"QScrollArea#pdfArea {{ background: {background}; border: none; }}")
        self._recolor()
        self.canvas.update()

    def _recolor(self):
        self.image = self.original_image.copy() if self.paper_tint else self.original_image
        if not self.paper_tint or self.image.isNull():
            return
        bg = QColor(self.background)
        # This is a display filter, not a rewrite of PDF objects. Images are affected too.
        dark = QColor(self.foreground).lightnessF() > .9
        if dark:
            self.image.invertPixels(QImage.InvertMode.InvertRgb)
        painter = QPainter(self.image)
        painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_Screen if dark
                                   else QPainter.CompositionMode.CompositionMode_Multiply)
        painter.fillRect(self.image.rect(), bg)
        painter.end()

    def hit(self, point: QPointF) -> int | None:
        if self.book is None or not self.book.can_extract or self.rendered is None:
            return None
        x, y = point.x() - MARGIN, point.y() - MARGIN
        if not (0 <= x < self.logical_width and 0 <= y < self.logical_height):
            return None
        try:
            return self.book.hit_test(self.page_index, self.rendered,
                                      x * self.rendered.width / self.logical_width,
                                      y * self.rendered.height / self.logical_height)
        except PdfError as exc:
            self.message.emit(str(exc))
            return None

    def select(self, match: PdfMatch | None):
        self.selection = match
        self._selected_text = ""
        self._selection_boxes = []
        if match is not None and self.book is not None:
            try:
                self._selected_text = self.book.text(self.page_index, match.start, match.count).strip()
                self._selection_boxes = self.book.selection_boxes(self.page_index, match.start, match.count)
            except PdfError as exc:
                self.selection = None
                self.message.emit(str(exc))
        self._update_highlights()
        self.canvas.update()

    def _update_highlights(self):
        self.highlight_rects = []
        if self.book is None or self.rendered is None:
            return
        sx, sy = self.logical_width / self.rendered.width, self.logical_height / self.rendered.height
        for left, bottom, right, top in self._selection_boxes:
            points = [self.book.page_to_device(self.page_index, self.rendered, x, y)
                      for x, y in ((left, bottom), (right, bottom), (right, top), (left, top))]
            xs, ys = [p[0] * sx + MARGIN for p in points], [p[1] * sy + MARGIN for p in points]
            self.highlight_rects.append(QRectF(min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)))

    def selected_text(self) -> str:
        return self._selected_text

    def selected_context(self) -> str:
        if self.book is None or self.selection is None:
            return ""
        try:
            return self.book.context(self.page_index, self.selection.start, self.selection.count)
        except PdfError:
            return ""

    def copy_selection(self):
        if self.book is not None and self.book.can_extract and self.selected_text():
            QApplication.clipboard().setText(self.selected_text())

    def reveal_selection(self):
        self.cancel_restore()
        if self.highlight_rects:
            rect = self.highlight_rects[0]
            self.ensureVisible(round(rect.center().x()), round(rect.center().y()), 40, 80)

    def turn_screen(self, direction: int):
        if self.book is None:
            return
        self.cancel_restore()
        bar = self.verticalScrollBar()
        edge = bar.value() >= bar.maximum() - 2 if direction > 0 else bar.value() <= 2
        if edge:
            self.pageRequested.emit(direction)
        else:
            bar.setValue(bar.value() + direction * max(40, round(self.viewport().height() * .88)))

    def keyPressEvent(self, event):
        self.cancel_restore()
        if event.matches(QKeySequence.StandardKey.Copy):
            self.copy_selection()
            event.accept()
            return
        key, modifiers = event.key(), event.modifiers()
        plain = modifiers == Qt.KeyboardModifier.NoModifier
        if plain and key in {Qt.Key.Key_Right, Qt.Key.Key_PageDown, Qt.Key.Key_Space}:
            self.turn_screen(1)
        elif (plain and key in {Qt.Key.Key_Left, Qt.Key.Key_PageUp}) or (
                modifiers == Qt.KeyboardModifier.ShiftModifier and key == Qt.Key.Key_Space):
            self.turn_screen(-1)
        elif plain and key == Qt.Key.Key_Escape:
            self.select(None)
        else:
            return super().keyPressEvent(event)
        event.accept()

    def wheelEvent(self, event):
        self.cancel_restore()
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.set_zoom(self.effective_zoom * (1.15 if event.angleDelta().y() > 0 else 1 / 1.15))
            event.accept()
        else:
            # Wheel scrolls only within the current page: no accidental page cascade on opening.
            super().wheelEvent(event)
