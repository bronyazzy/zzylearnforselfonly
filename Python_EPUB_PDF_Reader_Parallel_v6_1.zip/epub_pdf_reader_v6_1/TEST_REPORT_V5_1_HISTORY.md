# 测试记录 · 墨读 5.1 · Windows 词典导入修复

日期：2026-09-20。只把实际运行并通过的测试计为通过；平台模拟、后端测试与原生桌面验证分别列出。
旧版详细报告保存为 `TEST_REPORT_V5_HISTORY.md`，不是本次结果。

## 本次环境与结果

Linux，Python 3.13.5，SQLite 3.46.1，defusedxml 可用；pypdfium2 5.8.0 / PDFium 149.0.7825.0 可用。
PySide6 不可用。尝试安装 Essentials / Addons 的结果是当前可访问的包来源未返回匹配发行包
（`No matching distribution found`），见 `diagnostics/QT_INSTALL.txt`。
这不表示 PySide6 普遍不支持相应 Python 版本，只说明本执行环境未取得它。
没有启动 Qt 窗口，没有 Windows / macOS 机器或实际用户 MDX/MDD。

```bash
python -m unittest discover -s tests -v
```

```text
Ran 379 tests
OK (skipped=79)
```

**300 项实际通过，79 项 Qt GUI 测试跳过，0 项失败，0 项错误。不是 379 项全部通过。**
完整原始输出在 `TEST_OUTPUT.txt`。

| 模块 | 数量 | 本次结果 |
| --- | ---: | --- |
| test_core.py | 30 | 通过 |
| test_dictionary.py | 47 | 通过 |
| test_images.py | 36 | 通过 |
| test_settings.py | 11 | 通过 |
| test_reader_control.py | 8 | 通过：控制逻辑替身，不是 Qt 实测 |
| test_pdf.py | 46 | 通过：真实 PDFium 后端 |
| test_mdict.py | 96 | 通过：MDX/MDD 夹具、索引与资源 |
| test_import_io.py | 26 | 通过：本次新增文件句柄与诊断测试 |
| test_gui.py | 6 | 缺少 Qt，跳过 |
| test_dictionary_gui.py | 12 | 缺少 Qt，跳过 |
| test_reader_v3_gui.py | 18 | 缺少 Qt，跳过 |
| test_pdf_gui.py | 26 | 缺少 Qt，跳过 |
| test_mdict_gui.py | 17 | 缺少 Qt，跳过 |

## 原错误怎样复现

在修改源码前，对原 5.0 包进行真实 MDX/MDD、CSV 导入；测试在 Python 的 `os.fsync` 入口加入
“文件句柄须可写”的 Windows 风格检查。文件打开、二进制解析、SQLite 写入仍使用真实实现。
旧版两处均在 `rb` 打开的临时索引同步时触发 `[Errno 9] Bad file descriptor`，其中 MDX 的
最终异常为 `词典导入失败：[Errno 9] Bad file descriptor`，与截图文字相同。
原始记录在 `diagnostics/V50_REPRODUCTION.txt`。

**这是 Linux 上的可写句柄规则故障注入，不是原生 Windows 运行，也不是用户词典的实测。**
文件名、分卷和内容使用项目自带示例；截图没有完整调用栈，不能排除用户还有其他导入问题。

## 26 项新增验证覆盖

18 项文件句柄 / 导入测试：

- 模拟规则拒绝只读或已关闭句柄；接受真实的 `r+b` 句柄，并实际调用本机 `os.fsync`。
- MDX 无 MDD、MDX + 主 MDD + 数字分卷可导入，中文路径、中文释义、重定向和资源字节正常。
- 导入前后原 MDX/MDD/CSV 字节摘要不变；源文件保持只读访问，原只读属性不被改成可写。
- 临时 SQLite 同步后完整性检查为 `ok`；真实文件句柄在发布重命名前已关闭。
- 在真实 Python 工作线程中建索引，再在主线程登记和查词；没有跨线程使用工作连接。
- 已有词典重复导入仍只保留一个清单项；旧连接关闭后旧索引删除。
- 索引同步失败、清单写入失败不会覆盖原有可用词库；磁盘错误仍向调用方传播。
- 同步期间提出的取消在发布前被再次检查；MDX 与 CSV 的旧数据保持不变。
- MDX 发出验证 / 同步阶段提示；CSV 导入后原内置金融词条仍可查询。

8 项诊断测试：异常原因链、阶段和版本；日志目录创建失败、打开失败均不掩盖原错误；
多次追加、大小阈值轮转、长异常限制、并行写入，以及不读取词典正文来生成日志。
新增单独输出见 `diagnostics/IMPORT_IO_TEST_OUTPUT.txt`。

## 代码与交付检查

37 个 Python 文件通过语法编译和 Python 3.10 语法级 AST 检查；不等同于在 Python 3.10 解释器上运行。
`start_macos_linux.sh` 通过 `sh -n`；Windows 启动脚本没有实机运行。
5.1 相对 5.0 无新增依赖，原 EPUB/PDF 示例、金融词库和用户数据格式未改动。

完整 ZIP 执行 CRC 检查；在独立目录重新解压后，使用 `verify_package.py` 按 MANIFEST.json
逐文件核对 SHA-256，并重新运行全部 379 项测试，结果同为 300 通过、79 跳过。
这些摘要用于损坏检查，不是数字签名。包内不含 `.venv`、缓存、用户阅读记录或字体文件。

## 尚未验证

没有 Windows CRT/NTFS 实机测试，没有用户具体词典或多 GB 词典导入性能测试。
79 项 GUI 测试仍未运行：不能声称桌面排版、鼠标操作、音频设备或新错误弹窗已经实测通过。
诊断函数有独立测试，但 Qt 工作线程信号 / 弹窗的实际呈现仍需本机运行确认。
原有格式边界不变：不支持 MDict 3.x、注册 / 设备绑定解锁、JavaScript 交互或完整浏览器版式。
本修复不是对所有名为 .mdx/.mdd 的文件作兼容性承诺。

## 本机复查

```bash
python -m unittest discover -s tests -p "test_import_io.py" -v
python -m unittest discover -s tests -v
python verify_package.py
python epub_reader.py
```

在「MDX 词典」导入 `examples/mdict_demo/FinanceDemo.mdx`，再重试之前失败的词典。
若仍失败，按弹窗里的绝对路径查看 `dictionary_import.log`；分享前可以遮去私有路径。
无需为了本次修复删除 `state.json`、`vocabulary.json`、CSV 词库或既有 MDX 索引。
