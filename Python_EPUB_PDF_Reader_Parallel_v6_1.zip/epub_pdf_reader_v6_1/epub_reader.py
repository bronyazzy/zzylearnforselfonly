#!/usr/bin/env python3
"""墨读: local EPUB / PDF reader. Run: python epub_reader.py [book.epub|book.pdf]."""
from __future__ import annotations

import argparse
import math
from pathlib import Path
import sys

try:
    from PySide6.QtCore import (
        QByteArray, QPoint, QStandardPaths, Qt, QTimer, QUrl, Signal,
    )
    from PySide6.QtGui import (
        QAction, QColor, QDesktopServices, QFont, QFontDatabase, QImageReader,
        QKeySequence, QPalette, QTextCursor, QTextDocument,
    )
    from PySide6.QtWidgets import (
        QApplication, QColorDialog, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit,
        QListWidget, QListWidgetItem, QMainWindow, QMenu, QMessageBox, QPushButton,
        QSplitter, QTabWidget, QTextBrowser, QToolBar, QTreeWidget, QTreeWidgetItem,
        QVBoxLayout, QWidget,
    )
    from shiboken6 import isValid
    from epub_core import EpubBook, EpubError, StateStore, TocEntry, walk_toc
    from image_ui import ChapterImages
    from reader_settings import (PRESET_BACKGROUNDS, DEFAULT_BACKGROUND, NIGHT_BACKGROUND,
                                 ViewPosition, normalize_background, theme_colors)
    from dictionary_core import DictionaryError, valid_query
    from dictionary_ui import DictionaryDock
except ImportError as exc:
    print(f"缺少依赖：{exc}\n请在项目目录执行：python -m pip install -r requirements.txt", file=sys.stderr)
    raise SystemExit(1)


def ratio_value(value, default: float = 0.0) -> float:
    try:
        number = float(value)
        return min(1.0, max(0.0, number)) if math.isfinite(number) else default
    except (ValueError, TypeError, OverflowError):
        return default


def encoded_url(url: QUrl) -> str:
    return bytes(url.toEncoded()).decode("ascii")


def choose_font(candidates: list[str], fallback: str) -> str:
    available = set(QFontDatabase.families())
    return next((name for name in candidates if name in available), fallback)


class BookBrowser(QTextBrowser):
    pageRequested = Signal(int)
    widthChanged = Signal()
    widthAboutToChange = Signal()
    userInteracted = Signal()
    lookupRequested = Signal(str)
    selectionReleased = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.book: EpubBook | None = None
        self.current_path = ""
        self.image_width = 900
        self.resource_warnings: set[str] = set()
        self.images: ChapterImages | None = None
        self.setOpenLinks(False)
        self.setOpenExternalLinks(False)
        self.setAcceptDrops(False)
        self.setReadOnly(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        # A stable column width avoids scrollbar visibility / relayout feedback.
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)

    def loadResource(self, resource_type: int, name: QUrl):
        # Never use QTextBrowser's default file/network loader.
        if (self.book is None or self.images is None
                or resource_type != QTextDocument.ResourceType.ImageResource.value):
            return QByteArray()
        if name.scheme() not in {"", "epub", "epubimg"}:
            return QByteArray()
        image = self.images.resource(encoded_url(name), self.image_width)
        self.resource_warnings.update(self.images.warnings)
        return image

    def mousePressEvent(self, event):
        self.userInteracted.emit()
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):
        super().mouseDoubleClickEvent(event)
        if event.button() == Qt.MouseButton.LeftButton:
            text = self.textCursor().selectedText().replace("\u2029", " ").strip()
            if valid_query(text):
                # Defer opening the dock until Qt has finalized text selection.
                QTimer.singleShot(0, lambda word=text: self.lookupRequested.emit(word))

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        if event.button() == Qt.MouseButton.LeftButton:
            text = self.textCursor().selectedText().replace("\u2029", " ").strip()
            if valid_query(text):
                QTimer.singleShot(0, lambda word=text: self.selectionReleased.emit(word))

    def contextMenuEvent(self, event):
        text = self.textCursor().selectedText().replace("\u2029", " ").strip()
        if not text:
            cursor = self.cursorForPosition(event.pos())
            cursor.select(QTextCursor.SelectionType.WordUnderCursor)
            self.setTextCursor(cursor)
            text = cursor.selectedText().strip()
        menu = self.createStandardContextMenu()
        menu.addSeparator()
        action = menu.addAction(f"英汉金融词典：{text[:28]}" if valid_query(text) else "请先选中英文单词或短语")
        action.setEnabled(valid_query(text))
        action.triggered.connect(lambda _checked=False, word=text: self.lookupRequested.emit(word))
        menu.exec(event.globalPos())
        menu.deleteLater()

    def keyPressEvent(self, event):
        self.userInteracted.emit()
        modifiers = event.modifiers()
        plain = modifiers == Qt.KeyboardModifier.NoModifier
        shift = modifiers == Qt.KeyboardModifier.ShiftModifier
        key = event.key()
        if plain and key in {Qt.Key.Key_PageDown, Qt.Key.Key_Right, Qt.Key.Key_Space}:
            self.pageRequested.emit(1)
            event.accept()
        elif (plain and key in {Qt.Key.Key_PageUp, Qt.Key.Key_Left}) or (shift and key == Qt.Key.Key_Space):
            self.pageRequested.emit(-1)
            event.accept()
        else:
            super().keyPressEvent(event)

    def wheelEvent(self, event):
        self.userInteracted.emit()
        # Keep the font-size control authoritative; do not silently zoom with Ctrl+wheel.
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            event.ignore()
        else:
            super().wheelEvent(event)

    def resizeEvent(self, event):
        old_width = event.oldSize().width()
        if old_width != event.size().width():
            self.widthAboutToChange.emit()
        super().resizeEvent(event)
        if old_width != event.size().width():
            self.widthChanged.emit()


class BookDocument(QTextDocument):
    """Route resource requests directly to our allowlisted in-memory loader."""

    def __init__(self, browser: BookBrowser):
        super().__init__(browser)
        self.browser = browser

    def loadResource(self, resource_type: int, name: QUrl):
        return self.browser.loadResource(resource_type, name)


class ReaderWindow(QMainWindow):
    def __init__(self, state: StateStore):
        super().__init__()
        self.store = state
        self.book: EpubBook | None = None
        self.current_path = ""
        self.chapter_index = 0
        self.history: list[tuple[str, float]] = []
        self.bookmarks: list[dict] = []
        self._loading = False
        self._generation = 0
        self._ready_ratio = 0.0
        self._cached_html = ""
        self._save_error_shown = False
        self._reflow_anchor: ViewPosition | None = None
        self._pending_target = None
        preferences = self.store.data["preferences"]
        try:
            self.font_size = min(36, max(12, int(preferences.get("font_size", 18))))
        except (ValueError, TypeError, OverflowError):
            self.font_size = 18
        self.night = preferences.get("night", False) is True
        default_background = NIGHT_BACKGROUND if self.night else DEFAULT_BACKGROUND
        self.background = normalize_background(preferences.get("background_color"), default_background)
        self.day_background = normalize_background(preferences.get("day_background"), DEFAULT_BACKGROUND)
        self.night = theme_colors(self.background)[2] == "#ffffff"
        # Explicit opt-in prevents old unintended scroll positions from reopening halfway down.
        self.restore_position = preferences.get("restore_position", False) is True
        self.reading_font = choose_font(
            ["Noto Serif CJK SC", "Source Han Serif SC", "Songti SC", "SimSun", "Noto Sans CJK SC"],
            QApplication.font().family(),
        )
        self.setWindowTitle("墨读 · EPUB 金融英语阅读器 6.0")
        self.resize(1460, 860)
        self.setMinimumSize(980, 580)
        self.setAcceptDrops(True)
        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(800)
        self._save_timer.timeout.connect(self.save_state)
        self._resize_timer = QTimer(self)
        self._resize_timer.setSingleShot(True)
        self._resize_timer.setInterval(80)
        self._resize_timer.timeout.connect(self.reflow)
        self._restore_timer = QTimer(self)
        self._restore_timer.setSingleShot(True)
        self._restore_timer.timeout.connect(self._finish_restore)
        self._build_ui()
        self.apply_theme()
        self.show_welcome()
        self.update_controls()
        if state.warning:
            self.statusBar().showMessage(state.warning, 12000)

    def _action(self, text, callback, shortcut=None, checkable=False):
        action = QAction(text, self)
        action.setCheckable(checkable)
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
        action.triggered.connect(callback)
        self.addAction(action)
        return action

    def _build_ui(self):
        toolbar = QToolBar("阅读工具", self)
        toolbar.setMovable(False)
        toolbar.setObjectName("readerToolbar")
        self.addToolBar(toolbar)
        toolbar.addAction(self._action("打开书籍", self.choose_book, "Ctrl+O"))
        recent_action = QAction("最近阅读", self)
        self.recent_menu = QMenu(self)
        self.recent_menu.aboutToShow.connect(self.build_recent_menu)
        recent_action.setMenu(self.recent_menu)
        toolbar.addAction(recent_action)
        toolbar.addSeparator()
        self.prev_action = self._action("上一章", lambda: self.change_chapter(-1), "Alt+Left")
        self.next_action = self._action("下一章", lambda: self.change_chapter(1), "Alt+Right")
        self.back_action = self._action("返回", self.go_back, "Alt+Up")
        for action in (self.prev_action, self.next_action, self.back_action):
            toolbar.addAction(action)
        toolbar.addSeparator()
        toolbar.addAction(self._action("A−", lambda: self.change_font(-1), "Ctrl+-"))
        self.font_label = QLabel()
        self.font_label.setMinimumWidth(45)
        self.font_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        toolbar.addWidget(self.font_label)
        toolbar.addAction(self._action("A+", lambda: self.change_font(1), "Ctrl+="))
        self._action("放大字号", lambda: self.change_font(1), "Ctrl++")
        toolbar.addSeparator()
        self.night_action = self._action("夜间模式", self.toggle_night, "Ctrl+D", checkable=True)
        self.night_action.setChecked(self.night)
        toolbar.addAction(self.night_action)
        self.background_menu = QMenu("背景颜色", self)
        for name, color in PRESET_BACKGROUNDS:
            action = self.background_menu.addAction(name)
            action.triggered.connect(lambda _checked=False, c=color: self.set_background(c))
        self.background_menu.addSeparator()
        self.background_menu.addAction("自定义颜色…", self.choose_background)
        self.background_menu.addAction("恢复默认背景", lambda: self.set_background(DEFAULT_BACKGROUND))
        self.background_action = QAction("背景颜色", self)
        self.background_action.setMenu(self.background_menu)
        toolbar.addAction(self.background_action)
        self._action("自定义背景颜色", self.choose_background, "Ctrl+Shift+C")
        self.bookmark_action = self._action("添加书签", self.add_bookmark, "Ctrl+B")
        toolbar.addAction(self.bookmark_action)
        self.sidebar_action = self._action("目录", self.toggle_sidebar, "Ctrl+L", checkable=True)
        self.sidebar_action.setChecked(True)
        toolbar.addAction(self.sidebar_action)
        reading_menu = self.menuBar().addMenu("阅读")
        self.resume_action = self._action("打开时恢复上次阅读位置", self.toggle_restore_position, checkable=True)
        self.resume_action.setChecked(self.restore_position)
        reading_menu.addAction(self.resume_action)
        reading_menu.addAction(self._action("回到本章开头", self.go_to_chapter_start, "Ctrl+Home"))
        reading_menu.addAction(self._action("从全书开头阅读", self.restart_book))
        self.menuBar().addMenu(self.background_menu)

        self.splitter = QSplitter(Qt.Orientation.Horizontal, self)
        self.sidebar = QWidget()
        self.sidebar.setMinimumWidth(200)
        self.sidebar.setMaximumWidth(460)
        sidebar_layout = QVBoxLayout(self.sidebar)
        sidebar_layout.setContentsMargins(18, 20, 12, 12)
        self.book_title = QLabel("墨读")
        self.book_title.setTextFormat(Qt.TextFormat.PlainText)
        self.book_title.setWordWrap(True)
        self.book_title.setObjectName("bookTitle")
        self.book_author = QLabel("让阅读回到文字本身")
        self.book_author.setTextFormat(Qt.TextFormat.PlainText)
        self.book_author.setWordWrap(True)
        self.book_author.setObjectName("mutedLabel")
        sidebar_layout.addWidget(self.book_title)
        sidebar_layout.addWidget(self.book_author)
        self.tabs = QTabWidget()
        self.toc_tree = QTreeWidget()
        self.toc_tree.setHeaderHidden(True)
        self.toc_tree.setWordWrap(True)
        self.toc_tree.itemClicked.connect(self.toc_activated)
        self.toc_tree.itemActivated.connect(self.toc_activated)
        self.tabs.addTab(self.toc_tree, "目录")
        bookmark_page = QWidget()
        bookmark_layout = QVBoxLayout(bookmark_page)
        bookmark_layout.setContentsMargins(0, 0, 0, 0)
        self.bookmark_list = QListWidget()
        self.bookmark_list.setWordWrap(True)
        self.bookmark_list.itemActivated.connect(self.open_bookmark)
        self.bookmark_list.itemClicked.connect(self.open_bookmark)
        bookmark_layout.addWidget(self.bookmark_list)
        delete_button = QPushButton("删除所选书签")
        delete_button.clicked.connect(self.delete_bookmark)
        bookmark_layout.addWidget(delete_button)
        self.tabs.addTab(bookmark_page, "书签")
        sidebar_layout.addWidget(self.tabs, 1)
        self.splitter.addWidget(self.sidebar)

        reading_panel = QWidget()
        layout = QVBoxLayout(reading_panel)
        layout.setContentsMargins(0, 0, 0, 0)
        header = QWidget()
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(24, 12, 20, 12)
        self.chapter_label = QLabel("开始阅读")
        self.chapter_label.setTextFormat(Qt.TextFormat.PlainText)
        self.chapter_label.setWordWrap(True)
        header_layout.addWidget(self.chapter_label, 1)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("搜索当前章节…")
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.setMaximumWidth(230)
        self.search_edit.returnPressed.connect(lambda: self.find_text(False))
        header_layout.addWidget(self.search_edit)
        for label, backward in (("上一个", True), ("下一个", False)):
            button = QPushButton(label)
            button.clicked.connect(lambda _checked=False, b=backward: self.find_text(b))
            header_layout.addWidget(button)
        layout.addWidget(header)
        self.browser = BookBrowser()
        self.browser.setObjectName("readingArea")
        self.browser.anchorClicked.connect(self.link_activated)
        self.browser.pageRequested.connect(self.turn_page)
        self.browser.widthAboutToChange.connect(self.remember_view_before_resize)
        self.browser.widthChanged.connect(self.schedule_reflow)
        self.browser.userInteracted.connect(self.cancel_pending_position)
        self.browser.verticalScrollBar().sliderPressed.connect(self.cancel_pending_position)
        self.browser.verticalScrollBar().valueChanged.connect(self.scrolled)
        layout.addWidget(self.browser, 1)
        self.splitter.addWidget(reading_panel)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setSizes([260, 920])
        self.setCentralWidget(self.splitter)
        self.progress_label = QLabel("尚未打开书籍")
        self.statusBar().addPermanentWidget(self.progress_label)
        self._action("搜索", self.focus_search, "Ctrl+F")
        self._action("下一个匹配", lambda: self.find_text(False), "F3")
        self._action("上一个匹配", lambda: self.find_text(True), "Shift+F3")
        self._action("退出", self.close, "Ctrl+Q")

        self.dictionary_dock = None
        try:
            self.dictionary_dock = DictionaryDock(self.store.filename.parent, self.store.data["preferences"], self)
            self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dictionary_dock)
            self.resizeDocks([self.dictionary_dock], [390], Qt.Orientation.Horizontal)
            self.dictionary_dock.setVisible(self.store.data["preferences"].get("dictionary_visible", True) is True)
            toggle_dictionary = self.dictionary_dock.toggleViewAction()
            toggle_dictionary.setText("词典")
            toggle_dictionary.setShortcut(QKeySequence("Ctrl+J"))
            self.addAction(toggle_dictionary)
            toolbar.addSeparator()
            toolbar.addAction(toggle_dictionary)
            toolbar.addAction(self._action("查所选词", self.lookup_selection, "Ctrl+E"))
            self.browser.lookupRequested.connect(self.lookup_text)
            self.browser.selectionReleased.connect(self.lookup_automatic)
        except DictionaryError as exc:
            self.statusBar().showMessage(str(exc), 30000)

    def lookup_selection(self):
        text = self.browser.textCursor().selectedText().replace("\u2029", " ").strip()
        if valid_query(text):
            self.lookup_text(text)
        elif self.dictionary_dock is not None:
            self.dictionary_dock.show()
            self.dictionary_dock.query_edit.setFocus()
            self.dictionary_dock.query_edit.selectAll()

    def lookup_automatic(self, text: str):
        if self.dictionary_dock is not None and self.dictionary_dock.auto_check.isChecked():
            self.lookup_text(text)

    def lookup_text(self, text: str):
        if self.dictionary_dock is None or not valid_query(text):
            return
        context = self.browser.textCursor().block().text()[:1000] if self.book else ""
        title = self.book.title if self.book else ""
        self.dictionary_dock.show()
        self.dictionary_dock.raise_()
        self.dictionary_dock.lookup(text, context, title)
        # Preserve reading keyboard controls after opening the dictionary dock.
        self.browser.setFocus(Qt.FocusReason.OtherFocusReason)


    def apply_theme(self):
        bg, panel, fg, muted, border, accent = theme_colors(self.background)
        self._colors = bg, panel, fg, muted, border, accent
        self.setStyleSheet(f"""
            QMainWindow, QWidget {{ background: {panel}; color: {fg}; }}
            QToolBar {{ border: none; border-bottom: 1px solid {border}; padding: 8px; spacing: 5px; }}
            QToolButton, QPushButton {{ padding: 7px 10px; border: 1px solid transparent; border-radius: 5px; }}
            QToolButton:hover, QPushButton:hover {{ border-color: {accent}; }}
            QToolButton:checked {{ background: {bg}; border-color: {accent}; }}
            QToolButton:disabled, QPushButton:disabled {{ color: {muted}; }}
            QLineEdit {{ background: {bg}; border: 1px solid {border}; border-radius: 6px; padding: 7px; }}
            QTextBrowser#readingArea, QTextBrowser#dictionaryResults {{ background: {bg}; color: {fg}; border: none; selection-background-color: {accent}; }}
            QTreeWidget, QListWidget {{ background: {panel}; border: none; outline: none; }}
            QTreeWidget::item, QListWidget::item {{ padding: 8px 4px; }}
            QTreeWidget::item:selected, QListWidget::item:selected {{ background: {accent}; color: {bg}; }}
            QTabWidget::pane {{ border: none; }}
            QTabBar::tab {{ padding: 10px 18px; border-bottom: 2px solid transparent; }}
            QTabBar::tab:selected {{ border-bottom-color: {accent}; }}
            QLabel#bookTitle {{ font-size: 20px; font-weight: 600; padding-bottom: 6px; }}
            QLabel#mutedLabel {{ color: {muted}; padding-bottom: 12px; }}
            QDockWidget::title {{ padding: 8px; background: {panel}; color: {fg}; }}
            QLabel#dictionaryHint {{ color: {muted}; font-size: 11px; }}
            QStatusBar {{ border-top: 1px solid {border}; padding: 4px; }}
            QMenu {{ border: 1px solid {border}; }}
            QMenu::item {{ padding: 8px 18px; }}
            QMenu::item:selected {{ background: {accent}; color: {bg}; }}
            QSplitter::handle {{ background: {border}; width: 1px; }}
        """)
        palette = self.browser.palette()
        palette.setColor(QPalette.ColorRole.Base, QColor(bg))
        palette.setColor(QPalette.ColorRole.Text, QColor(fg))
        palette.setColor(QPalette.ColorRole.Link, QColor(accent))
        palette.setColor(QPalette.ColorRole.Window, QColor(bg))
        self.browser.setPalette(palette)
        self.browser.viewport().setPalette(palette)
        self.browser.viewport().setAutoFillBackground(True)
        self.night_action.setChecked(self.night)
        self.font_label.setText(f"{self.font_size} pt")
        if self.dictionary_dock is not None:
            self.dictionary_dock.set_night(self.night)

    def document_css(self):
        bg, panel, fg, _muted, _border, accent = self._colors
        n = self.font_size
        return f"""
            body {{ color: {fg}; background-color: {bg}; font-size: {n}pt; }}
            p, div {{ margin-top: 10px; margin-bottom: 12px; line-height: 155%; }}
            h1 {{ font-size: {n * 1.6}pt; margin-top: 18px; margin-bottom: 24px; }}
            h2 {{ font-size: {n * 1.35}pt; margin-top: 18px; margin-bottom: 16px; }}
            h3 {{ font-size: {n * 1.15}pt; }}
            a {{ color: {accent}; text-decoration: underline; }}
            blockquote {{ margin-left: 24px; margin-right: 20px; }}
            pre, code {{ background-color: {panel}; }}
            td, th {{ padding: 8px; }}
        """

    def show_welcome(self):
        document = self.browser.document()
        document.setDefaultFont(QFont(self.reading_font, self.font_size))
        document.setDocumentMargin(42)
        document.setDefaultStyleSheet(self.document_css())
        self.browser.setHtml("""<html><body><h1>墨读</h1><p>打开一本书，回到文字本身。</p>
            <p>点击左上角「打开书籍」，或将 EPUB 文件拖入窗口。</p>
            <p>← / → 按屏翻页　·　Alt + ← / → 切换章节<br />
            Ctrl + F 章节内搜索　·　Ctrl + B 添加书签</p>
            <p><b>金融英语查词</b>：双击英文，或选中短语后按 Ctrl + E。<br/>
            试试 leverage、equity、duration、cash flow、ETF。<br/>
            Ctrl + J 显示/隐藏右侧词典。内置词库离线可用。</p>
            <p>项目内附 finance_demo.epub 和 image_test.epub，可通过「打开书籍」阅读。</p>
            <p>「背景颜色」可选预设或自定义颜色（Ctrl + Shift + C）。<br/>
            默认打开时停在所记章节开头；在「阅读」菜单中可开启恢复上次位置。</p>
            <p>支持未加密 EPUB 的简化阅读排版。阅读进度与生词本保存在本机。</p></body></html>""")

    def choose_book(self):
        filename, _ = QFileDialog.getOpenFileName(self, "打开 EPUB", str(Path.home()), "EPUB 电子书 (*.epub);;所有文件 (*)")
        if filename:
            self.open_book(filename)

    def build_recent_menu(self):
        self.recent_menu.clear()
        for filename in self.store.data["recent"][:10]:
            if not isinstance(filename, str):
                continue
            action = self.recent_menu.addAction(Path(filename).name)
            action.setToolTip(filename)
            action.triggered.connect(lambda _checked=False, name=filename: self.open_book(name))
        if self.recent_menu.isEmpty():
            self.recent_menu.addAction("暂无最近阅读").setEnabled(False)

    def open_book(self, filename: str) -> bool:
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        new_book = None
        try:
            new_book = EpubBook(filename)
            record = self.store.data["books"].get(new_book.book_id, {})
            if not isinstance(record, dict):
                record = {}
            path = record.get("path")
            if not isinstance(path, str) or not new_book.is_document(path):
                path = new_book.chapters[0].path
            initial_html = new_book.chapter_html(path)
        except (EpubError, OSError) as exc:
            if new_book is not None:
                new_book.close()
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "无法打开书籍", str(exc))
            return False
        except Exception:
            if new_book is not None:
                new_book.close()
            QApplication.restoreOverrideCursor()
            raise
        QApplication.restoreOverrideCursor()
        self._save_timer.stop()
        self._resize_timer.stop()
        self._restore_timer.stop()
        self.save_state()
        if self.book is not None:
            self.book.close()
        self._generation += 1
        self.book = new_book
        self.browser.book = new_book
        self.current_path = ""
        self.history.clear()
        raw_bookmarks = record.get("bookmarks", [])
        self.bookmarks = []
        if isinstance(raw_bookmarks, list):
            for mark in raw_bookmarks[:200]:
                if isinstance(mark, dict) and isinstance(mark.get("path"), str) and new_book.is_document(mark["path"]):
                    self.bookmarks.append({"path": mark["path"], "ratio": ratio_value(mark.get("ratio")),
                                           "label": str(mark.get("label", "书签"))[:200],
                                           "web_anchor": mark.get("web_anchor") if isinstance(mark.get("web_anchor"), dict) else None})
        try:
            self.chapter_index = min(len(new_book.chapters) - 1, max(0, int(record.get("spine_index", 0))))
        except (ValueError, TypeError, OverflowError):
            self.chapter_index = 0
        self.book_title.setText(new_book.title)
        self.book_author.setText(new_book.author)
        self.setWindowTitle(f"{new_book.title} — 墨读 · 金融英语")
        self.populate_toc()
        self.populate_bookmarks()
        self.search_edit.clear()
        initial_ratio = ratio_value(record.get("ratio")) if self.restore_position else 0.0
        initial_view = ViewPosition.from_dict(record.get("viewport")) if self.restore_position else None
        self.navigate(path, ratio=initial_ratio, record_history=False, prepared_html=initial_html, view=initial_view)
        recent = [str(new_book.filename)] + [x for x in self.store.data["recent"]
                                           if isinstance(x, str) and x != str(new_book.filename)]
        self.store.data["recent"] = recent[:10]
        if new_book.warnings:
            self.statusBar().showMessage("；".join(new_book.warnings), 16000)
        self._save_timer.start()
        return True

    def populate_toc(self):
        self.toc_tree.clear()
        self._toc_items: dict[str, list[QTreeWidgetItem]] = {}

        def append(parent, entries: list[TocEntry]):
            for entry in entries:
                item = QTreeWidgetItem(parent, [entry.title])
                item.setData(0, Qt.ItemDataRole.UserRole, (entry.path, entry.fragment))
                item.setToolTip(0, entry.title)
                self._toc_items.setdefault(entry.path, []).append(item)
                append(item, entry.children)

        if self.book:
            append(self.toc_tree, self.book.toc)
        self.toc_tree.expandToDepth(1)

    def toc_activated(self, item, _column=0):
        target = item.data(0, Qt.ItemDataRole.UserRole)
        if target and target[0]:
            self.navigate(target[0], fragment=target[1])

    def title_for(self, path):
        if self.book:
            for chapter in self.book.chapters:
                if chapter.path == path:
                    return chapter.title
            for entry in walk_toc(self.book.toc):
                if entry.path == path:
                    return entry.title
        return Path(path).stem or "阅读"

    def current_ratio(self) -> float:
        if self._loading:
            return self._ready_ratio
        if self._reflow_anchor is not None:
            return self._reflow_anchor.ratio
        scrollbar = self.browser.verticalScrollBar()
        return scrollbar.value() / scrollbar.maximum() if scrollbar.maximum() > 0 else 0.0

    def navigate(self, path: str, fragment: str = "", ratio: float = 0.0,
                 record_history: bool = True, prepared_html: str | None = None,
                 view: ViewPosition | None = None):
        if self.book is None or not self.book.is_document(path):
            self.statusBar().showMessage("该链接不是可读取的书内章节。", 5000)
            return
        try:
            content = prepared_html if prepared_html is not None else self.book.chapter_html(path)
        except EpubError as exc:
            QMessageBox.warning(self, "章节读取失败", str(exc))
            return
        if record_history and self.current_path:
            self.history.append((self.current_path, self.current_ratio()))
            self.history = self.history[-128:]
        self._resize_timer.stop()
        self.current_path = path
        self.browser.current_path = path
        self._cached_html = content
        for index, chapter in enumerate(self.book.chapters):
            if chapter.path == path:
                self.chapter_index = index
                break
        self.chapter_label.setText(self.title_for(path))
        self.chapter_label.setToolTip(path)
        items = self._toc_items.get(path)
        if items:
            match = next((item for item in items if item.data(0, Qt.ItemDataRole.UserRole)[1] == fragment), items[0])
            self.toc_tree.setCurrentItem(match)
            self.toc_tree.scrollToItem(match)
        self.browser.images = ChapterImages(self.book, path)
        self.render(ratio, fragment, view=view)
        self.update_controls()
        self.browser.setFocus()

    def capture_view(self) -> ViewPosition:
        scrollbar = self.browser.verticalScrollBar()
        cursor = self.browser.cursorForPosition(QPoint(1, 1))
        maximum, value = scrollbar.maximum(), scrollbar.value()
        return ViewPosition(cursor.position(), self.browser.cursorRect(cursor).top(),
                            value / maximum if maximum > 0 else 0.0,
                            value == 0, maximum > 0 and value == maximum)

    def restore_view(self, view: ViewPosition):
        scrollbar = self.browser.verticalScrollBar()
        if view.at_top:
            scrollbar.setValue(0)
        elif view.at_bottom:
            scrollbar.setValue(scrollbar.maximum())
        elif 0 <= view.position < self.browser.document().characterCount():
            cursor = QTextCursor(self.browser.document())
            cursor.setPosition(view.position)
            delta = self.browser.cursorRect(cursor).top() - view.offset
            scrollbar.setValue(scrollbar.value() + delta)
        else:
            scrollbar.setValue(round(view.ratio * scrollbar.maximum()))

    def cancel_pending_position(self):
        # A real mouse/key event takes priority over deferred programmatic restoration.
        self._restore_timer.stop()
        self._pending_target = None
        self._loading = False
        if self._reflow_anchor is not None:
            self._reflow_anchor = None

    def render(self, ratio: float, fragment: str = "", view: ViewPosition | None = None):
        if self.book is None:
            return
        self._resize_timer.stop()
        self._restore_timer.stop()
        self._reflow_anchor = None
        self._generation += 1
        self._loading = True
        self._ready_ratio = ratio_value(ratio)
        self._pending_target = (view, self._ready_ratio, fragment)
        self.browser.resource_warnings.clear()
        self.browser.image_width = max(80, self.browser.viewport().width() - 88)
        if self.browser.images is None:
            self.browser.images = ChapterImages(self.book, self.current_path)
        self.browser.setUpdatesEnabled(False)
        try:
            # Decode and size pictures before installing the document. No late image
            # height changes and no setHtml() from a resize callback.
            document = BookDocument(self.browser)
            document.setUndoRedoEnabled(False)
            document.setDefaultFont(QFont(self.reading_font, self.font_size))
            document.setDocumentMargin(40)
            document.setDefaultStyleSheet(self.document_css())
            document.setBaseUrl(QUrl(self.book.url(self.current_path)))
            document.setTextWidth(max(1, self.browser.viewport().width()))
            prepared = self.browser.images.prepare(self._cached_html, document, self.browser.image_width)
            document.setHtml(prepared)
            document.documentLayout().documentSize()
            old_document = self.browser.document()
            self.browser.setDocument(document)
            if isValid(old_document):
                old_document.deleteLater()
            # Reset the caret before scrolling, not after position restoration.
            cursor = QTextCursor(document)
            cursor.movePosition(QTextCursor.MoveOperation.Start)
            self.browser.setTextCursor(cursor)
            self.browser.verticalScrollBar().setValue(0)
            self.browser.horizontalScrollBar().setValue(0)
        finally:
            self.browser.setUpdatesEnabled(True)
        # One queued restoration after the current layout event; never a repeating timer.
        self._restore_timer.start(0)

    def _finish_restore(self):
        target = self._pending_target
        if target is None or self.book is None:
            self._loading = False
            return
        view, ratio, fragment = target
        self._pending_target = None
        self.browser.document().documentLayout().documentSize()
        if fragment:
            self.browser.scrollToAnchor(fragment)
        elif view is not None:
            self.restore_view(view)
        else:
            bar = self.browser.verticalScrollBar()
            bar.setValue(round(ratio * bar.maximum()))
        self._loading = False
        self.scrolled()
        warnings = self.browser.images.warnings if self.browser.images is not None else set()
        if warnings:
            self.statusBar().showMessage("部分插图未显示：" + "；".join(sorted(warnings))[:400], 12000)

    def remember_view_before_resize(self):
        if self.book and self.current_path and not self._loading and self._reflow_anchor is None:
            self._reflow_anchor = self.capture_view()

    def schedule_reflow(self):
        if self.book and self.current_path:
            self._resize_timer.start()

    def reflow(self):
        if self.book is None or not self.current_path:
            return
        self._resize_timer.stop()
        # Preserve a pending chapter/anchor target instead of measuring transient layout.
        pending = self._pending_target
        view = self._reflow_anchor or self.capture_view()
        self._reflow_anchor = None
        self._loading = True
        self._ready_ratio = pending[1] if pending else view.ratio
        self.browser.setUpdatesEnabled(False)
        try:
            self.browser.image_width = max(80, self.browser.viewport().width() - 88)
            document = self.browser.document()
            if self.browser.images is not None:
                self.browser.images.resize_in_place(document, self.browser.image_width)
            document.setTextWidth(max(1, self.browser.viewport().width()))
            document.documentLayout().documentSize()
            if pending is None:
                self.restore_view(view)
        finally:
            self.browser.setUpdatesEnabled(True)
        if pending is not None:
            self._finish_restore()
        else:
            self._loading = False
            self.scrolled()

    def _appearance_view(self):
        if self._pending_target is not None:
            return self._pending_target
        view = self._reflow_anchor or self.capture_view()
        return view, view.ratio, ""

    def change_font(self, delta: int):
        target = self._appearance_view()
        self.font_size = max(12, min(36, self.font_size + delta))
        self.font_label.setText(f"{self.font_size} pt")
        if self.book:
            self.render(target[1], target[2], view=target[0])
        else:
            self.show_welcome()
        self._save_timer.start()

    def set_background(self, color: str):
        normalized = normalize_background(color, "")
        if not normalized:
            return
        target = self._appearance_view()
        self.background = normalized
        self.night = theme_colors(normalized)[2] == "#ffffff"
        if not self.night:
            self.day_background = normalized
        self.apply_theme()
        if self.book:
            self.render(target[1], target[2], view=target[0])
        else:
            self.show_welcome()
        self.save_state()

    def choose_background(self):
        color = QColorDialog.getColor(QColor(self.background), self, "选择阅读背景颜色")
        if color.isValid():
            self.set_background(color.name())

    def toggle_night(self, checked: bool):
        if checked and not self.night:
            self.day_background = self.background
        self.set_background(NIGHT_BACKGROUND if checked else self.day_background)

    def toggle_restore_position(self, checked: bool):
        self.restore_position = checked
        self.resume_action.setChecked(checked)
        self.save_state()
        self.statusBar().showMessage("下次打开将恢复阅读位置。" if checked else "下次打开将停在所记章节开头。", 5000)

    def go_to_chapter_start(self):
        if self.book:
            self.cancel_pending_position()
            self.browser.verticalScrollBar().setValue(0)
            self.scrolled()

    def restart_book(self):
        if self.book:
            self.navigate(self.book.chapters[0].path)

    def toggle_sidebar(self, checked: bool):
        self.sidebar.setVisible(checked)

    def change_chapter(self, direction: int, from_end=False):
        if self.book is None:
            return
        index = self.chapter_index + direction
        if 0 <= index < len(self.book.chapters):
            self.navigate(self.book.chapters[index].path, ratio=1.0 if from_end else 0.0)
        else:
            self.statusBar().showMessage("已经是第一章。" if direction < 0 else "已经读到最后一章。", 3500)

    def turn_page(self, direction: int):
        if self.book is None or self._loading:
            return
        scrollbar = self.browser.verticalScrollBar()
        at_edge = scrollbar.value() >= scrollbar.maximum() - 2 if direction > 0 else scrollbar.value() <= 2
        if at_edge:
            self.change_chapter(direction, from_end=direction < 0)
        else:
            step = max(40, round(self.browser.viewport().height() * 0.88))
            scrollbar.setValue(scrollbar.value() + direction * step)

    def go_back(self):
        if self.history:
            path, ratio = self.history.pop()
            self.navigate(path, ratio=ratio, record_history=False)
        self.update_controls()

    def link_activated(self, url: QUrl):
        if self.book is None:
            return
        if url.scheme().lower() in {"http", "https", "mailto"}:
            question = QMessageBox(self)
            question.setWindowTitle("打开外部链接")
            question.setTextFormat(Qt.TextFormat.PlainText)
            question.setText("将在系统浏览器或邮件应用中打开以下链接：\n" + url.toDisplayString()[:1000])
            question.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            question.setDefaultButton(QMessageBox.StandardButton.No)
            if question.exec() == QMessageBox.StandardButton.Yes:
                if not QDesktopServices.openUrl(url):
                    self.statusBar().showMessage("系统未能打开该链接。", 5000)
            return
        try:
            path, fragment = self.book.resolve(self.current_path, encoded_url(url))
            self.navigate(path, fragment=fragment)
        except EpubError as exc:
            self.statusBar().showMessage(str(exc), 5000)

    def focus_search(self):
        self.search_edit.setFocus()
        self.search_edit.selectAll()

    def find_text(self, backward=False):
        text = self.search_edit.text().strip()
        if self.book is None or not text:
            return
        flags = QTextDocument.FindFlag.FindBackward if backward else QTextDocument.FindFlag(0)
        old_cursor = self.browser.textCursor()
        if self.browser.find(text, flags):
            self.statusBar().showMessage("已定位匹配；搜索范围为当前章节。", 3000)
            return
        cursor = self.browser.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End if backward else QTextCursor.MoveOperation.Start)
        self.browser.setTextCursor(cursor)
        if self.browser.find(text, flags):
            self.statusBar().showMessage("已从本章另一端继续搜索。", 3500)
        else:
            self.browser.setTextCursor(old_cursor)
            self.statusBar().showMessage("当前章节没有找到该文字。", 4000)

    def populate_bookmarks(self):
        self.bookmark_list.clear()
        for mark in self.bookmarks:
            item = QListWidgetItem(mark["label"])
            item.setData(Qt.ItemDataRole.UserRole, mark)
            self.bookmark_list.addItem(item)
        self.tabs.setTabText(1, f"书签 ({len(self.bookmarks)})")

    def add_bookmark(self):
        if self.book is None or not self.current_path:
            return
        ratio = self.current_ratio()
        if any(mark["path"] == self.current_path and abs(mark["ratio"] - ratio) < 0.005 for mark in self.bookmarks):
            self.statusBar().showMessage("此处已经有书签。", 3500)
            return
        if len(self.bookmarks) >= 200:
            self.statusBar().showMessage("每本书最多保存 200 个书签，请先删除不需要的书签。", 5000)
            return
        selection = self.browser.textCursor().selectedText().strip().replace("\u2029", " ")
        label = f"{self.title_for(self.current_path)} · {ratio:.0%}"
        if selection:
            label += "\n" + selection[:45]
        self.bookmarks.append({"path": self.current_path, "ratio": ratio, "label": label})
        self.populate_bookmarks()
        self.save_state()
        self.statusBar().showMessage("书签已添加。", 3000)

    def open_bookmark(self, item):
        mark = item.data(Qt.ItemDataRole.UserRole)
        if isinstance(mark, dict):
            self.navigate(mark["path"], ratio=ratio_value(mark.get("ratio")))

    def delete_bookmark(self):
        index = self.bookmark_list.currentRow()
        if 0 <= index < len(self.bookmarks):
            del self.bookmarks[index]
            self.populate_bookmarks()
            self.save_state()

    def scrolled(self, _value=0):
        if self._loading or self._reflow_anchor is not None or self.book is None:
            return
        ratio = self.current_ratio()
        count = len(self.book.chapters)
        auxiliary = self.current_path != self.book.chapters[self.chapter_index].path
        if auxiliary:
            self.progress_label.setText(f"附加页面 · 页内 {ratio:.0%}")
        else:
            chapter_completion = ratio if self.browser.verticalScrollBar().maximum() else 1.0
            estimate = (self.chapter_index + chapter_completion) / count
            self.progress_label.setText(f"章节 {self.chapter_index + 1}/{count} · 本章 {chapter_completion:.0%} · 全书约 {estimate:.0%}")
        self._save_timer.start()

    def update_controls(self):
        has_book = self.book is not None
        self.prev_action.setEnabled(has_book and self.chapter_index > 0)
        self.next_action.setEnabled(has_book and self.chapter_index < len(self.book.chapters) - 1)
        self.back_action.setEnabled(bool(self.history))
        self.bookmark_action.setEnabled(has_book)
        self.search_edit.setEnabled(has_book)

    def save_state(self):
        self.store.data["preferences"].update({
            "font_size": self.font_size, "night": self.night,
            "background_color": self.background, "day_background": self.day_background,
            "restore_position": self.restore_position,
        })
        if self.dictionary_dock is not None:
            self.store.data["preferences"].update(self.dictionary_dock.preferences())
        if self.book and self.current_path:
            self.store.data["books"][self.book.book_id] = {
                "title": self.book.title, "path": self.current_path, "ratio": self.current_ratio(),
                "spine_index": self.chapter_index, "bookmarks": self.bookmarks,
            }
            # Do not persist an intermediate layout as the user's reading position.
            if not self._loading:
                viewport = self._reflow_anchor or self.capture_view()
                self.store.data["books"][self.book.book_id]["viewport"] = viewport.as_dict()
            elif self._pending_target and self._pending_target[0] is not None:
                self.store.data["books"][self.book.book_id]["viewport"] = self._pending_target[0].as_dict()
        if hasattr(self, "_extend_saved_state"):
            self._extend_saved_state()
        try:
            self.store.save()
            self._save_error_shown = False
            return True
        except (OSError, ValueError) as exc:
            if not self._save_error_shown:
                self.statusBar().showMessage(f"阅读记录保存失败：{exc}", 15000)
                self._save_error_shown = True
            return False

    def dragEnterEvent(self, event):
        if any(url.isLocalFile() and url.toLocalFile().lower().endswith(".epub") for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if url.isLocalFile() and url.toLocalFile().lower().endswith(".epub"):
                self.open_book(url.toLocalFile())
                event.acceptProposedAction()
                break

    def closeEvent(self, event):
        if self.dictionary_dock is not None and self.dictionary_dock.busy:
            self.dictionary_dock.cancel_import()
            self.statusBar().showMessage("已取消词库导入；导入线程结束后请再次关闭窗口。", 8000)
            event.ignore()
            return
        self._save_timer.stop()
        self._resize_timer.stop()
        self._restore_timer.stop()
        if not self.save_state():
            answer = QMessageBox.question(self, "阅读记录尚未保存", "无法保存阅读记录。仍然退出吗？",
                                          QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                          QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
        self._generation += 1
        if self.book:
            self.book.close()
            self.book = None
            self.browser.book = None
            self.browser.images = None
        if self.dictionary_dock is not None:
            self.dictionary_dock.shutdown()
        event.accept()


from pdf_integration import PdfReaderMixin


class MultiFormatReaderWindow(PdfReaderMixin, ReaderWindow):
    """Shared reader shell for EPUB and PDF, including the finance dictionary."""


# Load the original-layout engine before creating QApplication so its EPUB URL
# scheme is registered in time. Legacy classes remain available for regression.
try:
    from publisher_integration import PublisherReaderMixin
except ImportError as exc:
    print(f"缺少原书排版依赖：{exc}\n请执行：python -m pip install -r requirements.txt", file=sys.stderr)
    raise SystemExit(1)


class EnhancedReaderWindow(PublisherReaderMixin, MultiFormatReaderWindow):
    """6.1: monitored original-layout delivery plus native bilingual fallback."""


def main() -> int:
    parser = argparse.ArgumentParser(description="墨读：带音标和金融中文释义的离线 EPUB / PDF 阅读器")
    parser.add_argument("book", nargs="?", help="要打开的 EPUB 或 PDF 文件")
    parser.add_argument("--no-restore", action="store_true", help="不自动打开上次阅读的书籍")
    parser.add_argument("--data-dir", type=Path, help="自定义阅读记录目录")
    parser.add_argument("--software-rendering", action="store_true", help="原书内核使用软件绘图（显卡兼容排查）")
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument("--simple-epub", action="store_true", help="使用旧版简化 EPUB 排版")
    mode_group.add_argument("--compatible-epub", action="store_true", help="使用不启动浏览器内核的兼容双栏模式")
    args = parser.parse_args()
    import os
    if args.software_rendering:
        os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "") + " --disable-gpu"
    if args.simple_epub:
        os.environ["MODU_SIMPLE_EPUB"] = "1"
    if args.compatible_epub:
        os.environ["MODU_COMPATIBLE_EPUB"] = "1"
    app = QApplication(sys.argv[:1])
    app.setApplicationName("MoDuReader")
    app.setApplicationVersion("6.1")
    app.setOrganizationName("MoDuReader")
    app.setStyle("Fusion")
    ui_font = choose_font(["Microsoft YaHei", "PingFang SC", "Noto Sans CJK SC", "WenQuanYi Micro Hei"], app.font().family())
    app.setFont(QFont(ui_font, 10))
    QImageReader.setAllocationLimit(128)
    data_directory = args.data_dir or Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation))
    window = EnhancedReaderWindow(StateStore(data_directory / "state.json"))
    window.show()
    filename = args.book
    if filename is None and not args.no_restore:
        recent = window.store.data["recent"]
        if recent and isinstance(recent[0], str) and Path(recent[0]).is_file():
            filename = recent[0]
    if filename:
        QTimer.singleShot(0, lambda: window.open_book(filename))
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
