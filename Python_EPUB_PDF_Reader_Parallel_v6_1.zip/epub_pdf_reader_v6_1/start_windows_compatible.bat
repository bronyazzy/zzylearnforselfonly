@echo off
chcp 65001 >nul
setlocal
set "MODU_COMPATIBLE_EPUB=1"
call "%~dp0start_windows.bat" --compatible-epub %*
exit /b %ERRORLEVEL%
