#!/usr/bin/env python3
"""Optional local Chromium validation of selected EPUB chapters.

Resource inlining is for the test harness only; the actual application uses an
EPUB URL handler. This is not a substitute for native Qt/Windows testing.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from lxml import etree,html as LH
from epub_core import EpubBook
from publisher_core import PublisherResources,LayoutSettings,appearance_payload
sys.path.insert(0,str(Path(__file__).parent/'tests'))
from browser_harness import load,GEOMETRY


def validate(source,output,pattern=r'.*'):
    from playwright.sync_api import sync_playwright
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    before=hashlib.sha256(Path(source).read_bytes()).hexdigest()
    results=[]
    with EpubBook(source) as book,sync_playwright() as p:
        resources=PublisherResources(book)
        binary=shutil.which('chromium') or shutil.which('chromium-browser')
        browser=p.chromium.launch(**({'executable_path':binary} if binary else {}),headless=True,args=['--no-sandbox'] if hasattr(os,'geteuid') and os.geteuid()==0 else [])
        page=browser.new_page(viewport={'width':1440,'height':1000})
        page.route('**/*',lambda route:route.abort())
        errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
        version=browser.version
        for chapter in book.chapters:
            if not re.search(pattern,chapter.path):continue
            raw=etree.fromstring(book.read(chapter.path),etree.XMLParser(resolve_entities=False,no_network=True))
            body=raw.find('{http://www.w3.org/1999/xhtml}body')
            safe=LH.fromstring(resources.chapter(chapter.path)).find('body')
            normalize=lambda el:' '.join(''.join(el.itertext()).split())
            text_equal=normalize(body)==normalize(safe) if body is not None and safe is not None else None
            table_count=len(safe.xpath('.//table'))
            settings=appearance_payload(LayoutSettings(mode='parallel'),'#faf8f3',18)
            load(page,resources,chapter.path,settings)
            for width in (1440,600):
                page.set_viewport_size({'width':width,'height':1000});page.wait_for_timeout(80)
                rows=page.evaluate(GEOMETRY)
                mismatches=[i for i,r in enumerate(rows) if abs(r['ey']-r['zy'])>1 or (r['ew']>0 and r['zx']<=r['ex'])]
                info=page.evaluate('window.__modu.info()')
                results.append({'path':chapter.path,'width':width,'pairs':len(rows),'bad_alignment':mismatches,
                                'missing_images':info['missingImages'],'body_text_unchanged':text_equal,'tables':table_count})
            print(chapter.path,'pairs',len(rows),'text unchanged',text_equal,'errors',len(mismatches),flush=True)
        page.set_viewport_size({'width':1440,'height':1000})
        chapters=[c for c in book.chapters if re.search(pattern,c.path)]
        if chapters:
            first=chapters[0].path
            load(page,resources,first,appearance_payload(LayoutSettings(mode='parallel',english_percent=45),'#faf8f3',18))
            page.screenshot(path=str(output/'parallel_view.png'))
        browser.close()
    after=hashlib.sha256(Path(source).read_bytes()).hexdigest()
    report={'source_filename':Path(source).name,'source_sha256':before,'source_unchanged':before==after,
            'engine':'Chromium '+version,'harness':'production HTML/CSS/JS with local resources inlined; NOT Qt GUI',
            'results':results,'javascript_errors':errors}
    (output/'layout_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'pages_checked':len(results),'pairs_at_wide_width':sum(r['pairs'] for r in results if r['width']==1440),
          'alignment_failures':sum(len(r['bad_alignment']) for r in results),'missing_images':sum(r['missing_images'] for r in results),
          'text_changed':sum(r['body_text_unchanged'] is False for r in results),'source_unchanged':before==after},ensure_ascii=False))
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='本机排版检查；需要可选 Playwright/Chromium。')
    parser.add_argument('book');parser.add_argument('--output',default='layout-check')
    parser.add_argument('--pattern',default='.*',help='章节路径正则筛选')
    args=parser.parse_args();validate(args.book,args.output,args.pattern)
