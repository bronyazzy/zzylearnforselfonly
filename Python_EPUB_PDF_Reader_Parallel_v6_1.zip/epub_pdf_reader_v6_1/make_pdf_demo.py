"""Rebuild the original test PDF. Development-only dependencies: reportlab, Pillow.

No font files or third-party publication contents are included in the package.
"""
from __future__ import annotations
from io import BytesIO
from pathlib import Path


def make_demo(output: str | Path | None = None):
    from PIL import Image, ImageDraw, ImageFont
    from reportlab.pdfgen import canvas
    from reportlab.lib.utils import ImageReader
    path = Path(output) if output else Path(__file__).with_name('pdf_demo.pdf')
    c = canvas.Canvas(str(path), pagesize=(612, 792), pageCompression=1, invariant=1)
    c.setTitle('Finance Reading Lab - PDF Demo')
    c.setAuthor('MoDu Reader - original test content')
    c.setSubject('Fictional reading and rendering fixtures; not financial advice')

    def header(number, title, subtitle):
        c.setFillColorRGB(.13, .20, .26)
        c.rect(0, 718, 612, 74, fill=1, stroke=0)
        c.setFillColorRGB(1, 1, 1)
        c.setFont('Helvetica-Bold', 23)
        c.drawString(42, 753, title)
        c.setFont('Helvetica', 10)
        c.drawString(43, 735, subtitle)
        c.setFillColorRGB(.17, .2, .23)
        c.setFont('Helvetica', 10)
        c.drawString(42, 26, 'MODU / PDF READING LAB / ORIGINAL DEMONSTRATION')
        c.drawRightString(570, 26, str(number))

    header(1, 'Read finance in context', 'Selectable text + an embedded bitmap + outline navigation')
    c.bookmarkPage('start')
    c.addOutlineEntry('1. Finance vocabulary', 'start')
    sentences = [
        'Capital supports a business. Equity represents an ownership interest.',
        'A bond is a debt instrument. Yield and duration describe different properties.',
        'Liquidity concerns the ability to transact or meet near-term obligations.',
        'Cash flow, leverage and credit risk need context when reading a report.',
        'Try double-clicking equity, yield, liquidity, capital or leverage.',
        'Select the whole phrase cash flow to query the offline finance dictionary.',
    ]
    c.setFont('Helvetica', 12)
    for i, line in enumerate(sentences):
        c.drawString(42, 679 - 27*i, line)
    image = Image.new('RGB', (900, 270), '#e8eff3')
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((30, 35, 285, 235), 20, fill='#52768e')
    draw.rounded_rectangle((323, 35, 578, 235), 20, fill='#80a09d')
    draw.rounded_rectangle((616, 35, 871, 235), 20, fill='#d7b48a')
    image_bytes = BytesIO()
    image.save(image_bytes, 'PNG')
    c.drawImage(ImageReader(BytesIO(image_bytes.getvalue())), 42, 343, width=528, height=158.4)
    c.setFont('Helvetica', 11)
    c.drawString(42, 320, 'Embedded image: three blocks; the default reader view keeps their colors.')
    c.setFont('Helvetica-Bold', 12)
    c.drawString(42, 269, 'Reader checks')
    c.setFont('Helvetica', 11)
    for i, line in enumerate([
        'Use the PDF toolbar to fit width, fit page, rotate or enter a page number.',
        'Search is limited to the current PDF page. The original document is read-only.',
        'Bookmarks and vocabulary are saved locally, alongside your EPUB records.',
        'Opening defaults to the top of the remembered page, not an old scroll offset.',
        'The figures and statements here are demonstration material only.',
    ]):
        c.drawString(42, 244 - i * 23, line)
    c.showPage()

    header(2, 'Statements and tables', 'Original PDF layout: fixed columns, rules and selectable labels')
    c.bookmarkPage('statements')
    c.addOutlineEntry('2. Statements and tables', 'statements')
    c.bookmarkPage('cash-flow')
    c.addOutlineEntry('Cash flow example', 'cash-flow', level=1)
    c.setFont('Helvetica-Bold', 13)
    c.drawString(42, 680, 'Illustrative statement - fictional units')
    rows = [('Metric', 'Period A', 'Period B'), ('Revenue', '120', '135'),
            ('Operating expenses', '90', '96'), ('Operating income', '30', '39'),
            ('Operating cash flow', '27', '34'), ('Capital expenditure', '12', '15'),
            ('Free cash flow', '15', '19')]
    for i, (metric, a, b) in enumerate(rows):
        y = 634 - i * 38
        c.setFont('Helvetica-Bold' if i == 0 else 'Helvetica', 12)
        c.drawString(52, y, metric)
        c.drawRightString(416, y, a)
        c.drawRightString(552, y, b)
        c.setStrokeColorRGB(.8, .84, .86)
        c.line(42, y - 12, 570, y - 12)
    c.setFillColorRGB(.17, .2, .23)
    c.setFont('Helvetica', 11)
    for i, line in enumerate([
        'Interest rates, credit spreads and market prices may appear in the same report.',
        'The word security can refer to a financial instrument rather than physical safety.',
        'Financial statements use assets, liabilities, equity, revenue and expenses.',
        'Search cash flow on this page to cycle through the available text matches.',
        'Use Ctrl+B to add a bookmark here, then use the sidebar to return.',
    ]):
        c.drawString(42, 298 - i*25, line)
    c.showPage()

    # Page 3 is deliberately image-only, with no invisible text layer.
    scan = Image.new('RGB', (1000, 1250), '#fbfaf5')
    draw = ImageDraw.Draw(scan)
    font = ImageFont.load_default(size=34)
    small = ImageFont.load_default(size=24)
    draw.text((65, 95), 'IMAGE-ONLY PDF PAGE', font=font, fill='#273847')
    for i, text in enumerate([
        'This is a generated scan-style test image.',
        'equity / bond / liquidity / cash flow',
        'There is intentionally no PDF text layer.',
        'The page should display correctly.',
        'Double-click lookup and text search',
        'cannot recognize words in this image.',
        'This reader does not run OCR.',
        'Use manual dictionary input instead.',
    ]):
        draw.text((65, 200 + 72*i), text, font=small, fill='#273847')
    scan_bytes = BytesIO()
    scan.save(scan_bytes, 'PNG')
    c.drawImage(ImageReader(BytesIO(scan_bytes.getvalue())), 0, 0, width=612, height=792)
    c.bookmarkPage('scan')
    c.addOutlineEntry('3. Image-only scan fixture', 'scan')
    c.showPage()

    # A stored /Rotate=90 tests PDFium's coordinate mapping, not just image rotation.
    c.setPageRotation(90)
    c.setPageSize((792, 612))
    c.bookmarkPage('rotated')
    c.addOutlineEntry('4. Rotated page and selection', 'rotated')
    c.setFillColorRGB(.13, .20, .26)
    c.setFont('Helvetica-Bold', 20)
    c.drawString(42, 540, 'Rotated page: layout and selection')
    c.setFont('Helvetica', 14)
    c.drawString(42, 494, 'Equity and cash flow should remain selectable after rotation.')
    c.drawString(42, 456, 'Use the rotate button; the original file is not changed.')
    c.setFont('Helvetica', 10)
    c.drawString(42, 58, 'A stored PDF rotation tests text-to-image coordinate mapping.')
    c.showPage()
    c.save()
    return path


def make_security_fixtures():
    """Original fixtures, with intentionally public test credentials."""
    from reportlab.pdfgen import canvas
    from reportlab.lib.pdfencrypt import StandardEncryption
    folder = Path(__file__).with_name('tests') / 'fixtures'
    folder.mkdir(parents=True, exist_ok=True)
    for name, password, can_copy in [('password.pdf', 'demo123', 1), ('restricted.pdf', '', 0)]:
        encryption = StandardEncryption(password, ownerPassword='owner-fixture-only',
                                        canCopy=can_copy, strength=128)
        c = canvas.Canvas(str(folder / name), pagesize=(612, 792), encrypt=encryption, invariant=1)
        c.drawString(72, 700, 'equity cash flow - original PDF test fixture')
        c.save()


if __name__ == '__main__':
    print(make_demo())
    make_security_fixtures()
