"""Local import diagnostics; never upload content or let logging hide an error.

Logs contain paths and exception messages/tracebacks, but not a dump of a book,
dictionary, local variables, credentials or environment variables. Review paths
and exception messages before sharing a log. Keep at most one rotated log file.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import os
import sys
import threading
import traceback

MAX_LOG_BYTES = 512 * 1024
MAX_TRACE_CHARS = 64 * 1024
_LOG_LOCK = threading.Lock()


def report_import_failure(error: Exception, data_dir: Path, source: Path,
                          phase: str) -> str:
    """Save a chained traceback and return a user-facing error + log location.

    The caller should not pass ordinary user cancellation here. Failure to write
    this optional log does not change an import result or mask the original error.
    This module has no Qt dependency so worker-thread error reporting is testable.
    """
    message = str(error) or type(error).__name__
    summary = f'{message}\n\n阶段：{phase}'
    try:
        log_path = Path(data_dir).expanduser().resolve() / 'logs' / 'dictionary_import.log'
        details = ''.join(traceback.format_exception(type(error), error, error.__traceback__))
        if len(details) > MAX_TRACE_CHARS:
            details = '[Earlier traceback text truncated]\n' + details[-MAX_TRACE_CHARS:]
        report = (
            '\n' + '=' * 72 + '\n'
            f'Time (UTC): {datetime.now(timezone.utc).isoformat()}\n'
            'MoDuReader version: 6.1\n'
            f'Python: {sys.version.split()[0]}\nPlatform: {sys.platform}\n'
            f'Phase: {phase}\nSource: {source}\n'
            'Traceback (includes chained causes; no local-variable dump):\n'
            + details + '\n'
        )
        with _LOG_LOCK:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            if (log_path.exists() and
                    log_path.stat().st_size + len(report.encode('utf-8')) > MAX_LOG_BYTES):
                os.replace(log_path, log_path.with_name(log_path.name + '.1'))
            with log_path.open('a', encoding='utf-8') as stream:
                stream.write(report)
        return summary + f'\n诊断日志：{log_path}\n日志可能含本机路径，分享前请检查。'
    except Exception as log_error:
        # Diagnostics are best-effort. A full disk / blocked data directory must
        # leave the original exception visible, not replace it with a logging error.
        return summary + f'\n诊断日志未能写入：{type(log_error).__name__}: {log_error}'
