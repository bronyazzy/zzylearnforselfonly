# 实际测试记录 · 墨读 6.0 · 2026-09-22

本报告区分 Python 后端、真实 Chromium 排版、原生 Qt 窗口和目标系统测试。未运行的测试不会计作通过；历史文档见 `TEST_REPORT_V5_1_HISTORY.md`、`TEST_REPORT_V5_HISTORY.md`。

## 结果

Linux，Python 3.13.5，SQLite 3.46.1；defusedxml、lxml、pypdfium2 可用。系统 liblzo2 可用。真实浏览器为 Chromium 144.0.7559.96，由 Playwright 驱动。

本环境仍不能取得 PySide6 发行包：pip 未返回匹配版本，直接访问包站点时出现域名解析失败，见 `diagnostics/QT_INSTALL_V6.txt`。这不表示 PySide6 普遍不支持该 Python 版本；只说明当前环境无法安装。没有启动 Qt 窗口，没有 Windows 或 macOS 实机。

```text
Ran 442 tests
OK (skipped=94)
```

**348 项实际通过，94 项跳过，0 项失败、0 项错误。** 348 项中包括 16 项真实 Chromium 测试，而不是全部声称为“桌面测试”。完整输出见 `TEST_OUTPUT.txt`。

| 模块 | 数量 | 结果 |
| --- | ---: | --- |
| 原 EPUB / 词典 / 图片 / 设置 / PDF / MDX / Windows 同步故障注入等非 GUI 测试 | 300 | 重新执行并通过，不沿用历史结果 |
| test_publisher_core.py | 32 | 实际文件解析、结构保留、安全与设置测试通过 |
| test_publisher_browser.py | 16 | 实际 Chromium 执行生产 HTML/CSS/JS，通过 |
| 原有五组 Qt GUI 测试 | 79 | 缺少 Qt，跳过 |
| test_publisher_gui.py | 15 | 缺少 Qt，跳过 |

## 新后端与浏览器验证

后端覆盖：设置类型与边界；DOM 定位校验；出版方 class/CSS/lang/ID 保留；明确语言对识别，不猜测无标记内容；共享数值/图片不删除；拒绝书外资源、穿越、作者伪造内部标记、事件、脚本、表单及跳转；静态 SVG/MathML、图片 object 转换、宽表包装、内容预算与独享书包 origin。

实际 Chromium 覆盖：原 CSS 双栏、45/55 等宽度调整、600px 窄窗口下仍左右对照、上下视图不重叠、单语视图可恢复而非删正文、应用/取消主题、字号/栏宽/背景变化不重建 DOM、就近内容定位偏差在测试阈值 1px 内、默认顶部与静置不持续下滑、窗口改变后的定位、锚点和书签、单语言块选词上下文、PNG/SVG、宽表不把整个页面撑宽、真实 CSS Grid 和边界翻屏。

**测试方法限制：** 当前浏览器运行环境对一般导航实施限制，因此测试在受控的 about:blank 页面将生产 `PublisherResources` 返回的 HTML 及其本地 CSS/图片资源内联，再执行同一份 `assets/reader.js`。没有修改排版算法或伪造浏览器 DOM。此方法检验真实渲染，但不检验 Qt 自定义 `epub://` scheme、Qt 信号/回调、QBuffer 生命周期、独立 ApplicationWorld 与 MainWorld 设置、真实桌面菜单和鼠标音频。

原有 PDFium 渲染/文字/权限、MDX/MDD 真实二进制及 liblzo2 读取、Windows 风格可写句柄故障注入测试本次实际再次执行；Windows 故障注入仍不是 Windows 原机验证。

## 用户上传书的实际文件检查

文件：`全球宏观市场交易_中英左右对照完整版(1).epub`。
SHA-256：`53907d30624348142876a61fedfef7d1bd068f8b61a28a61bc5c06de936b2303`。
检查对象为 16 个正文章节 `OPS/c001.xhtml` 至 `OPS/c016.xhtml`。用户源书没有修改，也没有放进分发包。

- 每章分别用 1440px 和 600px 两种视口，即 32 次章节/宽度组合。
- 16 章共 1,991 个明确配对单元，包括标题、栏位说明和成对正文，不能称为 1,991 个自然段或新翻译。
- 所检查组合中，左右单元同组顶端对齐、左右顺序检查未发现不符合阈值的项（bad_alignment 为空）。
- 加载完成后没有检测到失败图片（missing_images 为 0）。此检查不等于每幅图已人工审查清晰度或全部 SVG 特效一致。
- 16 章保留前后正文可见文本按空白规范化比较一致；这不是中文翻译准确性审校，也不是字号/分页的像素级一致检查。
- 原 EPUB 检查前后 SHA-256 不变。

详见 `diagnostics/USER_BOOK_LAYOUT_VALIDATION.json` 和输出日志。可选命令：

```bash
python validate_epub_layout.py "你的书籍.epub" --pattern '^OPS/c[0-9]+\.xhtml$' --output ./layout-check
```

用户书的第一章也生成并人工查看了 Chromium 预览：英文左、中文右，标题和对应内容顶部对齐。预览不是 Qt 阅读器窗口截图；书中文字未随源码包分发。

## 打包与源码检查

全部 Python 文件经过语法编译及 Python 3.10 语法级 AST 检查；这不是在 Python 3.10 解释器上实际运行。JS 经 `node --check`，macOS/Linux 启动脚本经 `sh -n`。Windows 启动脚本未原机运行。

完整分发包执行 ZIP CRC 检查，在独立目录重新解压后按 `MANIFEST.json` 检查逐文件 SHA-256，并再次运行全部测试。清单是损坏检查，不是数字签名。包内不含 `.venv`、缓存、用户阅读记录、用户原书、第三方商业词典或字体文件。

## 尚未验证与明确限制

94 项原生 Qt GUI 测试未执行，包括新窗口初始化、页面 profile/scheme 生命周期、隔离世界代码运行、工具栏联动、Qt 搜索/菜单/拖拽、查词信号、设置落盘后重开、图片放大窗口、高清 DPI、Windows 显卡、macOS 及音频设备播放。**不能以浏览器渲染通过替代这些原生桌面测试。**

没有执行完整 EPUBCheck 认证、全平台兼容测试或对每个版本 Qt / 出版社排版穷尽测试。没有测试用户具体 MDX 商业词库。不是“所有 EPUB 完美兼容”。

出版方 JavaScript、音视频、DRM、特殊加密/混淆字体、完整固定版式/双页规范不在承诺范围。英语/中文单语显示只隐藏已识别的配对侧，共用及未标记内容不会自动过滤或翻译。MDX 的原有排版边界不因 EPUB 新视图而消失。原生图片与 WebEngine 进程的总资源使用没有强硬耗时/内存沙箱上限。
