"""Create an original, redistributable EPUB fixture using only the standard library."""
from __future__ import annotations

from pathlib import Path
import struct
from urllib.parse import quote
import zipfile
import zlib


def banner_png() -> bytes:
    width, height = 480, 96
    rows = bytearray()
    for y in range(height):
        rows.append(0)
        for x in range(width):
            rows.extend((32 + x * 36 // width, 91 + y * 38 // height, 88 + x * 24 // width))
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(bytes(rows))) + chunk(b'IEND', b''))


def xhtml(title: str, body: str) -> str:
    return f'''<?xml version="1.0" encoding="utf-8"?>
    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-CN"><head><title>{title}</title>
    <link rel="stylesheet" type="text/css" href="../Styles/book.css" /></head><body>{body}</body></html>'''


def sample_files(version: int = 3) -> dict[str, str | bytes]:
    c1 = "Text/" + quote("第一章.xhtml")
    files: dict[str, str | bytes] = {
        "mimetype": "application/epub+zip",
        "META-INF/container.xml": '''<?xml version="1.0"?>
        <container xmlns="urn:oasis:names:tc:opendocument:xmlns:container" version="1.0">
        <rootfiles><rootfile full-path="OPS/package.opf" media-type="application/oebps-package+xml" /></rootfiles></container>''',
    }
    nav_item = '<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav" />' if version == 3 else ""
    files["OPS/package.opf"] = f'''<?xml version="1.0" encoding="utf-8"?>
    <package xmlns="http://www.idpf.org/2007/opf" version="{version}.0" unique-identifier="bookid">
    <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:identifier id="bookid">urn:uuid:5fbe1a3a-73f7-4c4e-98d4-6d5d44a271ac</dc:identifier>
    <dc:title>在文字里散步</dc:title><dc:creator>墨读示例</dc:creator><dc:language>zh-CN</dc:language>
    <meta property="dcterms:modified">2026-09-08T00:00:00Z</meta>
    </metadata><manifest>
    <item id="c3" href="Text/chapter3.xhtml" media-type="application/xhtml+xml" />
    <item id="c2" href="Text/chapter2.xhtml" media-type="application/xhtml+xml" />
    <item id="c1" href="{c1}" media-type="application/xhtml+xml" />
    <item id="notes" href="Text/notes.xhtml" media-type="application/xhtml+xml" />
    <item id="image" href="Images/banner.png" media-type="image/png" />
    <item id="css" href="Styles/book.css" media-type="text/css" />
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml" />{nav_item}
    </manifest><spine toc="ncx"><itemref idref="c1" /><itemref idref="c2" /><itemref idref="c3" />
    <itemref idref="notes" linear="no" /></spine></package>'''
    files["OPS/nav.xhtml"] = f'''<?xml version="1.0" encoding="utf-8"?>
    <html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="zh-CN">
    <head><title>目录</title></head><body><nav epub:type="toc"><h1>目录</h1><ol>
    <li><a href="{c1}">第一章 · 打开一本书</a></li>
    <li><a href="Text/chapter2.xhtml">第二章 · 沿着文字走</a><ol>
    <li><a href="Text/chapter2.xhtml#half">中途的风景</a></li></ol></li>
    <li><a href="Text/chapter3.xhtml">第三章 · 下次再见</a></li>
    </ol></nav></body></html>'''
    files["OPS/toc.ncx"] = f'''<?xml version="1.0" encoding="utf-8"?>
    <ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head>
    <meta name="dtb:uid" content="urn:uuid:5fbe1a3a-73f7-4c4e-98d4-6d5d44a271ac" /></head>
    <docTitle><text>在文字里散步</text></docTitle><navMap>
    <navPoint id="a" playOrder="1"><navLabel><text>第一章 · 打开一本书</text></navLabel><content src="{c1}" /></navPoint>
    <navPoint id="b" playOrder="2"><navLabel><text>第二章 · 沿着文字走</text></navLabel><content src="Text/chapter2.xhtml" />
    <navPoint id="b1" playOrder="3"><navLabel><text>中途的风景</text></navLabel><content src="Text/chapter2.xhtml#half" /></navPoint></navPoint>
    <navPoint id="c" playOrder="4"><navLabel><text>第三章 · 下次再见</text></navLabel><content src="Text/chapter3.xhtml" /></navPoint>
    </navMap></ncx>'''
    files["OPS/Text/第一章.xhtml"] = xhtml("打开一本书", '''<h1 id="start">第一章 · 打开一本书</h1>
    <p>这不是一本关于速度的书。它只邀请你，在忙碌的一天里，为自己留下一小段安静的时间。</p>
    <p><img src="../Images/banner.png" alt="青绿色阅读横幅" /></p>
    <p>窗边有光，桌上有茶。翻开第一页时，世界并没有改变，但你的注意力慢慢回到了这里。</p>
    <h2>试试这些操作</h2><ul><li>点击目录，可以跳到另一章。</li><li>按左右方向键，可以按屏翻页。</li>
    <li>调整字号，或切换夜间模式，找到舒服的阅读方式。</li></ul>
    <p>这里有一条<a href="notes.xhtml#note1">书内注释</a>。读完后，可以点击工具栏的“返回”。</p>'''
    + "".join(f"<p>第 {i} 段。阅读不是一场必须抵达终点的比赛。你可以在喜欢的句子旁停下来，也可以暂时合上书，让刚刚读过的文字在心里多留一会儿。</p>" for i in range(1, 19)))
    paragraphs = []
    for i in range(1, 27):
        if i == 14:
            paragraphs.append('<h2 id="half">中途的风景</h2>')
        paragraphs.append(f"<p>第 {i} 段。小路经过一排旧树。风吹过树叶的时候，声音像翻书。我们沿着文字走，不急着解释每一处风景，也不急着为旅途取一个响亮的名字。</p>")
    files["OPS/Text/chapter2.xhtml"] = xhtml("沿着文字走", '<h1>第二章 · 沿着文字走</h1>' + "".join(paragraphs))
    files["OPS/Text/chapter3.xhtml"] = xhtml("下次再见", '''<h1>第三章 · 下次再见</h1>
    <p>故事暂时写到这里，阅读却不需要结束。</p><blockquote>每一次重新打开书，都是与自己的一次重逢。</blockquote>
    <p>可以先添加一个书签，再关闭窗口。下次打开同一本书时，程序会尝试恢复章节和滚动位置。</p>
    <p>这份示例文字为本项目原创，可随项目一起使用和修改。</p>''')
    files["OPS/Text/notes.xhtml"] = xhtml("注释", f'''<h1>注释</h1><p id="note1">这是一个不在连续正文中的注释页面。</p>
    <p>程序仍然可以通过书内链接显示它。<a href="{quote('第一章.xhtml')}#start">回到第一章开头</a>。</p>''')
    files["OPS/Images/banner.png"] = banner_png()
    files["OPS/Styles/book.css"] = "body { color: #111; font-family: serif; } p { line-height: 1.6; }"
    if version == 2:
        files.pop("OPS/nav.xhtml")
        files["OPS/package.opf"] = files["OPS/package.opf"].replace('<meta property="dcterms:modified">2026-09-08T00:00:00Z</meta>', '')
    return files


def write_epub(filename: Path, files: dict[str, str | bytes]):
    with zipfile.ZipFile(filename, "w") as archive:
        if "mimetype" in files:
            archive.writestr("mimetype", files["mimetype"], compress_type=zipfile.ZIP_STORED)
        for name, value in files.items():
            if name != "mimetype":
                archive.writestr(name, value, compress_type=zipfile.ZIP_DEFLATED)


if __name__ == "__main__":
    output = Path(__file__).with_name("demo.epub")
    write_epub(output, sample_files())
    print(f"已生成：{output}")
