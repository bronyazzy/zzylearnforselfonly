# 5.1 修复说明：MDX 导入 Bad file descriptor

## 问题及定位

用户截图为「MDX 导入未完成：词典导入失败：[Errno 9] Bad file descriptor」。
检查原 5.0 包，在 `mdict_core.build_index()` 找到索引完成后的如下调用：

```python
with staged.open('rb') as stream:
    os.fsync(stream.fileno())
```

`dictionary_core.import_csv()` 对临时 SQLite 文件也有同样写法。
Python 文档说明 Windows 的 `os.fsync()` 调用 MS `_commit()`；微软文档规定底层
`FlushFileBuffers` 的文件句柄需要写访问。只读文件存在，并不表示它的句柄适合写入同步。
参考原始文档见 `SOURCES.md` 末节。

这是一处代码层面可确认的 Windows 兼容性缺陷；结合截图判断它很可能是此次失败的原因。
不过没有用户词典或完整异常调用栈，不能把截图当作已经排除其他原因的证明。

## 修改

```python
# Only the generated temporary SQLite index, not the source MDX/MDD/CSV.
with staged.open('r+b') as stream:
    stream.flush()
    os.fsync(stream.fileno())
```

CSV 路径相同，只是变量名为 `temporary`。这里不能改成 `wb`（会截断文件），也不能简单忽略同步异常。
两处同步都在 SQLite 写连接和预验证读连接关闭之后，发布 / 重命名之前进行。
原始词典文件保持只读，不需要改文件权限、关闭杀毒软件或以管理员身份运行来绕过本缺陷。

额外加入了同步后取消检查。真正的写入失败仍会报错并保留旧库；没有去掉数据安全检查。

## 诊断日志

MDX 工作线程记录最近的导入阶段，失败时保留异常调用链；登记索引失败也有日志。
CSV 工作线程也接入同一日志模块。主动取消不作为错误记录。
日志在原应用数据目录的 `logs/dictionary_import.log`，超过阈值时最多保留一个 `.1` 历史文件。
日志写入自身失败时仍显示原导入异常，不用日志错误替换它。

日志可能包含本机路径和异常消息。程序不会联网提交日志，不转储局部变量，也不主动复制整本书或整部词典。

## 如何升级

关闭旧版，完整解压新版，运行 `start_windows.bat` 或 `python epub_reader.py`。
不要只拷贝一个 Python 文件；新增诊断模块与调用它的 UI 源码必须配套。
本次没有新增运行依赖，也没有改数据目录标识或清单版本。
之前使用过 `--data-dir` 的继续用同一路径；不用删除阅读记录、生词本或已有词库。
重新导入原来失败的 `.mdx`。程序仍自动发现对应 MDD 和数字分卷。

## 验证

`diagnostics/V50_REPRODUCTION.txt` 是修复前的故障注入记录：在 Linux 用严格的“fsync 必须针对可写句柄”
检查包住真实 MDX/MDD 和 CSV 导入，旧代码产生了与截图相同的错误文本。目录名里出现 v5_1 是因为
原 5.0 文件先解压到该工作目录，记录是在修改源码之前产生；不是用修复后的代码声称旧错误仍存在。

`tests/test_import_io.py` 测试新版通过同一规则，同时检查真实文件 / SQLite 内容、MDD 分卷、中文路径、
跨真实工作线程交付、关闭句柄后重命名、取消和磁盘错误不覆盖旧库，以及诊断日志。
完整测试计数和未验证范围见 `TEST_REPORT.md`。

**没有 Windows 实机、没有用户具体词典、没有可运行的 Qt GUI。模拟规则不能替代目标机器的实测。**
