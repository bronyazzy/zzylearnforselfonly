"""MDX/MDD tab, staged import worker, dictionary manager and explicit audio playback."""
from __future__ import annotations

import html
from pathlib import Path
import posixpath
import re
import sqlite3
from urllib.parse import unquote, urlsplit

from PySide6.QtCore import QByteArray, QBuffer, QIODevice, QThread, Qt, QTimer, QUrl, Signal, Slot
from PySide6.QtGui import QTextDocument
from PySide6.QtWidgets import (
    QApplication, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QHBoxLayout,
    QInputDialog, QLabel, QListWidget, QListWidgetItem, QMessageBox, QProgressDialog,
    QPushButton, QTextBrowser, QVBoxLayout, QWidget,
)
from shiboken6 import isValid
from dictionary_core import DictionaryError
from image_support import ImageError
from image_ui import ChapterImages, encoded
from mdict_core import MdictLibrary, MdictArticle, ImportPlan, build_index, discover_mdd
from mdict_format import MdictError, MdictCancelled, resource_key
from import_diagnostics import report_import_failure
from mdict_html import sanitize_article, split_virtual_url


class _MdictResourceBook:
    def __init__(self, library: MdictLibrary, identifier: str):
        self.library, self.identifier = library, identifier

    def local_image_bytes(self, base: str, reference: str) -> bytes:
        try:
            parts = urlsplit(reference.replace('\\', '/'))
            if parts.scheme or parts.netloc:
                raise ImageError('SVG 不能引用网络或磁盘外部资源')
            path = unquote(parts.path, errors='strict')
            path = posixpath.normpath(path.lstrip('/') if path.startswith('/') else
                                     posixpath.join(posixpath.dirname(base), path))
            resource_key(path)
            data = self.library.resource(self.identifier, path)
            if data is None:
                raise ImageError('SVG 配套图片未找到')
            return data
        except (MdictError, ValueError, OSError, sqlite3.Error) as exc:
            raise ImageError(str(exc)) from exc


class MdictImages(ChapterImages):
    def __init__(self, library: MdictLibrary, identifier: str):
        super().__init__(_MdictResourceBook(library, identifier), '')
        self.library, self.identifier = library, identifier

    def _read(self, url: str):
        try:
            identifier, path = split_virtual_url(url, 'mdictres')
            if identifier != self.identifier:
                raise ImageError('图片不属于当前词典')
            data = self.library.resource(identifier, path)
            if data is None:
                raise ImageError(f'缺少 MDD 或资源：{path}')
            return data, path
        except (MdictError, ValueError, OSError, sqlite3.Error) as exc:
            raise ImageError(str(exc)) from exc


class _ClosedDocument(QTextDocument):
    def loadResource(self, resource_type, name):
        # Only images explicitly preloaded with addResource are allowed.
        return QByteArray()


class MdictBrowser(QTextBrowser):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setOpenLinks(False)
        self.setOpenExternalLinks(False)
        self.setReadOnly(True)
        self.images: MdictImages | None = None
        self._resize_timer = QTimer(self)
        self._resize_timer.setSingleShot(True)
        self._resize_timer.setInterval(100)
        self._resize_timer.timeout.connect(self._resize_images)
        self.setDocument(_ClosedDocument(self))
        self.document().setDocumentMargin(16)

    def loadResource(self, resource_type, name):
        return QByteArray()

    def display(self, markup: str, library: MdictLibrary, identifier: str):
        self._resize_timer.stop()
        self.images = MdictImages(library, identifier)
        old = self.document()
        document = _ClosedDocument(self)
        document.setDocumentMargin(16)
        document.setDefaultFont(self.font())
        prepared = self.images.prepare(markup, document, max(100, self.viewport().width() - 40))
        document.setHtml(prepared)
        self.setDocument(document)
        if old is not document and isValid(old):
            old.deleteLater()
        self.verticalScrollBar().setValue(0)
        return sorted(self.images.warnings)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, '_resize_timer') and self.images:
            self._resize_timer.start()

    def _resize_images(self):
        if self.images:
            bar = self.verticalScrollBar()
            position = bar.value()
            self.images.resize_in_place(self.document(), max(100, self.viewport().width() - 40))
            bar.setValue(min(position, bar.maximum()))

    def clear_article(self, message: str):
        self._resize_timer.stop()
        self.images = None
        self.setPlainText(message)


class MdictImportThread(QThread):
    processed = Signal(str)
    completed = Signal(object, str)

    def __init__(self, source: Path, destination: Path, resources: list[Path] | None, parent=None):
        super().__init__(parent)
        self.source, self.destination, self.resources = source, destination, resources

    def run(self):
        phase = '准备 MDX / MDD 导入'

        def on_progress(text: str):
            nonlocal phase
            phase = text
            self.processed.emit(text)

        try:
            plan = build_index(self.source, self.destination, self.resources,
                               on_progress, self.isInterruptionRequested)
            self.completed.emit(plan, '')
        except MdictCancelled as exc:
            self.completed.emit(None, str(exc))
        except Exception as exc:
            self.completed.emit(None, report_import_failure(
                exc, self.destination.parent, self.source, phase))


class MdictPanel(QWidget):
    libraryChanged = Signal()
    lookupRequested = Signal(str)

    def __init__(self, dock):
        super().__init__(dock)
        self.dock = dock
        self.library = MdictLibrary(dock.data_directory)
        self.articles: list[MdictArticle] = []
        self.query = ''
        self.context = ''
        self.book_title = ''
        self.night = False
        self.thread: MdictImportThread | None = None
        self.progress: QProgressDialog | None = None
        self._completed_plan: ImportPlan | None = None
        self._completed_error = ''
        self._cancel_requested = False
        self._player = None
        self._audio_output = None
        self._audio_buffer = None
        self._build_ui()
        self.refresh_dictionaries()
        self.browser.clear_article('导入 MDX 词典后，可与内置金融词库同时查词。\nMDD 是配套图片、样式和音频资源包，不能单独作为词典。')
        if self.library.warning:
            self.hint.setText(self.library.warning)

    @property
    def busy(self):
        # Keep true until finished-handler commits/discards the staged result.
        return self.thread is not None

    @property
    def current_article(self) -> MdictArticle | None:
        index = self.entries.currentIndex()
        return self.articles[index] if 0 <= index < len(self.articles) else None

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 4, 0, 0)
        row = QHBoxLayout()
        self.dictionaries = QComboBox()
        self.dictionaries.setMinimumContentsLength(12)
        self.dictionaries.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.dictionaries.currentIndexChanged.connect(self.rerun_lookup)
        row.addWidget(self.dictionaries, 1)
        self.manage_button = QPushButton('管理词典')
        self.manage_button.clicked.connect(self.manage_dictionaries)
        row.addWidget(self.manage_button)
        layout.addLayout(row)
        row = QHBoxLayout()
        self.import_button = QPushButton('导入 MDX / MDD')
        self.import_button.clicked.connect(self.choose_import)
        row.addWidget(self.import_button)
        self.attach_button = QPushButton('补充 MDD')
        self.attach_button.clicked.connect(self.choose_resources)
        row.addWidget(self.attach_button)
        layout.addLayout(row)
        self.entries = QComboBox()
        self.entries.setMinimumContentsLength(12)
        self.entries.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.entries.currentIndexChanged.connect(self.show_current)
        layout.addWidget(self.entries)
        self.browser = MdictBrowser()
        self.browser.anchorClicked.connect(self.follow_link)
        layout.addWidget(self.browser, 1)
        row = QHBoxLayout()
        self.save_button = QPushButton('加入生词本')
        self.save_button.clicked.connect(self.save_current)
        self.copy_button = QPushButton('复制词条')
        self.copy_button.clicked.connect(self.copy_current)
        self.stop_button = QPushButton('停止音频')
        self.stop_button.clicked.connect(self.stop_audio)
        for button in (self.save_button, self.copy_button, self.stop_button):
            row.addWidget(button)
        layout.addLayout(row)
        self.hint = QLabel('首次导入建立索引；请保留原 MDX / MDD 文件的位置。')
        self.hint.setTextFormat(Qt.TextFormat.PlainText)
        self.hint.setWordWrap(True)
        layout.addWidget(self.hint)
        self.save_button.setEnabled(False)
        self.copy_button.setEnabled(False)
        self.stop_button.setEnabled(False)

    def refresh_dictionaries(self):
        selected = self.dictionaries.currentData()
        self.dictionaries.blockSignals(True)
        self.dictionaries.clear()
        self.dictionaries.addItem('所有启用的 MDX 词典', '')
        for item in self.library.items:
            if item.get('enabled', True) is True:
                self.dictionaries.addItem(item['title'], item['id'])
        index = self.dictionaries.findData(selected)
        self.dictionaries.setCurrentIndex(max(0, index))
        self.dictionaries.blockSignals(False)
        self.attach_button.setEnabled(bool(self.library.items) and not self.busy and not self.library.read_only)
        self.import_button.setEnabled(not self.busy and not self.library.read_only)
        self.manage_button.setEnabled(not self.busy)
        self.libraryChanged.emit()

    def lookup(self, text: str, context: str = '', book: str = '') -> int:
        self.query, self.context, self.book_title = text, context, book
        self.stop_audio()
        result = self.library.lookup(text, self.dictionaries.currentData() or '')
        self.articles = result.articles
        self.entries.blockSignals(True)
        self.entries.clear()
        for article in self.articles:
            self.entries.addItem(f'{article.title} · {article.word}')
        self.entries.blockSignals(False)
        self.hint.setText('\n'.join(result.warnings) or '音标、中文和音频以导入词典实际内容为准；不会自动补写或翻译。')
        self.show_current()
        if not self.articles:
            self.browser.clear_article('此查询在已启用的 MDX 词典中未收录。\n可以切换词典，或检查是否已导入、启用对应词库。')
        return len(self.articles)

    def rerun_lookup(self, _index=0):
        if self.query and not self.busy:
            self.lookup(self.query, self.context, self.book_title)

    def set_night(self, night: bool):
        self.night = night
        self.show_current()

    def show_current(self, _index=0):
        self.stop_audio()
        article = self.current_article
        self.save_button.setEnabled(bool(article) and not self.dock.vocabulary.read_only and not self.busy)
        self.copy_button.setEnabled(bool(article))
        if not article:
            return
        try:
            identifier = article.dictionary_id
            warnings = []
            try:
                default_css = self.library.default_css(identifier)
            except (MdictError, OSError, ValueError, sqlite3.Error) as exc:
                default_css = None
                warnings.append(str(exc))
            safe = sanitize_article(article.body, identifier,
                                    lambda path: self.library.resource(identifier, path, 512 * 1024),
                                    default_css=default_css, night=self.night)
            foreground = '#E6E6E6' if self.night else '#262A30'
            title = '<h2>' + html.escape(article.word) + '</h2>'
            title += '<p>' + html.escape(article.title + ' · ' + article.match_note) + '</p><hr>'
            markup = f'<html><body style="color:{foreground};">' + title + safe.markup + '</body></html>'
            warnings += safe.warnings
            warnings += self.browser.display(markup, self.library, identifier)
            if warnings:
                self.hint.setText('\n'.join(dict.fromkeys(warnings))[:1400])
        except (MdictError, OSError, ValueError, sqlite3.Error) as exc:
            self.browser.clear_article(f'词条显示失败：{exc}')

    def follow_link(self, url: QUrl):
        if url.scheme() == 'mdictlookup':
            # Preserve capitalization and decode exactly once via encoded URL.
            parts = urlsplit(encoded(url))
            article = self.current_article
            if article is None or parts.netloc != article.dictionary_id:
                return
            try:
                text = unquote(parts.path.lstrip('/'), errors='strict')
            except UnicodeError:
                return
            if 0 < len(text) <= 160:
                self.lookupRequested.emit(text)
        elif url.scheme() == 'mdictaudio':
            self.play_audio(encoded(url))
        elif not url.scheme() and url.hasFragment():
            self.browser.scrollToAnchor(url.fragment())

    def save_current(self):
        article = self.current_article
        if article is None or self.busy:
            return
        try:
            self.dock.vocabulary.add(article.as_entry(), self.context, self.book_title)
            self.dock.refresh_vocabulary()
            self.dock.update_stats()
            self.hint.setText('已保存此 MDX 词条的文字、可识别音标和阅读上下文；图片、音频不复制进生词本。')
        except (DictionaryError, OSError, ValueError) as exc:
            QMessageBox.warning(self, '生词未能保存', str(exc))

    def copy_current(self):
        article = self.current_article
        if article:
            entry = article.as_entry()
            QApplication.clipboard().setText(entry.word + '\n' + entry.translation)
            self.hint.setText('已复制当前 MDX 词条的纯文本。')

    def stop_audio(self):
        if self._player is not None:
            self._player.stop()
            self._player.setSource(QUrl())
        if self._audio_buffer is not None:
            self._audio_buffer.close()
            self._audio_buffer.deleteLater()
            self._audio_buffer = None
        if hasattr(self, 'stop_button'):
            self.stop_button.setEnabled(False)

    def play_audio(self, url: str):
        try:
            identifier, path = split_virtual_url(url, 'mdictaudio')
            article = self.current_article
            if article is None or article.dictionary_id != identifier:
                raise MdictError('音频不属于当前词典。')
            data = self.library.resource(identifier, path, 16 * 1024**2)
            if not data:
                raise MdictError('没有找到音频；请补充对应的 MDD 资源包。')
            from mdict_audio import validate_audio
            validate_audio(data, Path(path).suffix)
            try:
                from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
            except ImportError as exc:
                raise MdictError('缺少 QtMultimedia。请重新执行 python -m pip install -r requirements.txt。') from exc
            self.stop_audio()
            if self._player is None:
                self._audio_output = QAudioOutput(self)
                self._audio_output.setVolume(0.7)
                self._player = QMediaPlayer(self)
                self._player.setAudioOutput(self._audio_output)
                self._player.errorOccurred.connect(self.audio_error)
            self._audio_buffer = QBuffer(self)
            self._audio_buffer.setData(QByteArray(data))
            self._audio_buffer.open(QIODevice.OpenModeFlag.ReadOnly)
            self._player.setSourceDevice(self._audio_buffer, QUrl('mdict-audio' + Path(path).suffix.lower()))
            self._player.play()
            self.stop_button.setEnabled(True)
            self.hint.setText('正在播放词典自带音频；没有调用在线发音或文字转语音。')
        except (MdictError, OSError, ValueError, sqlite3.Error) as exc:
            self.hint.setText(str(exc))

    def audio_error(self, _error, message=''):
        self.hint.setText('音频播放失败：' + (message or '设备或解码器不可用') + '。解码能力取决于本机 Qt 多媒体后端。')
        self.stop_button.setEnabled(False)

    def _select_dictionary(self) -> dict | None:
        if not self.library.items:
            QMessageBox.information(self, '先导入 MDX', 'MDD 是资源包。请先导入相应的 MDX 词典正文。')
            return None
        selected = self.dictionaries.currentData()
        if selected:
            return next((x for x in self.library.items if x['id'] == selected), None)
        labels = [f'{i+1}. {item["title"]} — {Path(item["mdx_path"]).name}' for i, item in enumerate(self.library.items)]
        choice, ok = QInputDialog.getItem(self, '选择目标词典', '把资源包绑定到哪部 MDX？', labels, 0, False)
        return self.library.items[labels.index(choice)] if ok and choice in labels else None

    def choose_import(self):
        if self.dock.busy or self.library.read_only:
            return
        filename, _ = QFileDialog.getOpenFileName(self, '导入 MDX 词典 / 配套 MDD', str(Path.home()),
                                                  'MDict 词典 (*.mdx *.mdd *.MDX *.MDD)')
        if not filename:
            return
        path = Path(filename)
        if path.suffix.lower() == '.mdd':
            base = re.sub(r'\.\d+$', '', path.stem)
            siblings = [p for p in path.parent.iterdir() if p.suffix.lower() == '.mdx' and p.stem.casefold() == base.casefold()]
            if len(siblings) == 1:
                self.start_import(siblings[0])
            else:
                item = self._select_dictionary()
                if item:
                    resources = [Path(p) for p in item['mdd_paths']] + [path]
                    self.start_import(Path(item['mdx_path']), resources)
        else:
            self.start_import(path)

    def choose_resources(self):
        if self.dock.busy or self.library.read_only:
            return
        item = self._select_dictionary()
        if item is None:
            return
        names, _ = QFileDialog.getOpenFileNames(self, '补充此词典的 MDD 资源包', str(Path(item['mdx_path']).parent),
                                               'MDD 资源包 (*.mdd *.MDD)')
        if names:
            resources = [Path(p) for p in item['mdd_paths']] + [Path(p) for p in names]
            self.start_import(Path(item['mdx_path']), resources)

    def start_import(self, path: Path, resources: list[Path] | None = None):
        if self.dock.busy or self.library.read_only:
            return
        self.stop_audio()
        self._completed_plan, self._completed_error = None, ''
        self._cancel_requested = False
        self.thread = MdictImportThread(Path(path), self.library.directory, resources, self)
        self.thread.processed.connect(self.on_progress)
        self.thread.completed.connect(self.on_completed)
        self.thread.finished.connect(self.on_finished)
        self.progress = QProgressDialog('正在读取词典索引…', '取消', 0, 0, self)
        self.progress.setWindowTitle('导入 MDX / MDD')
        self.progress.setWindowModality(Qt.WindowModality.NonModal)
        self.progress.setMinimumDuration(0)
        self.progress.setAutoClose(False)
        self.progress.canceled.connect(self.cancel_import)
        self.progress.show()
        self._set_busy_controls(True)
        self.thread.start()

    def _set_busy_controls(self, busy: bool):
        for widget in (self.dock.query_edit, self.dock.query_button, self.dock.import_button,
                       self.dock.finance_check, self.dictionaries, self.entries, self.manage_button):
            widget.setEnabled(not busy)
        self.import_button.setEnabled(not busy and not self.library.read_only)
        self.attach_button.setEnabled(not busy and bool(self.library.items) and not self.library.read_only)
        self.save_button.setEnabled(not busy and self.current_article is not None and not self.dock.vocabulary.read_only)
        self.dock.save_button.setEnabled(not busy and bool(self.dock.current_result and self.dock.current_result.entries)
                                         and not self.dock.vocabulary.read_only)

    def cancel_import(self):
        self._cancel_requested = True
        if self.thread:
            self.thread.requestInterruption()
        self.hint.setText('已请求取消；原词典不会被未完成的索引覆盖。')

    @Slot(str)
    def on_progress(self, text: str):
        if self.progress:
            self.progress.setLabelText(text)

    @Slot(object, str)
    def on_completed(self, plan, error: str):
        self._completed_plan, self._completed_error = plan, error

    @Slot()
    def on_finished(self):
        thread, self.thread = self.thread, None
        cancelled = self._cancel_requested or bool(thread and thread.isInterruptionRequested())
        if thread:
            thread.deleteLater()
        if self.progress:
            self.progress.close()
            self.progress.deleteLater()
            self.progress = None
        plan, error = self._completed_plan, self._completed_error
        self._completed_plan = None
        if plan is not None:
            try:
                if cancelled:
                    raise MdictError('已取消导入，原词库保持不变。')
                self.library.commit(plan)
                self.hint.setText(f'已导入 {plan.title}：{plan.count:,} 个词头、{plan.resource_count:,} 个资源索引。')
            except (MdictError, OSError, ValueError, sqlite3.Error) as exc:
                error = str(exc) if cancelled else report_import_failure(
                    exc, self.dock.data_directory, Path(plan.mdx_path), '登记 MDX 词典索引')
            finally:
                plan.staged_path.unlink(missing_ok=True)
        self._set_busy_controls(False)
        self.refresh_dictionaries()
        if error:
            self.hint.setText(error)
            if not error.startswith('已取消'):
                QMessageBox.warning(self, 'MDX 导入未完成', error)
        elif self.query:
            self.dock.lookup(self.query, self.context, self.book_title)

    def manage_dictionaries(self):
        if self.dock.busy:
            return
        dialog = QDialog(self)
        dialog.setWindowTitle('MDX 词典管理')
        dialog.resize(640, 390)
        layout = QVBoxLayout(dialog)
        tip = QLabel('勾选启用；移除只删除本软件的索引，不删除原 MDX / MDD 文件。')
        tip.setWordWrap(True)
        layout.addWidget(tip)
        listing = QListWidget()
        layout.addWidget(listing, 1)
        def reload():
            listing.clear()
            for record in self.library.items:
                item = QListWidgetItem(f'{record["title"]}  ·  {record.get("count",0):,} 词头  ·  {len(record["mdd_paths"])} 个 MDD')
                item.setData(Qt.ItemDataRole.UserRole, record['id'])
                item.setToolTip(record['mdx_path'] + '\n' + '\n'.join(record['mdd_paths']))
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Checked if record.get('enabled', True) else Qt.CheckState.Unchecked)
                listing.addItem(item)
        reload()
        row = QHBoxLayout()
        remove = QPushButton('移除所选')
        reindex = QPushButton('重建所选索引')
        row.addWidget(remove)
        row.addWidget(reindex)
        layout.addLayout(row)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        layout.addWidget(buttons)
        def remove_selected():
            item = listing.currentItem()
            if item is None:
                return
            if QMessageBox.question(dialog, '移除词典', '移除此词典索引？原文件和生词本保持不变。',
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                    QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
                return
            try:
                self.library.remove(item.data(Qt.ItemDataRole.UserRole))
                reload()
            except (MdictError, OSError) as exc:
                QMessageBox.warning(dialog, '无法移除', str(exc))
        def rebuild():
            item = listing.currentItem()
            if item:
                record = next(x for x in self.library.items if x['id'] == item.data(Qt.ItemDataRole.UserRole))
                dialog.reject()
                self.start_import(Path(record['mdx_path']), [Path(p) for p in record['mdd_paths']])
        def save():
            try:
                updates = {listing.item(i).data(Qt.ItemDataRole.UserRole): listing.item(i).checkState() == Qt.CheckState.Checked
                           for i in range(listing.count())}
                self.library._save([dict(x, enabled=updates.get(x['id'], True)) for x in self.library.items])
                dialog.accept()
            except (MdictError, OSError) as exc:
                QMessageBox.warning(dialog, '无法保存', str(exc))
        remove.clicked.connect(remove_selected)
        reindex.clicked.connect(rebuild)
        buttons.accepted.connect(save)
        buttons.rejected.connect(dialog.reject)
        if self.library.read_only:
            remove.setEnabled(False)
            reindex.setEnabled(False)
            buttons.button(QDialogButtonBox.StandardButton.Save).setEnabled(False)
        dialog.exec()
        self.refresh_dictionaries()
        self.rerun_lookup()

    def shutdown(self):
        self.stop_audio()
        self.browser._resize_timer.stop()
        self.library.close()
