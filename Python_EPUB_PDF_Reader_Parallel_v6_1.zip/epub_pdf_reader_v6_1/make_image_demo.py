"""Create a local regression EPUB: bitmap, SVG, inline data and scrolling."""
from __future__ import annotations

import base64
from pathlib import Path
import struct
from urllib.parse import quote
import zlib

from make_demo import banner_png, sample_files, write_epub, xhtml


def large_png() -> bytes:
    width, height = 1600, 480
    rows = bytearray()
    for y in range(height):
        rows.append(0)
        for x in range(width):
            border = x < 8 or x >= width - 8 or y < 8 or y >= height - 8
            rows.extend((35, 70, 90) if border else (230 - x * 60 // width, 220 - y * 50 // height, 175))
    def chunk(name, data):
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', zlib.crc32(name + data) & 0xffffffff)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(bytes(rows))) + chunk(b'IEND', b''))


def image_files():
    files = sample_files()
    files['OPS/package.opf'] = files['OPS/package.opf'].replace('在文字里散步', '图片与滚动检查 · 墨读 3.0')
    additions = (
        '<item id="wide" href="Images/wide.png" media-type="image/png"/>'
        '<item id="vector" href="Images/chart.svg" media-type="image/svg+xml"/>'
        '<item id="wrapped" href="Images/wrapper.svg" media-type="image/svg+xml"/>'
        '<item id="space" href="Images/' + quote('封 面.png') + '" media-type="image/png"/>'
    )
    files['OPS/package.opf'] = files['OPS/package.opf'].replace('</manifest>', additions + '</manifest>')
    files['OPS/Images/wide.png'] = large_png()
    files['OPS/Images/封 面.png'] = banner_png()
    files['OPS/Images/chart.svg'] = '''<svg xmlns="http://www.w3.org/2000/svg" width="600" height="240" viewBox="0 0 600 240">
    <rect width="600" height="240" fill="#eef5f7"/><text x="26" y="38" font-size="24" fill="#234756">Cash flow / SVG</text>
    <path d="M40 190 H560 M40 70 V190" fill="none" stroke="#294a58" stroke-width="3"/>
    <rect x="80" y="140" width="55" height="50" fill="#458d80"/><rect x="180" y="100" width="55" height="90" fill="#458d80"/>
    <rect x="280" y="80" width="55" height="110" fill="#458d80"/><rect x="380" y="60" width="55" height="130" fill="#458d80"/>
    <text x="465" y="170" font-size="20" fill="#234756">1 : 2.5</text></svg>'''
    files['OPS/Images/wrapper.svg'] = '''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 480 96">
    <image xlink:href="banner.png" width="480" height="96"/></svg>'''
    data_uri = 'data:image/png;base64,' + base64.b64encode(banner_png()).decode()
    files['OPS/Text/第一章.xhtml'] = xhtml('图片与滚动检查', '''
    <h1>图片与滚动检查 · 3.0</h1>
    <p>打开后，这个标题应停留在章节开头。不要操作鼠标，观察页面是否自行下滑。</p>
    <p>1. 宽图应完整显示左右边框，不拉伸、不超出正文宽度。</p><img src="../Images/wide.png"/>
    <p>2. 普通位图与中文空格路径。</p><img src="../Images/%E5%B0%81%20%E9%9D%A2.png"/>
    <p>3. SVG 矢量图。</p><img src="../Images/chart.svg"/>
    <p>4. SVG 封面包装（引用本地位图）。</p><img src="../Images/wrapper.svg"/>
    <p>5. 内联 SVG（保留长宽比）。</p><svg viewBox="0 0 480 96"><image xlink:href="../Images/banner.png" width="480" height="96"/></svg>
    <p>6. data URI 内嵌位图。</p><img src="''' + data_uri + '''" style="width:50%"/>
    <p>7. 以 object 引入的 SVG。</p><object data="../Images/chart.svg" type="image/svg+xml">回退文字</object>
    <p>在这里可双击 equity、duration、cash flow 试用金融词典。查词不应改变正文阅读位置。</p>'''
    + ''.join(f'<p>定位标记 {i:03d}：调整窗口、开关词典、调整字号或更换背景后，应仍在这一段附近。Reading marker {i:03d}. Assets, equity and cash flow.</p>' for i in range(1, 41)))
    return files


if __name__ == '__main__':
    output = Path(__file__).with_name('image_test.epub')
    write_epub(output, image_files())
    print(f'已生成：{output}')
