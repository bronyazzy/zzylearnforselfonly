"""Build an original bilingual EPUB fixture; no third-party book content or fonts."""
from pathlib import Path
import struct
import zlib
import zipfile

ROOT=Path(__file__).resolve().parent

def png():
    width,height=720,180
    raw=bytearray()
    for y in range(height):
        raw.append(0)
        for x in range(width):
            border=x<5 or y<5 or x>=width-5 or y>=height-5
            raw.extend((25,65,80) if border else (205+int(x/width*35),224,230))
    def chunk(tag,data):return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')


def build(destination=ROOT/'parallel_demo.epub'):
    style='''body{font-family:serif;margin:28px;line-height:1.7}h1{font-size:1.6em}.parallel-row{display:table;width:100%;table-layout:fixed;margin-bottom:1.2em}.parallel-row>.bi-en,.parallel-row>.bi-zh{display:table-cell;width:50%;vertical-align:top;box-sizing:border-box}.bi-en{padding-right:18px}.bi-zh{padding-left:18px;border-left:1px solid #aaa}img{max-width:100%;height:auto}td,th{border:1px solid #888;padding:8px}.grid-demo{display:grid;grid-template-columns:1fr 1fr;gap:20px}.grid-demo>div{border:1px solid #aaa;padding:18px}'''
    rows=[]
    for i in range(1,41):
        rows.append(f'''<p id="pair-{i}"><span class="parallel-row"><span class="bi-en" lang="en">Pair {i}. Read the English paragraph on the left and its Chinese counterpart on the right. Try selecting <b>equity</b>, <b>cash flow</b>, or <b>duration</b>. A longer paragraph must not shift the next pair out of alignment.</span><span class="bi-zh" lang="zh-CN">第 {i} 组：左边是英文，右边是对应中文。两侧长度可以不同，但下一组从同一高度开始。双击英文词语可以使用金融词典。</span></span></p>''')
    first='''<h1><span class="parallel-row"><span class="bi-en" lang="en">Parallel reading check</span><span class="bi-zh" lang="zh">左右对照检查书</span></span></h1><p>原创测试资料，不是第三方书籍。可试用原书、左右、上下和单语模式。</p><p><a href="second.xhtml">第二章：图片与表格</a> · <a href="#pair-20">跳到第 20 组</a></p>'''+''.join(rows)
    second='''<h1>Pictures, tables and original CSS / 图片、表格与原书样式</h1><p><a href="first.xhtml#pair-20">返回第一章第 20 组</a></p><figure><img src="panel.png" alt="边框完整性测试图"/><figcaption><span class="parallel-row"><span class="bi-en" lang="en">Both edges of the picture should remain visible.</span><span class="bi-zh" lang="zh">缩放时，图片两侧边框应完整可见。</span></span></figcaption></figure><div class="grid-demo"><div>Original CSS Grid</div><div>原书 CSS 网格布局</div></div><p>下表可以在表格内部横向滚动，不应挤破正文：</p><table style="min-width:1600px"><tr><th>Label / 标签</th><th>Sample / 示例</th><th>Notes / 说明</th></tr><tr><td>equity</td><td>权益</td><td>仅用于查询测试</td></tr></table><p>Native MathML / 公式：</p><math xmlns="http://www.w3.org/1998/Math/MathML"><mfrac><mi>a</mi><mi>b</mi></mfrac></math><object data="shape.svg" type="image/svg+xml"></object>'''
    def chapter(body):return f'''<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Parallel demo</title><link rel="stylesheet" href="layout.css"/></head><body>{body}</body></html>'''
    opf='''<?xml version="1.0"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="id"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="id">modu-original-parallel-demo-6</dc:identifier><dc:title>左右对照检查书 · 墨读 6.0</dc:title><dc:language>zh</dc:language><dc:creator>墨读测试资料</dc:creator></metadata><manifest><item id="first" href="first.xhtml" media-type="application/xhtml+xml"/><item id="second" href="second.xhtml" media-type="application/xhtml+xml"/><item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/><item id="css" href="layout.css" media-type="text/css"/><item id="png" href="panel.png" media-type="image/png"/><item id="svg" href="shape.svg" media-type="image/svg+xml"/></manifest><spine><itemref idref="first"/><itemref idref="second"/></spine></package>'''
    nav='''<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"><head><title>目录</title></head><body><nav epub:type="toc"><ol><li><a href="first.xhtml">第一章：左右对照</a></li><li><a href="second.xhtml">第二章：图片与表格</a></li></ol></nav></body></html>'''
    destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('mimetype','application/epub+zip',compress_type=zipfile.ZIP_STORED)
        z.writestr('META-INF/container.xml','<container xmlns="urn:oasis:names:tc:opendocument:xmlns:container" version="1.0"><rootfiles><rootfile full-path="OPS/book.opf" media-type="application/oebps-package+xml"/></rootfiles></container>')
        z.writestr('OPS/book.opf',opf);z.writestr('OPS/nav.xhtml',nav)
        z.writestr('OPS/first.xhtml',chapter(first));z.writestr('OPS/second.xhtml',chapter(second))
        z.writestr('OPS/layout.css',style);z.writestr('OPS/panel.png',png())
        z.writestr('OPS/shape.svg','<svg xmlns="http://www.w3.org/2000/svg" width="500" height="100" viewBox="0 0 500 100"><rect x="2" y="2" width="496" height="96" fill="#e6f1e7" stroke="#345a62" stroke-width="4"/><circle cx="80" cy="50" r="25" fill="#5b9ea0"/></svg>')
    return destination

if __name__=='__main__':print(build())
