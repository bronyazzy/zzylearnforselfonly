#!/usr/bin/env python3
"""Verify shipped files against MANIFEST.json (accidental damage check, not signing)."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys


def main() -> int:
    root = Path(__file__).resolve().parent
    try:
        manifest = json.loads((root / 'MANIFEST.json').read_text(encoding='utf-8'))
        failed = []
        for item in manifest['files']:
            path = (root / item['path']).resolve()
            if root not in path.parents or not path.is_file():
                failed.append(item['path'])
                continue
            data = path.read_bytes()
            if len(data) != item['size'] or hashlib.sha256(data).hexdigest() != item['sha256']:
                failed.append(item['path'])
        if failed:
            print('以下文件缺失或与分发版本不同：\n' + '\n'.join(failed))
            return 1
        print(f"已核对 {len(manifest['files'])} 个文件，全部匹配。")
        print('此清单用于发现下载 / 解压损坏，不是数字签名。修改源码后出现不匹配是正常的。')
        return 0
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f'无法验证项目文件：{exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
