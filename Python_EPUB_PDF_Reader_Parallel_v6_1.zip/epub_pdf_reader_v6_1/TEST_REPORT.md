# 实际测试记录 · 墨读 6.1 · 空白正文修复

日期：2026-09-22。旧版报告存为 `TEST_REPORT_V6_HISTORY.md`，不是本轮运行结果。

## 环境与本次测试总数

Linux，Python 3.13.5，SQLite 3.46.1；defusedxml、lxml、pypdfium2 5.8.0 / PDFium 149.0.7825.0 可用。Playwright 驱动系统 Chromium 144.0.7559.96。系统 liblzo2 可用。

PySide6 不可用；重新尝试 pip 检索 Essentials 时返回 `No matching distribution found`，见 `diagnostics/QT_INSTALL_V6_1.txt`。没有运行 Qt6/PySide6 窗口，没有 Windows/macOS 实机。环境内虽然有 Qt5 Core/Widgets 动态库，但没有对应 Python 绑定/开发环境；不能用它冒充本项目的 Qt6 界面运行。

实际执行：

```bash
python -m unittest discover -s tests -v
```

```text
Ran 508 tests
OK (skipped=108)
```

**400 项实际通过，108 项跳过，0 项失败、0 项错误。不是 508 项全部通过。** 完整逐项输出是 `TEST_OUTPUT.txt`。

| 组别 | 本次执行结果 |
| --- | --- |
| 原 EPUB/词典/图片/设置/PDF/MDX/导入 I/O 等非 Qt 测试 | 300 项通过，重新运行而非引用历史数字 |
| 原书排版核心 `test_publisher_core.py` | 32 项通过 |
| 原书生产 HTML/CSS/JS 的真实 Chromium 测试 | 16 项通过；资源内联，不是 Qt 自定义 URL 投递 |
| 新 `test_display_recovery.py` | 52 项通过：地址、备用正文、列内图片几何、日志、真实方法的控制流回归 |
| 原有 Qt GUI 测试 | 94 项跳过 |
| 新 `test_display_native_gui.py` | 14 项跳过：真实 QUrl、QTextDocument 双栏、窗口、切换、书签与 EPUB/PDF 联动 |

其中 52 项新测试包含计时器、窗口、信号的替身；用 AST 取得生产方法体来检查控制流，不是用模拟结果冒充 Qt 渲染。新增测试的本次逐项状态以 TEST_OUTPUT 为准。

## 关键错误及修复验证

旧 URL 主机名为 64 个十六进制字符的单一标签。Python IDNA 编码器拒绝旧标签，接受新标签；完整摘要可由新主机名重构，原 `book_id` 不改变。测试涵盖中文/空格/百分号/锚点往返、同书旧地址兼容、外书地址拒绝、正文资源与虚拟图片新地址、存储记录保留。

此外实际调用了本机**原生 Qt 5.15 Core 的 QUrl**，通过独立 C++ ABI 探针构造新旧地址：旧地址 `isValid()=false`，新地址 `isValid()=true`。原始输出是 `diagnostics/QT5_URL_PROBE.txt`。这个探针不是 PySide6、不是 Qt6、不是 WebEngine、不是整窗运行，不计入上述 400 项 unittest 通过数。Qt6 的相同限制另外核对了官方源码，出处见 FIX_6_1.md / SOURCES.md。

生产代码已在真正调用 `view.load()` 之前增加 QUrl 校验。当前环境无法执行该 Qt6 调用，但本机的 `check_display.py` 和新增 GUI 回归在装有 PySide6 的系统会调用它，而不是用字符串解析替代。

## 新恢复逻辑与备用正文

新测试实际解析二进制 EPUB，并以生产代码生成备用 HTML：明确的中英文标记转换为真实两列表格；标题、链接、锚点、中文、英文、图片引用保留；未知对应关系不猜测；空分隔页显示说明；不把 table 放在 p/span/标题等无效内联祖先下；宽度/内边距属性有界，脚本/书外图片仍过滤。

比例 30%–70% 及非法输入边界有检查。图片所在嵌套百分比表格的可用宽度、退出单元格后上下文恢复和小窗口下最小尺寸经过纯几何测试；真正 QTextDocument 的画像尺寸回归仍需 Qt 环境运行。

对生产恢复方法体进行控制流故障注入，验证失败时从书包重建非空正文，保留待恢复的比例/锚点，不把空缓存交给 native 视图；缺失 WebEngine、构造错误、出版方整理错误、重复/迟到回调、渲染退出、初始化失败、空页面、显示超时入口与 PDF 切换保护均覆盖。故意拒绝的链接导航不会把已成功显示的页面误判为失败。双重失败有可见错误文字，异常插入 HTML 时经过转义。

这些控制测试不证明真实 Qt 事件排序、15 秒计时精度、桌面菜单/鼠标或进程崩溃恢复。图形驱动或整个主进程崩溃也不可能由同进程计时器保证自动恢复。兼容启动脚本提供不导入 WebEngine 的另一条入口。

显示日志实际经过写入、追加、轮转、无法建立目录等测试。日志失败不覆盖原错误。兼容入口、依赖检查和全部脚本做过语法检查，Windows .bat 未原机执行。

## 用户提供的左右对照 EPUB

检查原文件 SHA-256：`53907d30624348142876a61fedfef7d1bd068f8b61a28a61bc5c06de936b2303`。原 EPUB 字节未改变，也不随软件分发。

本轮重新检查全部 **27 个 spine 阅读项**，原书资源服务可返回非空 HTML，兼容生成也非空；全部新主机名通过 IDNA 校验。`check_display.py` 明确报告 Qt 不可用，原生 QUrl 字段为 null，不把该字段记作原生通过。

27 项兼容输出在忽略空白的条件下正文与原 body 相同；总共识别 3,134 个明确配对单元，含目录/索引/前后资料。其中 **16 个正文章节有 1,991 个配对单元**，不能把这些单元称为自然段数或翻译数。兼容 HTML 未检测到表格留在 p/span/标题等无效祖先内。数据见 `diagnostics/USER_BOOK_COMPATIBLE_V6_1.json`。

还重新用真实 Chromium 检查原书引擎的这 16 章，每章分别 1440px / 600px，共 32 个组合；未检测到左右顶端/顺序异常或图片加载失败，正文规范化空白后保持一致。数据见 `USER_BOOK_BROWSER_V6_1.json`。这是生产 HTML/CSS/JS 资源内联测试，不是 Qt 自定义 URL 或 Windows 窗口验证。

兼容 HTML 第一章额外在 Chromium 中检查 32 个实际表格的几何并查看预览；此浏览器对 table 的排版不是 QTextDocument 渲染证明，预览没有伪装成 Qt 窗口截图。书中版权正文或预览图片没有打进项目包。

## 源码与打包

全部 **51 个 Python 文件**经过 compile 和 Python 3.10 语法级 AST 检查，不等于在 Python 3.10 解释器实际运行。生产 JS 通过 `node --check`；两个 macOS/Linux 启动脚本通过 `sh -n`。没有修改现有 PDF、MDX、CSV 数据格式。

完整包经 ZIP CRC 检查，重新解压，在独立副本中按 MANIFEST.json 核对逐文件 SHA-256，并重新执行全部 508 项测试。结果仍为 400 通过、108 跳过。清单用于损坏检查，不是数字签名。没有打包 .venv、缓存、用户书籍、个人阅读数据、商业词典或字体文件。

## 本机可复查

```bash
python -m pip install -r requirements.txt
python check_display.py parallel_demo.epub --output display_check.json
python -m unittest discover -s tests -v
python verify_package.py
python epub_reader.py --compatible-epub parallel_demo.epub
```

检查兼容启动下标题与中英文均出现、两列对齐、图片可见，静置不自行下滑；在原书模式检查页面实际加载、词典查词、目录/锚点和重复切换；PDF 与词典原功能也需目标系统检查。没有对所有出版商 CSS、商业 MDX、多 GB 词典或 Windows 显卡组合做穷尽验证。
