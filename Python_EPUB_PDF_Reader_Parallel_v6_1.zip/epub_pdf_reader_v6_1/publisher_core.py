"""Bounded, offline publication resources for the browser-based EPUB view.

Keep publisher CSS, classes, tables and bilingual structure. Strip active content
instead of flattening the book. No file extraction, network I/O or Qt dependency.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import html
import math
from pathlib import Path
import re
from urllib.parse import urlsplit

from lxml import etree, html as LH
from epub_core import EpubBook, EpubError, MAX_DOCUMENT_BYTES, decode_document
from image_support import ImageError, decode_data_image, raster_mime, sanitize_svg
from reader_settings import normalize_background, theme_colors

MAX_NODES = 120_000
MAX_CSS_BYTES = 4 * 1024 * 1024
MODES = {'publisher', 'parallel', 'stack', 'en', 'zh', 'simple', 'compatible'}
MODE_NAMES = {'publisher': '原书排版', 'parallel': '左右对照', 'stack': '上下对照',
              'en': '只看英文', 'zh': '只看中文', 'compatible': '兼容双栏', 'simple': '简化阅读'}
# Unknown elements are unwrapped, not reinterpreted as active browser elements.
HTML_TAGS = set(('html head body title style link a p div span section article main header footer '
 'aside nav figure figcaption h1 h2 h3 h4 h5 h6 b strong i em u s sub sup small big '
 'code pre kbd samp var blockquote q cite abbr address time mark del ins '
 'ol ul li dl dt dd table caption colgroup col thead tbody tfoot tr td th '
 'br hr img wbr ruby rt rp bdi bdo details summary').split())
SVG_TAGS = set(('svg g defs symbol use path rect circle ellipse line polyline polygon text tspan '
 'textpath lineargradient radialgradient stop clippath mask pattern image title desc').split())
MATH_TAGS = set(('math mrow mi mn mo ms mtext mspace mfrac msqrt mroot mstyle merror '
 'mpadded mphantom mfenced menclose msub msup msubsup munder mover munderover '
 'mmultiscripts mprescripts none mtable mtr mtd mlabeledtr semantics annotation').split())
DROP = set(('script iframe frame frameset embed applet form input button textarea select option '
 'audio video source track canvas template noscript foreignobject animate animatemotion '
 'animatetransform set annotation-xml').split())
ATTRS = set(('id class lang dir title role style href src alt width height colspan rowspan span '
 'start reversed type align valign border cellpadding cellspacing summary open scope headers '
 'datetime cite value abbr display xmlns viewbox preserveaspectratio x y x1 y1 x2 y2 '
 'cx cy r rx ry d points fill fill-rule fill-opacity stroke stroke-width stroke-opacity '
 'stroke-linecap stroke-linejoin stroke-dasharray opacity transform offset stop-color '
 'stop-opacity gradientunits gradienttransform patternunits patterntransform clip-path '
 'mask font-family font-size font-weight text-anchor dx dy lengthadjust textlength '
 'mathvariant mathsize mathcolor mathbackground encoding').split())
STYLE_BASE = '''
html { scroll-behavior:auto !important; }
* { animation:none!important; transition:none!important; scroll-behavior:auto!important; }
body { overflow-wrap:break-word; }
img { max-width:100%; object-fit:contain; }
figure { max-width:100%; }
[data-mr-table-wrap] { max-width:100%; overflow-x:auto; }
[data-mr-table-wrap] > table { margin-left:0; }
::selection { background:#acd4f7; color:#101b27; }
'''


def finite(value, default, low, high):
    try:
        n = float(value)
        return min(high, max(low, n)) if math.isfinite(n) else default
    except (ValueError, TypeError, OverflowError):
        return default


@dataclass(frozen=True)
class LayoutSettings:
    mode: str = 'publisher'
    english_percent: int = 50
    gutter: int = 24
    content_width: int = 0   # 0 = full available width; otherwise CSS pixels
    line_height: float = 0  # 0 = publisher setting
    use_theme: bool = True

    @classmethod
    def from_dict(cls, value):
        d = value if isinstance(value, dict) else {}
        return cls(d.get('mode') if isinstance(d.get('mode'), str) and d.get('mode') in MODES else 'publisher',
                   round(finite(d.get('english_percent'), 50, 30, 70)),
                   round(finite(d.get('gutter'), 24, 8, 64)),
                   round(finite(d.get('content_width'), 0, 0, 2400)),
                   finite(d.get('line_height'), 0, 0, 2.8),
                   d.get('use_theme', True) is not False)

    def as_dict(self):
        return asdict(self)


def clean_anchor(value):
    if not isinstance(value, dict):
        return None
    ident = str(value.get('id', ''))
    if not re.fullmatch(r'\d{0,8}', ident):
        ident = ''
    return {'id': ident, 'offset': finite(value.get('offset'), 0, -1e6, 1e6),
            'ratio': finite(value.get('ratio'), 0, 0, 1),
            'top': value.get('top') is True, 'bottom': value.get('bottom') is True,
            'x': finite(value.get('x'), 0, 0, 1e6), 'y': finite(value.get('y'), 0, 0, 1e8)}


def classes(node):
    return set(node.get('class', '').split())


def language(node):
    c = classes(node)
    if c & {'bi-en', 'parallel-en', 'toc-en'}:
        return 'en'
    if c & {'bi-zh', 'parallel-zh', 'toc-zh'}:
        return 'zh'
    lang = node.get('lang', node.get('xml:lang', '')).lower().split('-')[0]
    return lang if lang in {'en', 'zh'} else ''


def has_pair(node):
    kids = [c for c in node if isinstance(c.tag, str)]
    # Only explicit neighbouring language units. Never invent alignments.
    return (len(kids) == 2 and {language(c) for c in kids} == {'en', 'zh'}
            and not (node.text or '').strip()
            and not any((c.tail or '').strip() for c in kids))


def _tag(node):
    return str(node.tag).rsplit('}', 1)[-1].rsplit(':', 1)[-1].lower() if isinstance(node.tag, str) else ''


def _unwrap(node):
    if node.getparent() is not None:
        node.drop_tag()


def _drop(node):
    if node.getparent() is not None:
        node.drop_tree()


class PublisherResources:
    """The handler serves only this open archive under its own EPUB origin."""
    def __init__(self, book: EpubBook):
        self.book = book
        self.warnings: set[str] = set()
        self.pair_counts: dict[str, int] = {}
        self._chapter_cache: tuple[str, bytes] | None = None

    def accepts(self, url: str) -> bool:
        try:
            p = urlsplit(url)
            return p.scheme == 'epub' and p.netloc == self.book.url_host
        except ValueError:
            return False

    def local_url(self, base: str, value: str, *, link=False, image=False) -> str:
        value = value.strip()
        if value.startswith('#'):
            return value
        p = urlsplit(value)
        if link and p.scheme.lower() in {'http', 'https', 'mailto'}:
            return value  # navigation is separately confirmed by the host window
        if image and p.scheme.lower() == 'data':
            decode_data_image(value)  # type and length validation
            return value
        path, fragment = self.book.resolve(base, value)
        if path not in self.book._files:
            raise EpubError('书内资源不存在：' + path[:160])
        return self.book.url(path, fragment)

    def chapter(self, path: str) -> bytes:
        if self._chapter_cache is not None and self._chapter_cache[0] == path:
            return self._chapter_cache[1]
        if not self.book.is_document(path):
            raise EpubError('不是 EPUB 正文章节。')
        text = decode_document(self.book.read(path, MAX_DOCUMENT_BYTES))
        # HTML parser never fetches a DTD. Original declaration does not become an
        # executable element; HTML serialization expands XHTML's empty elements.
        parser = LH.HTMLParser(no_network=True, recover=True, remove_comments=True,
                               huge_tree=False, encoding='utf-8')
        try:
            root = LH.document_fromstring(text.encode('utf-8'), parser=parser)
        except (etree.ParserError, ValueError) as exc:
            raise EpubError('原书页面无法解析。') from exc
        if any('Excessive depth' in str(e) for e in parser.error_log):
            raise EpubError('章节嵌套过深，原书模式拒绝静默截断正文。')
        if len(list(root.iter())) > MAX_NODES:
            raise EpubError('单章元素过多，原书模式拒绝加载。')
        pairs = 0
        for node in list(root.iter()):
            if not isinstance(node.tag, str) or (node is not root and node.getparent() is None):
                continue
            tag = _tag(node)
            node.tag = tag
            if tag in DROP or tag in {'base', 'meta'}:
                _drop(node)
                continue
            if tag == 'object':
                src = node.get('data', '')
                try:
                    local = self.local_url(path, src, image=True)
                    resolved, _ = self.book.resolve(path, src)
                    if not self.book.is_image(resolved):
                        raise EpubError('非图片 object')
                    node.tag = 'img'; node.attrib.clear(); node.set('src', local)
                    for child in list(node): node.remove(child)
                    node.text = None; tag = 'img'
                except (EpubError, ImageError, ValueError):
                    _unwrap(node)
                    continue
            if tag not in HTML_TAGS | SVG_TAGS | MATH_TAGS:
                _unwrap(node)
                continue
            attrs = dict(node.attrib)
            node.attrib.clear()
            for key, value in attrs.items():
                key = key.lower()
                if key == 'xml:lang': key = 'lang'
                if key == 'xlink:href': key = 'href'
                if key not in ATTRS and not key.startswith('aria-'):
                    continue
                if len(value) > 2 * 1024 * 1024:
                    continue
                if key in {'href', 'src', 'cite'}:
                    try:
                        # Links to other entries may leave the origin only after confirmation.
                        value = self.local_url(path, value, link=tag == 'a', image=tag in {'img', 'image'})
                    except (EpubError, ImageError, ValueError, UnicodeError):
                        if key == 'src': self.warnings.add('已阻止缺失或书外图片')
                        continue
                if key == 'id' and value in {'mr-reader-style', 'mr-base-style'}:
                    continue
                node.set(key, value)
            if tag == 'link':
                if 'stylesheet' not in attrs.get('rel', '').lower().split() or not node.get('href'):
                    _drop(node); continue
                node.set('rel', 'stylesheet')
                if attrs.get('media'): node.set('media', attrs['media'][:500])
                node.set('type', 'text/css')
            if tag == 'img':
                node.set('loading', 'eager')
                node.set('decoding', 'sync')
                if not node.get('alt'): node.set('alt', '书中插图')
            if tag == 'style':
                # CSP allows styling only. Network, plugins and author scripts remain blocked.
                if len(node.text or '') > MAX_CSS_BYTES:
                    _drop(node); continue
                node.set('type', 'text/css')
            if has_pair(node):
                node.set('data-mr-pair', '1')
                for child in node:
                    child.set('data-mr-lang', language(child))
                pairs += 1
        # Child sanitization above removes untrusted data-*; mark pairs again after
        # all attributes have been processed so their language markers survive.
        for node in root.iter():
            if isinstance(node.tag, str) and has_pair(node):
                node.set('data-mr-pair', '1')
                for child in node: child.set('data-mr-lang', language(child))
        body = root.find('body')
        if body is None:
            body = LH.Element('body'); root.append(body)
        for i, node in enumerate(body.iter()):
            if _tag(node) in {'p','div','span','section','article','figure','h1','h2','h3','h4','h5','h6','li','td','th','img','table'}:
                node.set('data-mr-id', str(i))
        # Overflow belongs to the individual wide table, not both language columns.
        for table in list(body.iter('table')):
            parent = table.getparent()
            if parent is not None and not any(_tag(a) == 'table' for a in table.iterancestors()):
                if 'table-scroll' in classes(parent):
                    parent.set('data-mr-table-wrap', '1')
                else:
                    index = parent.index(table); tail = table.tail; table.tail = None
                    wrap = LH.Element('div', {'data-mr-table-wrap':'1'})
                    parent.remove(table); parent.insert(index, wrap); wrap.append(table); wrap.tail = tail
        head = root.find('head')
        if head is None:
            head = LH.Element('head'); root.insert(0, head)
        csp = ("default-src 'none'; script-src 'none'; style-src 'self' 'unsafe-inline'; "
               "img-src 'self' data:; font-src 'self'; connect-src 'none'; frame-src 'none'; "
               "object-src 'none'; media-src 'none'; base-uri 'none'; form-action 'none'")
        head.insert(0, LH.Element('meta', charset='utf-8'))
        head.insert(1, LH.Element('meta', {'http-equiv':'Content-Security-Policy','content':csp}))
        head.insert(2, LH.Element('meta', {'name':'viewport','content':'width=device-width, initial-scale=1'}))
        style = LH.Element('style', {'id':'mr-base-style'}); style.text = STYLE_BASE; head.append(style)
        theme = LH.Element('style', {'id':'mr-reader-style'}); head.append(theme)
        result = b'<!DOCTYPE html>\n' + LH.tostring(root, encoding='utf-8', method='html')
        self.pair_counts[path] = len(root.xpath('//*[@data-mr-pair]'))
        self._chapter_cache = path, result
        return result

    def serve(self, url: str) -> tuple[str, bytes]:
        if not self.accepts(url):
            raise EpubError('资源不属于当前 EPUB。')
        path, _ = self.book.resolve(self.book.chapters[0].path, url)
        if self.book.is_document(path):
            return 'text/html', self.chapter(path)
        item = self.book.resources.get(path)
        declared = item.media_type if item else ''
        suffix = Path(path).suffix.lower()
        if declared == 'text/css' or suffix == '.css':
            data = self.book.read(path, MAX_CSS_BYTES)
            return 'text/css', decode_document(data).encode('utf-8')
        if self.book.is_image(path):
            data = self.book.read(path)
            kind = raster_mime(data)
            if kind:
                return kind, data
            return 'image/svg+xml', sanitize_svg(data, lambda src: self.book.local_image_bytes(path, src))
        font_mime = {'.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf','.otf':'font/otf'}
        if suffix in font_mime and (declared.startswith('font/') or 'font' in declared):
            return font_mime[suffix], self.book.read(path, 16 * 1024 * 1024)
        raise EpubError('原书模式不加载这类资源。')


def appearance_payload(settings: LayoutSettings, background: str, font_size: int):
    bg = normalize_background(background)
    colors = theme_colors(bg)
    d = settings.as_dict()
    d.update({'background': bg, 'foreground': colors[2], 'border': colors[4], 'accent': colors[5],
              'fontSize': round(finite(font_size, 18, 12, 36))})
    return d
