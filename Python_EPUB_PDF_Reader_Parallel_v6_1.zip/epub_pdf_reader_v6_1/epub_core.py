"""EPUB parsing, reading-mode HTML and atomic JSON state; no GUI dependency."""
from __future__ import annotations

import hashlib
import html
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import posixpath
import re
import stat
import tempfile
from dataclasses import dataclass, field
from urllib.parse import quote, unquote, urlsplit
import zipfile

from defusedxml import ElementTree as SafeET
from defusedxml.common import DefusedXmlException
from xml.etree.ElementTree import ParseError

from image_support import (ImageError, is_image_candidate, decode_data_image, sanitize_svg)

MAX_FILES = 20_000
MAX_ITEM_BYTES = 32 * 1024 * 1024
MAX_DOCUMENT_BYTES = 8 * 1024 * 1024
MAX_TOTAL_BYTES = 512 * 1024 * 1024
HTML_TYPES = {"application/xhtml+xml", "text/html"}
RASTER_TYPES = {"image/jpeg", "image/png", "image/gif", "image/webp", "image/bmp"}
EPUB_NS = "http://www.idpf.org/2007/ops"


class EpubError(Exception):
    """A user-facing EPUB validation or reading error."""


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def children(element, name: str):
    return [child for child in element if local_name(child.tag) == name]


def first(element, name: str):
    return next((node for node in element.iter() if local_name(node.tag) == name), None)


def element_text(element) -> str:
    return " ".join("".join(element.itertext()).split()) if element is not None else ""


def resolve_href(base: str, href: str, authority: str = "") -> tuple[str, str]:
    """Resolve an EPUB URL once, without allowing escape from the archive root."""
    try:
        parts = urlsplit(href)
        if parts.scheme not in ("", "epub"):
            raise EpubError("不允许访问书外资源。")
        if parts.netloc and (parts.scheme != "epub" or parts.netloc != authority):
            raise EpubError("不允许访问其他来源的资源。")
        relative = unquote(parts.path, errors="strict")
        fragment = unquote(parts.fragment, errors="strict")
    except (ValueError, UnicodeError) as exc:
        raise EpubError("书内链接格式无效。") from exc
    if "\\" in relative or "\0" in relative or "\0" in fragment:
        raise EpubError("书内路径包含非法字符。")
    if not relative:
        path = base
    elif relative.startswith("/"):
        path = posixpath.normpath(relative.lstrip("/"))
    else:
        path = posixpath.normpath(posixpath.join(posixpath.dirname(base), relative))
    if path in ("", ".", "..") or path.startswith("../") or ":" in path.split("/")[0]:
        raise EpubError("书内链接超出有效路径范围。")
    return path, fragment


@dataclass(frozen=True)
class Resource:
    identifier: str
    path: str
    media_type: str
    properties: frozenset[str] = frozenset()
    fallback: str = ""


@dataclass
class Chapter:
    path: str
    title: str


@dataclass
class TocEntry:
    title: str
    path: str = ""
    fragment: str = ""
    children: list[TocEntry] = field(default_factory=list)


def walk_toc(entries: list[TocEntry]):
    for entry in entries:
        yield entry
        yield from walk_toc(entry.children)


class EpubBook:
    """Keep the ZIP open and read requested resources in memory, never extract it."""

    def __init__(self, filename: str | Path):
        self.filename = Path(filename).expanduser().resolve()
        self.warnings: list[str] = []
        self.resources: dict[str, Resource] = {}
        self.embedded_images: dict[str, bytes] = {}
        self._embedded_bytes = 0
        self.manifest: dict[str, Resource] = {}
        self.chapters: list[Chapter] = []
        self.toc: list[TocEntry] = []
        self.title = self.filename.stem
        self.author = "未知作者"
        self._zip: zipfile.ZipFile | None = None
        try:
            self._zip = zipfile.ZipFile(self.filename)
            self._validate_archive()
            self._check_encryption()
            self._load_package()
        except EpubError:
            self.close()
            raise
        except (OSError, zipfile.BadZipFile, RuntimeError, NotImplementedError) as exc:
            self.close()
            raise EpubError(f"无法读取 EPUB：{exc}") from exc
        except Exception:
            self.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.close()

    def close(self):
        if self._zip is not None:
            self._zip.close()
            self._zip = None

    def _validate_archive(self):
        assert self._zip is not None
        infos = self._zip.infolist()
        if len(infos) > MAX_FILES:
            raise EpubError(f"书籍资源过多，最多允许 {MAX_FILES} 个条目。")
        self._files: dict[str, zipfile.ZipInfo] = {}
        total = 0
        for info in infos:
            name = info.filename
            if (name.startswith("/") or "\\" in name or "\0" in name
                    or ".." in name.split("/") or ":" in name.split("/")[0]
                    or posixpath.normpath(name) != name.rstrip("/")):
                raise EpubError(f"EPUB 包含不安全的资源路径：{name[:120]}")
            if stat.S_ISLNK(info.external_attr >> 16):
                raise EpubError("EPUB 包含不支持的符号链接。")
            if info.flag_bits & 1:
                raise EpubError("不支持加密的 ZIP/EPUB 文件。")
            if info.is_dir():
                continue
            if name in self._files:
                raise EpubError(f"EPUB 包含重复资源路径：{name[:120]}")
            if info.file_size > MAX_ITEM_BYTES:
                raise EpubError("单个资源超过 32 MiB，本阅读器为控制内存占用拒绝打开。")
            total += info.file_size
            if total > MAX_TOTAL_BYTES:
                raise EpubError("书籍解压后超过 512 MiB，本阅读器暂不支持。")
            self._files[name] = info
        digest = hashlib.sha256()
        for name, info in sorted(self._files.items()):
            digest.update(json.dumps([name, info.CRC, info.file_size], ensure_ascii=True).encode())
        self.book_id = digest.hexdigest()
        if "META-INF/container.xml" not in self._files:
            raise EpubError("未找到 META-INF/container.xml，这不是有效的 EPUB 文件。")
        if "mimetype" not in self._files or self.read("mimetype", 128).strip() != b"application/epub+zip":
            self.warnings.append("mimetype 缺失或不规范；已尝试按 EPUB 读取。")

    def read(self, path: str, limit: int = MAX_ITEM_BYTES) -> bytes:
        if self._zip is None:
            raise EpubError("书籍已经关闭。")
        info = self._files.get(path)
        if info is None:
            raise EpubError(f"找不到书内资源：{path[:160]}")
        if info.file_size > limit:
            raise EpubError(f"资源超过读取上限：{path[:160]}")
        try:
            with self._zip.open(info) as stream:
                data = stream.read(limit + 1)
            if len(data) > limit:
                raise EpubError("资源实际大小超过读取上限。")
            return data
        except (OSError, zipfile.BadZipFile, RuntimeError, NotImplementedError) as exc:
            raise EpubError(f"资源损坏或压缩方式不受支持：{path[:160]}") from exc

    def _xml(self, path: str):
        try:
            return SafeET.fromstring(self.read(path, MAX_DOCUMENT_BYTES))
        except (ParseError, DefusedXmlException) as exc:
            raise EpubError(f"XML 格式错误或包含不安全的实体：{path[:160]}") from exc

    def _check_encryption(self):
        if "META-INF/encryption.xml" not in self._files:
            return
        root = self._xml("META-INF/encryption.xml")
        font_algorithms = {
            "http://www.idpf.org/2008/embedding",
            "http://ns.adobe.com/pdf/enc#RC",
        }
        for entry in root.iter():
            if local_name(entry.tag) != "EncryptedData":
                continue
            method = first(entry, "EncryptionMethod")
            algorithm = method.get("Algorithm", "") if method is not None else ""
            if algorithm not in font_algorithms:
                raise EpubError("这本书含有 DRM 或不支持的加密资源，无法打开；本程序不移除 DRM。")
        self.warnings.append("检测到字体混淆；阅读时改用系统字体，不读取内嵌字体。")

    @property
    def url_host(self) -> str:
        """A QUrl-valid origin, without changing the persistent book identifier.

        A SHA-256 hex digest is 64 characters: too long for one IDNA/DNS label.
        Keep all 256 bits, but split into two alphabetically-prefixed labels.
        The epub scheme is handled only in memory, never resolved through DNS.
        """
        return f"b{self.book_id[:32]}.b{self.book_id[32:]}.epub"

    def resolve(self, base: str, href: str) -> tuple[str, str]:
        # Accept an old internal URL only for this same book. New output always
        # uses url_host. State keys/bookmarks still use book_id and chapter paths.
        try:
            authority = self.book_id if urlsplit(href).netloc == self.book_id else self.url_host
        except ValueError as exc:
            raise EpubError("书内链接格式无效。") from exc
        return resolve_href(base, href, authority)

    def url(self, path: str, fragment: str = "") -> str:
        return f"epub://{self.url_host}/{quote(path, safe='/')}" + (
            "#" + quote(fragment, safe="") if fragment else ""
        )

    def _load_package(self):
        container = self._xml("META-INF/container.xml")
        roots = [x for x in container.iter() if local_name(x.tag) == "rootfile"]
        if not roots:
            raise EpubError("EPUB 没有声明内容包。")
        preferred = next((x for x in roots if x.get("media-type") == "application/oebps-package+xml"), roots[0])
        raw_path = preferred.get("full-path", "")
        if not raw_path:
            raise EpubError("内容包路径为空。")
        # container.xml full-path is a container path, not a percent-encoded URL.
        if raw_path not in self._files:
            raise EpubError("EPUB 声明的内容包不存在。")
        self.opf_path = raw_path
        package = self._xml(self.opf_path)
        metadata = first(package, "metadata")
        if metadata is not None:
            self.title = element_text(first(metadata, "title")) or self.title
            authors = [element_text(x) for x in metadata if local_name(x.tag) == "creator"]
            self.author = "、".join(x for x in authors if x) or self.author
            if any(x.get("property") == "rendition:layout" and element_text(x) == "pre-paginated"
                   for x in metadata):
                self.warnings.append("这是固定版式书籍；本版只提供简化阅读排版。")
        manifest = first(package, "manifest")
        spine = first(package, "spine")
        if manifest is None or spine is None:
            raise EpubError("EPUB 缺少 manifest 或 spine。")
        for item in children(manifest, "item"):
            identifier, href = item.get("id", ""), item.get("href", "")
            if not identifier or not href:
                continue
            if identifier in self.manifest:
                raise EpubError(f"重复的 manifest id：{identifier[:80]}")
            try:
                path, _ = self.resolve(self.opf_path, href)
            except EpubError:
                self.warnings.append(f"跳过非本地或无效资源：{identifier[:80]}")
                continue
            resource = Resource(identifier, path, item.get("media-type", ""),
                                frozenset(item.get("properties", "").split()), item.get("fallback", ""))
            self.manifest[identifier] = resource
            self.resources[path] = resource
        itemrefs = children(spine, "itemref")
        linear = [ref for ref in itemrefs if ref.get("linear", "yes").lower() != "no"]
        for ref in linear or itemrefs:
            resource = self.manifest.get(ref.get("idref", ""))
            visited: set[str] = set()
            while resource is not None and resource.media_type not in HTML_TYPES:
                if resource.identifier in visited:
                    resource = None
                    break
                visited.add(resource.identifier)
                resource = self.manifest.get(resource.fallback)
            if resource is None or resource.path not in self._files:
                self.warnings.append(f"跳过无法显示的 spine 条目：{ref.get('idref', '')[:80]}")
                continue
            self.chapters.append(Chapter(resource.path, f"第 {len(self.chapters) + 1} 章"))
        if not self.chapters:
            raise EpubError("未找到可读取的 HTML/XHTML 正文章节。")
        self._load_toc(spine.get("toc", ""))
        titles: dict[str, str] = {}
        for entry in walk_toc(self.toc):
            if entry.path and (entry.path not in titles or not entry.fragment):
                titles[entry.path] = entry.title
        for chapter in self.chapters:
            chapter.title = titles.get(chapter.path, chapter.title)
        if not self.toc:
            self.toc = [TocEntry(chapter.title, chapter.path) for chapter in self.chapters]

    def is_document(self, path: str) -> bool:
        return path in self._files and path in self.resources and self.resources[path].media_type in HTML_TYPES

    def _target(self, base: str, href: str) -> tuple[str, str]:
        if not href:
            return "", ""
        try:
            path, fragment = self.resolve(base, href)
            return (path, fragment) if self.is_document(path) else ("", "")
        except EpubError:
            return "", ""

    def _load_toc(self, ncx_id: str):
        nav = next((x for x in self.manifest.values() if "nav" in x.properties), None)
        if nav is not None:
            try:
                root = self._xml(nav.path)
                toc = next((x for x in root.iter() if local_name(x.tag) == "nav"
                            and ("toc" in x.get(f"{{{EPUB_NS}}}type", "").split()
                                 or x.get("role") == "doc-toc")), None)
                if toc is not None:
                    ol = first(toc, "ol")
                    if ol is not None:
                        self.toc = self._nav_items(ol, nav.path)
            except EpubError as exc:
                self.warnings.append(f"EPUB 3 目录读取失败，尝试后备目录：{exc}")
        if self.toc and any(x.path for x in walk_toc(self.toc)):
            return
        self.toc = []
        ncx = self.manifest.get(ncx_id) or next(
            (x for x in self.manifest.values() if x.media_type == "application/x-dtbncx+xml"), None)
        if ncx is not None:
            try:
                navmap = first(self._xml(ncx.path), "navMap")
                if navmap is not None:
                    self.toc = self._ncx_items(navmap, ncx.path)
            except EpubError as exc:
                self.warnings.append(f"NCX 目录读取失败，改用正文顺序：{exc}")
        if not any(x.path for x in walk_toc(self.toc)):
            self.toc = []

    def _nav_items(self, ol, base: str, depth: int = 0) -> list[TocEntry]:
        if depth > 32:
            raise EpubError("目录嵌套层数超过上限。")
        output = []
        for li in children(ol, "li"):
            label = next((x for x in li if local_name(x.tag) in {"a", "span"}), None)
            path, fragment = self._target(base, label.get("href", "") if label is not None else "")
            entry = TocEntry(element_text(label) or "未命名章节", path, fragment)
            for nested in children(li, "ol"):
                entry.children.extend(self._nav_items(nested, base, depth + 1))
            if entry.path or entry.children:
                output.append(entry)
        return output

    def _ncx_items(self, parent, base: str, depth: int = 0) -> list[TocEntry]:
        if depth > 32:
            raise EpubError("目录嵌套层数超过上限。")
        output = []
        for point in children(parent, "navPoint"):
            content = next(iter(children(point, "content")), None)
            label = next(iter(children(point, "navLabel")), None)
            path, fragment = self._target(base, content.get("src", "") if content is not None else "")
            nested = self._ncx_items(point, base, depth + 1)
            if path or nested:
                output.append(TocEntry(element_text(label) or "未命名章节", path, fragment, nested))
        return output

    def is_image(self, path: str) -> bool:
        resource = self.resources.get(path)
        return path in self._files and is_image_candidate(path, resource.media_type if resource else "")

    def image_url(self, base: str, source: str) -> str:
        if source.lower().startswith("data:"):
            return self.register_image(decode_data_image(source))
        path, _ = self.resolve(base, source)
        if not self.is_image(path):
            raise ImageError("图片未收录、格式不支持或路径不存在")
        return self.url(path)

    def register_image(self, data: bytes) -> str:
        key = hashlib.sha256(data).hexdigest()
        url = f"epubimg://{self.url_host}/{key}"
        if url not in self.embedded_images:
            if self._embedded_bytes + len(data) > 32 * 1024 * 1024:
                raise ImageError("本书内嵌图片缓存超过 32 MiB")
            self.embedded_images[url] = data
            self._embedded_bytes += len(data)
        return url

    def local_image_bytes(self, base: str, source: str) -> bytes:
        try:
            path, _ = self.resolve(base, source)
            if not self.is_image(path):
                raise ImageError("不是书内图片")
            return self.read(path)
        except EpubError as exc:
            raise ImageError(str(exc)) from exc

    def chapter_html(self, path: str) -> str:
        if not self.is_document(path):
            raise EpubError("该资源不是可显示的章节。")
        parser = ReadingHTML(self, path)
        try:
            parser.feed(decode_document(self.read(path, MAX_DOCUMENT_BYTES)))
            parser.close()
        except (ValueError, RecursionError) as exc:
            raise EpubError("章节 HTML 无法解析。") from exc
        return "<html><body>" + "".join(parser.output) + "</body></html>"


def decode_document(data: bytes) -> str:
    """EPUB uses Unicode. Also tolerate some legacy HTML encoding declarations."""
    import re
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16", errors="replace")
    declared = re.search(br'(?:encoding\s*=\s*[\'"]|charset\s*=\s*[\'\"]?)([\w-]+)', data[:1024], re.I)
    encodings = ["utf-8-sig"]
    if declared:
        encodings.insert(0, declared.group(1).decode("ascii", errors="ignore"))
    for encoding in encodings:
        try:
            return data.decode(encoding)
        except (LookupError, UnicodeError):
            continue
    return data.decode("utf-8", errors="replace")


class ReadingHTML(HTMLParser):
    """A normalized reading view: preserve structure, discard publisher CSS/scripts."""

    DROP = {"head", "script", "style", "iframe", "object", "form", "audio", "video", "noscript", "template"}
    VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "wbr", "image"}
    TAGS = {"p", "div", "span", "h1", "h2", "h3", "h4", "h5", "h6", "b", "strong", "i", "em", "u", "s",
            "sub", "sup", "code", "pre", "blockquote", "ol", "ul", "li", "table", "tr", "td", "th",
            "thead", "tbody", "tfoot", "br", "hr", "a", "dl", "dt", "dd"}
    TO_DIV = {"section", "article", "main", "header", "footer", "aside", "figure", "figcaption", "nav"}

    def __init__(self, book: EpubBook, path: str):
        super().__init__(convert_charrefs=True)
        self.book, self.path = book, path
        self.output: list[str] = []
        self.suppressed: list[str] = []
        self.svg_parts: list[str] = []
        self.svg_depth = 0

    def handle_starttag(self, tag: str, attrs):
        if self.svg_depth:
            self.svg_parts.append(self.get_starttag_text() or f"<{tag}>")
            if tag == "svg":
                self.svg_depth += 1
            return
        if tag == "svg" and not self.suppressed:
            self.svg_parts = [self.get_starttag_text() or "<svg>"]
            self.svg_depth = 1
            return
        if tag == "object" and not self.suppressed:
            values = dict(attrs)
            source = values.get("data") or ""
            if source:
                try:
                    url = self.book.image_url(self.path, source)
                    self.output.append(f'<img src="{html.escape(url, quote=True)}" alt="插图" />')
                except (EpubError, ImageError):
                    self.output.append("<span>［未显示嵌入对象］</span>")
        if tag in self.DROP:
            self.suppressed.append(tag)
            return
        if self.suppressed:
            return
        values = dict(attrs)
        anchor = values.get("id") or (values.get("name") if tag == "a" else None)
        if anchor:
            self.output.append(f'<a name="{html.escape(anchor, quote=True)}"></a>')
        if tag in {"img", "image"}:
            src = (values.get("src") or values.get("xlink:href") or values.get("href")
                   or values.get("data-src") or "")
            try:
                url = self.book.image_url(self.path, src)
                hints = {}
                for part in (values.get("style") or "").split(";"):
                    key, _, value = part.partition(":")
                    if key.strip().lower() in {"width", "height"}:
                        hints[key.strip().lower()] = value.strip()
                dimensions = ""
                for key in ("width", "height"):
                    value = hints.get(key) or values.get(key) or ""
                    if re.fullmatch(r"\d+(?:\.\d+)?(?:px|%)?", value.strip(), re.I):
                        dimensions += f' {key}="{value.strip()}"'
                self.output.append(f'<img src="{html.escape(url, quote=True)}"{dimensions} '
                                   f'alt="{html.escape(values.get("alt") or "插图", quote=True)}" />')
            except (EpubError, ImageError):
                self.output.append("<span>［未显示插图：" + html.escape(values.get("alt") or "不支持或非本地图片") + "］</span>")
            return
        tag = "div" if tag in self.TO_DIV else tag
        if tag not in self.TAGS:
            return
        safe: dict[str, str] = {}
        if tag == "a" and values.get("href"):
            href = values["href"]
            try:
                scheme = urlsplit(href).scheme.lower()
                if scheme in {"http", "https", "mailto"}:
                    safe["href"] = href
                else:
                    target, fragment = self.book.resolve(self.path, href)
                    if self.book.is_document(target):
                        safe["href"] = self.book.url(target, fragment)
            except (EpubError, ValueError):
                pass
        for key in ("colspan", "rowspan", "start"):
            value = values.get(key) or ""
            if value.isascii() and value.isdigit() and len(value) <= 4 and 0 < int(value) <= 1000:
                safe[key] = value
        if tag in {"table", "td", "th"}:
            width = (values.get("width") or "").strip()
            if re.fullmatch(r"(?:[1-9]\d{0,3}|100)(?:%)?", width):
                number = int(width.rstrip("%"))
                if number <= (100 if width.endswith("%") else 4000):
                    safe["width"] = width
            if values.get("valign") in {"top", "middle", "bottom"}:
                safe["valign"] = values["valign"]
        if tag == "table":
            for key in ("border", "cellspacing", "cellpadding"):
                value = values.get(key) or ""
                if value.isascii() and value.isdigit() and len(value) <= 2 and int(value) <= 32:
                    safe[key] = str(int(value))
        if values.get("align") in {"left", "right", "center", "justify"}:
            safe["align"] = values["align"]
        attributes = "".join(f' {key}="{html.escape(value, quote=True)}"' for key, value in safe.items())
        self.output.append(f"<{tag}{attributes}>")

    def handle_endtag(self, tag: str):
        if self.svg_depth:
            self.svg_parts.append(f"</{tag}>")
            if tag == "svg":
                self.svg_depth -= 1
                if not self.svg_depth:
                    self.flush_svg()
            return
        if tag in self.DROP:
            if tag in self.suppressed:
                index = len(self.suppressed) - 1 - self.suppressed[::-1].index(tag)
                del self.suppressed[index:]
            return
        if self.suppressed:
            return
        tag = "div" if tag in self.TO_DIV else tag
        if tag in self.TAGS and tag not in self.VOID:
            self.output.append(f"</{tag}>")

    def handle_startendtag(self, tag: str, attrs):
        if self.svg_depth:
            self.svg_parts.append(self.get_starttag_text() or f"<{tag} />")
            return
        if tag == "svg" and not self.suppressed:
            self.svg_parts = [self.get_starttag_text() or "<svg />"]
            self.flush_svg()
            return
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_data(self, data: str):
        if self.svg_depth:
            self.svg_parts.append(html.escape(data))
        elif not self.suppressed:
            self.output.append(html.escape(data))

    def flush_svg(self):
        try:
            data = sanitize_svg("".join(self.svg_parts).encode("utf-8"),
                                lambda src: self.book.local_image_bytes(self.path, src))
            url = self.book.register_image(data)
            self.output.append(f'<img src="{url}" alt="SVG 插图" />')
        except (ImageError, UnicodeError):
            self.output.append("<span>［未显示 SVG：格式无效或超出安全限制］</span>")
        self.svg_parts = []

    def close(self):
        super().close()
        if self.svg_depth:
            self.svg_depth = 0
            self.svg_parts = []
            self.output.append("<span>［未显示 SVG：标签不完整］</span>")


class StateStore:
    """Write progress atomically. Errors are reported, not silently discarded."""

    def __init__(self, filename: Path):
        self.filename = filename
        self.warning = ""
        self.data: dict = {"books": {}, "recent": [], "preferences": {}}
        try:
            if filename.exists():
                if filename.stat().st_size > MAX_DOCUMENT_BYTES:
                    raise ValueError("状态文件过大")
                loaded = json.loads(filename.read_text(encoding="utf-8"))
                if not isinstance(loaded, dict):
                    raise ValueError("状态文件结构错误")
                for key, expected in (("books", dict), ("recent", list), ("preferences", dict)):
                    if isinstance(loaded.get(key), expected):
                        self.data[key] = loaded[key]
        except (OSError, ValueError) as exc:
            self.warning = f"阅读记录未能载入，将从默认状态开始：{exc}"

    def save(self):
        self.filename.parent.mkdir(parents=True, exist_ok=True)
        temporary: str | None = None
        try:
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=self.filename.parent,
                                             prefix=".state-", suffix=".tmp", delete=False) as stream:
                temporary = stream.name
                json.dump(self.data, stream, ensure_ascii=False, indent=2, allow_nan=False)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.filename)
            temporary = None
        finally:
            if temporary is not None:
                try:
                    os.unlink(temporary)
                except OSError:
                    pass
