"""Native Qt/WebEngine tests. Skipped honestly when Qt is unavailable.

The offscreen root-only sandbox flag below is for tests, never the launcher.
"""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
if hasattr(os,'geteuid') and os.geteuid()==0:
    os.environ.setdefault('QTWEBENGINE_DISABLE_SANDBOX','1')
try:
    from PySide6.QtWidgets import QApplication
    from PySide6.QtTest import QTest
    from PySide6.QtCore import QUrl
    from epub_reader import EnhancedReaderWindow
    from epub_core import StateStore
    QT=True
except (ImportError,SystemExit):
    QT=False
ROOT=Path(__file__).resolve().parents[1]

@unittest.skipUnless(QT,'缺少 Qt / QtWebEngine，未执行原生界面测试')
class PublicationGuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.file=Path(self.temp.name)/'state.json'
        self.window=EnhancedReaderWindow(StateStore(self.file));self.window.show()
        self.assertTrue(self.window.open_book(str(ROOT/'parallel_demo.epub')))
        self.wait_ready();self.view=self.window.publication_view
    def tearDown(self):
        self.window.close();QTest.qWait(100);self.temp.cleanup()
    def wait_ready(self):
        for _ in range(160):
            QTest.qWait(50)
            if self.window.publication_view.ready:break
        self.assertTrue(self.window.publication_view.ready,'EPUB custom scheme / isolated host script did not initialize')
    def js(self,code):
        values=[];self.view.js(code,values.append)
        for _ in range(100):
            if values:break
            QTest.qWait(20)
        self.assertTrue(values);return values[0]
    def test_native_url_and_helpers_load(self):
        self.assertEqual(self.view.url().scheme(),'epub')
        self.assertEqual(self.js('window.__modu.info().pairs'),41)
    def test_original_css_produces_two_columns(self):
        data=self.js("[...document.querySelectorAll('[data-mr-lang]')].slice(0,2).map(n=>({y:n.getBoundingClientRect().y,x:n.getBoundingClientRect().x}))")
        self.assertAlmostEqual(data[0]['y'],data[1]['y'],delta=1);self.assertGreater(data[1]['x'],data[0]['x'])
    def test_no_downward_scroll_on_open(self):
        QTest.qWait(500);self.assertEqual(self.js('scrollY'),0)
    def test_mode_changes_without_reload(self):
        self.js('window.nativeTest=7');self.window.set_layout(mode='parallel',english_percent=42)
        QTest.qWait(100);self.assertEqual(self.js('window.nativeTest'),7)
    def test_switch_to_simple_and_back(self):
        self.window.set_layout(mode='simple');QTest.qWait(100)
        self.assertIs(self.window.document_stack.currentWidget(),self.window.browser)
        self.window.set_layout(mode='publisher');self.wait_ready()
        self.assertIs(self.window.document_stack.currentWidget(),self.window.publication_view)
    def test_theme_updates_real_page(self):
        self.window.set_background('#e6f1e7');QTest.qWait(100)
        self.assertEqual(self.js('getComputedStyle(document.body).backgroundColor'),'rgb(230, 241, 231)')
    def test_same_chapter_anchor_does_not_reload(self):
        self.js('window.nativeTest=9');self.window.navigate('OPS/first.xhtml',fragment='pair-20');QTest.qWait(100)
        self.assertEqual(self.js('window.nativeTest'),9);self.assertGreater(self.js('scrollY'),0)
    def test_next_chapter_and_package_images(self):
        self.window.change_chapter(1);self.wait_ready()
        self.assertEqual(self.window.current_path,'OPS/second.xhtml')
        self.assertEqual(self.js('window.__modu.info().missingImages'),0)
    def test_pdf_switch_and_dictionary_retained(self):
        dock=self.window.dictionary_dock
        self.assertTrue(self.window.open_book(str(ROOT/'pdf_demo.pdf')))
        self.assertIs(self.window.dictionary_dock,dock);self.assertIsNotNone(self.window.pdf_book)
        self.assertTrue(self.window.open_book(str(ROOT/'parallel_demo.epub')));self.wait_ready()
    def test_failed_open_preserves_current_book(self):
        old=self.window.book
        with patch('publisher_integration.QMessageBox.warning'):
            self.assertFalse(self.window.open_book(str(ROOT/'missing.epub')))
        self.assertIs(old,self.window.book)
        self.assertIs(self.window.document_stack.currentWidget(),self.view)
    def test_selection_reaches_dictionary(self):
        with patch.object(self.window.dictionary_dock,'lookup') as lookup:
            self.window._publication_lookup('equity','Read equity here.',True)
            lookup.assert_called_once_with('equity','Read equity here.',self.window.book.title)
    def test_mode_and_dom_anchor_persist(self):
        self.window.set_layout(mode='parallel',english_percent=43)
        self.view.go_to(ratio=.4);QTest.qWait(200);self.window.save_state()
        record=self.window.store.data['books'][self.window.book.book_id]
        self.assertEqual(record['epub_layout']['english_percent'],43)
        self.assertIn('epub_web_anchor',record);self.assertNotIn('viewport',record)
    def test_fullscreen_does_not_steal_escape_outside_focus(self):
        self.assertFalse(self.window._focus_exit_action.isEnabled())
        self.window.toggle_focus();QTest.qWait(100);self.assertTrue(self.window.isFullScreen())
        self.window.exit_focus();self.assertFalse(self.window._focus_exit_action.isEnabled())
    def test_external_resource_is_denied(self):
        self.assertFalse(self.view.resources.accepts('file:///etc/passwd'))
        self.assertFalse(self.view.resources.accepts('https://example.com/a.png'))
    def test_bookmark_keeps_dom_anchor(self):
        self.view.go_to(ratio=.3);QTest.qWait(150);self.window.add_bookmark();QTest.qWait(150)
        self.assertEqual(len(self.window.bookmarks),1)
        self.assertIsInstance(self.window.bookmarks[0]['web_anchor'],dict)

if __name__=='__main__':unittest.main()
