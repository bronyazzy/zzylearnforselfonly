"""Memory-only Chromium layout harness (NOT the native Qt transport).

The constrained test browser denies URL navigation. Inline resources returned by
production PublisherResources without changing body layout or the reader script.
No localhost server is used and no publication is uploaded.
"""
import base64
from lxml import html as LH
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def inline_fixture(resources,path):
    root=LH.fromstring(resources.chapter(path))
    for link in root.xpath('//link[@rel="stylesheet"]'):
        mime,css=resources.serve(link.get('href'))
        style=LH.Element('style');style.text=css.decode('utf-8')
        if link.get('media'):style.set('media',link.get('media'))
        link.getparent().replace(link,style)
    for image in root.xpath('//img[@src]'):
        if image.get('src').startswith('data:'):continue
        mime,data=resources.serve(image.get('src'))
        image.set('src','data:'+mime+';base64,'+base64.b64encode(data).decode())
    for image in root.xpath('//*[local-name()="image"][@href]'):
        if image.get('href').startswith(('data:','#')):continue
        mime,data=resources.serve(image.get('href'))
        image.set('href','data:'+mime+';base64,'+base64.b64encode(data).decode())
    return LH.tostring(root,encoding='unicode',method='html')


def load(page,resources,path,settings):
    page.goto('about:blank')
    page.set_content(inline_fixture(resources,path),wait_until='load')
    page.evaluate((ROOT/'assets/reader.js').read_text(encoding='utf-8'))
    page.evaluate('(s)=>window.__modu.settings(s,false)',settings)
    page.wait_for_timeout(60)


GEOMETRY='''()=>[...document.querySelectorAll('[data-mr-pair]')].map(n=>{
const e=n.querySelector(':scope>[data-mr-lang="en"]').getBoundingClientRect();
const z=n.querySelector(':scope>[data-mr-lang="zh"]').getBoundingClientRect();
return {ey:e.y,zy:z.y,ex:e.x,zx:z.x,ew:e.width,zw:z.width,eh:e.height,zh:z.height};})'''
