"""Qt-free control-flow tests using the actual ReaderWindow method AST.

Timers/widgets are test doubles. These tests do NOT prove Qt rendering behavior.
"""
import ast
from pathlib import Path
import unittest
from unittest.mock import Mock

from reader_settings import ViewPosition


def method_class():
    source = Path(__file__).resolve().parents[1] / 'epub_reader.py'
    module = ast.parse(source.read_text(encoding='utf-8'))
    reader = next(node for node in module.body if isinstance(node, ast.ClassDef) and node.name == 'ReaderWindow')
    reader.bases = [ast.Name(id='object', ctx=ast.Load())]
    test_module = ast.Module(body=[ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0), reader], type_ignores=[])
    ast.fix_missing_locations(test_module)
    environment = {'ViewPosition': ViewPosition}
    exec(compile(test_module, str(source), 'exec'), environment)
    return environment['ReaderWindow']


class ReaderControlTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reader = method_class()

    def make(self):
        w = self.reader.__new__(self.reader)
        w.book = object()
        w.current_path = 'chapter.xhtml'
        w.browser = Mock()
        w.browser.viewport().width.return_value = 600
        w._restore_timer = Mock()
        w._resize_timer = Mock()
        w._pending_target = None
        w._reflow_anchor = None
        w._loading = False
        w._ready_ratio = .2
        w.capture_view = Mock(return_value=ViewPosition(100, -4, .5))
        w.restore_view = Mock()
        w.scrolled = Mock()
        return w

    def test_current_ratio_uses_pending_target_not_transient_scrollbar(self):
        w = self.make()
        w._loading = True
        self.assertEqual(w.current_ratio(), .2)
        w.browser.verticalScrollBar.assert_not_called()

    def test_capture_before_resize_is_not_overwritten_by_later_events(self):
        w = self.make()
        w.remember_view_before_resize()
        first = w._reflow_anchor
        w.capture_view.return_value = ViewPosition(900, 0, .95)
        w.remember_view_before_resize()
        self.assertEqual(w._reflow_anchor, first)
        w.capture_view.assert_called_once()

    def test_loading_does_not_capture_an_intermediate_view(self):
        w = self.make()
        w._loading = True
        w.remember_view_before_resize()
        w.capture_view.assert_not_called()

    def test_cancel_pending_restore_gives_user_priority(self):
        w = self.make()
        w._loading = True
        w._pending_target = (None, .9, '')
        w._reflow_anchor = ViewPosition(400, 0, .4)
        w.cancel_pending_position()
        self.assertIsNone(w._pending_target)
        self.assertIsNone(w._reflow_anchor)
        self.assertFalse(w._loading)
        w._restore_timer.stop.assert_called_once()

    def test_restore_is_applied_only_once(self):
        w = self.make()
        target = ViewPosition(900, -5, .6)
        w._pending_target = (target, .6, '')
        w.browser.images.warnings = set()
        w._finish_restore()
        w._finish_restore()
        w.restore_view.assert_called_once_with(target)
        self.assertIsNone(w._pending_target)

    def test_anchor_target_takes_priority_over_ratio(self):
        w = self.make()
        w._pending_target = (None, 0, 'note1')
        w.browser.images.warnings = set()
        w._finish_restore()
        w.browser.scrollToAnchor.assert_called_once_with('note1')
        w.browser.verticalScrollBar.assert_not_called()

    def test_reflow_resizes_images_without_replacing_html(self):
        w = self.make()
        w.render = Mock()
        w.reflow()
        w.render.assert_not_called()
        w.browser.setDocument.assert_not_called()
        w.browser.setHtml.assert_not_called()
        w.browser.images.resize_in_place.assert_called_once()
        w.restore_view.assert_called_once_with(w.capture_view.return_value)
        self.assertFalse(w._loading)

    def test_reflow_preserves_a_pending_navigation_target(self):
        w = self.make()
        w._pending_target = (None, .5, 'section2')
        w._finish_restore = Mock()
        w.reflow()
        w.restore_view.assert_not_called()
        w._finish_restore.assert_called_once()
        self.assertEqual(w._pending_target, (None, .5, 'section2'))


if __name__ == '__main__':
    unittest.main()
