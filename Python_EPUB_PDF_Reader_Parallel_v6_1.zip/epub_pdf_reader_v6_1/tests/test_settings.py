"""Qt-free appearance and persistent viewport validation tests."""
import unittest

from reader_settings import (ViewPosition, DEFAULT_BACKGROUND, NIGHT_BACKGROUND,
                             PRESET_BACKGROUNDS, normalize_background, theme_colors, luminance)


class AppearanceTests(unittest.TestCase):
    def test_hex_normalized(self):
        self.assertEqual(normalize_background('#Ab12CD'), '#ab12cd')

    def test_invalid_colors_cannot_inject_stylesheet(self):
        for invalid in (None, 123, '#fff', 'red', '#fff; color: red', 'url(file:///tmp/x)'):
            with self.subTest(value=invalid):
                self.assertEqual(normalize_background(invalid), DEFAULT_BACKGROUND)

    def test_presets_all_valid(self):
        self.assertEqual(len(PRESET_BACKGROUNDS), 5)
        for name, color in PRESET_BACKGROUNDS:
            self.assertTrue(name)
            self.assertEqual(normalize_background(color), color)

    def test_dark_background_uses_white_text(self):
        self.assertEqual(theme_colors(NIGHT_BACKGROUND)[2], '#ffffff')

    def test_light_background_uses_dark_text(self):
        self.assertEqual(theme_colors('#ffffff')[2], '#161c20')

    def test_selected_rgb_colors_have_legible_text_contrast(self):
        for color in ('#00ff00', '#0000ff', '#ff0000', '#777777', '#f0b2e1', '#000000', '#ffffff'):
            foreground = theme_colors(color)[2]
            a, b = sorted((luminance(color), luminance(foreground)))
            self.assertGreaterEqual((b + .05) / (a + .05), 4.2, color)

    def test_viewport_roundtrip(self):
        value = ViewPosition(321, -9, .4)
        self.assertEqual(ViewPosition.from_dict(value.as_dict()), value)

    def test_invalid_viewport_rejected(self):
        for value in (None, {}, 'bad', {'position': -1}, {'position': float('inf')},
                      {'position': 5, 'ratio': float('nan')}, {'position': 5, 'offset': 2_000_000}):
            self.assertIsNone(ViewPosition.from_dict(value))

    def test_ratio_clamped_for_legacy_data(self):
        self.assertEqual(ViewPosition.from_dict({'position': 9, 'ratio': 200}).ratio, 1)

    def test_top_and_bottom_flags_preserved(self):
        self.assertTrue(ViewPosition.from_dict(ViewPosition(at_top=True).as_dict()).at_top)
        self.assertTrue(ViewPosition.from_dict(ViewPosition(at_bottom=True).as_dict()).at_bottom)

    def test_string_false_does_not_enable_flags(self):
        self.assertFalse(ViewPosition.from_dict({'position': 0, 'at_top': 'true'}).at_top)


if __name__ == '__main__':
    unittest.main()
