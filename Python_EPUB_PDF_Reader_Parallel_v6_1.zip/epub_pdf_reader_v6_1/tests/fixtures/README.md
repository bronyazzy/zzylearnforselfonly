# 原创 PDF 测试文件

`password.pdf` 的打开密码为 `demo123`；`restricted.pdf` 没有打开密码，但设置了禁止文字复制的权限。
它们只用于验证密码提示与权限处理，不含用户书籍、用户密码或其他用户数据。

安装开发依赖后运行 `python make_pdf_demo.py` 可重新生成它们。
文件使用公开的测试所有者密码 `owner-fixture-only`；阅读器不会以该密码尝试解除真实文档的限制。
