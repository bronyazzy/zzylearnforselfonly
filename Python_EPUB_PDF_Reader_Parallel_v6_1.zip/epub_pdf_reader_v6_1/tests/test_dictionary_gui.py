"""Optional Qt integration checks. Skipped honestly when PySide6 is unavailable."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest

HAS_QT = importlib.util.find_spec("PySide6") is not None
if HAS_QT:
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QTextCursor
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication
    from epub_core import StateStore
    from epub_reader import ReaderWindow
    from make_finance_demo import finance_files
    from make_demo import write_epub


@unittest.skipUnless(HAS_QT, "PySide6 未安装，跳过金融词典 GUI 测试")
class DictionaryGuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setStyle("Fusion")
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.epub = self.directory / "finance.epub"
        write_epub(self.epub, finance_files())
        self.window = ReaderWindow(StateStore(self.directory / "state.json"))
        self.window.show()
        self.assertTrue(self.window.open_book(str(self.epub)))
        QTest.qWait(300)
        self.dock = self.window.dictionary_dock

    def tearDown(self):
        if self.dock.busy:
            self.dock.cancel_import()
            for _ in range(100):
                QTest.qWait(20)
                if not self.dock.busy:
                    break
        self.window.close()
        QTest.qWait(30)
        self.temp.cleanup()

    def select(self, text):
        cursor = self.window.browser.document().find(text)
        self.assertFalse(cursor.isNull(), text)
        self.window.browser.setTextCursor(cursor)
        return cursor

    def test_dock_and_counts(self):
        self.assertIsNotNone(self.dock)
        self.assertFalse(self.dock.isHidden())
        self.assertIn("453", self.dock.stats.text())
        self.assertTrue(self.dock.finance_check.isChecked())

    def test_manual_word_lookup(self):
        self.dock.query_edit.setText("leverage")
        self.dock.query_from_edit()
        self.assertIn("杠杆", self.dock.result_view.toPlainText())
        self.assertIn("ˈlevərɪdʒ", self.dock.result_view.toPlainText())
        self.assertTrue(self.dock.save_button.isEnabled())

    def test_phrase_selection_shortcut_handler(self):
        self.select("cash flow")
        self.window.lookup_selection()
        self.assertIn("现金流", self.dock.result_view.toPlainText())
        self.assertEqual(self.dock.current_result.entries[0].word, "cash flow")

    def test_ctrl_e_key_event(self):
        self.select("equity")
        self.window.browser.setFocus()
        QTest.keyClick(self.window.browser, Qt.Key.Key_E, Qt.KeyboardModifier.ControlModifier)
        QTest.qWait(30)
        self.assertEqual(self.dock.current_result.entries[0].word, "equity")

    def test_double_click_word(self):
        cursor = self.select("leverage")
        start = cursor.selectionStart()
        cursor.setPosition(start + 3)
        self.window.browser.setTextCursor(cursor)
        self.window.browser.ensureCursorVisible()
        QTest.qWait(30)
        point = self.window.browser.cursorRect(cursor).center()
        QTest.mouseDClick(self.window.browser.viewport(), Qt.MouseButton.LeftButton,
                         Qt.KeyboardModifier.NoModifier, point)
        QTest.qWait(50)
        self.assertIsNotNone(self.dock.current_result)
        self.assertEqual(self.dock.current_result.entries[0].word, "leverage")

    def test_automatic_lookup_signal_and_off_switch(self):
        self.window.browser.selectionReleased.emit("duration")
        self.assertEqual(self.dock.current_result.entries[0].word, "duration")
        self.dock.auto_check.setChecked(False)
        self.window.browser.selectionReleased.emit("equity")
        self.assertEqual(self.dock.current_result.entries[0].word, "duration")

    def test_missing_entry_disables_save(self):
        self.dock.lookup("unlistedzzzzword")
        self.assertIn("未收录", self.dock.result_view.toPlainText())
        self.assertFalse(self.dock.save_button.isEnabled())

    def test_wordbook_preserves_book_context(self):
        self.select("leverage")
        self.window.lookup_selection()
        self.dock.save_current()
        row = self.dock.vocabulary.items["leverage"]
        self.assertIn("leverage", row["context"].lower())
        self.assertEqual(row["book"], self.window.book.title)
        self.assertEqual(self.dock.vocab_list.count(), 1)
        self.assertTrue((self.directory / "vocabulary.json").exists())

    def test_manual_lookup_does_not_save_stale_context(self):
        self.select("leverage")
        self.window.lookup_selection()
        self.dock.query_edit.setText("equity")
        self.dock.query_from_edit()
        self.dock.save_current()
        self.assertEqual(self.dock.vocabulary.items["equity"]["context"], "")

    def test_theme_preserves_result(self):
        self.dock.lookup("equity")
        self.window.toggle_night(True)
        self.assertTrue(self.dock.night)
        self.assertIn("股权", self.dock.result_view.toPlainText())
        self.assertEqual(self.dock.current_result.entries[0].word, "equity")

    def test_lookup_does_not_change_chapter(self):
        previous = self.window.current_path
        self.window.lookup_text("ETF")
        self.assertEqual(self.window.current_path, previous)
        self.assertEqual(self.dock.current_result.entries[0].word, "exchange traded fund")

    def test_import_worker_completes_and_lookup_works(self):
        source = Path(__file__).resolve().parents[1] / "examples" / "custom_dictionary.csv"
        self.dock.start_import(source)
        for _ in range(200):
            QTest.qWait(20)
            if self.dock._thread is None:
                break
        self.assertIsNone(self.dock._thread)
        self.assertEqual(self.dock.engine.extra_count, 4)
        self.dock.lookup("fintech")
        self.assertIn("金融科技", self.dock.result_view.toPlainText())


if __name__ == "__main__":
    unittest.main()
