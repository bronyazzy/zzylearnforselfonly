"""Optional real Qt integration tests for the MDX/MDD tab (no fake pass results)."""
from __future__ import annotations
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HAS_QT = importlib.util.find_spec('PySide6') is not None
if HAS_QT:
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtCore import QUrl
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication, QMessageBox
    from epub_core import StateStore
    from epub_reader import ReaderWindow
    from mdict_core import build_index
    from make_mdict_demo import write_demo


@unittest.skipUnless(HAS_QT, 'PySide6 未安装，跳过真实 Qt MDX/MDD 界面测试')
class MdictGuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.mdx = write_demo(self.root / 'dictionary')
        self.window = ReaderWindow(StateStore(self.root / 'data' / 'state.json'))
        self.window.show()
        QTest.qWait(80)
        self.dock = self.window.dictionary_dock
        self.panel = self.dock.mdict_panel
        plan = build_index(self.mdx, self.panel.library.directory)
        self.panel.library.commit(plan)
        self.panel.refresh_dictionaries()
        self.dock.tabs.setCurrentWidget(self.panel)

    def tearDown(self):
        if self.panel.busy:
            self.panel.cancel_import()
            for _ in range(250):
                QTest.qWait(20)
                if not self.panel.busy:
                    break
        self.window.close()
        QTest.qWait(40)
        self.temp.cleanup()

    def test_tab_and_statistics(self):
        self.assertIn('MDX 1 部', self.dock.stats.text())
        self.assertEqual(self.dock.tabs.count(), 3)
        self.assertEqual(self.panel.dictionaries.count(), 2)

    def test_lookup_ipa_chinese(self):
        self.dock.lookup('equity')
        self.assertIn('股权', self.panel.browser.toPlainText())
        self.assertIn('ˈekwɪti', self.panel.browser.toPlainText())
        self.assertTrue(self.panel.save_button.isEnabled())

    def test_missing_word_switches_when_only_mdx_has_hit(self):
        self.dock.tabs.setCurrentIndex(0)
        self.dock.lookup('mdx test')
        self.assertIs(self.dock.tabs.currentWidget(), self.panel)
        self.assertIn('兼容测试', self.panel.browser.toPlainText())

    def test_builtin_finance_tab_preserved(self):
        self.dock.tabs.setCurrentIndex(0)
        self.dock.lookup('equity')
        self.assertEqual(self.dock.tabs.currentIndex(), 0)
        self.assertIn('股权', self.dock.result_view.toPlainText())

    def test_repeat_lookup_document_ownership(self):
        for _ in range(3):
            self.dock.lookup('equity')
            self.dock.lookup('cash flow')
        self.assertIn('现金流', self.panel.browser.toPlainText())

    def test_mdd_image_decodes(self):
        self.dock.lookup('equity')
        images = self.panel.browser.images
        self.assertIsNotNone(images)
        self.assertTrue(images.cache)
        self.assertTrue(all(not image.error for image in images.cache.values()))

    def test_image_resizes_without_replacing_document(self):
        self.dock.lookup('equity')
        document = self.panel.browser.document()
        self.panel.browser.resize(500, 500)
        QTest.qWait(160)
        self.assertIs(self.panel.browser.document(), document)
        self.assertIn('股权', document.toPlainText())

    def test_no_automatic_audio(self):
        self.dock.lookup('equity')
        self.assertIsNone(self.panel._player)
        self.assertFalse(self.panel.stop_button.isEnabled())

    def test_external_resources_blocked(self):
        self.assertTrue(self.panel.browser.loadResource(2, QUrl('file:///etc/passwd')).isEmpty())
        self.assertTrue(self.panel.browser.document().loadResource(2, QUrl('https://example.com/a.png')).isEmpty())

    def test_redirect_lookup(self):
        self.dock.lookup('equities')
        self.assertEqual(self.panel.current_article.word, 'equity')
        self.assertIn('股权', self.panel.browser.toPlainText())

    def test_entry_link(self):
        self.dock.lookup('equity')
        identifier = self.panel.current_article.dictionary_id
        self.panel.follow_link(QUrl('mdictlookup://' + identifier + '/cash%20flow'))
        self.assertEqual(self.dock.query_edit.text(), 'cash flow')
        self.assertIn('现金流', self.panel.browser.toPlainText())

    def test_save_reading_context(self):
        self.dock.lookup('equity', 'The company issued equity.', 'A report.pdf · 第 2 页')
        self.panel.save_current()
        record = self.dock.vocabulary.items['equity']
        self.assertEqual(record['phonetic'], 'ˈekwɪti')
        self.assertEqual(record['context'], 'The company issued equity.')
        self.assertIn('MDX', record['source'])

    def test_night_preserves_article(self):
        self.dock.lookup('equity')
        self.dock.set_night(True)
        self.assertIn('股权', self.panel.browser.toPlainText())
        self.assertTrue(self.panel.night)

    def test_disable_dictionary(self):
        identifier = self.panel.library.items[0]['id']
        self.panel.library.set_enabled(identifier, False)
        self.panel.refresh_dictionaries()
        self.dock.lookup('equity')
        self.assertIsNone(self.panel.current_article)
        self.assertIn('未收录', self.panel.browser.toPlainText())

    def test_async_import(self):
        with patch.object(QMessageBox, 'warning') as warning:
            self.panel.start_import(self.mdx)
            for _ in range(300):
                QTest.qWait(20)
                if not self.panel.busy:
                    break
            self.assertFalse(self.panel.busy)
            warning.assert_not_called()
        self.assertEqual(len(self.panel.library.items), 1)
        self.assertTrue(self.dock.query_edit.isEnabled())
        self.dock.lookup('equity')
        self.assertIn('股权', self.panel.browser.toPlainText())

    def test_cancel_async_import_retains_old(self):
        previous = self.panel.library.items[0]['index']
        self.panel.start_import(self.mdx)
        self.panel.cancel_import()
        for _ in range(300):
            QTest.qWait(20)
            if not self.panel.busy:
                break
        self.assertFalse(self.panel.busy)
        self.assertEqual(self.panel.library.items[0]['index'], previous)

    def test_failed_async_import(self):
        missing = self.root / 'absent.mdx'
        previous = self.panel.library.items[0]['index']
        with patch.object(QMessageBox, 'warning'):
            self.panel.start_import(missing)
            for _ in range(300):
                QTest.qWait(20)
                if not self.panel.busy:
                    break
        self.assertFalse(self.panel.busy)
        self.assertEqual(self.panel.library.items[0]['index'], previous)
        self.assertTrue(self.dock.query_edit.isEnabled())


if __name__ == '__main__':
    unittest.main()
