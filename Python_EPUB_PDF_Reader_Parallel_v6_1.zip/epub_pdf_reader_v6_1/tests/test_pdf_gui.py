"""Real Qt integration tests, explicitly skipped when Qt is unavailable."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HAS_QT = importlib.util.find_spec('PySide6') is not None
ROOT = Path(__file__).resolve().parents[1]
if HAS_QT:
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtCore import Qt, QPoint
    from PySide6.QtGui import QColor
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication
    from epub_core import StateStore
    from epub_reader import MultiFormatReaderWindow
    from pdf_core import page_path
    from pdf_ui import MARGIN


@unittest.skipUnless(HAS_QT, 'PySide6 未安装，跳过 PDF 图形界面测试')
class PdfGuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setStyle('Fusion')
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.state_file = Path(self.tmp.name) / 'state.json'
        self.window = MultiFormatReaderWindow(StateStore(self.state_file))
        self.window.show()
        QTest.qWait(100)
        self.assertTrue(self.window.open_book(str(ROOT / 'pdf_demo.pdf')))
        QTest.qWait(250)
        self.view = self.window.pdf_view

    def tearDown(self):
        self.window.close()
        QTest.qWait(40)
        self.tmp.cleanup()

    def test_pdf_opens_as_canvas_with_image(self):
        self.assertIs(self.window.document_stack.currentWidget(), self.view)
        self.assertFalse(self.view.image.isNull())
        self.assertEqual(self.window.pdf_page_spin.maximum(), 4)

    def test_default_open_does_not_scroll_down(self):
        self.assertEqual(self.view.verticalScrollBar().value(), 0)
        QTest.qWait(400)
        self.assertEqual(self.view.verticalScrollBar().value(), 0)

    def test_fit_width_stays_at_top_across_resizes(self):
        for width in (1250, 1490, 1100, 1460):
            self.window.resize(width, 840)
            QTest.qWait(200)
            self.assertEqual(self.view.verticalScrollBar().value(), 0)

    def test_dictionary_toggle_does_not_scroll_down(self):
        for enabled in (False, True, False, True):
            self.window.dictionary_dock.setVisible(enabled)
            QTest.qWait(180)
            self.assertEqual(self.view.verticalScrollBar().value(), 0)

    def test_next_previous_page_controls(self):
        self.window.change_chapter(1)
        QTest.qWait(100)
        self.assertEqual(self.view.page_index, 1)
        self.assertEqual(self.window.pdf_page_spin.value(), 2)
        self.window.change_chapter(-1)
        QTest.qWait(100)
        self.assertEqual(self.view.page_index, 0)

    def test_page_spin_navigation(self):
        self.window.pdf_page_spin.setValue(3)
        QTest.qWait(100)
        self.assertEqual(self.view.page_index, 2)
        self.assertFalse(self.view.image.isNull())

    def test_pdf_outline_jump(self):
        item = self.window.toc_tree.topLevelItem(1)
        self.window.toc_activated(item)
        QTest.qWait(100)
        self.assertEqual(self.view.page_index, 1)

    def test_zoom_and_rotation(self):
        self.view.set_zoom(1.5)
        QTest.qWait(100)
        self.assertEqual(self.view.zoom_mode, 'custom')
        before = self.view.logical_width, self.view.logical_height
        self.view.rotate()
        QTest.qWait(100)
        self.assertEqual((self.view.logical_width, self.view.logical_height), before[::-1])

    def test_fit_page_no_vertical_overflow(self):
        self.view.set_zoom_mode('page')
        QTest.qWait(150)
        self.assertEqual(self.view.verticalScrollBar().maximum(), 0)

    def test_current_page_search_selects_phrase(self):
        self.window.search_edit.setText('cash flow')
        self.window.find_text()
        self.assertEqual(self.view.selected_text().lower(), 'cash flow')
        self.assertTrue(self.view.highlight_rects)

    def test_scan_page_no_false_text(self):
        self.window.navigate('pdf:2')
        QTest.qWait(100)
        self.window.search_edit.setText('equity')
        self.window.find_text()
        self.assertEqual(self.view.selected_text(), '')

    def test_selection_dictionary_context(self):
        match = self.window.pdf_book.find_matches(0, 'equity')[0]
        self.view.select(match)
        self.window.lookup_selection()
        self.assertEqual(self.window.dictionary_dock.query_edit.text().lower(), 'equity')
        self.assertIn('Equity', self.view.selected_context())

    def test_mouse_double_click_uses_text_layer(self):
        match = self.window.pdf_book.find_matches(0, 'equity')[0]
        box = self.window.pdf_book.textpage(0).get_charbox(match.start)
        x,y = self.window.pdf_book.page_to_device(0, self.view.rendered, (box[0]+box[2])/2, (box[1]+box[3])/2)
        pos = QPoint(round(x*self.view.logical_width/self.view.rendered.width+MARGIN),
                     round(y*self.view.logical_height/self.view.rendered.height+MARGIN))
        self.view.ensureVisible(pos.x(),pos.y(),20,20)
        QTest.mouseDClick(self.view.canvas, Qt.MouseButton.LeftButton, pos=pos)
        QTest.qWait(150)
        self.assertEqual(self.window.dictionary_dock.query_edit.text().lower(),'equity')

    def test_copy_selection(self):
        self.view.select(self.window.pdf_book.find_matches(0, 'equity')[0])
        self.view.copy_selection()
        self.assertEqual(QApplication.clipboard().text().lower(),'equity')

    def test_bookmark_round_trip(self):
        self.window.navigate('pdf:1')
        QTest.qWait(100)
        self.window.add_bookmark()
        self.window.navigate('pdf:0')
        self.window.open_bookmark(self.window.bookmark_list.item(0))
        QTest.qWait(100)
        self.assertEqual(self.view.page_index,1)

    def test_saved_pdf_page_defaults_to_top(self):
        self.window.navigate('pdf:1')
        QTest.qWait(100)
        self.view.verticalScrollBar().setValue(self.view.verticalScrollBar().maximum())
        self.window.save_state()
        self.window.close()
        self.window = MultiFormatReaderWindow(StateStore(self.state_file))
        self.window.show()
        self.window.open_book(str(ROOT/'pdf_demo.pdf'))
        QTest.qWait(250)
        self.assertEqual(self.window.pdf_view.page_index,1)
        self.assertEqual(self.window.pdf_view.verticalScrollBar().value(),0)

    def test_resume_opt_in_restores_offset(self):
        self.view.set_zoom(1.5)
        QTest.qWait(100)
        self.view.verticalScrollBar().setValue(round(self.view.verticalScrollBar().maximum()*.6))
        self.window.toggle_restore_position(True)
        self.window.close()
        self.window = MultiFormatReaderWindow(StateStore(self.state_file))
        self.window.show()
        self.window.open_book(str(ROOT/'pdf_demo.pdf'))
        QTest.qWait(250)
        self.assertAlmostEqual(self.window.pdf_view.current_ratio(),.6,delta=.03)

    def test_background_keeps_original_pdf_colors_by_default(self):
        before = self.view.original_image.pixelColor(10,10)
        self.window.set_background('#cde3f0')
        self.assertEqual(self.view.background,'#cde3f0')
        self.assertEqual(self.view.image.pixelColor(10,10),before)

    def test_tint_toggle_and_night_mode(self):
        self.window.set_background('#e6f1e7')
        self.window.pdf_tint_check.setChecked(True)
        # White paper near the bottom margin maps to the selected background.
        self.assertNotEqual(self.view.image,self.view.original_image)
        self.window.toggle_night(True)
        self.assertFalse(self.view.image.isNull())
        self.window.pdf_tint_check.setChecked(False)
        self.assertEqual(self.view.image,self.view.original_image)

    def test_switch_epub_and_pdf_does_not_lose_dictionary(self):
        dock = self.window.dictionary_dock
        old_pdf = self.window.pdf_book
        self.assertTrue(self.window.open_book(str(ROOT/'finance_demo.epub')))
        QTest.qWait(150)
        self.assertIsNone(self.window.pdf_book)
        self.assertIsNone(old_pdf._document)
        self.assertIs(self.window.document_stack.currentWidget(),self.window.browser)
        self.assertTrue(self.window.open_book(str(ROOT/'pdf_demo.pdf')))
        QTest.qWait(150)
        self.assertIs(self.window.dictionary_dock,dock)

    def test_invalid_new_book_preserves_current_pdf(self):
        original = self.window.pdf_book
        with patch('epub_reader.QMessageBox.warning'):
            self.assertFalse(self.window.open_book(str(ROOT/'missing.epub')))
        self.assertIs(self.window.pdf_book,original)
        self.assertFalse(self.view.image.isNull())

    def test_password_cancel_preserves_current_book(self):
        original = self.window.pdf_book
        with patch('pdf_integration.QInputDialog.getText',return_value=('',False)):
            self.assertFalse(self.window.open_book(str(ROOT/'tests/fixtures/password.pdf')))
        self.assertIs(self.window.pdf_book,original)

    def test_correct_password_opens_without_saving_password(self):
        with patch('pdf_integration.QInputDialog.getText',return_value=('demo123',True)):
            self.assertTrue(self.window.open_book(str(ROOT/'tests/fixtures/password.pdf')))
        QTest.qWait(100)
        self.window.save_state()
        self.assertNotIn('demo123',self.state_file.read_text())

    def test_copy_restricted_document_disables_search(self):
        self.assertTrue(self.window.open_book(str(ROOT/'tests/fixtures/restricted.pdf')))
        QTest.qWait(100)
        self.assertFalse(self.window.search_edit.isEnabled())
        self.assertFalse(self.view.image.isNull())

    def test_manual_input_cancels_late_scroll_restore(self):
        self.view.show_page(0, .9)
        self.view.cancel_restore()
        self.view.verticalScrollBar().setValue(0)
        QTest.qWait(120)
        self.assertEqual(self.view.verticalScrollBar().value(),0)

    def test_return_to_page_top(self):
        self.view.set_zoom(1.5)
        QTest.qWait(100)
        self.view.verticalScrollBar().setValue(self.view.verticalScrollBar().maximum())
        self.window.go_to_chapter_start()
        self.assertEqual(self.view.verticalScrollBar().value(),0)


if __name__ == '__main__':
    unittest.main()
