"""Actual PDFium regression tests. These do not substitute for GUI testing."""
from __future__ import annotations

from pathlib import Path
import math
import shutil
import tempfile
import unittest
from unittest.mock import patch

from pdf_core import (MAX_RENDER_PIXELS, MAX_RENDER_SIDE, PdfBook, PdfError,
                      PdfMatch, PdfPasswordRequired, PdfPosition, finite_number,
                      page_index, page_path, render_scale)

ROOT = Path(__file__).resolve().parents[1]


def write_basic_pdf(path: Path, crop=False, rotate=0, text='equity cash flow capital'):
    """Minimal PDF with native text, vector graphics and optional shifted crop box."""
    objects = [b'<< /Type /Catalog /Pages 2 0 R >>',
               b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>']
    extra = f' /Rotate {rotate}' + (' /CropBox [40 80 550 730]' if crop else '')
    objects.append(('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792]'+extra+
                    ' /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>').encode())
    objects.append(b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>')
    stream = f'BT /F1 20 Tf 80 650 Td ({text}) Tj ET\n0 0 1 rg 80 140 140 90 re f\n'.encode('ascii')
    objects.append(b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'endstream')
    result = bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n')
    offsets = [0]
    for i, body in enumerate(objects, 1):
        offsets.append(len(result))
        result.extend(f'{i} 0 obj\n'.encode()+body+b'\nendobj\n')
    xref = len(result)
    result.extend(f'xref\n0 {len(objects)+1}\n0000000000 65535 f \n'.encode())
    for offset in offsets[1:]:
        result.extend(f'{offset:010d} 00000 n \n'.encode())
    result.extend(f'trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())
    path.write_bytes(result)


class PdfSettingsTests(unittest.TestCase):
    def test_paths_round_trip(self):
        self.assertEqual(page_index(page_path(13), 20), 13)

    def test_bad_paths_rejected(self):
        for path in ('pdf:-1', 'pdf:3.1', 'pdf:99999999', '../pdf:1', 'file:///pdf:1', None, 2, 'pdf:20'):
            self.assertIsNone(page_index(path, 20))

    def test_invalid_records_default(self):
        for record in (None, [], 'bad'):
            self.assertEqual(PdfPosition.from_record(record, 5), PdfPosition())

    def test_default_open_retains_page_but_not_old_offsets(self):
        p = PdfPosition.from_record({'path': 'pdf:3', 'ratio': .85, 'horizontal': .4}, 8)
        self.assertEqual((p.page, p.ratio, p.horizontal), (3, 0, 0))

    def test_explicit_resume_preserves_offsets(self):
        p = PdfPosition.from_record({'path': 'pdf:3', 'ratio': .85, 'horizontal': .4}, 8, True)
        self.assertEqual((p.page, p.ratio, p.horizontal), (3, .85, .4))

    def test_stale_page_and_zoom_clamped(self):
        p = PdfPosition.from_record({'page': 9000, 'zoom': 10, 'rotation': 33, 'zoom_mode': 'oops'}, 8, True)
        self.assertEqual((p.page, p.zoom, p.rotation, p.zoom_mode), (7, 4, 0, 'width'))

    def test_nonfinite_position_cannot_poison_state(self):
        p = PdfPosition.from_record({'page': float('nan'), 'ratio': float('inf'), 'zoom': 'NaN'}, 8, True)
        self.assertEqual(p, PdfPosition())

    def test_valid_rotation_and_mode(self):
        p = PdfPosition.from_record({'rotation': 270, 'zoom_mode': 'page', 'zoom': .75}, 8)
        self.assertEqual((p.rotation, p.zoom_mode, p.zoom), (270, 'page', .75))

    def test_float_validation(self):
        self.assertEqual(finite_number(None, 3, 0, 4), 3)
        self.assertEqual(finite_number(-8, 3, 0, 4), 0)
        self.assertEqual(finite_number(90, 3, 0, 4), 4)

    def test_scale_limit_precedes_allocation(self):
        for w, h in ((612, 792), (50000, 500), (1000, 900000)):
            scale = render_scale(w, h, 99)
            self.assertLessEqual(math.ceil(w*scale)*math.ceil(h*scale), MAX_RENDER_PIXELS)
            self.assertLessEqual(max(math.ceil(w*scale), math.ceil(h*scale)), MAX_RENDER_SIDE)

    def test_scale_rejects_invalid_values(self):
        for dims in ((0, 3, 1), (-1, 4, 1), (2, float('nan'), 1), (2, 4, float('inf'))):
            with self.assertRaises(PdfError):
                render_scale(*dims)


class PdfEngineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.folder = Path(self.tmp.name)
        self.book = PdfBook(ROOT / 'pdf_demo.pdf')

    def tearDown(self):
        self.book.close()
        self.tmp.cleanup()

    def test_metadata_and_page_count(self):
        self.assertEqual(self.book.page_count, 4)
        self.assertIn('Finance Reading Lab', self.book.title)
        self.assertTrue(self.book.can_extract)

    def test_outline_nested_and_destinations(self):
        self.assertEqual(len(self.book.toc), 4)
        self.assertEqual(self.book.toc[1].children[0].path, 'pdf:1')

    def test_selectable_text_contains_finance_terms(self):
        self.assertIn('Cash flow, leverage', self.book.text(0))

    def test_scan_page_has_no_invented_text(self):
        self.assertEqual(self.book.text(2), '')
        self.assertEqual(self.book.find_matches(2, 'equity'), [])

    def test_each_page_renders_real_pixels(self):
        for i in range(4):
            rendered = self.book.render(i, .5)
            self.assertGreater(rendered.width, 200)
            self.assertGreater(rendered.height, 200)
            self.assertEqual(len(rendered.pixels), rendered.stride * rendered.height)
            self.assertGreater(len(set(rendered.pixels)), 20)

    def test_rgba_order_and_embedded_image_color(self):
        rendered = self.book.render(0, 1)
        # Center of the first embedded colored rectangle.
        x, y = 100, 792 - 425
        offset = y * rendered.stride + x * 4
        r, g, b, a = rendered.pixels[offset:offset+4]
        self.assertLess(r, b)
        self.assertEqual(a, 255)

    def test_bad_page_indices_are_errors(self):
        for index in (-1, 4, '0', True):
            with self.assertRaises(PdfError):
                self.book.page(index)

    def test_page_size_rotation(self):
        a, b = self.book.page_size(0)
        self.assertEqual(self.book.page_size(0, 90), (b, a))

    def test_display_rotation_changes_image_shape(self):
        a, b = self.book.render(0, 1), self.book.render(0, 1, 90)
        self.assertEqual((a.width, a.height), (b.height, b.width))

    def test_unsupported_rotation_is_rejected(self):
        with self.assertRaises(PdfError):
            self.book.render(0, 1, 45)

    def test_render_scale_nonfinite_is_rejected(self):
        with self.assertRaises(PdfError):
            self.book.render(0, float('nan'))

    def test_huge_requested_render_is_clamped(self):
        with patch('pdf_core.MAX_RENDER_PIXELS', 180000):
            with patch('pdf_core.MAX_RENDER_SIDE', 1000):
                rendered = self.book.render(0, 50)
                self.assertTrue(rendered.limited)
                self.assertLessEqual(rendered.width * rendered.height, 180000)

    def test_case_insensitive_search_and_phrase_ranges(self):
        matches = self.book.find_matches(1, 'CASH FLOW')
        self.assertEqual(len(matches), 3)
        for match in matches:
            self.assertEqual(self.book.text(1, match.start, match.count).lower(), 'cash flow')

    def test_search_missing_or_empty(self):
        self.assertEqual(self.book.find_matches(0, 'zzzyyyzzz'), [])
        self.assertEqual(self.book.find_matches(0, ''), [])

    def test_search_query_limits(self):
        for query in ('a'*257, 'a\x00b'):
            with self.assertRaises(PdfError):
                self.book.find_matches(0, query)

    def test_word_at_native_char_position(self):
        match = self.book.find_matches(0, 'leverage')[0]
        word = self.book.word_at(0, match.start + 3)
        self.assertEqual(self.book.text(0, word.start, word.count), 'leverage')

    def test_word_at_outside_character_range(self):
        self.assertIsNone(self.book.word_at(0, -1))
        self.assertIsNone(self.book.word_at(0, 1_000_000))

    def test_context_contains_selection(self):
        match = self.book.find_matches(0, 'leverage')[0]
        self.assertIn('leverage', self.book.context(0, match.start, match.count))

    def test_highlight_boxes_finite_and_positive(self):
        match = self.book.find_matches(0, 'cash flow')[0]
        boxes = self.book.selection_boxes(0, match.start, match.count)
        self.assertTrue(boxes)
        for a, b, c, d in boxes:
            self.assertTrue(all(math.isfinite(v) for v in (a,b,c,d)))
            self.assertGreater(c, a)
            self.assertGreater(d, b)

    def test_round_trip_coordinates_at_all_rotations(self):
        for stored_page in (0, 3):
            for angle in (0, 90, 180, 270):
                render = self.book.render(stored_page, 1, angle)
                x, y = self.book.device_to_page(stored_page, render, 100, 120)
                xx, yy = self.book.page_to_device(stored_page, render, x, y)
                self.assertAlmostEqual(xx, 100, delta=1)
                self.assertAlmostEqual(yy, 120, delta=1)

    def test_rotated_text_can_be_hit_at_visible_location(self):
        for page in (0, 3):
            match = self.book.find_matches(page, 'equity')[0]
            box = self.book.textpage(page).get_charbox(match.start)
            x, y = (box[0]+box[2])/2, (box[1]+box[3])/2
            for angle in (0,90,180,270):
                render = self.book.render(page, 1.5, angle)
                xx, yy = self.book.page_to_device(page, render, x, y)
                self.assertEqual(self.book.hit_test(page, render, xx, yy), match.start)

    def test_cropped_shifted_page_selection(self):
        target = self.folder / 'crop.pdf'
        for angle in (0,90,180,270):
            write_basic_pdf(target, crop=True, rotate=angle)
            with PdfBook(target) as book:
                match = book.find_matches(0, 'equity')[0]
                box = book.textpage(0).get_charbox(match.start)
                render = book.render(0, 1.5, 90)
                xx, yy = book.page_to_device(0, render, (box[0]+box[2])/2, (box[1]+box[3])/2)
                self.assertEqual(book.hit_test(0, render, xx, yy), match.start)

    def test_identical_content_retains_identity_across_path(self):
        target = self.folder / '财务报告 副本.PDF'
        shutil.copyfile(self.book.filename, target)
        with PdfBook(target) as book:
            self.assertEqual(book.book_id, self.book.book_id)

    def test_modified_content_has_new_identity(self):
        target = self.folder / 'different.pdf'
        write_basic_pdf(target)
        with PdfBook(target) as book:
            self.assertNotEqual(book.book_id, self.book.book_id)

    def test_missing_file_user_facing_error(self):
        with self.assertRaises(PdfError):
            PdfBook(self.folder / 'absent.pdf')

    def test_corrupt_file_user_facing_error(self):
        target = self.folder / 'broken.pdf'
        target.write_bytes(b'not a PDF')
        with self.assertRaises(PdfError):
            PdfBook(target)

    def test_closed_book_cannot_be_used(self):
        self.book.close()
        self.book.close()
        with self.assertRaises(PdfError):
            self.book.render(0)

    def test_page_switch_releases_old_handles(self):
        self.book.text(0)
        previous = self.book._page
        self.book.text(1)
        self.assertIsNot(self.book._page, previous)
        self.assertIsNone(previous.raw)

    def test_page_without_outline_has_no_fake_chapters(self):
        target = self.folder / 'simple.pdf'
        write_basic_pdf(target)
        with PdfBook(target) as book:
            self.assertEqual(book.toc, [])

    def test_copy_permission_disables_text_not_rendering(self):
        self.book.can_extract = False
        with self.assertRaises(PdfError):
            self.book.text(0)
        self.assertGreater(self.book.render(0, .25).width, 0)

    def test_page_character_limit(self):
        with patch('pdf_core.MAX_PAGE_CHARS', 2):
            with self.assertRaises(PdfError):
                self.book.characters(0)
        self.assertGreater(self.book.render(0,.25).width, 0)

    def test_file_size_limit(self):
        with patch('pdf_core.MAX_PDF_BYTES', 10):
            with self.assertRaises(PdfError):
                PdfBook(ROOT / 'pdf_demo.pdf')

    def test_page_count_limit(self):
        with patch('pdf_core.MAX_PAGES', 2):
            with self.assertRaises(PdfError):
                PdfBook(ROOT / 'pdf_demo.pdf')

    def test_password_required_wrong_and_correct(self):
        target = ROOT / 'tests' / 'fixtures' / 'password.pdf'
        with self.assertRaises(PdfPasswordRequired):
            PdfBook(target)
        with self.assertRaises(PdfPasswordRequired):
            PdfBook(target, 'not-the-password')
        with PdfBook(target, 'demo123') as book:
            self.assertIn('equity', book.text(0))

    def test_real_permission_restriction(self):
        target = ROOT / 'tests' / 'fixtures' / 'restricted.pdf'
        with PdfBook(target) as book:
            self.assertFalse(book.can_extract)
            with self.assertRaises(PdfError):
                book.find_matches(0, 'equity')
            self.assertGreater(book.render(0, .25).width, 0)


if __name__ == '__main__':
    unittest.main()
