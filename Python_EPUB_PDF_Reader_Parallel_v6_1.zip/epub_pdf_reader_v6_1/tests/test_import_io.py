"""File-handle regression tests for the v5.1 Windows import hotfix.

The access guard is a portable fault-injection model, NOT a Windows emulator.
It rejects fsync on read-only/closed streams, then performs real OS fsync for
accepted streams. MDX/MDD parsing, SQLite, source bytes and renames remain real.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
import errno
import hashlib
import os
from pathlib import Path
import sqlite3
import tempfile
import threading
import unittest
from unittest.mock import patch

from dictionary_core import import_csv, ImportCancelled, DictionaryEngine
from mdict_core import build_index, MdictLibrary, MdictIndex
from mdict_format import MdictError, MdictCancelled
from make_mdict_demo import encode_mdict, write_demo
from import_diagnostics import report_import_failure

ROOT = Path(__file__).resolve().parents[1]


class WritableSyncGuard:
    """Track real Python streams and enforce the writable-fsync precondition."""
    def __init__(self, after_sync=None):
        self.streams = {}
        self.opens = []
        self.syncs = []
        self.renames = []
        self.after_sync = after_sync
        self.original_open = Path.open
        self.original_fdopen = os.fdopen
        self.original_fsync = os.fsync
        self.original_replace = os.replace
        self.stack = ExitStack()

    def open(self, path, *args, **kwargs):
        stream = self.original_open(path, *args, **kwargs)
        self.streams[stream.fileno()] = stream
        self.opens.append((Path(path), stream))
        return stream

    def fdopen(self, fd, *args, **kwargs):
        stream = self.original_fdopen(fd, *args, **kwargs)
        self.streams[stream.fileno()] = stream
        self.opens.append((None, stream))
        return stream

    def fsync(self, fd):
        os.fstat(fd)  # Check that this is a live OS descriptor, not a fake stream.
        stream = self.streams.get(fd)
        if stream is None or stream.closed or not stream.writable():
            raise OSError(errno.EBADF, 'Bad file descriptor')
        self.syncs.append((stream.name, stream.mode))
        self.original_fsync(fd)
        if self.after_sync:
            self.after_sync()

    def replace(self, source, destination, *args, **kwargs):
        alive = [str(path) for path, stream in self.opens if not stream.closed]
        self.renames.append((Path(source), Path(destination), alive))
        return self.original_replace(source, destination, *args, **kwargs)

    def __enter__(self):
        # Use a closure instead of a bound method as the Path descriptor.
        owner = self
        self.stack.enter_context(patch.object(Path, 'open', lambda path, *a, **kw: owner.open(path, *a, **kw)))
        self.stack.enter_context(patch('os.fdopen', self.fdopen))
        self.stack.enter_context(patch('os.fsync', self.fsync))
        self.stack.enter_context(patch('os.replace', self.replace))
        return self

    def __exit__(self, *args):
        return self.stack.__exit__(*args)


class ImportFileHandleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.mdx = write_demo(self.root / '中文 Finance #1')
        self.library = MdictLibrary(self.root / '用户 数据')
        self.addCleanup(self.library.close)
        self.csv = self.root / '英汉 词库.csv'
        self.csv.write_text('word,translation,phonetic\nfintech,金融科技,/ˈfɪntek/\n', encoding='utf-8')
        self.csv_db = self.root / 'extra.sqlite'

    def test_guard_rejects_original_readonly_fsync(self):
        with WritableSyncGuard(), self.csv.open('rb') as stream:
            with self.assertRaises(OSError) as caught:
                os.fsync(stream.fileno())
            self.assertEqual(caught.exception.errno, errno.EBADF)

    def test_guard_accepts_writable_sync_without_truncation(self):
        before = self.csv.read_bytes()
        with WritableSyncGuard(), self.csv.open('r+b') as stream:
            stream.flush()
            os.fsync(stream.fileno())
        self.assertEqual(self.csv.read_bytes(), before)

    def test_guard_rejects_a_closed_descriptor(self):
        with WritableSyncGuard():
            stream = self.csv.open('r+b')
            fd = stream.fileno()
            stream.close()
            with self.assertRaises(OSError):
                os.fsync(fd)

    def test_mdx_without_mdd_imports_with_strict_sync(self):
        with WritableSyncGuard() as guard:
            plan = build_index(self.mdx, self.library.directory, [])
            self.library.commit(plan)
        self.assertEqual(plan.resource_count, 0)
        self.assertEqual(len(guard.syncs), 2)  # staged SQLite and the JSON registry
        self.assertTrue(self.library.lookup('equity').articles)

    def test_mdx_mdd_split_resources_import_and_source_bytes_unchanged(self):
        sources = [self.mdx, *self.mdx.parent.glob('*.mdd')]
        before = {p: hashlib.sha256(p.read_bytes()).digest() for p in sources}
        with WritableSyncGuard() as guard:
            plan = build_index(self.mdx, self.library.directory)
            self.library.commit(plan)
        self.assertEqual(plan.count, 6)
        self.assertEqual(plan.resource_count, 3)
        index = self.library.index(plan.dictionary_id)
        for source in (1, 2):
            row = index.db.execute('SELECT rowid AS key_id,start FROM keys WHERE source=? LIMIT 1', (source,)).fetchone()
            self.assertTrue(index.record(source, row['start'], key_id=row['key_id']))
        self.assertEqual(before, {p: hashlib.sha256(p.read_bytes()).digest() for p in sources})
        self.assertTrue(all(not stream.writable() for path, stream in guard.opens if path in sources))

    def test_mdx_staged_index_is_valid_after_sync(self):
        with WritableSyncGuard():
            plan = build_index(self.mdx, self.library.directory)
        db = sqlite3.connect(plan.staged_path)
        try:
            self.assertEqual(db.execute('PRAGMA integrity_check').fetchone()[0], 'ok')
            self.assertGreater(db.execute('SELECT COUNT(*) FROM keys').fetchone()[0], 0)
        finally:
            db.close()
            plan.staged_path.unlink()

    def test_mdx_handles_closed_before_rename(self):
        with WritableSyncGuard() as guard:
            plan = build_index(self.mdx, self.library.directory)
            self.library.commit(plan)
        self.assertTrue(guard.renames)
        self.assertTrue(all(not alive for _, _, alive in guard.renames))

    def test_reimport_keeps_one_dictionary_and_closes_old_index(self):
        self.library.commit(build_index(self.mdx, self.library.directory))
        self.library.lookup('equity')  # Open a cached old SQLite connection.
        old = self.library.directory / self.library.items[0]['index']
        with WritableSyncGuard():
            plan = build_index(self.mdx, self.library.directory)
            self.library.commit(plan)
        self.assertEqual(len(self.library.items), 1)
        self.assertFalse(old.exists())
        self.assertTrue(self.library.lookup('equities').articles)

    def test_worker_build_main_thread_commit(self):
        # Real thread boundary: the worker must not return an open SQLite handle.
        with WritableSyncGuard(), ThreadPoolExecutor(max_workers=1) as pool:
            plan = pool.submit(build_index, self.mdx, self.library.directory).result(timeout=10)
            self.library.commit(plan)
        self.assertTrue(self.library.lookup('cash flow').articles)

    def test_mdx_real_io_failure_keeps_old_registry_and_index(self):
        self.library.commit(build_index(self.mdx, self.library.directory))
        registry = self.library.registry_path.read_bytes()
        old = self.library.directory / self.library.items[0]['index']
        old_bytes = old.read_bytes()
        with patch('os.fsync', side_effect=OSError(errno.ENOSPC, 'No space left on device')):
            with self.assertRaises(MdictError) as caught:
                build_index(self.mdx, self.library.directory)
        self.assertEqual(caught.exception.__cause__.errno, errno.ENOSPC)
        self.assertEqual(self.library.registry_path.read_bytes(), registry)
        self.assertEqual(old.read_bytes(), old_bytes)
        self.assertFalse(list(self.library.directory.glob('.mdict-import-*')))
        self.assertTrue(self.library.lookup('equity').articles)

    def test_mdx_registry_io_failure_preserves_existing_dictionary(self):
        self.library.commit(build_index(self.mdx, self.library.directory))
        registry = self.library.registry_path.read_bytes()
        plan = build_index(self.mdx, self.library.directory)
        with patch('os.fsync', side_effect=OSError(errno.EIO, 'I/O error')):
            with self.assertRaises(OSError):
                self.library.commit(plan)
        self.assertEqual(self.library.registry_path.read_bytes(), registry)
        self.assertEqual(len(list(self.library.directory.glob('*.sqlite'))), 1)
        self.assertTrue(self.library.lookup('equity').articles)

    def test_mdx_cancellation_after_sync_does_not_publish(self):
        cancelled = threading.Event()
        with WritableSyncGuard(after_sync=cancelled.set):
            with self.assertRaises(MdictCancelled):
                build_index(self.mdx, self.library.directory, cancelled=cancelled.is_set)
        self.assertFalse(self.library.registry_path.exists())
        self.assertFalse(list(self.library.directory.glob('.mdict-import-*')))

    def test_mdx_reports_sync_stage(self):
        steps = []
        plan = build_index(self.mdx, self.library.directory, progress=steps.append)
        try:
            self.assertIn('正在验证词条及资源索引…', steps)
            self.assertEqual(steps[-1], '正在同步索引文件…')
        finally:
            plan.staged_path.unlink()

    def test_csv_import_with_strict_sync_and_source_unchanged(self):
        before = self.csv.read_bytes()
        with WritableSyncGuard() as guard:
            self.assertEqual(import_csv(self.csv, self.csv_db), 1)
        self.assertEqual(self.csv.read_bytes(), before)
        self.assertTrue(all(not stream.writable() for path, stream in guard.opens if path == self.csv))
        self.assertEqual(len(guard.syncs), 1)
        engine = DictionaryEngine(self.csv_db)
        try:
            self.assertEqual(engine.lookup('fintech').entries[0].translation, '金融科技')
            self.assertTrue(engine.lookup('equity').entries)  # built-in still exists
        finally:
            engine.close()

    def test_csv_handles_closed_before_rename(self):
        with WritableSyncGuard() as guard:
            import_csv(self.csv, self.csv_db)
        self.assertEqual(len(guard.renames), 1)
        self.assertFalse(guard.renames[0][2])

    def test_csv_io_failure_keeps_existing_database(self):
        import_csv(self.csv, self.csv_db)
        before = self.csv_db.read_bytes()
        self.csv.write_text('word,translation\nnewword,新词\n', encoding='utf-8')
        with patch('os.fsync', side_effect=OSError(errno.ENOSPC, 'No space left on device')):
            with self.assertRaises(OSError) as caught:
                import_csv(self.csv, self.csv_db)
        self.assertEqual(caught.exception.errno, errno.ENOSPC)
        self.assertEqual(self.csv_db.read_bytes(), before)
        self.assertFalse(list(self.root.glob('.dictionary-*')))

    def test_csv_cancellation_after_sync_keeps_existing_database(self):
        import_csv(self.csv, self.csv_db)
        before = self.csv_db.read_bytes()
        cancelled = threading.Event()
        with WritableSyncGuard(after_sync=cancelled.set):
            with self.assertRaises(ImportCancelled):
                import_csv(self.csv, self.csv_db, cancelled=cancelled.is_set)
        self.assertEqual(self.csv_db.read_bytes(), before)
        self.assertFalse(list(self.root.glob('.dictionary-*')))

    def test_readonly_source_files_remain_readonly(self):
        self.mdx.chmod(0o444)
        self.csv.chmod(0o444)
        try:
            with WritableSyncGuard():
                plan = build_index(self.mdx, self.library.directory)
                self.library.commit(plan)
                import_csv(self.csv, self.csv_db)
            self.assertFalse(self.mdx.stat().st_mode & 0o200)
            self.assertFalse(self.csv.stat().st_mode & 0o200)
        finally:
            self.mdx.chmod(0o644)
            self.csv.chmod(0o644)


class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / '中文 dictionary.mdx'
        self.log = self.root / 'logs' / 'dictionary_import.log'

    def test_log_contains_chain_phase_and_version(self):
        try:
            try:
                raise OSError(errno.EBADF, 'Bad file descriptor')
            except OSError as cause:
                raise MdictError('词典导入失败') from cause
        except MdictError as exc:
            message = report_import_failure(exc, self.root, self.source, '正在同步索引文件…')
        details = self.log.read_text(encoding='utf-8')
        self.assertIn('[Errno 9]', details)
        self.assertIn('MdictError', details)
        self.assertIn('6.1', details)
        self.assertIn('正在同步索引文件', details)
        self.assertIn(str(self.log), message)

    def test_failure_to_create_log_does_not_mask_original_error(self):
        with patch.object(Path, 'mkdir', side_effect=PermissionError('blocked')):
            message = report_import_failure(OSError(9, 'Bad file descriptor'), self.root, self.source, 'prepare')
        self.assertIn('[Errno 9]', message)
        self.assertIn('诊断日志未能写入', message)
        self.assertFalse(self.log.exists())

    def test_failure_to_open_log_does_not_mask_original_error(self):
        with patch.object(Path, 'open', side_effect=OSError(errno.ENOSPC, 'disk full')):
            message = report_import_failure(ValueError('original'), self.root, self.source, 'prepare')
        self.assertIn('original', message)
        self.assertIn('disk full', message)

    def test_small_reports_append(self):
        report_import_failure(ValueError('first'), self.root, self.source, 'one')
        report_import_failure(ValueError('second'), self.root, self.source, 'two')
        text = self.log.read_text(encoding='utf-8')
        self.assertIn('ValueError: first', text)
        self.assertIn('ValueError: second', text)

    def test_large_log_rotates_once(self):
        self.log.parent.mkdir()
        self.log.write_text('old text\n' * 100, encoding='utf-8')
        with patch('import_diagnostics.MAX_LOG_BYTES', 500):
            report_import_failure(ValueError('new'), self.root, self.source, 'sync')
        self.assertIn('old text', self.log.with_name(self.log.name + '.1').read_text())
        self.assertNotIn('old text', self.log.read_text())
        self.assertIn('ValueError: new', self.log.read_text())

    def test_log_does_not_read_source_file(self):
        original = Path.open
        def only_log(path, *args, **kwargs):
            if path == self.source:
                raise AssertionError('Diagnostics must not read original MDX contents')
            return original(path, *args, **kwargs)
        with patch.object(Path, 'open', only_log):
            report_import_failure(ValueError('test'), self.root, self.source, 'sync')
        self.assertTrue(self.log.is_file())

    def test_long_traceback_is_bounded(self):
        report_import_failure(ValueError('x' * 100000), self.root, self.source, 'sync')
        self.assertLess(self.log.stat().st_size, 70000)

    def test_parallel_reports_do_not_lose_entries(self):
        def write(i):
            return report_import_failure(ValueError(f'case_{i}'), self.root, self.source, 'sync')
        with ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(write, range(12)))
        text = self.log.read_text(encoding='utf-8')
        for i in range(12):
            self.assertIn(f'ValueError: case_{i}\n', text)


if __name__ == '__main__':
    unittest.main()
