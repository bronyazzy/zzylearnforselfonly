"""Optional offscreen GUI smoke tests. Skipped when PySide6 is not installed."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest

HAS_QT = importlib.util.find_spec("PySide6") is not None
if HAS_QT:
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtCore import QUrl
    from PySide6.QtGui import QImage, QTextDocument
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication
    from epub_core import StateStore
    from epub_reader import ReaderWindow
    from make_demo import sample_files, write_epub


@unittest.skipUnless(HAS_QT, "PySide6 未安装，跳过 GUI 测试")
class GuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setStyle("Fusion")
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.epub = self.directory / "demo.epub"
        write_epub(self.epub, sample_files())
        self.state_path = self.directory / "state.json"
        self.window = ReaderWindow(StateStore(self.state_path))
        self.window.show()
        QTest.qWait(250)
        self.assertTrue(self.window.open_book(str(self.epub)))
        QTest.qWait(250)

    def tearDown(self):
        self.window.close()
        QTest.qWait(20)
        self.temp.cleanup()

    def test_open_and_render(self):
        self.assertIn("第一章", self.window.browser.toPlainText())
        self.assertEqual(self.window.toc_tree.topLevelItemCount(), 3)
        self.assertFalse(self.window.prev_action.isEnabled())
        self.assertTrue(self.window.next_action.isEnabled())

    def test_image_resource_is_loaded_from_zip(self):
        url = QUrl(self.window.book.url("OPS/Images/banner.png"))
        image = self.window.browser.document().resource(QTextDocument.ResourceType.ImageResource.value, url)
        self.assertIsInstance(image, QImage)
        self.assertFalse(image.isNull())
        self.assertLessEqual(image.width(), self.window.browser.image_width)
        blocked = self.window.browser.loadResource(QTextDocument.ResourceType.ImageResource.value, QUrl("file:///etc/passwd"))
        self.assertEqual(bytes(blocked), b"")

    def test_navigation_anchor_and_history(self):
        self.window.navigate("OPS/Text/chapter2.xhtml", fragment="half")
        QTest.qWait(50)
        self.assertEqual(self.window.chapter_index, 1)
        self.assertGreater(self.window.browser.verticalScrollBar().value(), 0)
        self.window.go_back()
        QTest.qWait(50)
        self.assertEqual(self.window.chapter_index, 0)
        self.window.navigate("OPS/Text/notes.xhtml", fragment="note1")
        QTest.qWait(50)
        self.assertIn("注释页面", self.window.browser.toPlainText())

    def test_find_font_and_night(self):
        self.window.search_edit.setText("世界")
        self.window.find_text()
        self.assertEqual(self.window.browser.textCursor().selectedText(), "世界")
        self.window.change_font(2)
        QTest.qWait(50)
        self.assertEqual(self.window.font_size, 20)
        self.window.night_action.setChecked(True)
        self.window.toggle_night(True)
        QTest.qWait(50)
        self.assertTrue(self.window.night)
        self.assertIn("第一章", self.window.browser.toPlainText())

    def test_progress_and_bookmarks_roundtrip(self):
        scrollbar = self.window.browser.verticalScrollBar()
        self.assertGreater(scrollbar.maximum(), 0)
        scrollbar.setValue(round(scrollbar.maximum() * 0.48))
        expected = self.window.current_ratio()
        self.window.add_bookmark()
        self.window.toggle_restore_position(True)
        self.assertTrue(self.window.save_state())
        self.window.close()
        QTest.qWait(30)
        self.window = ReaderWindow(StateStore(self.state_path))
        self.window.show()
        QTest.qWait(250)
        self.window.open_book(str(self.epub))
        QTest.qWait(250)
        self.assertEqual(len(self.window.bookmarks), 1)
        self.assertAlmostEqual(self.window.current_ratio(), expected, delta=0.03)

    def test_page_boundary_changes_chapter(self):
        scrollbar = self.window.browser.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
        self.window.turn_page(1)
        QTest.qWait(50)
        self.assertEqual(self.window.chapter_index, 1)
        self.window.turn_page(-1)
        QTest.qWait(50)
        self.assertEqual(self.window.chapter_index, 0)
        self.assertAlmostEqual(self.window.current_ratio(), 1.0, delta=0.01)


if __name__ == "__main__":
    unittest.main()
