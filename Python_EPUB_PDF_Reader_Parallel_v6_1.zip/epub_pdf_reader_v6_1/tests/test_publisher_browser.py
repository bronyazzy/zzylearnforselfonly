"""Execute the production sanitized layout and reader JS in real Chromium.

These tests inline package resources because the sandbox browser denies URL
navigation. They do not certify Qt widgets, custom-scheme delivery or Windows.
"""
from pathlib import Path
import os
import shutil
import unittest
from epub_core import EpubBook
from publisher_core import PublisherResources,LayoutSettings,appearance_payload
from browser_harness import load,GEOMETRY,ROOT
try:
    from playwright.sync_api import sync_playwright
    AVAILABLE=True
except ImportError:
    AVAILABLE=False

@unittest.skipUnless(AVAILABLE,'缺少可选 Playwright 浏览器测试依赖')
class PublicationBrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start()
        executable=os.environ.get('MODU_CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser')
        try:
            cls.browser=cls.pw.chromium.launch(**({'executable_path':executable} if executable else {}),headless=True,args=['--no-sandbox'] if hasattr(os,'geteuid') and os.geteuid()==0 else [])
        except Exception as exc:
            cls.pw.stop();raise unittest.SkipTest('没有可启动的测试 Chromium：'+str(exc)[:180])
    @classmethod
    def tearDownClass(cls):
        cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.book=EpubBook(ROOT/'parallel_demo.epub');self.addCleanup(self.book.close)
        self.r=PublisherResources(self.book)
        self.page=self.browser.new_page(viewport={'width':1440,'height':900})
        self.addCleanup(self.page.close)
        self.page.route('**/*',lambda route:route.abort())
        self.errors=[];self.page.on('pageerror',lambda error:self.errors.append(str(error)))
        self.settings=appearance_payload(LayoutSettings(),'#faf8f3',18)
        load(self.page,self.r,'OPS/first.xhtml',self.settings)
    def apply(self,**settings):
        self.settings.update(settings)
        self.page.evaluate('(s)=>window.__modu.settings(s,true)',self.settings)
        self.page.wait_for_timeout(80)
    def alignment(self):
        rows=self.page.evaluate(GEOMETRY)
        self.assertEqual(len(rows),41)
        for row in rows:
            self.assertAlmostEqual(row['ey'],row['zy'],delta=1)
            self.assertGreater(row['zx'],row['ex'])
        self.assertFalse(self.errors)
    def test_publisher_css_displays_original_parallel_rows(self):self.alignment()
    def test_parallel_ratio_40_60(self):
        self.apply(mode='parallel',english_percent=40)
        self.alignment()
        for row in self.page.evaluate(GEOMETRY):self.assertAlmostEqual(row['ew']/(row['ew']+row['zw']),.4,delta=.002)
    def test_narrow_viewport_keeps_two_columns(self):
        self.page.set_viewport_size({'width':600,'height':900});self.apply(mode='parallel');self.alignment()
    def test_stacked_pairs_do_not_overlap(self):
        self.apply(mode='stack')
        for r in self.page.evaluate(GEOMETRY):self.assertGreaterEqual(r['zy'],r['ey']+r['eh'])
    def test_english_only_and_back_preserve_text(self):
        original=self.page.locator('body').text_content();self.apply(mode='en')
        self.assertTrue(all(r['zw']==0 for r in self.page.evaluate(GEOMETRY)))
        self.apply(mode='publisher');self.assertEqual(self.page.locator('body').text_content(),original);self.alignment()
    def test_chinese_only_preserves_shared_content(self):
        self.apply(mode='zh')
        self.assertTrue(all(r['ew']==0 for r in self.page.evaluate(GEOMETRY)))
        self.assertIn('原创测试资料',self.page.locator('body').inner_text())
    def test_theme_changes_do_not_replace_document(self):
        self.page.evaluate('window.testToken=42');self.apply(background='#1b2028',foreground='#ffffff')
        self.assertEqual(self.page.evaluate('window.testToken'),42)
        self.assertEqual(self.page.locator('body').evaluate('e=>getComputedStyle(e).backgroundColor'),'rgb(27, 32, 40)')
        self.assertEqual(self.page.locator('[data-mr-lang="zh"]').first.evaluate('e=>getComputedStyle(e).color'),'rgb(255, 255, 255)')
    def test_theme_opt_out_leaves_source_color(self):
        self.apply(use_theme=False)
        self.assertNotEqual(self.page.locator('body').evaluate('e=>getComputedStyle(e).backgroundColor'),'rgb(250, 248, 243)')
    def test_font_and_ratio_changes_keep_anchor(self):
        self.page.evaluate('window.__modu.goTo("",.4,null)');self.page.wait_for_timeout(50)
        anchor=self.page.evaluate('window.__modu.snapshot()')
        self.apply(fontSize=23,mode='parallel',english_percent=42)
        delta=self.page.evaluate('(s)=>document.querySelector(`[data-mr-id="${s.id}"]`).getBoundingClientRect().top-s.offset',anchor)
        self.assertAlmostEqual(delta,0,delta=1)
    def test_idle_no_automatic_scroll(self):
        self.page.evaluate('window.__modu.goTo("",0,null)');self.page.wait_for_timeout(300)
        self.assertEqual(self.page.evaluate('scrollY'),0)
        self.page.evaluate('window.__modu.goTo("",.3,null)');self.page.wait_for_timeout(50)
        y=self.page.evaluate('scrollY');self.page.wait_for_timeout(350)
        self.assertEqual(self.page.evaluate('scrollY'),y)
    def test_resize_keeps_nearby_anchor(self):
        self.page.evaluate('window.__modu.goTo("",.4,null)');self.page.wait_for_timeout(50)
        anchor=self.page.evaluate('window.__modu.snapshot()')
        self.page.set_viewport_size({'width':900,'height':900});self.page.wait_for_timeout(100)
        delta=self.page.evaluate('(s)=>document.querySelector(`[data-mr-id="${s.id}"]`).getBoundingClientRect().top-s.offset',anchor)
        self.assertAlmostEqual(delta,0,delta=1)
    def test_bookmark_restore_and_fragment_target(self):
        self.page.evaluate('window.__modu.goTo("pair-20",0,null)');self.page.wait_for_timeout(50)
        self.assertAlmostEqual(self.page.locator('#pair-20').bounding_box()['y'],0,delta=1)
        a=self.page.evaluate('window.__modu.snapshot()')
        self.page.evaluate('window.__modu.goTo("",0,null)')
        self.page.evaluate('(a)=>window.__modu.restore(a)',a);self.page.wait_for_timeout(50)
        self.assertAlmostEqual(self.page.evaluate('scrollY'),a['y'],delta=1)
    def test_selection_returns_one_language_context(self):
        value=self.page.evaluate('''()=>{const n=document.querySelector('[data-mr-lang="en"]');let r=document.createRange();r.selectNodeContents(n);getSelection().removeAllRanges();getSelection().addRange(r);return window.__modu.selection();}''')
        self.assertIn('Parallel reading check',value['text']);self.assertNotIn('左右对照',value['context'])
    def test_wide_table_scroll_and_images(self):
        load(self.page,self.r,'OPS/second.xhtml',self.settings)
        value=self.page.evaluate('''()=>{let w=document.querySelector('[data-mr-table-wrap]');return {overflow:w.scrollWidth>w.clientWidth,body:document.documentElement.scrollWidth,viewport:innerWidth,images:[...document.images].map(i=>[i.naturalWidth,i.width])}}''')
        self.assertTrue(value['overflow']);self.assertLessEqual(value['body'],value['viewport']+1)
        self.assertEqual(len(value['images']),2);self.assertTrue(all(x[0]>0 for x in value['images']))
    def test_original_grid_layout_survives(self):
        load(self.page,self.r,'OPS/second.xhtml',self.settings)
        self.assertEqual(self.page.locator('.grid-demo').evaluate('e=>getComputedStyle(e).display'),'grid')
    def test_turn_screen_reports_boundary_and_scrolls_once(self):
        self.assertTrue(self.page.evaluate('window.__modu.turn(-1)'))
        self.assertFalse(self.page.evaluate('window.__modu.turn(1)'))
        self.assertGreater(self.page.evaluate('scrollY'),0)

if __name__=='__main__':unittest.main()
