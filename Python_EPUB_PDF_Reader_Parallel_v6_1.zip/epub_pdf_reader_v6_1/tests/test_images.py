"""Image parsing/sanitization/geometry regressions; no GUI dependency."""
import base64
from html.parser import HTMLParser
from pathlib import Path
import tempfile
import unittest
from xml.etree import ElementTree as ET

from epub_core import EpubBook
from image_support import (ImageError, decode_data_image, fit_image_size,
                           is_image_candidate, raster_mime, sanitize_svg)
from make_demo import banner_png, sample_files, write_epub, xhtml


class ImageUtilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.png = banner_png()

    def test_jpg_media_alias(self):
        self.assertTrue(is_image_candidate('cover', 'image/jpg'))

    def test_missing_or_wrong_mime_uses_extension(self):
        self.assertTrue(is_image_candidate('Images/封 面.PNG', 'application/octet-stream'))
        self.assertFalse(is_image_candidate('chapter.html', 'text/html'))

    def test_data_base64_image(self):
        uri = 'data:image/png;base64,' + base64.b64encode(self.png).decode()
        self.assertEqual(decode_data_image(uri), self.png)

    def test_data_image_wrong_mime_uses_magic(self):
        uri = 'data:image/jpg;base64,' + base64.b64encode(self.png).decode()
        self.assertEqual(raster_mime(decode_data_image(uri)), 'image/png')

    def test_bad_base64_rejected(self):
        with self.assertRaises(ImageError):
            decode_data_image('data:image/png;base64,%%%not-base64')

    def test_non_image_data_rejected(self):
        for value in ('file:///etc/passwd', 'data:text/html,hi', 'data:image/svg+xml,<svg/>'):
            with self.subTest(value=value), self.assertRaises(ImageError):
                decode_data_image(value)

    def test_wide_image_fits_column(self):
        self.assertEqual(fit_image_size(2400, 1200, 600), (600, 300))

    def test_small_image_not_automatically_upscaled(self):
        self.assertEqual(fit_image_size(80, 40, 600), (80, 40))

    def test_percent_image_width(self):
        self.assertEqual(fit_image_size(480, 96, 600, '50%'), (300, 60))

    def test_height_only_preserves_ratio(self):
        self.assertEqual(fit_image_size(480, 96, 600, '', '20'), (100, 20))

    def test_conflicting_hints_do_not_distort(self):
        self.assertEqual(fit_image_size(480, 96, 600, '200', '99999'), (200, 40))

    def test_invalid_geometry_rejected(self):
        for size in ((0, 20), (10, -1), (float('inf'), 10), (float('nan'), 10)):
            with self.subTest(size=size), self.assertRaises(ImageError):
                fit_image_size(*size, 500)

    def test_svg_shapes_and_inline_styles(self):
        data = b'<svg viewBox="0 0 100 20"><rect width="80" height="10" style="fill:#123456;stroke:#000000"/></svg>'
        root = ET.fromstring(sanitize_svg(data))
        self.assertEqual(root.attrib['viewBox'], '0 0 100 20')
        self.assertEqual(root[0].attrib['fill'], '#123456')

    def test_svg_active_content_removed(self):
        data = b'<svg><script>doEvil()</script><foreignObject>bad</foreignObject><animate/><rect onclick="bad()" width="5"/></svg>'
        text = sanitize_svg(data).decode()
        for bad in ('script', 'foreignObject', 'onclick', 'animate', 'doEvil'):
            self.assertNotIn(bad, text)

    def test_svg_external_style_url_removed(self):
        data = b'<svg><rect fill="url(file:///etc/passwd)"/><style>@import "http://example.invalid"</style></svg>'
        self.assertNotIn(b'file:', sanitize_svg(data))
        self.assertNotIn(b'http://example', sanitize_svg(data))

    def test_svg_local_gradient_survives(self):
        data = b'<svg><defs><linearGradient id="g"><stop offset="0" stop-color="red"/></linearGradient></defs><rect fill="url(#g)"/></svg>'
        text = sanitize_svg(data).decode()
        self.assertIn('linearGradient', text)
        self.assertIn('url(#g)', text)

    def test_svg_raster_wrapper_embeds_local_bytes(self):
        data = b'<svg viewBox="0 0 480 96"><image xlink:href="../Images/banner.png" width="480" height="96"/></svg>'
        text = sanitize_svg(data, lambda src: self.png).decode()
        self.assertIn('data:image/png;base64,', text)
        self.assertNotIn('../Images/banner', text)

    def test_svg_network_reference_removed(self):
        data = b'<svg><image href="https://example.invalid/x.png"/><use href="file:///bad.svg#x"/></svg>'
        text = sanitize_svg(data).decode()
        self.assertNotIn('https:', text)
        self.assertNotIn('file:', text)

    def test_svg_entity_rejected(self):
        with self.assertRaises(ImageError):
            sanitize_svg(b'<!DOCTYPE svg [<!ENTITY x SYSTEM "file:///etc/passwd">]><svg>&x;</svg>')

    def test_svg_standard_external_doctype_is_removed_without_fetching(self):
        data = b'<!DOCTYPE svg SYSTEM "https://example.invalid/svg.dtd"><svg width="10" height="10"/>'
        result = sanitize_svg(data)
        self.assertNotIn(b'DOCTYPE', result)
        self.assertNotIn(b'example.invalid', result)

    def test_utf16_svg(self):
        result = sanitize_svg('<svg width="10" height="10"><title>图片</title></svg>'.encode('utf-16'))
        self.assertIn('图片', result.decode('utf-8'))

    def test_bad_encoding_is_readable_error(self):
        with self.assertRaises(ImageError):
            sanitize_svg(b'<svg>\xff</svg>')

    def test_svg_deep_nesting_rejected(self):
        with self.assertRaises(ImageError):
            sanitize_svg(('<svg>' + '<g>' * 70 + '</g>' * 70 + '</svg>').encode())

    def test_non_svg_xml_rejected(self):
        with self.assertRaises(ImageError):
            sanitize_svg(b'<html><body>not a picture</body></html>')


class ImageBookTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.file = Path(self.temp.name) / 'images.epub'
        self.files = sample_files()

    def tearDown(self):
        self.temp.cleanup()

    def render(self, body):
        self.files['OPS/Text/第一章.xhtml'] = xhtml('images', body)
        write_epub(self.file, self.files)
        self.book = EpubBook(self.file)
        self.addCleanup(self.book.close)
        return self.book.chapter_html('OPS/Text/第一章.xhtml')

    def test_unlisted_local_image_allowed(self):
        self.files['OPS/Images/unlisted.png'] = banner_png()
        result = self.render('<img src="../Images/unlisted.png"/>')
        self.assertIn('Images/unlisted.png', result)
        self.assertNotIn('未显示', result)

    def test_wrong_manifest_mime_supported(self):
        self.files['OPS/package.opf'] = self.files['OPS/package.opf'].replace('media-type="image/png"', 'media-type="image/jpg"')
        self.assertNotIn('未显示', self.render('<img src="../Images/banner.png"/>'))

    def test_chinese_and_spaces_image_url(self):
        self.files['OPS/Images/封 面.png'] = banner_png()
        result = self.render('<img src="../Images/%E5%B0%81%20%E9%9D%A2.png"/>')
        self.assertIn('%E5%B0%81%20%E9%9D%A2.png', result)

    def test_standalone_svg_reference(self):
        self.files['OPS/Images/chart.svg'] = '<svg viewBox="0 0 10 10"><rect width="10" height="10"/></svg>'
        result = self.render('<img src="../Images/chart.svg"/>')
        self.assertIn('Images/chart.svg', result)
        self.assertNotIn('未显示', result)

    def test_inline_svg_keeps_viewbox_and_shapes(self):
        result = self.render('<svg viewBox="0 0 10 10"><circle cx="5" cy="5" r="3"/></svg><p>正文仍在</p>')
        self.assertIn('epubimg://', result)
        self.assertIn('正文仍在', result)
        data = next(iter(self.book.embedded_images.values()))
        self.assertIn(b'viewBox="0 0 10 10"', data)
        self.assertIn(b'circle', data)

    def test_svg_wrapper_with_inherited_xlink_namespace(self):
        result = self.render('<svg viewBox="0 0 480 96"><image xlink:href="../Images/banner.png" width="480" height="96"/></svg>')
        self.assertIn('epubimg://', result)
        self.assertIn(b'data:image/png;base64,', next(iter(self.book.embedded_images.values())))

    def test_embedded_png_uses_virtual_url_and_deduplicates(self):
        uri = 'data:image/png;base64,' + base64.b64encode(banner_png()).decode()
        result = self.render(f'<img src="{uri}"/><img src="{uri}"/>')
        self.assertEqual(len(self.book.embedded_images), 1)
        self.assertEqual(result.count('epubimg://'), 2)

    def test_image_object_supported_and_fallback_hidden(self):
        result = self.render('<object data="../Images/banner.png">fallback</object><p>after</p>')
        self.assertIn('Images/banner.png', result)
        self.assertNotIn('fallback', result)
        self.assertIn('after', result)

    def test_width_and_height_hints_sanitized(self):
        result = self.render('<img src="../Images/banner.png" style="width:50%;height:auto;position:fixed" onload="evil()"/>')
        self.assertIn('width="50%"', result)
        self.assertNotIn('position:', result)
        self.assertNotIn('onload', result)

    def test_external_and_local_disk_images_blocked(self):
        result = self.render('<img src="https://example.invalid/x.png"/><img src="file:///tmp/a.png"/>')
        self.assertEqual(result.count('未显示插图'), 2)
        self.assertNotIn('src=', result)

    def test_invalid_unclosed_inline_svg_does_not_crash(self):
        self.assertIn('标签不完整', self.render('<svg><rect width="3"/>'))

    def test_svg_external_entities_cannot_read_files(self):
        result = self.render('<svg><image href="file:///etc/passwd"/><rect width="2" height="2"/></svg>')
        self.assertIn('epubimg://', result)
        self.assertNotIn(b'file:', next(iter(self.book.embedded_images.values())))


if __name__ == '__main__':
    unittest.main()
