from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from epub_core import EpubBook, EpubError, StateStore, decode_document, resolve_href, walk_toc
from make_demo import sample_files, write_epub


class BookTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "示例书籍.epub"

    def book(self, files=None, version=3):
        write_epub(self.path, files if files is not None else sample_files(version))
        result = EpubBook(self.path)
        self.addCleanup(result.close)
        return result

    def test_metadata(self):
        book = self.book()
        self.assertEqual(book.title, "在文字里散步")
        self.assertEqual(book.author, "墨读示例")

    def test_spine_order_not_manifest_order(self):
        book = self.book()
        self.assertEqual([c.path for c in book.chapters], ["OPS/Text/第一章.xhtml", "OPS/Text/chapter2.xhtml", "OPS/Text/chapter3.xhtml"])
        self.assertNotIn("OPS/Text/notes.xhtml", [c.path for c in book.chapters])
        self.assertTrue(book.is_document("OPS/Text/notes.xhtml"))

    def test_epub3_nested_navigation(self):
        book = self.book()
        self.assertEqual(len(book.toc), 3)
        self.assertEqual(book.toc[1].children[0].fragment, "half")
        self.assertEqual(book.chapters[1].title, "第二章 · 沿着文字走")

    def test_epub2_ncx(self):
        book = self.book(version=2)
        self.assertEqual(len(book.toc), 3)
        self.assertEqual(book.toc[1].children[0].fragment, "half")

    def test_ncx_fallback_for_invalid_nav(self):
        files = sample_files()
        files["OPS/nav.xhtml"] = "<invalid"
        book = self.book(files)
        self.assertEqual(len(book.toc), 3)
        self.assertTrue(book.warnings)

    def test_spine_fallback_for_absent_navigation(self):
        files = sample_files()
        files.pop("OPS/nav.xhtml")
        files.pop("OPS/toc.ncx")
        book = self.book(files)
        self.assertEqual([e.path for e in book.toc], [c.path for c in book.chapters])

    def test_heading_anchor_conversion(self):
        book = self.book()
        text = book.chapter_html("OPS/Text/chapter2.xhtml")
        self.assertIn('<a name="half"></a>', text)
        self.assertIn("中途的风景", text)

    def test_reading_html_keeps_images_links_and_structure(self):
        book = self.book()
        text = book.chapter_html("OPS/Text/第一章.xhtml")
        self.assertIn("<h1>", text)
        self.assertIn("<ul>", text)
        self.assertIn(book.url("OPS/Images/banner.png"), text)
        self.assertIn(book.url("OPS/Text/notes.xhtml", "note1"), text)
        self.assertNotIn("<link", text)

    def test_script_style_local_file_and_network_images_removed(self):
        files = sample_files()
        files["OPS/Text/chapter3.xhtml"] = '''<html><head><style>p{font-size:999px}</style></head><body>
        <script>alert('DO_NOT_KEEP')</script><p style="color:red" onclick="run()">安全文字</p>
        <a href="javascript:run()">脚本</a><a href="file:///etc/passwd">文件</a>
        <img src="https://example.com/tracker.png" /><img src="file:///etc/passwd" />
        <a href="https://example.com">外部链接</a></body></html>'''
        book = self.book(files)
        rendered = book.chapter_html("OPS/Text/chapter3.xhtml")
        for text in ("DO_NOT_KEEP", "<script", "<style", "onclick", "font-size", "file:", "javascript:", "tracker.png"):
            self.assertNotIn(text, rendered)
        self.assertIn("安全文字", rendered)
        self.assertIn('href="https://example.com"', rendered)

    def test_svg_image_wrapper_points_to_raster(self):
        files = sample_files()
        files["OPS/Text/chapter3.xhtml"] = '<svg><image xlink:href="../Images/banner.png" /></svg>'
        book = self.book(files)
        self.assertIn('<img src="', book.chapter_html("OPS/Text/chapter3.xhtml"))

    def test_archive_path_traversal_rejected(self):
        files = sample_files()
        files["../escape.txt"] = "unsafe"
        with self.assertRaises(EpubError):
            self.book(files)
        self.assertFalse((Path(self.temp.name).parent / "escape.txt").exists())

    def test_duplicate_zip_resource_rejected(self):
        import warnings
        write_epub(self.path, sample_files())
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            with zipfile.ZipFile(self.path, "a") as archive:
                archive.writestr("OPS/Text/chapter2.xhtml", "duplicate")
        with self.assertRaises(EpubError):
            EpubBook(self.path)

    def test_xml_entity_expansion_rejected(self):
        files = sample_files()
        files["META-INF/container.xml"] = '<!DOCTYPE x [<!ENTITY a "bad">]><x>&a;</x>'
        with self.assertRaises(EpubError):
            self.book(files)

    def test_drm_rejected(self):
        files = sample_files()
        files["META-INF/encryption.xml"] = '<encryption><EncryptedData><EncryptionMethod Algorithm="aes" /></EncryptedData></encryption>'
        with self.assertRaisesRegex(EpubError, "DRM"):
            self.book(files)

    def test_font_obfuscation_does_not_block_text(self):
        files = sample_files()
        files["META-INF/encryption.xml"] = '<encryption><EncryptedData><EncryptionMethod Algorithm="http://www.idpf.org/2008/embedding" /></EncryptedData></encryption>'
        book = self.book(files)
        self.assertEqual(len(book.chapters), 3)
        self.assertTrue(book.warnings)

    def test_limit_enforced_before_read(self):
        book = self.book()
        with self.assertRaises(EpubError):
            book.read("OPS/Text/chapter2.xhtml", 20)

    def test_archive_total_limit(self):
        with patch("epub_core.MAX_TOTAL_BYTES", 20):
            with self.assertRaises(EpubError):
                self.book()

    def test_manifest_fallback_chain(self):
        files = sample_files()
        files["OPS/package.opf"] = files["OPS/package.opf"].replace(
            '<manifest>', '<manifest><item id="foreign" href="unknown.bin" media-type="application/octet-stream" fallback="c1" />'
        ).replace('<itemref idref="c1" />', '<itemref idref="foreign" />')
        files["OPS/unknown.bin"] = b"binary"
        book = self.book(files)
        self.assertEqual(book.chapters[0].path, "OPS/Text/第一章.xhtml")

    def test_book_identity_stable_across_copies(self):
        book = self.book()
        copy = Path(self.temp.name) / "copy.epub"
        copy.write_bytes(self.path.read_bytes())
        with EpubBook(copy) as other:
            self.assertEqual(book.book_id, other.book_id)

    def test_book_url_roundtrip(self):
        book = self.book()
        path = "OPS/Text/第一章.xhtml"
        self.assertEqual(book.resolve(path, book.url(path, "中文 锚点")), (path, "中文 锚点"))
        with self.assertRaises(EpubError):
            book.resolve(path, "epub://otherbook/OPS/Text/chapter2.xhtml")

    def test_bad_zip_and_missing_container(self):
        self.path.write_text("not a zip")
        with self.assertRaises(EpubError):
            EpubBook(self.path)
        write_epub(self.path, {"mimetype": "application/epub+zip"})
        with self.assertRaises(EpubError):
            EpubBook(self.path)

    def test_closed_book_error(self):
        book = self.book()
        book.close()
        with self.assertRaises(EpubError):
            book.read("OPS/package.opf")


class PathTests(unittest.TestCase):
    def test_relative_unicode_and_fragment(self):
        self.assertEqual(resolve_href("OPS/Text/ch1.xhtml", "../Text/%E7%AC%AC%E4%B8%80%E7%AB%A0.xhtml#%E5%B0%8F%E8%8A%82"),
                         ("OPS/Text/第一章.xhtml", "小节"))

    def test_fragment_and_single_decoding(self):
        self.assertEqual(resolve_href("OPS/a.xhtml", "#note"), ("OPS/a.xhtml", "note"))
        self.assertEqual(resolve_href("OPS/a.xhtml", "%2520.xhtml"), ("OPS/%20.xhtml", ""))

    def test_invalid_paths(self):
        for href in ("../../../etc/passwd", "%2e%2e/%2e%2e/etc", "file:///etc/passwd", "//evil.test/a", "https://x.test/a", "a%00.xhtml", "..\\evil"):
            with self.subTest(href=href), self.assertRaises(EpubError):
                resolve_href("OPS/a.xhtml", href)

    def test_unicode_decoding(self):
        self.assertEqual(decode_document("中文".encode("utf-8")), "中文")
        self.assertEqual(decode_document("中文".encode("utf-16")), "中文")
        data = '<?xml version="1.0" encoding="gb18030"?><p>中文</p>'.encode("gb18030")
        self.assertIn("中文", decode_document(data))


class StateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "settings" / "state.json"

    def test_atomic_unicode_roundtrip(self):
        store = StateStore(self.path)
        store.data["books"]["abc"] = {"title": "中文书名", "ratio": 0.42, "bookmarks": []}
        store.save()
        self.assertEqual(StateStore(self.path).data, store.data)
        self.assertEqual(list(self.path.parent.glob(".state-*.tmp")), [])

    def test_corrupted_json_recovers_defaults(self):
        self.path.parent.mkdir()
        self.path.write_text("{broken", encoding="utf-8")
        store = StateStore(self.path)
        self.assertTrue(store.warning)
        self.assertEqual(store.data["books"], {})

    def test_failed_replace_keeps_previous_record(self):
        store = StateStore(self.path)
        store.save()
        original = self.path.read_bytes()
        store.data["preferences"]["font_size"] = 22
        with patch("epub_core.os.replace", side_effect=OSError("disk unavailable")):
            with self.assertRaises(OSError):
                store.save()
        self.assertEqual(self.path.read_bytes(), original)
        self.assertEqual(list(self.path.parent.glob(".state-*.tmp")), [])

    def test_invalid_container_types_ignored(self):
        self.path.parent.mkdir()
        self.path.write_text('{"books": [], "recent": {}, "preferences": null}')
        store = StateStore(self.path)
        self.assertEqual(store.data, {"books": {}, "recent": [], "preferences": {}})


if __name__ == "__main__":
    unittest.main()
