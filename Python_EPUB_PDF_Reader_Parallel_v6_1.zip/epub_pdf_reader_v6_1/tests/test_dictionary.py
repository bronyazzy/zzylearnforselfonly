"""Dictionary, import and vocabulary tests; no Qt or network needed."""
from __future__ import annotations

import csv
import io
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from dictionary_core import (
    BUILTIN_PATH, DictionaryEngine, DictionaryError, Entry, ImportCancelled,
    LookupResult, VocabularyStore, import_csv, normalize, result_html,
    safe_csv_cell, valid_query, word_candidates,
)
from epub_core import EpubBook
from make_finance_demo import finance_files
from make_demo import write_epub


class BuiltinDictionaryTests(unittest.TestCase):
    def setUp(self):
        self.engine = DictionaryEngine()

    def tearDown(self):
        self.engine.close()

    def test_counts_and_every_entry_has_ipa_and_chinese(self):
        self.assertEqual(len(self.engine.entries), 453)
        self.assertEqual(self.engine.finance_count, 332)
        for entry in self.engine.entries.values():
            with self.subTest(word=entry.word):
                self.assertTrue(entry.phonetic)
                self.assertTrue(entry.chinese)
                self.assertTrue(valid_query(entry.word))
                self.assertRegex(entry.chinese, r"[\u4e00-\u9fff]")

    def test_all_bundled_headwords_can_be_looked_up(self):
        for key in self.engine.entries:
            with self.subTest(key=key):
                self.assertIn(key, [normalize(e.word) for e in self.engine.lookup(key).entries])

    def test_every_alias_resolves_to_its_headword(self):
        for alias, targets in self.engine.aliases.items():
            with self.subTest(alias=alias):
                found = {normalize(e.word) for e in self.engine.lookup(alias).entries}
                self.assertTrue(set(targets).issubset(found))

    def test_capital_has_finance_and_general_senses(self):
        entry = self.engine.lookup("capital").entries[0]
        self.assertIn("资本", entry.finance)
        self.assertIn("首都", entry.translation)

    def test_finance_first_and_general_first(self):
        self.assertEqual(self.engine.lookup("forecasting", True).entries[0].word, "forecast")
        self.assertEqual(self.engine.lookup("forecasting", False).entries[0].word, "forecasting")

    def test_case_and_outer_punctuation(self):
        self.assertEqual(self.engine.lookup(' “LEVERAGE,” ').entries[0].word, "leverage")
        self.assertEqual(normalize("  cash\u2029flow  "), "cash flow")

    def test_short_forms(self):
        for word, target in {"ETF": "exchange traded fund", "NAV": "net asset value",
                             "EPS": "earnings per share", "P/E": "price to earnings ratio",
                             "WACC": "weighted average cost of capital", "VaR": "value at risk"}.items():
            self.assertEqual(self.engine.lookup(word).entries[0].word, target)

    def test_known_irregular_forms(self):
        for form, base in {"bought": "buy", "sold": "sell", "indices": "index",
                           "liabilities": "liability", "hedging": "hedge", "equities": "equity"}.items():
            self.assertEqual(self.engine.lookup(form).entries[0].word, base)

    def test_hyphens_apostrophes_and_uk_alias(self):
        self.assertEqual(self.engine.lookup("risk-free rate").entries[0].word, "risk free rate")
        self.assertEqual(self.engine.lookup("investor’s").entries[0].word, "investor")
        self.assertEqual(self.engine.lookup("amortisation").entries[0].word, "amortization")

    def test_plural_phrase(self):
        self.assertEqual(self.engine.lookup("interest rates").entries[0].word, "interest rate")

    def test_suffix_guess_has_explicit_notice(self):
        self.assertEqual(self.engine.lookup("allocations'").entries[0].word, "allocation")
        result = self.engine.lookup("couponed")
        self.assertEqual(result.entries[0].word, "coupon")
        self.assertIn("推测", result.match_note)

    def test_no_result_has_suggestions(self):
        result = self.engine.lookup("leverag")
        self.assertFalse(result.entries)
        self.assertIn("leverage", result.suggestions)
        self.assertIn("未收录", result.match_note)

    def test_query_limits_and_non_english_selection(self):
        for query in ("", "只有中文", "a" * 161, "a " * 13, "<script>alert(1)</script>", "a\x00b"):
            self.assertFalse(valid_query(query))
            self.assertFalse(self.engine.lookup(query).entries)
        self.assertTrue(valid_query("P/E"))

    def test_inflection_exceptions(self):
        for word in ("news", "series", "analysis", "futures", "earnings"):
            self.assertEqual(word_candidates(word), [(word, "精确匹配")])
            self.assertEqual(normalize(self.engine.lookup(word).entries[0].word), word)

    def test_financial_meanings_distinguish_key_concepts(self):
        self.assertIn("默认", self.engine.lookup("default").entries[0].translation)
        self.assertIn("违约", self.engine.lookup("default").entries[0].finance)
        self.assertIn("不是最大", self.engine.lookup("VaR").entries[0].finance)
        self.assertIn("不等于", self.engine.lookup("disinflation").entries[0].finance)

    def test_html_all_untrusted_fields_are_escaped(self):
        entry = Entry(word='<img src="file:///etc/passwd">', phonetic="<bad>",
                      finance='<script>alert(1)</script>', source='<iframe src="http://x">',
                      examples=(("<b>unsafe</b>", "<svg>"),))
        rendered = result_html(LookupResult("x", [entry], "<bad>"))
        for tag in ("<script>", "<img ", "<iframe ", "<svg>", "<bad>"):
            self.assertNotIn(tag, rendered)
        self.assertIn("&lt;script&gt;", rendered)

    def test_render_order_and_ipa_fallback(self):
        result = self.engine.lookup("equity")
        self.assertLess(result_html(result).index("金融释义"), result_html(result).index("普通中文释义"))
        self.assertGreater(result_html(result, False).index("金融释义"), result_html(result, False).index("普通中文释义"))
        self.assertIn("暂无音标", result_html(LookupResult("x", [Entry("x", translation="测试")])) )

    def test_prefix_suggestions_and_encoding(self):
        self.assertIn("cash flow", self.engine.suggest("cash"))
        html_text = result_html(LookupResult("x", [], suggestions=["cash flow", "P/E"]))
        self.assertIn("lookup:///cash%20flow", html_text)
        self.assertIn("lookup:///P%2FE", html_text)

    def test_all_30_original_examples_are_bilingual(self):
        examples = [example for e in self.engine.entries.values() for example in e.examples]
        self.assertEqual(len(examples), 30)
        self.assertTrue(all(en and zh for en, zh in examples))

    def test_missing_and_corrupt_builtin_is_a_readable_error(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "missing.json"
            with self.assertRaises(DictionaryError):
                DictionaryEngine(builtin_path=path)
            path.write_text('{bad', encoding="utf-8")
            with self.assertRaises(DictionaryError):
                DictionaryEngine(builtin_path=path)

    def test_finance_epub_parses_without_warnings(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "demo.epub"
            write_epub(path, finance_files())
            with EpubBook(path) as book:
                self.assertEqual(len(book.chapters), 4)
                self.assertEqual(len(book.toc), 4)
                self.assertEqual(book.warnings, [])
                self.assertIn("leverage", book.chapter_html(book.chapters[0].path))


class CsvImportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.csv = self.directory / "词库.csv"
        self.db = self.directory / "dictionary.sqlite"

    def tearDown(self):
        self.temp.cleanup()

    def write_rows(self, rows, fields=None):
        fields = fields or ["word", "phonetic", "translation", "finance", "exchange", "aliases", "source"]
        with self.csv.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)

    def test_utf8_bom_import_and_sqlite_roundtrip(self):
        self.write_rows([{"word": "fintech", "phonetic": "ˈfɪntek", "translation": "金融科技"}])
        self.assertEqual(import_csv(self.csv, self.db), 1)
        engine = DictionaryEngine(self.db)
        try:
            entry = engine.lookup("FINTECH").entries[0]
            self.assertEqual(entry.phonetic, "ˈfɪntek")
            self.assertEqual(entry.translation, "金融科技")
            self.assertEqual(engine.extra_count, 1)
        finally:
            engine.close()

    def test_ecdict_exchange_fields(self):
        self.write_rows([{"word": "walk", "phonetic": "wɔːk", "translation": "行走",
                          "exchange": "p:walked/d:walked/i:walking/3:walks"}])
        import_csv(self.csv, self.db)
        engine = DictionaryEngine(self.db)
        try:
            for word in ("walked", "walking", "walks"):
                self.assertEqual(engine.lookup(word).entries[0].word, "walk")
        finally:
            engine.close()

    def test_ecdict_lemma_relation_survives_reverse_row_order(self):
        self.write_rows([{"word": "went", "translation": "去的过去式", "exchange": "0:go/1:p"},
                         {"word": "go", "translation": "去"}])
        import_csv(self.csv, self.db)
        engine = DictionaryEngine(self.db)
        try:
            found = [e.word for e in engine.lookup("went").entries]
            self.assertIn("go", found)
        finally:
            engine.close()

    def test_finance_priority_preserves_bundled_sense(self):
        self.write_rows([{"word": "equity", "phonetic": "ˈekwɪti", "translation": "普通扩展释义"},
                         {"word": "special finance", "translation": "一般", "finance": "金融专义"}])
        import_csv(self.csv, self.db)
        engine = DictionaryEngine(self.db)
        try:
            entries = engine.lookup("equity").entries
            self.assertIn("股权", entries[0].finance)
            self.assertEqual(len(entries), 2)
            self.assertEqual(engine.lookup("special finance").entries[0].finance, "金融专义")
        finally:
            engine.close()

    def test_custom_aliases_and_multiline_fields(self):
        self.write_rows([{"word": "custom term", "translation": "第一行\n第二行", "aliases": "ct,custom-term"}])
        import_csv(self.csv, self.db)
        engine = DictionaryEngine(self.db)
        try:
            self.assertEqual(engine.lookup("CT").entries[0].translation, "第一行\n第二行")
        finally:
            engine.close()

    def test_duplicate_last_definition_wins(self):
        self.write_rows([{"word": "custom", "translation": "旧"}, {"word": "CUSTOM", "translation": "新"}])
        self.assertEqual(import_csv(self.csv, self.db), 1)
        engine = DictionaryEngine(self.db)
        try:
            self.assertEqual(engine.lookup("custom").entries[0].translation, "新")
        finally:
            engine.close()

    def test_sql_metacharacters_are_parameterized(self):
        self.write_rows([{"word": "o'brien", "translation": "测试词"}])
        import_csv(self.csv, self.db)
        engine = DictionaryEngine(self.db)
        try:
            self.assertEqual(engine.lookup("O'Brien").entries[0].translation, "测试词")
            self.assertFalse(engine.lookup("' OR 'x'='x").entries)
            self.assertEqual(engine.extra_count, 1)
        finally:
            engine.close()

    def test_bad_header_leaves_existing_database_unchanged(self):
        self.write_rows([{"word": "custom", "translation": "测试"}])
        import_csv(self.csv, self.db)
        before = self.db.read_bytes()
        self.csv.write_text("word,meaning\na,错误表头\n", encoding="utf-8")
        with self.assertRaises(DictionaryError):
            import_csv(self.csv, self.db)
        self.assertEqual(self.db.read_bytes(), before)
        self.assertFalse(list(self.directory.glob(".dictionary-*")))

    def test_invalid_utf8_and_extra_columns_do_not_publish(self):
        self.csv.write_bytes(b'word,translation\na,\xff\n')
        with self.assertRaises(DictionaryError):
            import_csv(self.csv, self.db)
        self.assertFalse(self.db.exists())
        self.csv.write_text('word,translation\na,meaning,extra\n', encoding="utf-8")
        with self.assertRaises(DictionaryError):
            import_csv(self.csv, self.db)
        self.assertFalse(self.db.exists())

    def test_empty_invalid_and_too_long_rows_are_skipped(self):
        self.write_rows([{"word": "有效中文", "translation": "ignored"},
                         {"word": "x" * 161, "translation": "ignored"},
                         {"word": "empty", "translation": ""},
                         {"word": "valid", "translation": "有效"}])
        self.assertEqual(import_csv(self.csv, self.db), 1)

    def test_no_valid_rows_is_an_error(self):
        self.write_rows([{"word": "", "translation": ""}])
        with self.assertRaises(DictionaryError):
            import_csv(self.csv, self.db)
        self.assertFalse(self.db.exists())

    def test_cancel_retains_original_and_removes_temporary_files(self):
        self.write_rows([{"word": "custom", "translation": "old"}])
        import_csv(self.csv, self.db)
        before = self.db.read_bytes()
        self.write_rows([{"word": "replacement", "translation": "new"}])
        with self.assertRaises(ImportCancelled):
            import_csv(self.csv, self.db, cancelled=lambda: True)
        self.assertEqual(self.db.read_bytes(), before)
        self.assertFalse(list(self.directory.glob(".dictionary-*")))

    def test_progress_and_mid_import_cancel(self):
        self.write_rows([{"word": f"test{i}", "translation": "测试"} for i in range(2100)])
        values = []
        with self.assertRaises(ImportCancelled):
            import_csv(self.csv, self.db, progress=values.append, cancelled=lambda: bool(values))
        self.assertEqual(values, [2000])
        self.assertFalse(self.db.exists())

    def test_io_failure_does_not_replace_original(self):
        self.write_rows([{"word": "custom", "translation": "old"}])
        import_csv(self.csv, self.db)
        before = self.db.read_bytes()
        with patch("dictionary_core.os.replace", side_effect=OSError("read-only destination")):
            with self.assertRaises(OSError):
                import_csv(self.csv, self.db)
        self.assertEqual(before, self.db.read_bytes())
        self.assertFalse(list(self.directory.glob(".dictionary-*")))

    def test_corrupt_extra_db_degrades_to_bundled_dictionary(self):
        self.db.write_bytes(b"not sqlite")
        engine = DictionaryEngine(self.db)
        try:
            self.assertTrue(engine.warning)
            self.assertEqual(engine.extra_count, 0)
            self.assertTrue(engine.lookup("leverage").entries)
        finally:
            engine.close()

    def test_source_cannot_be_destination(self):
        self.write_rows([{"word": "test", "translation": "测试"}])
        with self.assertRaises(DictionaryError):
            import_csv(self.csv, self.csv)

    def test_example_csv_import(self):
        path = BUILTIN_PATH.parent.parent / "examples" / "custom_dictionary.csv"
        self.assertEqual(import_csv(path, self.db), 4)
        engine = DictionaryEngine(self.db)
        try:
            self.assertEqual(engine.lookup("walking").entries[0].word, "walk")
            self.assertTrue(engine.lookup("buy-and-hold").entries)
        finally:
            engine.close()


class VocabularyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.filename = self.directory / "vocabulary.json"
        self.store = VocabularyStore(self.filename)
        self.entry = Entry("leverage", "ˈlevərɪdʒ", "杠杆", "影响力", source="测试来源")

    def tearDown(self):
        self.temp.cleanup()

    def test_roundtrip_includes_context_and_book(self):
        self.assertTrue(self.store.add(self.entry, "Leverage increases risk.", "Finance book"))
        restored = VocabularyStore(self.filename)
        row = restored.items["leverage"]
        self.assertEqual(row["phonetic"], "ˈlevərɪdʒ")
        self.assertEqual(row["finance"], "杠杆")
        self.assertEqual(row["context"], "Leverage increases risk.")
        self.assertEqual(row["book"], "Finance book")

    def test_duplicates_update_without_changing_creation_date(self):
        self.store.add(self.entry, "old")
        created = self.store.items["leverage"]["created"]
        self.assertFalse(self.store.add(self.entry, "new"))
        self.assertEqual(len(self.store.items), 1)
        self.assertEqual(self.store.items["leverage"]["created"], created)
        self.assertEqual(self.store.items["leverage"]["context"], "new")

    def test_delete_roundtrip(self):
        self.store.add(self.entry)
        self.assertTrue(self.store.delete("LEVERAGE"))
        self.assertFalse(self.store.delete("missing"))
        self.assertFalse(VocabularyStore(self.filename).items)

    def test_export_utf8_bom_and_all_fields(self):
        self.store.add(self.entry, '"quoted", context\nsecond line', "测试书")
        export = self.directory / "words.csv"
        self.assertEqual(self.store.export_csv(export), 1)
        self.assertTrue(export.read_bytes().startswith(b"\xef\xbb\xbf"))
        with export.open(encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(rows[0]["context"], '"quoted", context\nsecond line')
        self.assertEqual(rows[0]["phonetic"], self.entry.phonetic)
        self.assertEqual(rows[0]["book"], "测试书")

    def test_formula_injection_is_neutralized(self):
        for value in ('=HYPERLINK("http://x")', "+cmd", "-cmd", "@SUM(A1)", "  =1", "\tunsafe"):
            self.assertTrue(safe_csv_cell(value).startswith("'"))
        self.assertEqual(safe_csv_cell("ordinary"), "ordinary")

    def test_failed_write_does_not_change_memory_or_existing_file(self):
        self.store.add(self.entry, "before")
        before = self.filename.read_bytes()
        with patch("dictionary_core.os.replace", side_effect=OSError("disk error")):
            with self.assertRaises(OSError):
                self.store.add(self.entry, "after")
        self.assertEqual(self.filename.read_bytes(), before)
        self.assertEqual(self.store.items["leverage"]["context"], "before")
        self.assertFalse(list(self.directory.glob(".vocabulary-*")))

    def test_corrupt_wordbook_is_protected(self):
        self.filename.write_text('{broken', encoding="utf-8")
        restored = VocabularyStore(self.filename)
        self.assertTrue(restored.warning)
        self.assertTrue(restored.read_only)
        with self.assertRaises(DictionaryError):
            restored.add(self.entry)
        self.assertEqual(self.filename.read_text(), '{broken')

    def test_limits_and_context_truncation(self):
        self.store.add(self.entry, "x" * 2000, "b" * 600)
        self.assertEqual(len(self.store.items["leverage"]["context"]), 1000)
        self.assertEqual(len(self.store.items["leverage"]["book"]), 300)
        with patch("dictionary_core.MAX_VOCAB", 1):
            with self.assertRaises(DictionaryError):
                self.store.add(Entry("second", translation="第二"))

    def test_export_cannot_overwrite_native_wordbook(self):
        self.store.add(self.entry)
        with self.assertRaises(DictionaryError):
            self.store.export_csv(self.filename)
        self.assertTrue(VocabularyStore(self.filename).items)


if __name__ == "__main__":
    unittest.main()
