"""Real QUrl/QTextDocument/native-window regressions. Never simulated as passes."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
try:
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QUrl
    from PySide6.QtGui import QTextTable
    from PySide6.QtTest import QTest
    from epub_reader import EnhancedReaderWindow
    from epub_core import EpubBook, StateStore
    from publisher_core import LayoutSettings
    QT=True
except (ImportError,SystemExit,OSError):
    QT=False
ROOT=Path(__file__).resolve().parents[1]

@unittest.skipUnless(QT,'缺少 Qt；未执行原生地址/双栏/窗口恢复测试')
class NativeDisplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        with patch.dict(os.environ,{'MODU_COMPATIBLE_EPUB':'1'}):
            self.window=EnhancedReaderWindow(StateStore(Path(self.temp.name)/'state.json'))
        self.window.show();self.assertTrue(self.window.open_book(str(ROOT/'parallel_demo.epub')));QTest.qWait(100)
    def tearDown(self):self.window.close();QTest.qWait(50)
    def tables(self):
        return [f for f in self.window.browser.document().rootFrame().childFrames() if isinstance(f,QTextTable)]
    def test_qurl_rejects_old_64_character_label(self):
        u=QUrl('epub://'+self.window.book.book_id+'/OPS/first.xhtml')
        self.assertFalse(u.isValid())
    def test_qurl_accepts_new_host_and_utf8_path(self):
        b=self.window.book;u=QUrl(b.url('OPS/中文 空格.xhtml','注释'))
        self.assertTrue(u.isValid(),u.errorString());self.assertEqual(u.host(),b.url_host)
    def test_embedded_image_url_is_valid(self):
        u=QUrl(self.window.book.register_image(b'abc'));self.assertTrue(u.isValid(),u.errorString())
    def test_compatible_launch_does_not_create_browser_view(self):
        self.assertIsNone(self.window.publication_view)
        self.assertIs(self.window.document_stack.currentWidget(),self.window.browser)
    def test_native_bilingual_document_is_nonempty(self):
        text=self.window.browser.toPlainText();self.assertIn('Parallel reading check',text);self.assertIn('左右对照',text)
        self.assertEqual(len(self.tables()),41)
    def test_native_table_cells_preserve_languages(self):
        table=self.tables()[0];self.assertEqual(table.columns(),2)
        c=table.cellAt(0,0);cursor=c.firstCursorPosition();cursor.setPosition(c.lastCursorPosition().position(),cursor.MoveMode.KeepAnchor)
        self.assertIn('Parallel',cursor.selectedText())
    def test_start_and_idle_remain_at_top(self):
        self.assertEqual(self.window.browser.verticalScrollBar().value(),0)
        QTest.qWait(400);self.assertEqual(self.window.browser.verticalScrollBar().value(),0)
    def test_native_column_ratio_changes_keep_content(self):
        old=self.window.browser.toPlainText();self.window.set_layout(mode='compatible',english_percent=42);QTest.qWait(100)
        self.assertEqual(self.window.browser.toPlainText(),old);self.assertEqual(len(self.tables()),41)
    def test_theme_change_keeps_two_columns(self):
        self.window.set_background('#e6f1e7');QTest.qWait(100)
        self.assertEqual(len(self.tables()),41);self.assertTrue(self.window.browser.toPlainText())
    def test_manual_repair_rebuilds_instead_of_blank_cache(self):
        self.window._cached_html='';self.window.use_compatible();QTest.qWait(100)
        self.assertEqual(len(self.tables()),41);self.assertIn('Parallel',self.window.browser.toPlainText())
    def test_missing_webengine_uses_native(self):
        self.window._force_compatible=False
        with patch('publisher_integration.PublicationView',None),patch('publisher_integration.WEBENGINE_ERROR','Missing test DLL'):
            self.window.set_layout(mode='publisher');QTest.qWait(100)
        self.assertEqual(self.window.layout_settings.mode,'compatible');self.assertIn('Parallel',self.window.browser.toPlainText())
    def test_native_next_chapter_images_and_back(self):
        self.window.change_chapter(1);QTest.qWait(100)
        self.assertEqual(self.window.current_path,'OPS/second.xhtml');self.assertFalse(self.window.browser.images.warnings)
        self.window.change_chapter(-1);QTest.qWait(100);self.assertEqual(len(self.tables()),41)
    def test_mode_saved_and_bookmarks_not_deleted(self):
        self.window.add_bookmark();self.window.save_state()
        record=self.window.store.data['books'][self.window.book.book_id]
        self.assertEqual(record['epub_layout']['mode'],'compatible');self.assertEqual(len(self.window.bookmarks),1)
    def test_pdf_and_compatible_epub_switch_keep_dictionary(self):
        dock=self.window.dictionary_dock
        self.assertTrue(self.window.open_book(str(ROOT/'pdf_demo.pdf')));QTest.qWait(100)
        self.assertIsNotNone(self.window.pdf_book);self.assertIs(self.window.dictionary_dock,dock)
        self.assertTrue(self.window.open_book(str(ROOT/'parallel_demo.epub')));QTest.qWait(100)
        self.assertTrue(self.window.browser.toPlainText());self.assertIs(self.window.dictionary_dock,dock)

if __name__=='__main__':unittest.main()
