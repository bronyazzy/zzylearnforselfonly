"""Actual Qt regression tests; explicitly skipped when PySide6 is unavailable."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HAS_QT = importlib.util.find_spec('PySide6') is not None
if HAS_QT:
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtCore import QUrl
    from PySide6.QtGui import QColor, QImage, QTextCursor, QTextDocument
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication
    from epub_core import StateStore
    from epub_reader import ReaderWindow
    from image_ui import ChapterImages
    from make_image_demo import image_files
    from make_demo import write_epub


@unittest.skipUnless(HAS_QT, 'PySide6 未安装，跳过 3.0 图形回归测试')
class ReaderV3GuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setStyle('Fusion')
        cls.app.setQuitOnLastWindowClosed(False)
        cls.fixture = image_files()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.epub = self.directory / 'images.epub'
        write_epub(self.epub, self.fixture)
        self.state_file = self.directory / 'state.json'
        self.window = ReaderWindow(StateStore(self.state_file))
        self.window.show()
        self.assertTrue(self.window.open_book(str(self.epub)))
        QTest.qWait(350)

    def tearDown(self):
        self.window.close()
        QTest.qWait(30)
        self.temp.cleanup()

    def test_first_open_stays_at_top_without_interaction(self):
        bar = self.window.browser.verticalScrollBar()
        self.assertGreater(bar.maximum(), 0)
        for _ in range(8):
            QTest.qWait(120)
            self.assertEqual(bar.value(), 0)
        self.assertFalse(self.window._resize_timer.isActive())
        self.assertFalse(self.window._restore_timer.isActive())

    def test_old_scroll_record_not_restored_by_default(self):
        record = self.window.store.data['books'][self.window.book.book_id]
        record.update(ratio=.7)
        record.pop('viewport', None)
        self.window.open_book(str(self.epub))
        QTest.qWait(350)
        self.assertEqual(self.window.browser.verticalScrollBar().value(), 0)

    def test_repeated_resizes_do_not_replace_document_or_scroll_top(self):
        doc = self.window.browser.document()
        for width in (1250, 1500, 1120, 1420, 1300):
            self.window.resize(width, 840)
            QTest.qWait(180)
            self.assertIs(self.window.browser.document(), doc)
            self.assertEqual(self.window.browser.verticalScrollBar().value(), 0)

    def test_resize_keeps_near_same_text(self):
        cursor = self.window.browser.document().find('定位标记 025')
        self.assertFalse(cursor.isNull())
        self.window.browser.setTextCursor(cursor)
        self.window.browser.ensureCursorVisible()
        QTest.qWait(30)
        before = self.window.capture_view().position
        self.window.resize(1120, 780)
        QTest.qWait(300)
        self.assertLess(abs(self.window.capture_view().position - before), 300)

    def test_dock_toggle_does_not_scroll_top(self):
        for visible in (False, True, False, True):
            self.window.dictionary_dock.setVisible(visible)
            QTest.qWait(200)
            self.assertEqual(self.window.browser.verticalScrollBar().value(), 0)

    def test_custom_background_is_saved(self):
        self.window.set_background('#DCF1E5')
        QTest.qWait(80)
        self.assertEqual(self.window.background, '#dcf1e5')
        self.assertEqual(StateStore(self.state_file).data['preferences']['background_color'], '#dcf1e5')
        self.assertIn('#dcf1e5', self.window.document_css())

    def test_background_reloaded_by_new_window(self):
        self.window.set_background('#cde3f0')
        self.window.close()
        QTest.qWait(30)
        self.window = ReaderWindow(StateStore(self.state_file))
        self.window.show()
        QTest.qWait(80)
        self.assertEqual(self.window.background, '#cde3f0')

    def test_dark_custom_background_chooses_light_text(self):
        self.window.set_background('#102030')
        self.assertTrue(self.window.night)
        self.assertEqual(self.window._colors[2], '#ffffff')
        self.assertTrue(self.window.dictionary_dock.night)

    def test_night_toggle_returns_to_chosen_day_color(self):
        self.window.set_background('#e6f1e7')
        self.window.toggle_night(True)
        self.window.toggle_night(False)
        self.assertEqual(self.window.background, '#e6f1e7')

    def test_color_dialog_cancel_is_noop(self):
        before = self.window.background
        with patch('epub_reader.QColorDialog.getColor', return_value=QColor()):
            self.window.choose_background()
        self.assertEqual(self.window.background, before)

    def test_invalid_color_does_not_change_theme(self):
        before = self.window.background
        self.window.set_background('red; background: url(file:///tmp/any)')
        self.assertEqual(self.window.background, before)

    def test_font_and_background_keep_reading_position(self):
        bar = self.window.browser.verticalScrollBar()
        bar.setValue(round(bar.maximum() * .6))
        before = self.window.capture_view().position
        self.window.change_font(2)
        QTest.qWait(120)
        self.window.set_background('#e6f1e7')
        QTest.qWait(120)
        self.assertLess(abs(self.window.capture_view().position - before), 300)

    def test_all_image_fixtures_decode_without_warning(self):
        loader = self.window.browser.images
        self.assertGreaterEqual(len(loader.specs), 7)
        for spec in loader.specs:
            picture = loader.get(spec.url)
            self.assertFalse(picture.image.isNull(), spec.url)
            self.assertFalse(picture.error, picture.error)
        self.assertFalse(loader.warnings, loader.warnings)

    def test_image_width_is_capped_and_ratio_kept(self):
        url = self.window.book.url('OPS/Images/wide.png')
        picture = self.window.browser.images.get(url)
        self.assertEqual((picture.width, picture.height), (1600, 480))
        image = self.window.browser.document().resource(QTextDocument.ResourceType.ImageResource.value, QUrl(url))
        self.assertIsInstance(image, QImage)
        self.assertLessEqual(image.width(), self.window.browser.image_width)
        self.assertAlmostEqual(image.width() / image.height(), 1600 / 480, delta=.03)

    def test_corrupt_image_gets_visible_placeholder(self):
        url = self.window.book.register_image(b'bad-image')
        picture = self.window.browser.images.get(url)
        self.assertTrue(picture.error)
        self.assertFalse(picture.image.isNull())

    def test_resume_opt_in_persists_viewport(self):
        bar = self.window.browser.verticalScrollBar()
        bar.setValue(round(bar.maximum() * .45))
        before = self.window.capture_view().position
        self.window.toggle_restore_position(True)
        self.window.close()
        QTest.qWait(50)
        self.window = ReaderWindow(StateStore(self.state_file))
        self.window.show()
        self.window.open_book(str(self.epub))
        QTest.qWait(350)
        self.assertTrue(self.window.restore_position)
        self.assertLess(abs(self.window.capture_view().position - before), 200)

    def test_manual_input_cancels_deferred_restore(self):
        self.window.navigate(self.window.current_path, ratio=.9)
        self.window.cancel_pending_position()
        self.window.browser.verticalScrollBar().setValue(100)
        QTest.qWait(300)
        self.assertEqual(self.window.browser.verticalScrollBar().value(), 100)
        self.assertIsNone(self.window._pending_target)

    def test_chapter_start_command(self):
        bar = self.window.browser.verticalScrollBar()
        bar.setValue(bar.maximum())
        self.window.go_to_chapter_start()
        self.assertEqual(bar.value(), 0)


if __name__ == '__main__':
    unittest.main()
