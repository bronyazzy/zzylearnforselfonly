from pathlib import Path
import hashlib
import tempfile
import unittest
from unittest.mock import patch
from lxml import html as LH
from epub_core import EpubBook, EpubError
from make_demo import sample_files,write_epub
from publisher_core import LayoutSettings, PublisherResources, appearance_payload, clean_anchor
from make_parallel_demo import build

ROOT=Path(__file__).resolve().parents[1]

class LayoutValueTests(unittest.TestCase):
    def test_default_and_unknown_mode(self):
        for value in (None,[],{}, {'mode':[]},{'mode':'unknown'}):
            self.assertEqual(LayoutSettings.from_dict(value).mode,'publisher')
    def test_numeric_limits_and_nan(self):
        d=LayoutSettings.from_dict({'english_percent':999,'content_width':-1,'gutter':0,'line_height':float('nan')})
        self.assertEqual((d.english_percent,d.content_width,d.gutter,d.line_height),(70,0,8,0))
    def test_settings_roundtrip(self):
        d=LayoutSettings(mode='parallel',english_percent=43,use_theme=False)
        self.assertEqual(LayoutSettings.from_dict(d.as_dict()),d)
    def test_palette_is_validated(self):
        d=appearance_payload(LayoutSettings(),'red;url(http://a)',999)
        self.assertEqual(d['background'],'#faf8f3');self.assertEqual(d['fontSize'],36)
    def test_invalid_anchor_cannot_become_selector(self):
        a=clean_anchor({'id':'1"] + script','offset':float('nan'),'ratio':7,'x':-9})
        self.assertEqual((a['id'],a['offset'],a['ratio'],a['x']),('',0,1,0))
    def test_anchor_roundtrip(self):
        a={'id':'17','offset':-43.5,'ratio':.2,'top':False,'bottom':False,'x':0,'y':540}
        self.assertEqual(clean_anchor(a),a);self.assertIsNone(clean_anchor(None))


class PublicationCoreTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'双语测试.epub'
    def resource(self,source=None,extra=None):
        files=sample_files()
        if source is not None:files['OPS/Text/chapter3.xhtml']=source
        if extra:files.update(extra)
        write_epub(self.path,files);b=EpubBook(self.path);self.addCleanup(b.close)
        return PublisherResources(b)
    def parsed(self,source,extra=None):
        r=self.resource(source,extra);return r,LH.fromstring(r.chapter('OPS/Text/chapter3.xhtml'))
    def test_keeps_classes_styles_links_ids_language(self):
        r,d=self.parsed('<html lang="zh"><head><style>.pair{display:grid}</style><link rel="stylesheet" href="a.css"/></head><body class="edition"><p id="p1" class="pair" lang="en" style="line-height:1.7">text</p></body></html>',{'OPS/Text/a.css':'.pair{display:table}'})
        self.assertEqual(d.xpath('//body/@class'),['edition']);self.assertEqual(d.xpath('//p/@class'),['pair'])
        self.assertEqual(d.xpath('//p/@lang'),['en']);self.assertIn('line-height:1.7',d.xpath('//p/@style')[0])
        self.assertEqual(r.serve(d.xpath('//link/@href')[0]),('text/css',b'.pair{display:table}'))
    def test_marks_explicit_bilingual_pairs(self):
        r,d=self.parsed('<p><span class="parallel-row"><span class="bi-en">English</span><span class="bi-zh">中文</span></span></p>')
        self.assertEqual(len(d.xpath('//*[@data-mr-pair]')),1);self.assertEqual(d.xpath('//*[@data-mr-lang]/@data-mr-lang'),['en','zh'])
    def test_language_pairs_without_specific_css_class(self):
        r,d=self.parsed('<div><p lang="en">English</p><p lang="zh-CN">中文</p></div>')
        self.assertEqual(len(d.xpath('//*[@data-mr-pair]')),1)
    def test_does_not_guess_alignment(self):
        r,d=self.parsed('<section><p>English</p><p>中文</p></section>')
        self.assertEqual(len(d.xpath('//*[@data-mr-pair]')),0)
    def test_unpaired_text_is_not_dropped(self):
        r,d=self.parsed('<p lang="en">only English</p><p>共用公式 100</p>')
        self.assertIn('only English',d.text_content());self.assertIn('共用公式 100',d.text_content())
    def test_source_data_markers_cannot_spoof_pair_or_anchor(self):
        r,d=self.parsed('<p data-mr-pair="1" data-mr-id="evil" data-mr-lang="zh">unchanged</p>')
        self.assertEqual(d.xpath('//*[@data-mr-pair]'),[]);self.assertNotIn('evil',str(d.attrib))
    def test_blocks_author_scripts_events_and_active_elements(self):
        r,d=self.parsed('<body onload="bad()"><script>secret()</script><p onclick="bad()">safe</p><iframe src="file:///tmp/a"></iframe><form><input value="bad"/></form></body>')
        self.assertFalse(d.xpath('//script|//iframe|//form|//input|//*[@onclick]|//*[@onload]'))
        self.assertNotIn('secret()',LH.tostring(d,encoding='unicode'))
    def test_blocks_base_meta_refresh_file_and_javascript_urls(self):
        r,d=self.parsed('<head><base href="file:///"/><meta http-equiv="refresh" content="0;url=https://example.com"/></head><body><a href="javascript:bad()">a</a><img src="file:///etc/passwd"/></body>')
        self.assertFalse(d.xpath('//base|//a[@href]|//img[@src]'))
        self.assertEqual(len(d.xpath('//meta[@http-equiv="Content-Security-Policy"]')),1)
    def test_external_links_are_explicit_navigation_only(self):
        r,d=self.parsed('<a href="https://example.com">external</a><img src="https://example.com/a.png"/>')
        self.assertEqual(d.xpath('//a/@href'),['https://example.com']);self.assertFalse(d.xpath('//img/@src'))
    def test_local_links_and_fragments_preserved(self):
        r,d=self.parsed('<p id="a">text<a href="#a">self</a><a href="chapter2.xhtml#half">other</a></p>')
        self.assertEqual(d.xpath('//a/@href'),['#a',r.book.url('OPS/Text/chapter2.xhtml','half')])
    def test_source_bytes_unchanged_after_render(self):
        r=self.resource();before=hashlib.sha256(self.path.read_bytes()).digest()
        for c in r.book.chapters:r.chapter(c.path)
        self.assertEqual(before,hashlib.sha256(self.path.read_bytes()).digest())
    def test_only_current_book_origin_accepted(self):
        r=self.resource();self.assertTrue(r.accepts(r.book.url('OPS/Text/chapter3.xhtml')))
        for url in ['file:///etc/passwd','https://example.com','epub://other/OPS/a.xhtml','epub://'+r.book.book_id+'@evil/a']:
            self.assertFalse(r.accepts(url))
            with self.assertRaises(EpubError):r.serve(url)
    def test_parent_path_traversal_is_rejected(self):
        r=self.resource()
        with self.assertRaises(EpubError):r.serve(f'epub://{r.book.book_id}/../../etc/passwd')
    def test_raster_bytes_keep_exact_content(self):
        r=self.resource();url=r.book.url('OPS/Images/banner.png')
        mime,data=r.serve(url)
        self.assertEqual(mime,'image/png');self.assertEqual(data,r.book.read('OPS/Images/banner.png'))
    def test_object_image_becomes_a_safe_img(self):
        r,d=self.parsed('<object data="../Images/banner.png" type="image/png"></object>')
        self.assertEqual(d.xpath('//object'),[]);self.assertEqual(len(d.xpath('//img')),1)
    def test_nonimage_object_has_no_active_object(self):
        r,d=self.parsed('<object data="chapter2.xhtml"><p>fallback</p></object>')
        self.assertFalse(d.xpath('//object'));self.assertIn('fallback',d.text_content())
    def test_svg_and_mathml_markup_survive(self):
        r,d=self.parsed('<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="20"/><script>bad()</script></svg><math><mfrac><mi>a</mi><mi>b</mi></mfrac></math>')
        self.assertEqual(len(d.xpath('//svg//circle')),1);self.assertEqual(len(d.xpath('//math//mfrac')),1)
        self.assertFalse(d.xpath('//script'))
    def test_wide_table_has_independent_scroll_wrapper(self):
        r,d=self.parsed('<table><tr><td>100</td><td>200</td></tr></table>')
        self.assertEqual(len(d.xpath('//*[@data-mr-table-wrap]/table')),1)
        self.assertEqual(d.xpath('//td/text()'),['100','200'])
    def test_existing_table_scroll_not_double_wrapped(self):
        r,d=self.parsed('<div class="table-scroll"><table><tr><td>x</td></tr></table></div>')
        self.assertEqual(len(d.xpath('//*[@data-mr-table-wrap]')),1)
        self.assertEqual(d.xpath('//table/parent::*/@class'),['table-scroll'])
    def test_cache_only_keeps_current_chapter(self):
        r=self.resource();a=r.chapter('OPS/Text/chapter2.xhtml');self.assertIs(r.chapter('OPS/Text/chapter2.xhtml'),a)
        r.chapter('OPS/Text/chapter3.xhtml');self.assertEqual(r._chapter_cache[0],'OPS/Text/chapter3.xhtml')
    def test_css_limit_is_enforced(self):
        r=self.resource(extra={'OPS/Text/a.css':'p{}'*200})
        with patch('publisher_core.MAX_CSS_BYTES',50):
            with self.assertRaises(EpubError):r.serve(r.book.url('OPS/Text/a.css'))
    def test_node_limit_is_enforced(self):
        r=self.resource('<p>1</p><p>2</p>')
        with patch('publisher_core.MAX_NODES',2):
            with self.assertRaises(EpubError):r.chapter('OPS/Text/chapter3.xhtml')
    def test_unsupported_file_type_not_served(self):
        r=self.resource(extra={'OPS/a.js':'bad()'})
        with self.assertRaises(EpubError):r.serve(r.book.url('OPS/a.js'))
    def test_original_demo_pairs_and_resources(self):
        build(self.path);b=EpubBook(self.path);self.addCleanup(b.close);r=PublisherResources(b)
        d=LH.fromstring(r.chapter('OPS/first.xhtml'))
        self.assertEqual(len(d.xpath('//*[@data-mr-pair]')),41)
        d=LH.fromstring(r.chapter('OPS/second.xhtml'))
        for source in d.xpath('//img/@src'):self.assertTrue(r.serve(source)[1])
    def test_csp_blocks_scripts_remote_requests_forms(self):
        _,d=self.parsed('<p>hello</p>');csp=d.xpath('//meta[@http-equiv="Content-Security-Policy"]/@content')[0]
        for expected in ["script-src 'none'","connect-src 'none'","form-action 'none'","base-uri 'none'"]:
            self.assertIn(expected,csp)
    def test_reserved_style_id_cannot_clobber_controls(self):
        _,d=self.parsed('<img id="mr-reader-style" src="../Images/banner.png"/>')
        self.assertEqual(len(d.xpath('//*[@id="mr-reader-style"]')),1)
        self.assertEqual(d.xpath('//*[@id="mr-reader-style"]')[0].tag,'style')

if __name__=='__main__':unittest.main()
