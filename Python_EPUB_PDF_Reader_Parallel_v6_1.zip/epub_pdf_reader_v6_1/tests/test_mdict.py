"""Real binary MDX/MDD fixtures, security checks, storage and resource regressions."""
from __future__ import annotations

import ctypes.util
import io
import json
import os
from pathlib import Path
import sqlite3
import struct
import tempfile
import unittest
from unittest.mock import patch
import zlib

from dictionary_core import DictionaryEngine, VocabularyStore
from make_mdict_demo import encode_mdict, write_demo, demo_png, demo_tone
from mdict_audio import validate_audio
from mdict_core import build_index, MdictLibrary, MdictIndex, discover_mdd, dictionary_id
from mdict_format import MdictError, MdictCancelled, resource_key, read_header, unpack_block
from mdict_hash import ripemd128
from mdict_html import sanitize_article, text_snapshot, safe_css, resource_url, split_virtual_url


class HashTests(unittest.TestCase):
    def test_published_vectors(self):
        vectors = {
            b'': 'cdf26213a150dc3ecb610f18f6b38b46',
            b'a': '86be7afa339d0fc7cfc785e72f578d33',
            b'abc': 'c14a12199c66e4ba84636b0f69144c77',
            b'message digest': '9e327b3d6e523062afc1132d7df9d1b8',
            b'abcdefghijklmnopqrstuvwxyz': 'fd2aa607f71dc8f510714922b371834e',
            b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789': 'd1e959eb179c911faea4624c60c5c702',
            b'1234567890' * 8: '3f45ef194732c2dbb2c4a2c769795fa3',
        }
        for message, expected in vectors.items():
            with self.subTest(message=message):
                self.assertEqual(ripemd128(message).hex(), expected)


class FormatTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.library = MdictLibrary(self.root / 'data')

    def tearDown(self):
        self.library.close()
        self.temp.cleanup()

    def install(self, entries=None, name='a.mdx', resources=None, **kwargs):
        path = self.root / name
        path.write_bytes(encode_mdict(entries or [('equity', '<p>/ˈekwɪti/ 股权</p>')], **kwargs))
        plan = build_index(path, self.library.directory, resources)
        self.library.commit(plan)
        return path, plan.dictionary_id

    def test_v2_utf8_basic(self):
        self.install()
        self.assertIn('股权', self.library.lookup('equity').articles[0].body)

    def test_v2_masked_index(self):
        self.install(mask=True)
        self.assertIn('股权', self.library.lookup('equity').articles[0].body)

    def test_v1_plain_blocks(self):
        self.install(version='1.2', compression=0)
        self.assertEqual(len(self.library.lookup('equity').articles), 1)

    def test_v1_zlib_blocks(self):
        self.install(version='1.2')
        self.assertIn('股权', self.library.lookup('equity').articles[0].body)

    def test_utf16_cross_byte_boundaries(self):
        body = '<p>所有者权益 /ˈekwɪti/ ' + '中😀文' * 50 + '</p>'
        self.install([('equity', body)], encoding='UTF-16', block_size=31)
        self.assertEqual(self.library.lookup('equity').articles[0].body, body)

    def test_gbk(self):
        self.install([('capital', '<p>资本，资金</p>')], encoding='GBK', block_size=13)
        self.assertIn('资本', self.library.lookup('capital').articles[0].body)

    def test_big5(self):
        self.install([('capital', '<p>資本，資金</p>')], encoding='BIG5', block_size=17)
        self.assertIn('資金', self.library.lookup('capital').articles[0].body)

    def test_v1_utf16(self):
        self.install([('equity', '所有者权益')], version='1.2', encoding='UTF-16', key_batch=1)
        self.assertEqual(self.library.lookup('EQUITY').articles[0].body, '所有者权益')

    def test_multiple_key_and_record_blocks(self):
        entries = [(f'word{i:04}', f'<p>词条 {i}' + 'x' * i + '</p>') for i in range(100)]
        self.install(entries, key_batch=7, block_size=43)
        for word, value in entries:
            self.assertEqual(self.library.lookup(word).articles[0].body, value)

    def test_empty_mdd_record(self):
        # A zero-size MDD entry gives two keys pointing to one start. The first
        # resource must stay empty, not acquire the contents of its neighbor.
        mdx, _ = self.install()
        mdd = self.root / 'a.mdd'
        mdd.write_bytes(encode_mdict([('\\a.png', b''), ('\\b.png', demo_png())], kind='mdd'))
        plan = build_index(mdx, self.library.directory)
        self.library.commit(plan)
        self.assertEqual(self.library.resource(plan.dictionary_id, 'a.png'), b'')
        self.assertEqual(self.library.resource(plan.dictionary_id, 'b.png'), demo_png())

    def test_redirect(self):
        self.install([('equities', '@@@LINK=equity\r\n'), ('equity', '<p>股权</p>')])
        article = self.library.lookup('equities').articles[0]
        self.assertEqual(article.word, 'equity')
        self.assertIn('跳转', article.match_note)

    def test_redirect_cycle(self):
        self.install([('aa', '@@@LINK=bb'), ('bb', '@@@LINK=aa')])
        results = self.library.lookup('aa')
        self.assertFalse(results.articles)
        self.assertIn('循环', results.warnings[0])

    def test_redirect_missing(self):
        self.install([('aa', '@@@LINK=bb')])
        self.assertIn('未找到', self.library.lookup('aa').warnings[0])

    def test_duplicate_headwords_retained(self):
        self.install([('bank', '<p>银行</p>'), ('bank', '<p>河岸</p>')])
        results = self.library.lookup('bank')
        self.assertEqual(len(results.articles), 2)
        self.assertTrue(any('河岸' in x.body for x in results.articles))

    def test_explicit_case_spelling_first(self):
        self.install([('US', '美国'), ('us', '我们')])
        self.assertEqual(self.library.lookup('us').articles[0].body, '我们')

    def test_wordform_fallback(self):
        self.install([('interest rate', '利率')])
        self.assertIn('推测', self.library.lookup('interest rates').articles[0].match_note)

    def test_unicode_manual_query(self):
        self.install([('股票', 'stock')])
        self.assertEqual(self.library.lookup('股票').articles[0].body, 'stock')

    def test_text_format_is_escaped(self):
        self.install([('aa', '<script>not a tag</script>')], attributes={'Format': 'Text'})
        self.assertIn('&lt;script&gt;', self.library.lookup('aa').articles[0].body)

    def test_compact_styles(self):
        self.install([('aa', '`1`bold`2`italic')], attributes={'StyleSheet': '1\n<b>\n</b>\n2\n<i>\n</i>\n'})
        self.assertEqual(self.library.lookup('aa').articles[0].body, '<b>bold</b><i>italic</i>')

    def test_v3_rejected_clearly(self):
        path = self.root / 'v3.mdx'
        path.write_bytes(encode_mdict([('a', 'b')], version='3.0'))
        with self.assertRaisesRegex(MdictError, '3.x'):
            build_index(path, self.library.directory)
        self.assertEqual(list(self.library.directory.glob('.mdict-import-*')), [])

    def test_registration_encryption_rejected(self):
        path = self.root / 'encrypted.mdx'
        path.write_bytes(encode_mdict([('a', 'b')], attributes={'Encrypted': '1'}))
        with self.assertRaisesRegex(MdictError, '注册'):
            build_index(path, self.library.directory)

    def test_invalid_header_checksum(self):
        raw = bytearray(encode_mdict([('a', 'b')]))
        raw[30] ^= 1
        with self.assertRaisesRegex(MdictError, '校验'):
            read_header(io.BytesIO(raw), 'mdx')

    def test_header_size_bound(self):
        with self.assertRaises(MdictError):
            read_header(io.BytesIO(b'\xff\xff\xff\xff'), 'mdx')

    def test_header_entities_rejected(self):
        text = '<!DOCTYPE Dictionary [<!ENTITY x "bad">]><Dictionary GeneratedByEngineVersion="2.0"/>'.encode('utf-16le')
        raw = struct.pack('>I', len(text)) + text + struct.pack('<I', zlib.adler32(text) & 0xffffffff)
        with self.assertRaisesRegex(MdictError, '实体'):
            read_header(io.BytesIO(raw), 'mdx')

    def test_unknown_encoding(self):
        raw = encode_mdict([('a', 'b')], attributes={'Encoding': 'not-real'})
        with self.assertRaisesRegex(MdictError, '编码'):
            read_header(io.BytesIO(raw), 'mdx')

    def test_file_type_mismatch(self):
        raw = encode_mdict([('\\a', b'data')], kind='mdd')
        with self.assertRaisesRegex(MdictError, '扩展名'):
            read_header(io.BytesIO(raw), 'mdx')

    def test_truncated_file_rejected(self):
        path = self.root / 'broken.mdx'
        path.write_bytes(encode_mdict([('a', 'b')])[:-7])
        with self.assertRaises(MdictError):
            build_index(path, self.library.directory)

    def test_trailing_file_data_rejected(self):
        path = self.root / 'broken.mdx'
        path.write_bytes(encode_mdict([('a', 'b')]) + b'junk')
        with self.assertRaises(MdictError):
            build_index(path, self.library.directory)

    def test_unpack_unknown_method(self):
        with self.assertRaisesRegex(MdictError, '压缩'):
            unpack_block(struct.pack('<II', 9, 0), 0)

    def test_unpack_size_mismatch(self):
        data = b'abcdef'
        raw = struct.pack('<I', 2) + struct.pack('>I', zlib.adler32(data)) + zlib.compress(data)
        with self.assertRaises(MdictError):
            unpack_block(raw, 5)

    def test_unpack_checksum_mismatch(self):
        raw = struct.pack('<I', 2) + struct.pack('>I', 0) + zlib.compress(b'a')
        with self.assertRaisesRegex(MdictError, '校验'):
            unpack_block(raw, 1)

    def test_zlib_trailing_payload_rejected(self):
        data = b'abcdef'
        raw = struct.pack('<I', 2) + struct.pack('>I', zlib.adler32(data)) + zlib.compress(data) + b'junk'
        with self.assertRaises(MdictError):
            unpack_block(raw, len(data))

    @unittest.skipUnless(ctypes.util.find_library('lzo2'), '系统未提供 LZO 编解码库')
    def test_lzo_v1_actual_decode(self):
        self.install([('equity', '所有者权益' * 200)], version='1.2', compression=1, block_size=97)
        self.assertEqual(self.library.lookup('equity').articles[0].body, '所有者权益' * 200)

    @unittest.skipUnless(ctypes.util.find_library('lzo2'), '系统未提供 LZO 编解码库')
    def test_lzo_v2_actual_decode(self):
        self.install([('equity', '所有者权益' * 100)], compression=1, mask=True, block_size=93)
        self.assertEqual(self.library.lookup('equity').articles[0].body, '所有者权益' * 100)


class LibraryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.mdx = write_demo(self.root / 'original')
        self.library = MdictLibrary(self.root / 'data')
        self.plan = build_index(self.mdx, self.library.directory)
        self.library.commit(self.plan)

    def tearDown(self):
        self.library.close()
        self.temp.cleanup()

    def test_auto_discovery_split_mdd(self):
        self.assertEqual([p.name for p in discover_mdd(self.mdx)], ['FinanceDemo.mdd', 'FinanceDemo.1.mdd'])
        self.assertEqual(self.library.items[0]['resources'], 3)

    def test_natural_numeric_mdd_order(self):
        for n in (2, 10):
            (self.mdx.parent / f'FinanceDemo.{n}.mdd').write_bytes(b'')
        names = [p.name for p in discover_mdd(self.mdx)]
        self.assertEqual(names[-2:], ['FinanceDemo.2.mdd', 'FinanceDemo.10.mdd'])

    def test_unrelated_mdd_not_discovered(self):
        (self.mdx.parent / 'Unrelated.mdd').write_bytes(b'')
        self.assertEqual(len(discover_mdd(self.mdx)), 2)

    def test_resource_image(self):
        self.assertEqual(self.library.resource(self.plan.dictionary_id, '\\IMAGES\\FINANCE.PNG'), demo_png())

    def test_resource_audio_cross_blocks(self):
        self.assertEqual(self.library.resource(self.plan.dictionary_id, 'audio/test.wav'), demo_tone())

    def test_css_resource(self):
        self.assertIn(b'.phonetic', self.library.default_css(self.plan.dictionary_id))

    def test_persistent_index(self):
        self.library.close()
        self.library = MdictLibrary(self.root / 'data')
        self.assertIn('股权', self.library.lookup('equity').articles[0].body)

    def test_disabled_dictionary(self):
        self.library.set_enabled(self.plan.dictionary_id, False)
        self.assertFalse(self.library.lookup('equity').articles)
        self.library.set_enabled(self.plan.dictionary_id, True)
        self.assertTrue(self.library.lookup('equity').articles)

    def test_multiple_dictionaries(self):
        other = self.root / 'other.mdx'
        other.write_bytes(encode_mdict([('equity', '第二部词典')], title='Other'))
        plan = build_index(other, self.library.directory)
        self.library.commit(plan)
        self.assertEqual(len(self.library.lookup('equity').articles), 2)
        self.assertEqual(len(self.library.lookup('equity', plan.dictionary_id).articles), 1)

    def test_remove_keeps_originals(self):
        originals = [self.mdx, *discover_mdd(self.mdx)]
        content = [p.read_bytes() for p in originals]
        self.library.remove(self.plan.dictionary_id)
        self.assertFalse(self.library.items)
        self.assertEqual(content, [p.read_bytes() for p in originals])

    def test_reimport_replaces_index_not_duplicate(self):
        old_index = self.library.items[0]['index']
        self.library.lookup('equity')  # open old DB handle
        replacement = build_index(self.mdx, self.library.directory)
        self.library.commit(replacement)
        self.assertEqual(len(self.library.items), 1)
        self.assertNotEqual(old_index, self.library.items[0]['index'])
        self.assertFalse((self.library.directory / old_index).exists())
        self.assertTrue(self.library.lookup('equity').articles)

    def test_cancel_retains_index(self):
        previous = self.library.registry_path.read_bytes()
        with self.assertRaises(MdictCancelled):
            build_index(self.mdx, self.library.directory, cancelled=lambda: True)
        self.assertEqual(previous, self.library.registry_path.read_bytes())
        self.assertEqual(list(self.library.directory.glob('.mdict-import-*')), [])

    def test_failed_commit_rolls_back_registry_and_index(self):
        previous = self.library.registry_path.read_bytes()
        plan = build_index(self.mdx, self.library.directory)
        with patch.object(self.library, '_save', side_effect=OSError('simulated disk full')):
            with self.assertRaises(OSError):
                self.library.commit(plan)
        self.assertEqual(previous, self.library.registry_path.read_bytes())
        self.assertEqual(len(list(self.library.directory.glob('*.sqlite'))), 1)
        self.assertTrue(self.library.lookup('equity').articles)

    def test_moved_mdx_warning_not_crash(self):
        self.mdx.rename(self.mdx.with_suffix('.moved'))
        result = self.library.lookup('equity')
        self.assertFalse(result.articles)
        self.assertIn('找不到', result.warnings[0])

    def test_changed_mdx_invalidates_cache(self):
        self.library.lookup('equity')
        self.mdx.write_bytes(self.mdx.read_bytes() + b'changed')
        result = self.library.lookup('equity')
        self.assertFalse(result.articles)
        self.assertIn('改变', result.warnings[0])

    def test_missing_mdd_does_not_break_definition(self):
        (self.mdx.parent / 'FinanceDemo.mdd').unlink()
        self.assertTrue(self.library.lookup('equity').articles)
        with self.assertRaisesRegex(MdictError, '找不到'):
            self.library.resource(self.plan.dictionary_id, 'images/finance.png')

    def test_mdx_without_mdd(self):
        plan = build_index(self.mdx, self.library.directory, [])
        self.library.commit(plan)
        self.assertIn('股权', self.library.lookup('equity').articles[0].body)
        self.assertIsNone(self.library.resource(plan.dictionary_id, 'images/finance.png'))

    def test_explicit_mdd_with_different_name(self):
        resource = self.root / 'custom.mdd'
        resource.write_bytes(encode_mdict([('\\image.png', demo_png())], kind='mdd'))
        plan = build_index(self.mdx, self.library.directory, [resource])
        self.library.commit(plan)
        self.assertEqual(self.library.resource(plan.dictionary_id, 'image.png'), demo_png())

    def test_sidecar_css(self):
        (self.mdx.parent / 'sidecar.css').write_text('p {color:red}', encoding='utf-8')
        self.assertIn(b'color:red', self.library.resource(self.plan.dictionary_id, 'SIDECAR.CSS'))

    def test_sidecar_js_and_font_not_read(self):
        for name in ('bad.js', 'font.ttf', 'file.exe'):
            (self.mdx.parent / name).write_bytes(b'no')
            self.assertIsNone(self.library.resource(self.plan.dictionary_id, name))

    def test_sidecar_path_escape(self):
        for path in ('../secret.css', 'C:\\secret.css', 'images/../../bad.png'):
            with self.subTest(path=path), self.assertRaises(MdictError):
                self.library.resource(self.plan.dictionary_id, path)

    @unittest.skipIf(os.name == 'nt', '符号链接测试需要非 Windows 权限环境')
    def test_sidecar_symlink_escape(self):
        external = self.root / 'secret.css'
        external.write_text('secret')
        (self.mdx.parent / 'leak.css').symlink_to(external)
        with self.assertRaises(MdictError):
            self.library.resource(self.plan.dictionary_id, 'leak.css')

    def test_bad_registry_protected(self):
        self.library.close()
        self.library.registry_path.write_text('{bad json')
        self.library = MdictLibrary(self.root / 'data')
        self.assertTrue(self.library.read_only)
        with self.assertRaises(MdictError):
            self.library.set_enabled(self.plan.dictionary_id, False)
        self.assertEqual(self.library.registry_path.read_text(), '{bad json')

    def test_registry_field_types_protected(self):
        original = dict(self.library.items[0])
        self.library.close()
        for field, value in [('mdd_paths', [None]), ('count', 'many'),
                             ('resources', -1), ('enabled', 'yes'),
                             ('mdx_path', 'bad\0path'), ('title', ['bad'])]:
            with self.subTest(field=field):
                item = dict(original, **{field: value})
                content = json.dumps({'version': 1, 'dictionaries': [item]})
                self.library.registry_path.write_text(content)
                self.library = MdictLibrary(self.root / 'data')
                self.assertTrue(self.library.read_only)
                self.assertFalse(self.library.items)
                self.assertEqual(self.library.registry_path.read_text(), content)
                self.library.close()

    def test_registry_index_traversal_rejected(self):
        self.library.close()
        self.library.items[0]['index'] = '../../outside.sqlite'
        self.library.registry_path.write_text(json.dumps({'version':1,'dictionaries':self.library.items}))
        self.library = MdictLibrary(self.root / 'data')
        self.assertTrue(self.library.read_only)

    def test_wordbook_snapshot(self):
        article = self.library.lookup('equity').articles[0]
        entry = article.as_entry()
        store = VocabularyStore(self.root / 'data' / 'vocabulary.json')
        store.add(entry, 'reading context', 'a.pdf · 第 1 页')
        saved = store.items['equity']
        self.assertEqual(saved['phonetic'], 'ˈekwɪti')
        self.assertIn('股权', saved['translation'])
        self.assertEqual(saved['context'], 'reading context')

    def test_builtin_untouched(self):
        engine = DictionaryEngine(self.root / 'data' / 'dictionary_extra.sqlite')
        self.assertEqual(len(engine.entries), 453)
        self.assertEqual(engine.finance_count, 332)
        self.assertIn('股权', engine.lookup('equity').entries[0].chinese)
        engine.close()

    def test_mdd_cannot_be_imported_without_mdx(self):
        with self.assertRaisesRegex(MdictError, 'MDX'):
            build_index(self.mdx.with_suffix('.mdd'), self.library.directory)

    def test_huge_record_limit(self):
        index = self.library.index(self.plan.dictionary_id)
        row = index.lookup_rows('equity')[0]
        with self.assertRaisesRegex(MdictError, '单项限制'):
            index.record(0, row['start'], 10)

    def test_binary_keys_not_extracted(self):
        bad = self.root / 'bad.mdd'
        bad.write_bytes(encode_mdict([('\\..\\secret.txt', b'bad'), ('\\safe.png', demo_png())], kind='mdd'))
        plan = build_index(self.mdx, self.library.directory, [bad])
        self.library.commit(plan)
        self.assertFalse((self.root / 'secret.txt').exists())
        self.assertEqual(self.library.resource(plan.dictionary_id, 'safe.png'), demo_png())


class HtmlTests(unittest.TestCase):
    identifier = 'a' * 24

    def clean(self, text, **kwargs):
        return sanitize_article(text, self.identifier, **kwargs)

    def test_basic_text_and_ipa(self):
        result = self.clean('<b>equity</b><span class="ipa">/ˈekwɪti/</span><p>股权</p>')
        self.assertIn('<b>equity</b>', result.markup)
        self.assertIn('ˈekwɪti', result.markup)
        self.assertIn('股权', result.markup)

    def test_script_removed(self):
        result = self.clean('<p>safe</p><script>alert(1)</script><p>after</p>')
        self.assertNotIn('alert', result.markup)
        self.assertIn('after', result.markup)

    def test_nested_script_and_iframe_removed(self):
        result = self.clean('<iframe src="file:///secret"><div>hidden</div></iframe>visible')
        self.assertNotIn('hidden', result.markup)
        self.assertNotIn('secret', result.markup)
        self.assertIn('visible', result.markup)

    def test_event_handlers_removed(self):
        result = self.clean('<p onclick="danger()">safe</p>')
        self.assertNotIn('onclick', result.markup)
        self.assertNotIn('danger', result.markup)

    def test_external_images_removed(self):
        for url in ('https://evil/a.png', 'file:///etc/passwd', '//evil/a.png', 'data:image/png,abcd', 'javascript:bad'):
            with self.subTest(url=url):
                result = self.clean(f'<img src="{url}">')
                self.assertFalse(result.resources)
                self.assertNotIn('src=', result.markup)

    def test_mdd_image_url(self):
        result = self.clean('<img src="\\images\\finance.png">')
        self.assertEqual(result.resources, [f'mdictres://{self.identifier}/images/finance.png'])

    def test_url_percent_decode_once(self):
        value = resource_url('images/50%2525.png', self.identifier)
        self.assertEqual(split_virtual_url(value, 'mdictres')[1], 'images/50%25.png')

    def test_literal_archive_percent_not_decoded(self):
        self.assertEqual(resource_key('images/50%25.png'), 'images/50%25.png')

    def test_html_ampersand_decode_once(self):
        result = self.clean('<img src="a&amp;amp;b.png">')
        self.assertEqual(split_virtual_url(result.resources[0], 'mdictres')[1], 'a&amp;b.png')

    def test_chinese_space_path(self):
        result = self.clean('<img src="图片/a%20b.png">')
        self.assertEqual(split_virtual_url(result.resources[0], 'mdictres')[1], '图片/a b.png')

    def test_traversal_encoded_removed(self):
        for url in ('../evil.png', '%2e%2e/evil.png', 'C:/evil.png', '/../../evil.png'):
            with self.subTest(url=url):
                self.assertFalse(self.clean(f'<img src="{url}">').resources)

    def test_entry_link(self):
        result = self.clean('<a href="entry://Cash%20Flow">link</a>')
        self.assertIn('mdictlookup://' + self.identifier + '/Cash%20Flow', result.markup)

    def test_sound_link(self):
        result = self.clean('<a href="sound://audio/test.wav">play</a>')
        self.assertEqual(result.audio, [f'mdictaudio://{self.identifier}/audio/test.wav'])

    def test_audio_tag_no_autoplay(self):
        result = self.clean('<audio src="audio/test.wav" autoplay="true" controls></audio>')
        self.assertNotIn('autoplay', result.markup)
        self.assertNotIn('<audio', result.markup)
        self.assertIn('播放', result.markup)

    def test_external_sound_rejected(self):
        result = self.clean('<audio src="https://evil/test.wav"></audio>')
        self.assertFalse(result.audio)

    def test_css_allowlist(self):
        result = safe_css('p{color:red;font-size:12pt;background-image:url(file:///x);position:fixed;}')
        self.assertIn('color:red', result)
        self.assertNotIn('url', result)
        self.assertNotIn('fixed', result)

    def test_css_fonts_and_import_removed(self):
        result = safe_css('@import "https://evil/style.css"; @font-face {src:url(file:///secret);font-family:x;} p{color:red}')
        self.assertNotIn('url', result)
        self.assertNotIn('@', result)

    def test_inline_styles_sanitized(self):
        result = self.clean('<p style="color:blue;background-image:url(https://evil);font-weight:bold" onload="x">abc</p>')
        self.assertIn('font-weight:bold', result.markup)
        self.assertNotIn('evil', result.markup)

    def test_night_drops_forced_dark_text(self):
        result = self.clean('<style>p{color:black;background-color:white}</style><p style="color:black">abc</p>', night=True)
        self.assertNotIn('color:black', result.markup)
        self.assertNotIn('background-color:white', result.markup)

    def test_css_resource_loader_local_only(self):
        calls = []
        def load(path):
            calls.append(path)
            return b'.ipa{color:blue}'
        result = self.clean('<link rel="stylesheet" href="x.css"><link rel="stylesheet" href="https://evil/x.css">', css_loader=load)
        self.assertEqual(calls, ['x.css'])
        self.assertIn('color:blue', result.markup)

    def test_plain_snapshot_extracts_ipa(self):
        text, ipa = text_snapshot('<p class="phonetic">/ˈekwɪti/</p><p>股权</p>')
        self.assertEqual(ipa, 'ˈekwɪti')
        self.assertIn('股权', text)

    def test_snapshot_does_not_invent_ipa(self):
        text, ipa = text_snapshot('<p>unknown meaning</p>')
        self.assertEqual(ipa, '')
        self.assertIn('unknown', text)

    def test_snapshot_ipa_fallback(self):
        self.assertEqual(text_snapshot('<p>equity /ˈekwɪti/ 股权</p>')[1], 'ˈekwɪti')

    def test_invalid_virtual_authority(self):
        with self.assertRaises(MdictError):
            split_virtual_url('mdictres://../../secret', 'mdictres')

    def test_node_limit(self):
        with patch('mdict_html.MAX_NODES', 3), self.assertRaises(MdictError):
            self.clean('<p>a</p>' * 4)

    def test_image_limit(self):
        with patch('mdict_html.MAX_RESOURCES', 2):
            result = self.clean('<img src="a.png"><img src="b.png"><img src="c.png">')
        self.assertEqual(len(result.resources), 2)
        self.assertIn('[图片不可用]', result.markup)


class AudioTests(unittest.TestCase):
    def test_wav_tone_container(self):
        validate_audio(demo_tone(), '.wav')

    def test_mp3_id3_container(self):
        validate_audio(b'ID3' + b'\0' * 20, '.mp3')

    def test_reject_playlist(self):
        with self.assertRaises(MdictError):
            validate_audio(b'#EXTM3U\nhttps://evil/test.mp3', '.mp3')

    def test_reject_executable_extension(self):
        with self.assertRaises(MdictError):
            validate_audio(demo_tone(), '.exe')

    def test_reject_empty_audio(self):
        with self.assertRaises(MdictError):
            validate_audio(b'', '.wav')


if __name__ == '__main__':
    unittest.main()
