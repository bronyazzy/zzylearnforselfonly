"""A browser-independent EPUB fallback using actual QTextDocument HTML tables.

Only explicit neighbouring en/zh units are paired. This is not translation and
not full publisher CSS support. The source archive is never modified. The same
ReadingHTML sanitizer still validates links, raster images and static SVGs.
"""
from __future__ import annotations

from dataclasses import dataclass
from lxml import etree, html as LH
from epub_core import EpubBook, EpubError, ReadingHTML, MAX_DOCUMENT_BYTES, decode_document
from publisher_core import MAX_NODES, has_pair, language


@dataclass(frozen=True)
class CompatibleChapter:
    html: str
    pairs: int


def compatible_chapter(book: EpubBook, path: str, english_percent: int = 50) -> CompatibleChapter:
    """Build two real cells per explicit pair, with deterministic top alignment."""
    if not book.is_document(path):
        raise EpubError('不是可读取的 EPUB 章节。')
    try:
        percent = max(30, min(70, int(english_percent)))
    except (ValueError, TypeError, OverflowError):
        percent = 50
    parser = LH.HTMLParser(no_network=True, recover=True, remove_comments=True, encoding='utf-8')
    try:
        root = LH.document_fromstring(decode_document(book.read(path, MAX_DOCUMENT_BYTES)).encode('utf-8'), parser=parser)
    except (etree.ParserError, ValueError) as exc:
        raise EpubError('兼容排版无法解析此章节。') from exc
    if any('Excessive depth' in str(e) for e in parser.error_log) or len(list(root.iter())) > MAX_NODES:
        raise EpubError('章节结构过大或过深，未静默截断正文。')
    # Capture language decisions before rewriting/stripping classes.
    pairs = [n for n in root.iter() if isinstance(n.tag, str) and has_pair(n)]
    count = 0
    for node in reversed(pairs):
        if any(str(a.tag).lower() in {'head','script','style','template','noscript'} for a in node.iterancestors()):
            continue
        original_tag = str(node.tag).rsplit('}', 1)[-1].lower()
        heading = next((str(a.tag).lower() for a in (node, *node.iterancestors())
                        if str(a.tag).lower() in {'h1','h2','h3','h4','h5','h6','p','blockquote'}), '')
        link = node.get('href') if original_tag == 'a' else None
        children = list(node)
        by_language = {language(c): c for c in children}
        if set(by_language) != {'en', 'zh'}:
            continue
        # td/th/li cannot be replaced by table directly. Keep the semantic outer
        # container and insert a table within it. Other pair containers become a
        # div containing a table (never a table nested in p or span).
        inner_table = LH.Element('table', width='100%', border='0', cellspacing='0', cellpadding='8')
        row = etree.SubElement(inner_table, 'tr')
        node.text = None
        for lang in ('en', 'zh'):
            unit = by_language[lang]
            node.remove(unit)
            # Preserve id/name anchors and links by keeping the original element
            # intact inside its cell, rather than renaming <a> to <td>.
            cell = etree.SubElement(row, 'td', width=f'{percent if lang == "en" else 100-percent}%', valign='top')
            content = etree.SubElement(cell, heading) if heading else cell
            if link:
                content = etree.SubElement(content, 'a', href=link)
            content.append(unit)
        if original_tag not in {'td','th','li','dd','dt'}:
            node.tag = 'div'
        node.append(inner_table)
        count += 1
    # A pair often occurs as <p><span class=parallel-row>...</span></p>.
    # Block tables must not remain under p/span/headings (HTML5 would reparent
    # them). Keep the enclosing anchors/contents but use a valid block container.
    for table in root.iter('table'):
        for ancestor in table.iterancestors():
            if str(ancestor.tag).lower() in {'p','span','h1','h2','h3','h4','h5','h6','strong','b','i','em','u','small'}:
                ancestor.tag = 'div'
    # QTextBrowser has no author JS engine, but still allow only validated local
    # resources. ReadingHTML preserves the generated bounded geometry attributes.
    sanitizer = ReadingHTML(book, path)
    try:
        sanitizer.feed(LH.tostring(root, encoding='unicode', method='html'))
        sanitizer.close()
    except (ValueError, RecursionError) as exc:
        raise EpubError('兼容正文无法整理。') from exc
    result = '<html><body>' + ''.join(sanitizer.output) + '</body></html>'
    # Some books deliberately contain empty separators; do not claim these pages
    # contain translated text. Give a visible, non-modal explanation instead.
    parsed = LH.fromstring(result)
    if not parsed.text_content().strip() and not parsed.xpath('//img'):
        result = '<html><body><p>本章没有可显示的文字或图片。可通过目录或“下一章”继续阅读。</p></body></html>'
    return CompatibleChapter(result, count)
