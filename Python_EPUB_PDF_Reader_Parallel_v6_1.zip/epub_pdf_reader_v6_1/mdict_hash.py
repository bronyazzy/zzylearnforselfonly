"""RIPEMD-128 for the MDict v2 index checksum-derived mask (not password cracking).

Independent implementation of the published RIPEMD-128 algorithm. This module
is only format plumbing; it is not a recommended cryptographic hash API.
"""
from __future__ import annotations
import struct

_R = (
    tuple(range(16)),
    (7,4,13,1,10,6,15,3,12,0,9,5,2,14,11,8),
    (3,10,14,4,9,15,8,1,2,7,0,6,13,11,5,12),
    (1,9,11,10,0,8,12,4,13,3,7,15,14,5,6,2),
)
_RR = (
    (5,14,7,0,9,2,11,4,13,6,15,8,1,10,3,12),
    (6,11,3,7,0,13,5,10,14,15,8,12,4,9,1,2),
    (15,5,1,3,7,14,6,9,11,8,12,2,10,0,4,13),
    (8,6,4,1,3,11,15,0,5,12,2,13,9,7,10,14),
)
_S = (
    (11,14,15,12,5,8,7,9,11,13,14,15,6,7,9,8),
    (7,6,8,13,11,9,7,15,7,12,15,9,11,7,13,12),
    (11,13,6,7,14,9,13,15,14,8,13,6,5,12,7,5),
    (11,12,14,15,14,15,9,8,9,14,5,6,8,6,5,12),
)
_SS = (
    (8,9,9,11,13,15,15,5,7,7,8,11,14,14,12,6),
    (9,13,15,7,12,8,9,11,7,7,12,7,6,15,13,11),
    (9,7,15,11,8,6,6,14,12,13,5,14,13,13,7,5),
    (15,5,8,11,14,14,6,14,6,9,12,9,12,5,15,8),
)
_K = (0, 0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC)
_KK = (0x50A28BE6, 0x5C4DD124, 0x6D703EF3, 0)
_MASK = 0xffffffff


def _f(which: int, x: int, y: int, z: int) -> int:
    if which == 0:
        return x ^ y ^ z
    if which == 1:
        return (x & y) | (~x & z)
    if which == 2:
        return (x | ~y) ^ z
    return (x & z) | (y & ~z)


def _rol(value: int, shift: int) -> int:
    value &= _MASK
    return ((value << shift) | (value >> (32 - shift))) & _MASK


def ripemd128(data: bytes) -> bytes:
    length = len(data)
    padded = data + b'\x80' + b'\0' * ((55 - length) % 64) + struct.pack('<Q', length * 8)
    h = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476]
    for start in range(0, len(padded), 64):
        x = struct.unpack_from('<16I', padded, start)
        a, b, c, d = h
        aa, bb, cc, dd = h
        for r in range(4):
            for j in range(16):
                t = _rol(a + _f(r, b, c, d) + x[_R[r][j]] + _K[r], _S[r][j])
                a, b, c, d = d, t, b, c
                t = _rol(aa + _f(3-r, bb, cc, dd) + x[_RR[r][j]] + _KK[r], _SS[r][j])
                aa, bb, cc, dd = dd, t, bb, cc
        h = [(h[1] + c + dd) & _MASK, (h[2] + d + aa) & _MASK,
             (h[3] + a + bb) & _MASK, (h[0] + b + cc) & _MASK]
    return struct.pack('<4I', *h)


def decode_index_mask(block: bytes) -> bytes:
    """Undo the public checksum-derived v2 index mask; preserve block framing."""
    if len(block) < 8:
        raise ValueError('索引块过短')
    key = ripemd128(block[4:8] + b'\x95\x36\0\0')
    out = bytearray(block)
    previous = 0x36
    for i, value in enumerate(block[8:]):
        out[i+8] = ((value >> 4) | ((value << 4) & 255)) ^ previous ^ (i & 255) ^ key[i % 16]
        previous = value
    return bytes(out)
