"""Local PDF rendering/text/outline support, independent of Qt.

All PDFium calls must stay on a single thread. Files are read-only; JavaScript,
form actions, embedded attachments and external links are never executed.
"""
from __future__ import annotations

from ctypes import byref, c_double, c_int
from dataclasses import dataclass
from functools import wraps
import hashlib
import math
from pathlib import Path
import re
from typing import Any

from epub_core import TocEntry

MAX_PDF_BYTES = 512 * 1024 * 1024
MAX_PAGES = 20_000
MAX_OUTLINE_ITEMS = 10_000
MAX_PAGE_CHARS = 200_000
MAX_RENDER_PIXELS = 12_000_000
MAX_RENDER_SIDE = 8192
MAX_SELECTION_CHARS = 20_000
MAX_PAGE_MATCHES = 5000


class PdfError(Exception):
    """An error suitable for display to the reader."""


class PdfPasswordRequired(PdfError):
    """A valid document-open password is required; no bypass is attempted."""


def _backend():
    try:
        import pypdfium2 as pdfium
        import pypdfium2.raw as raw
        return pdfium, raw
    except (ImportError, OSError) as exc:
        raise PdfError("缺少或无法加载 PDF 依赖。请执行：python -m pip install -r requirements.txt") from exc


def page_path(index: int) -> str:
    return f"pdf:{index}"


def page_index(path: Any, count: int) -> int | None:
    if not isinstance(path, str) or not re.fullmatch(r"pdf:[0-9]{1,6}", path):
        return None
    value = int(path[4:])
    return value if 0 <= value < count else None


def finite_number(value: Any, default: float, minimum: float, maximum: float) -> float:
    try:
        value = float(value)
        return min(maximum, max(minimum, value)) if math.isfinite(value) else default
    except (TypeError, ValueError, OverflowError):
        return default


def render_scale(width: float, height: float, requested: float) -> float:
    """Clamp before native bitmap allocation, including rounding headroom."""
    if not all(math.isfinite(v) and v > 0 for v in (width, height, requested)):
        raise PdfError("PDF 页面尺寸或缩放比例无效。")
    limit = min((MAX_RENDER_SIDE - 2) / width, (MAX_RENDER_SIDE - 2) / height,
                math.sqrt((MAX_RENDER_PIXELS - 4 * MAX_RENDER_SIDE) / (width * height)))
    return min(requested, limit)


@dataclass(frozen=True)
class PdfPosition:
    page: int = 0
    ratio: float = 0.0
    horizontal: float = 0.0
    zoom_mode: str = "width"
    zoom: float = 1.0
    rotation: int = 0

    @classmethod
    def from_record(cls, value: Any, count: int, restore: bool = False) -> 'PdfPosition':
        record = value if isinstance(value, dict) else {}
        page = page_index(record.get("path"), count)
        if page is None:
            page = int(finite_number(record.get("page"), 0, 0, max(0, count - 1)))
        mode = record.get("zoom_mode")
        mode = mode if mode in {"width", "page", "custom"} else "width"
        rotation = record.get("rotation", 0)
        rotation = rotation if type(rotation) is int and rotation in (0, 90, 180, 270) else 0
        return cls(page, finite_number(record.get("ratio"), 0, 0, 1) if restore else 0,
                   finite_number(record.get("horizontal"), 0, 0, 1) if restore else 0,
                   mode, finite_number(record.get("zoom"), 1, .25, 4), rotation)


@dataclass(frozen=True)
class RenderedPage:
    pixels: bytes
    width: int
    height: int
    stride: int
    scale: float
    rotation: int
    limited: bool = False


@dataclass(frozen=True)
class PdfMatch:
    start: int
    count: int


def _pdf_operation(method):
    """Turn recoverable native errors into user-facing errors at the UI boundary."""
    @wraps(method)
    def call(self, *args, **kwargs):
        try:
            return method(self, *args, **kwargs)
        except PdfError:
            raise
        except (self._pdfium.PdfiumError, ValueError, OverflowError, MemoryError, OSError) as exc:
            raise PdfError(f"PDF 操作失败：{exc}") from exc
    return call


class PdfBook:
    """Keep only one native page/text handle cached; release every bitmap promptly."""

    def __init__(self, filename: str | Path, password: str | None = None):
        self.filename = Path(filename).expanduser().resolve()
        self.title = self.filename.stem
        self.author = "未知作者"
        self.warnings: list[str] = []
        self.toc: list[TocEntry] = []
        self._document = None
        self._page = None
        self._textpage = None
        self._cached_index = -1
        self._chars: list[str] | None = None
        self.page_count = 0
        self.can_extract = False
        self._pdfium, self._raw = _backend()
        try:
            if not self.filename.is_file():
                raise PdfError("找不到指定的 PDF 文件。")
            if self.filename.stat().st_size > MAX_PDF_BYTES:
                raise PdfError("PDF 文件超过 512 MiB，本版暂不打开。")
            # Full streaming hash: equal content shares records; modified content does not.
            digest = hashlib.sha256()
            total_bytes = 0
            with self.filename.open("rb") as stream:
                while data := stream.read(1024 * 1024):
                    total_bytes += len(data)
                    if total_bytes > MAX_PDF_BYTES:
                        raise PdfError("读取过程中 PDF 大小超过限制。")
                    digest.update(data)
            self.book_id = "pdf:" + digest.hexdigest()
            self._document = self._pdfium.PdfDocument(str(self.filename), password=password)
            self.page_count = len(self._document)
            if not 1 <= self.page_count <= MAX_PAGES:
                raise PdfError(f"PDF 页数必须在 1 到 {MAX_PAGES} 页之间。")
            # Respect the document's copy/extraction permission, including empty user passwords.
            permissions = int(self._raw.FPDF_GetDocPermissions(self._document))
            self.can_extract = bool(permissions & (1 << 4))
            if not self.can_extract:
                self.warnings.append("此 PDF 限制文字复制：查词、复制及搜索已禁用，仍可阅读页面。")
            try:
                metadata = self._document.get_metadata_dict()
                self.title = str(metadata.get("Title") or self.title).strip()[:500] or self.title
                self.author = str(metadata.get("Author") or self.author).strip()[:300]
            except self._pdfium.PdfiumError:
                self.warnings.append("PDF 元数据无法读取，已使用文件名。")
            self._read_outline()
        except self._pdfium.PdfiumError as exc:
            self.close()
            if exc.err_code == self._raw.FPDF_ERR_PASSWORD:
                raise PdfPasswordRequired("此 PDF 需要打开密码，或所输入的密码不正确。") from exc
            raise PdfError(f"无法解析 PDF：{exc}") from exc
        except (OSError, ValueError) as exc:
            self.close()
            raise PdfError(f"无法读取 PDF：{exc}") from exc
        except Exception:
            self.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.close()

    def _drop_page(self):
        if self._textpage is not None:
            self._textpage.close()
            self._textpage = None
        if self._page is not None:
            self._page.close()
            self._page = None
        self._chars = None
        self._cached_index = -1

    def close(self):
        self._drop_page()
        if self._document is not None:
            self._document.close()
            self._document = None

    def is_document(self, path: str) -> bool:
        return page_index(path, self.page_count) is not None

    def _read_outline(self):
        stack: list[TocEntry] = []
        try:
            for number, bookmark in enumerate(self._document.get_toc(max_depth=32)):
                if number >= MAX_OUTLINE_ITEMS:
                    self.warnings.append("目录超过 10,000 项，后续项未显示；仍可通过页码跳转。")
                    break
                destination = bookmark.get_dest()
                index = destination.get_index() if destination else None
                path = page_path(index) if index is not None and 0 <= index < self.page_count else ""
                item = TocEntry(bookmark.get_title().strip()[:500] or "未命名目录", path)
                level = min(max(0, bookmark.level), len(stack))
                stack = stack[:level]
                (stack[-1].children if stack else self.toc).append(item)
                stack.append(item)
        except (self._pdfium.PdfiumError, ValueError, RecursionError):
            self.warnings.append("部分 PDF 目录未能读取；可通过页码跳转。")

    def page(self, index: int):
        if self._document is None:
            raise PdfError("PDF 已关闭。")
        if type(index) is not int or not 0 <= index < self.page_count:
            raise PdfError("PDF 页码超出范围。")
        if self._cached_index != index:
            self._drop_page()
            try:
                self._page = self._document[index]
            except self._pdfium.PdfiumError as exc:
                raise PdfError(f"无法读取第 {index + 1} 页：{exc}") from exc
            self._cached_index = index
        return self._page

    @_pdf_operation
    def page_size(self, index: int, rotation: int = 0) -> tuple[float, float]:
        w, h = self.page(index).get_size()
        if not all(math.isfinite(v) and v > 0 for v in (w, h)):
            raise PdfError("PDF 页面尺寸无效。")
        return (h, w) if rotation % 180 else (w, h)

    @_pdf_operation
    def page_label(self, index: int) -> str:
        self.page(index)
        try:
            label = self._document.get_page_label(index).strip()[:80]
            return f"第 {index + 1} 页" + (f" · 原页标 {label}" if label and label != str(index + 1) else "")
        except self._pdfium.PdfiumError:
            return f"第 {index + 1} 页"

    @_pdf_operation
    def render(self, index: int, scale: float = 1, rotation: int = 0) -> RenderedPage:
        if rotation not in (0, 90, 180, 270):
            raise PdfError("仅支持 0、90、180、270 度旋转。")
        page = self.page(index)
        width, height = self.page_size(index, rotation)
        actual = render_scale(width, height, scale)
        bitmap = None
        try:
            bitmap = page.render(scale=actual, rotation=rotation, may_draw_forms=False,
                                 draw_annots=True, limit_image_cache=True,
                                 force_bitmap_format=self._raw.FPDFBitmap_BGRA,
                                 rev_byteorder=True)
            if bitmap.width * bitmap.height > MAX_RENDER_PIXELS:
                raise PdfError("渲染后的页面过大。")
            return RenderedPage(bytes(bitmap.buffer), bitmap.width, bitmap.height,
                                bitmap.stride, actual, rotation, actual < scale - 1e-6)
        except (self._pdfium.PdfiumError, MemoryError, OverflowError) as exc:
            raise PdfError(f"PDF 页面渲染失败，请降低缩放比例：{exc}") from exc
        finally:
            if bitmap is not None:
                bitmap.close()

    def textpage(self, index: int):
        page = self.page(index)
        if not self.can_extract:
            raise PdfError("此 PDF 不允许文字提取。")
        if self._textpage is None:
            try:
                self._textpage = page.get_textpage()
            except self._pdfium.PdfiumError as exc:
                raise PdfError(f"PDF 文字层无法读取：{exc}") from exc
        return self._textpage

    @_pdf_operation
    def characters(self, index: int) -> list[str]:
        textpage = self.textpage(index)
        if self._chars is None:
            count = textpage.count_chars()
            if count > MAX_PAGE_CHARS:
                raise PdfError("本页文字层超过 200,000 字符：页面可阅读，但不启用本页查词和搜索。")
            # Keep the native character indices; extracted text length may differ.
            values = (int(self._raw.FPDFText_GetUnicode(textpage, i)) for i in range(count))
            self._chars = [chr(v) if 0 < v <= 0x10ffff and not 0xd800 <= v <= 0xdfff
                           else ("" if v == 0 else "\ufffd") for v in values]
        return self._chars

    @_pdf_operation
    def text(self, index: int, start: int = 0, count: int | None = None) -> str:
        chars = self.characters(index)
        start = max(0, int(start))
        end = len(chars) if count is None else start + max(0, int(count))
        return "".join(chars[start:end]).replace("\r\n", "\n").replace("\r", "\n")

    @_pdf_operation
    def context(self, index: int, start: int, count: int) -> str:
        begin = max(0, start - 200)
        return " ".join(self.text(index, begin, min(1000, count + start - begin + 200)).split())

    @_pdf_operation
    def word_at(self, index: int, char_index: int) -> PdfMatch | None:
        chars = self.characters(index)
        if not 0 <= char_index < len(chars):
            return None
        def is_word(c):
            return bool(c) and (c.isalpha() or c.isdigit() or c in "'-’/&.")
        if not is_word(chars[char_index]):
            return None
        start = end = char_index
        while start > 0 and char_index - start < 160 and is_word(chars[start - 1]):
            start -= 1
        while end < len(chars) and end - start < 160 and is_word(chars[end]):
            end += 1
        while start < end and chars[start] in "'.’&/-":
            start += 1
        while end > start and chars[end - 1] in "'.’&/-":
            end -= 1
        return PdfMatch(start, end - start) if end > start else None

    @_pdf_operation
    def device_to_page(self, index: int, rendered: RenderedPage, x: float, y: float) -> tuple[float, float]:
        xx, yy = c_double(), c_double()
        ok = self._raw.FPDF_DeviceToPage(self.page(index), 0, 0, rendered.width, rendered.height,
                                       rendered.rotation // 90, int(round(x)), int(round(y)), byref(xx), byref(yy))
        if not ok:
            raise PdfError("PDF 坐标转换失败。")
        return xx.value, yy.value

    @_pdf_operation
    def page_to_device(self, index: int, rendered: RenderedPage, x: float, y: float) -> tuple[int, int]:
        xx, yy = c_int(), c_int()
        ok = self._raw.FPDF_PageToDevice(self.page(index), 0, 0, rendered.width, rendered.height,
                                       rendered.rotation // 90, x, y, byref(xx), byref(yy))
        if not ok:
            raise PdfError("PDF 坐标转换失败。")
        return xx.value, yy.value

    @_pdf_operation
    def hit_test(self, index: int, rendered: RenderedPage, x: float, y: float) -> int | None:
        self.characters(index)  # Enforce the same limits as all text operations.
        x, y = self.device_to_page(index, rendered, x, y)
        return self.textpage(index).get_index(x, y, 5, 5)

    @_pdf_operation
    def selection_boxes(self, index: int, start: int, count: int) -> list[tuple[float, float, float, float]]:
        chars = self.characters(index)
        textpage = self.textpage(index)
        boxes: list[tuple[float, float, float, float]] = []
        end = min(len(chars), start + min(MAX_SELECTION_CHARS, max(0, count)))
        for i in range(max(0, start), end):
            if not chars[i] or chars[i].isspace():
                continue
            try:
                left, bottom, right, top = textpage.get_charbox(i)
            except self._pdfium.PdfiumError:
                continue
            if (not all(math.isfinite(v) for v in (left, bottom, right, top))
                    or right <= left or top <= bottom):
                continue
            # Combine adjoining same-line boxes, avoiding thousands of paint operations.
            if boxes:
                a, b, c, d = boxes[-1]
                if abs(b - bottom) < 2 and abs(d - top) < 2 and -.5 <= left - c <= max(10, top - bottom):
                    boxes[-1] = min(a, left), min(b, bottom), max(c, right), max(d, top)
                    continue
            boxes.append((left, bottom, right, top))
        return boxes

    @_pdf_operation
    def find_matches(self, index: int, query: str) -> list[PdfMatch]:
        if not isinstance(query, str) or not query.strip():
            return []
        if len(query) > 256 or "\0" in query:
            raise PdfError("搜索文字最多 256 个字符，且不能包含空字符。")
        if not self.characters(index):
            return []
        searcher = self.textpage(index).search(query)
        matches = []
        try:
            while len(matches) < MAX_PAGE_MATCHES:
                item = searcher.get_next()
                if item is None:
                    break
                matches.append(PdfMatch(*item))
        finally:
            searcher.close()
        return matches
