@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 "%~dp0bootstrap.py" %*
) else (
    python "%~dp0bootstrap.py" %*
)
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
    echo.
    echo 启动未成功。请确认已安装 Python 3.10+，并查看上方错误和 README.md。
    pause
)
exit /b %RESULT%
