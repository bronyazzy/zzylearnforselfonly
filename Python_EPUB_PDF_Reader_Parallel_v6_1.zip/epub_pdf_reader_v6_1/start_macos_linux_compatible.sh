#!/usr/bin/env sh
set -eu
cd -- "$(dirname -- "$0")"
export MODU_COMPATIBLE_EPUB=1
exec python3 bootstrap.py --compatible-epub "$@"
