"""Offline English–Chinese lookup, atomic CSV import and a local vocabulary book.

This module uses only the Python standard library.  It never contacts the network.
CLI example: python dictionary_core.py "interest rates"
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass, field
from datetime import datetime, timezone
import difflib
import html
import json
import os
from pathlib import Path
import re
import sqlite3
import tempfile
from typing import Callable
import unicodedata
from urllib.parse import quote

APP_ROOT = Path(__file__).resolve().parent
BUILTIN_PATH = APP_ROOT / "data" / "finance_dictionary.json"
MAX_QUERY_LENGTH = 160
MAX_QUERY_WORDS = 12
MAX_JSON_BYTES = 16 * 1024 * 1024
MAX_CSV_BYTES = 1024 * 1024 * 1024
MAX_ROWS = 3_000_000
MAX_VOCAB = 10_000


class DictionaryError(Exception):
    """A readable validation or dictionary-data error."""


class ImportCancelled(DictionaryError):
    """Raised when a CSV import was cancelled; the old database is unchanged."""


def normalize(text: str) -> str:
    """Case-fold and normalize punctuation, but preserve meaningful inner symbols."""
    if not isinstance(text, str):
        return ""
    text = unicodedata.normalize("NFKC", text)
    for old, new in (("’", "'"), ("‘", "'"), ("–", "-"), ("—", "-"),
                     ("‑", "-"), ("\u00ad", ""), ("\u200b", "")):
        text = text.replace(old, new)
    text = " ".join(text.split()).strip(" \t\r\n.,;:!?\"'()[]{}<>“”‘’。；：！？、")
    return text.casefold()


def valid_query(text: str) -> bool:
    key = normalize(text)
    return (0 < len(key) <= MAX_QUERY_LENGTH and len(key.split()) <= MAX_QUERY_WORDS
            and re.search(r"[a-z]", key) is not None
            and all(c.isascii() and (c.isalnum() or c in " -'/&.+%$") for c in key))


def word_candidates(text: str) -> list[tuple[str, str]]:
    """Exact lookup first; conservatively suggest known inflection candidates.

    Suffix guesses are used only after checking exact entries and explicit aliases.
    They are labeled as guesses instead of pretending to be a full NLP lemmatizer.
    """
    key = normalize(text)
    results: list[tuple[str, str]] = [(key, "精确匹配")]
    if "-" in key:
        results.append((key.replace("-", " "), "连字符匹配"))
    if key.endswith("'s"):
        results.append((key[:-2], "所有格还原"))
    if key.endswith("s'"):
        results.append((key[:-1], "所有格还原"))
    # Explicit exceptions stop news -> new or analysis -> analysi guesses.
    if key in {"news", "series", "species", "analysis", "basis", "futures", "earnings"}:
        return results
    stem_prefix, _, last = key.rpartition(" ")
    prefix = stem_prefix + " " if stem_prefix else ""
    guesses: list[str] = []
    if len(last) > 4 and last.endswith("ies"):
        guesses.append(last[:-3] + "y")
    if len(last) > 4 and last.endswith("es"):
        if last[:-2].endswith(("s", "x", "z", "ch", "sh")):
            guesses.append(last[:-2])
    if len(last) > 3 and last.endswith("s") and not last.endswith(("ss", "us", "is")):
        guesses.append(last[:-1])
    if len(last) > 5 and last.endswith("ing"):
        base = last[:-3]
        guesses += [base, base + "e"]
        if len(base) > 2 and base[-1] == base[-2]:
            guesses.append(base[:-1])
    if len(last) > 4 and last.endswith("ied"):
        guesses.append(last[:-3] + "y")
    elif len(last) > 4 and last.endswith("ed"):
        base = last[:-2]
        guesses += [base, last[:-1]]
        if len(base) > 2 and base[-1] == base[-2]:
            guesses.append(base[:-1])
    seen = {c for c, _ in results}
    for item in guesses:
        candidate = prefix + item
        if candidate not in seen:
            seen.add(candidate)
            results.append((candidate, "词形推测，请结合语境"))
    return results


@dataclass(frozen=True)
class Entry:
    word: str
    phonetic: str = ""
    finance: str = ""
    translation: str = ""
    category: str = ""
    source: str = ""
    phonetic_label: str = "词库音标"
    definition: str = ""
    examples: tuple[tuple[str, str], ...] = ()

    @property
    def chinese(self) -> str:
        return self.finance or self.translation


@dataclass
class LookupResult:
    query: str
    entries: list[Entry] = field(default_factory=list)
    match_note: str = ""
    suggestions: list[str] = field(default_factory=list)


class DictionaryEngine:
    """Small bundled glossary plus an optional indexed, read-only CSV database."""

    def __init__(self, extra_path: Path | None = None, builtin_path: Path = BUILTIN_PATH):
        self.extra_path = Path(extra_path) if extra_path is not None else None
        self.builtin_path = Path(builtin_path)
        self.entries: dict[str, Entry] = {}
        self.aliases: dict[str, list[str]] = {}
        self.warning = ""
        self.extra_count = 0
        self._db: sqlite3.Connection | None = None
        self.meta: dict = {}
        self._load_builtin()
        self.reopen_extra()

    def _load_builtin(self):
        try:
            if self.builtin_path.stat().st_size > MAX_JSON_BYTES:
                raise ValueError("内置词库超过大小限制")
            data = json.loads(self.builtin_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or not isinstance(data.get("entries"), list):
                raise ValueError("内置词库格式错误")
            self.meta = {k: v for k, v in data.items() if k != "entries"}
            for raw in data["entries"]:
                if not isinstance(raw, dict) or not isinstance(raw.get("word"), str):
                    raise ValueError("内置词条格式错误")
                word = raw["word"]
                if not valid_query(word):
                    raise ValueError(f"词头无效：{word!r}")
                strings = {}
                for key in ("phonetic", "finance", "translation", "category", "source", "phonetic_label", "definition"):
                    value = raw.get(key, "")
                    if not isinstance(value, str):
                        raise ValueError(f"{word}: {key} 必须为字符串")
                    strings[key] = value
                examples = tuple((e["en"], e["zh"]) for e in raw.get("examples", [])
                                 if isinstance(e, dict) and isinstance(e.get("en"), str)
                                 and isinstance(e.get("zh"), str))
                key = normalize(word)
                if key in self.entries:
                    raise ValueError(f"重复词头：{word}")
                self.entries[key] = Entry(word=word, examples=examples, **strings)
                for alias in raw.get("aliases", []):
                    if not isinstance(alias, str) or not valid_query(alias):
                        raise ValueError(f"无效别名：{alias!r}")
                    self.aliases.setdefault(normalize(alias), []).append(key)
            if not self.entries:
                raise ValueError("内置词库为空")
        except (OSError, ValueError, KeyError, TypeError) as exc:
            raise DictionaryError(f"无法读取内置词库；请完整解压下载包。\n{exc}") from exc

    @property
    def finance_count(self) -> int:
        return sum(bool(e.finance) for e in self.entries.values())

    def close_extra(self):
        if self._db is not None:
            self._db.close()
            self._db = None
        self.extra_count = 0

    def close(self):
        self.close_extra()

    def reopen_extra(self):
        self.close_extra()
        self.warning = ""
        if self.extra_path is None or not self.extra_path.is_file():
            return
        try:
            self._db = sqlite3.connect(self.extra_path.resolve().as_uri() + "?mode=ro", uri=True)
            self._db.row_factory = sqlite3.Row
            self._db.execute("PRAGMA query_only = ON")
            version = self._db.execute("PRAGMA user_version").fetchone()[0]
            if version != 1:
                raise sqlite3.DatabaseError("扩展词库版本不受支持，请重新导入 CSV")
            self.extra_count = int(self._db.execute("SELECT value FROM metadata WHERE key='count'").fetchone()[0])
            self._db.execute("SELECT word_key,word,phonetic,translation,finance,definition,source FROM entries LIMIT 1")
            self._db.execute("SELECT form,word_key FROM forms LIMIT 1")
        except (OSError, sqlite3.Error, TypeError, ValueError) as exc:
            self.close_extra()
            self.warning = f"扩展词库未加载，内置词库仍可使用：{exc}"

    def _extra_entry(self, key: str) -> Entry | None:
        if self._db is None:
            return None
        row = self._db.execute("SELECT * FROM entries WHERE word_key=?", (key,)).fetchone()
        if row is None:
            return None
        return Entry(word=row["word"], phonetic=row["phonetic"], translation=row["translation"],
                     finance=row["finance"], definition=row["definition"],
                     category="扩展词库", source=row["source"], phonetic_label="导入词库音标（标法依来源）")

    def lookup(self, query: str, finance_first: bool = True) -> LookupResult:
        result = LookupResult(query=query.strip() if isinstance(query, str) else "")
        if not valid_query(query):
            result.match_note = "请选择或输入英文单词/短语（最多 160 字符、12 个词）。"
            return result
        key = normalize(query)
        matched: list[tuple[Entry, str]] = []
        seen: set[tuple[str, str]] = set()

        def add(entry: Entry | None, note: str):
            if entry and (normalize(entry.word), entry.source) not in seen:
                seen.add((normalize(entry.word), entry.source))
                matched.append((entry, note))

        def exact_and_aliases(candidate: str, note: str):
            add(self.entries.get(candidate), note)
            for canonical in self.aliases.get(candidate, []):
                add(self.entries[canonical], "缩写/别名/已知词形匹配")
            add(self._extra_entry(candidate), note)
            if self._db:
                # Reverse ECDICT exchange mapping: forms -> dictionary headwords.
                rows = self._db.execute("SELECT word_key FROM forms WHERE form=? LIMIT 8", (candidate,))
                for row in rows:
                    add(self._extra_entry(row[0]), "扩展词库词形匹配")

        exact_and_aliases(key, "精确匹配")
        # Do not erase a genuine exact meaning by inventing a suffix-derived one.
        if not matched:
            for candidate, note in word_candidates(key)[1:]:
                exact_and_aliases(candidate, note)
                if matched:
                    break
        if finance_first:
            matched.sort(key=lambda item: not bool(item[0].finance))
        else:
            matched.sort(key=lambda item: not bool(item[0].translation))
        result.entries = [entry for entry, _ in matched[:8]]
        if matched:
            result.match_note = matched[0][1]
            if normalize(matched[0][0].word) != key:
                result.match_note += f"：{query.strip()} → {matched[0][0].word}"
        else:
            result.match_note = "未收录。内置为精选小词库，可导入 ECDICT 或自有 CSV 扩展。"
            result.suggestions = self.suggest(query)
        return result

    def suggest(self, query: str, limit: int = 10) -> list[str]:
        prefix = normalize(query)
        if not prefix or len(prefix) > MAX_QUERY_LENGTH:
            return []
        values = [e.word for key, e in self.entries.items() if key.startswith(prefix)]
        for alias, canonical in self.aliases.items():
            if alias.startswith(prefix):
                values.extend(self.entries[k].word for k in canonical)
        if self._db and len(values) < limit:
            rows = self._db.execute(
                "SELECT word FROM entries WHERE word_key>=? AND word_key<? ORDER BY word_key LIMIT ?",
                (prefix, prefix + "\uffff", limit))
            values.extend(row[0] for row in rows)
        if len(values) < limit:
            matches = difflib.get_close_matches(prefix, self.entries.keys(), n=limit, cutoff=0.64)
            values.extend(self.entries[key].word for key in matches)
        return list(dict.fromkeys(values))[:limit]


def _text(value: str | None, length: int = 12000) -> str:
    return (value or "").replace("\\n", "\n").replace("\x00", "").strip()[:length]


def import_csv(source: Path, destination: Path,
               progress: Callable[[int], None] | None = None,
               cancelled: Callable[[], bool] | None = None) -> int:
    """Convert an ECDICT/custom CSV to a local SQLite DB and atomically replace it.

    Required columns: word, translation. Optional: phonetic, finance, definition,
    source, aliases (comma-separated), exchange (ECDICT's p/d/i/3/s/0 format).
    CSV decoding/validation failure or cancellation leaves the old DB unchanged.
    The caller must close readers before replacement (notably on Windows).
    """
    source, destination = Path(source), Path(destination)
    if not source.is_file():
        raise DictionaryError("找不到要导入的 CSV 文件。")
    if source.stat().st_size > MAX_CSV_BYTES:
        raise DictionaryError("CSV 超过 1 GiB 限制。")
    if source.resolve() == destination.resolve():
        raise DictionaryError("输入文件不能与输出词库相同。")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary: Path | None = None
    db: sqlite3.Connection | None = None
    old_limit = csv.field_size_limit()
    try:
        csv.field_size_limit(1024 * 1024)
        fd, filename = tempfile.mkstemp(prefix=".dictionary-", suffix=".sqlite", dir=destination.parent)
        os.close(fd)
        temporary = Path(filename)
        db = sqlite3.connect(temporary)
        db.executescript("""
            PRAGMA journal_mode=DELETE;
            PRAGMA user_version=1;
            CREATE TABLE entries (
                word_key TEXT PRIMARY KEY, word TEXT NOT NULL, phonetic TEXT NOT NULL,
                translation TEXT NOT NULL, finance TEXT NOT NULL, definition TEXT NOT NULL,
                source TEXT NOT NULL
            ) WITHOUT ROWID;
            CREATE TABLE forms (form TEXT NOT NULL, word_key TEXT NOT NULL,
                                PRIMARY KEY (form,word_key)) WITHOUT ROWID;
            CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        with source.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            if not reader.fieldnames:
                raise DictionaryError("CSV 为空或缺少表头。")
            names = [name.strip().lower() for name in reader.fieldnames]
            if len(set(names)) != len(names) or not {"word", "translation"}.issubset(names):
                raise DictionaryError("CSV 需要唯一的 word 和 translation 列；可选 phonetic、finance 等列。")
            reader.fieldnames = names
            for index, row in enumerate(reader, start=1):
                if cancelled and cancelled():
                    raise ImportCancelled("已取消导入，原扩展词库保持不变。")
                if index > MAX_ROWS:
                    raise DictionaryError("CSV 超过 300 万行限制。")
                if None in row:
                    raise DictionaryError(f"第 {reader.line_num} 行列数多于表头，请检查引号与逗号。")
                word = _text(row.get("word"), MAX_QUERY_LENGTH + 1)
                if not valid_query(word):
                    continue
                translation = _text(row.get("translation"))
                finance = _text(row.get("finance"))
                definition = _text(row.get("definition"))
                if not (translation or finance or definition):
                    continue
                key = normalize(word)
                db.execute("INSERT OR REPLACE INTO entries VALUES(?,?,?,?,?,?,?)",
                           (key, word, _text(row.get("phonetic"), 400), translation, finance,
                            definition, _text(row.get("source"), 300) or f"用户导入：{source.name}"))
                # Last duplicate definition wins; keep explicit form relations from all rows.
                for alias in _text(row.get("aliases"), 3000).split(","):
                    if valid_query(alias):
                        db.execute("INSERT OR IGNORE INTO forms VALUES(?,?)", (normalize(alias), key))
                for pair in _text(row.get("exchange"), 6000).split("/"):
                    label, sep, values = pair.partition(":")
                    if not sep or label not in {"p", "d", "i", "3", "r", "t", "s", "0"}:
                        continue
                    for form in values.split(","):
                        form_key = normalize(form)
                        if not valid_query(form):
                            continue
                        # 0 is a lemma: the current row is the inflected form.
                        relation = (key, form_key) if label == "0" else (form_key, key)
                        db.execute("INSERT OR IGNORE INTO forms VALUES(?,?)", relation)
                if progress and index % 2000 == 0:
                    progress(index)
            count = db.execute("SELECT COUNT(*) FROM entries").fetchone()[0]
            if count == 0:
                raise DictionaryError("没有可导入的英文词条；请检查 CSV 编码和字段内容。")
            db.executemany("INSERT INTO metadata VALUES(?,?)", [
                ("count", str(count)), ("source_file", source.name),
                ("created", datetime.now(timezone.utc).isoformat()),
            ])
            db.commit()
        if cancelled and cancelled():
            raise ImportCancelled("已取消导入，原扩展词库保持不变。")
        db.close()
        db = None
        # Sync only the completed temporary index. Windows requires a writable
        # handle for fsync/_commit; r+b does not truncate existing SQLite bytes.
        # The original CSV remains read-only, and genuine I/O errors propagate.
        with temporary.open("r+b") as stream:
            stream.flush()
            os.fsync(stream.fileno())
        if cancelled and cancelled():
            raise ImportCancelled("已取消导入，原扩展词库保持不变。")
        os.replace(temporary, destination)
        temporary = None
        if progress:
            progress(count)
        return count
    except (UnicodeError, csv.Error, sqlite3.Error) as exc:
        raise DictionaryError(f"导入失败，原词库未替换：{exc}") from exc
    finally:
        csv.field_size_limit(old_limit)
        if db is not None:
            db.close()
        if temporary is not None:
            temporary.unlink(missing_ok=True)
            Path(str(temporary) + "-journal").unlink(missing_ok=True)


def safe_csv_cell(value: str) -> str:
    """Prevent formula execution when a text export is opened in spreadsheets."""
    text = str(value)
    if text.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")) or text.startswith(("\t", "\r", "\n")):
        return "'" + text
    return text


class VocabularyStore:
    """An atomic, editable JSON wordbook, kept outside the program directory."""

    def __init__(self, filename: Path):
        self.filename = Path(filename)
        self.items: dict[str, dict] = {}
        self.warning = ""
        self.read_only = False
        try:
            if self.filename.exists():
                if self.filename.stat().st_size > MAX_JSON_BYTES:
                    raise ValueError("生词本过大")
                loaded = json.loads(self.filename.read_text(encoding="utf-8"))
                if not isinstance(loaded, dict) or loaded.get("version") != 1 or not isinstance(loaded.get("items"), list):
                    raise ValueError("生词本格式错误")
                if len(loaded["items"]) > MAX_VOCAB:
                    raise ValueError("生词本超过 10000 条上限")
                for item in loaded["items"]:
                    if not isinstance(item, dict) or not isinstance(item.get("word"), str):
                        raise ValueError("生词本存在无效记录")
                    for key in ("word", "phonetic", "finance", "translation", "source", "context", "book", "created"):
                        if not isinstance(item.get(key, ""), str):
                            raise ValueError("生词本字段必须为字符串")
                    self.items[normalize(item["word"])] = item
        except (OSError, ValueError, TypeError) as exc:
            # Do not overwrite potentially valuable data when loading failed.
            self.items.clear()
            self.read_only = True
            self.warning = f"生词本未能读取，已保护原文件并暂停写入：{exc}"

    def _commit(self, items: dict[str, dict]):
        if self.read_only:
            raise DictionaryError("生词本处于保护状态。请先备份并修复或移走损坏的 vocabulary.json，再重启。")
        payload = json.dumps({"version": 1, "items": list(items.values())}, ensure_ascii=False, indent=2)
        if len(payload.encode("utf-8")) > MAX_JSON_BYTES:
            raise DictionaryError("生词本超过 16 MiB 限制，请先导出并删除部分词条。")
        self.filename.parent.mkdir(parents=True, exist_ok=True)
        temporary: str | None = None
        try:
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=self.filename.parent,
                                             prefix=".vocabulary-", suffix=".tmp", delete=False) as stream:
                temporary = stream.name
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.filename)
            temporary = None
            self.items = items
        finally:
            if temporary:
                Path(temporary).unlink(missing_ok=True)

    def add(self, entry: Entry, context: str = "", book: str = "") -> bool:
        key = normalize(entry.word)
        if not key:
            raise DictionaryError("词条不能为空。")
        existed = key in self.items
        if not existed and len(self.items) >= MAX_VOCAB:
            raise DictionaryError("生词本已达到 10000 条上限，请先导出并删除部分词条。")
        record = dict(word=entry.word, phonetic=entry.phonetic, finance=entry.finance,
                      translation=entry.translation, source=entry.source,
                      context=context[:1000], book=book[:300],
                      created=self.items.get(key, {}).get("created") or datetime.now(timezone.utc).isoformat())
        items = self.items.copy()
        items[key] = record
        self._commit(items)
        return not existed

    def delete(self, word: str) -> bool:
        key = normalize(word)
        if key not in self.items:
            return False
        items = self.items.copy()
        del items[key]
        self._commit(items)
        return True

    def export_csv(self, filename: Path) -> int:
        filename = Path(filename)
        if filename.resolve() == self.filename.resolve():
            raise DictionaryError("CSV 导出位置不能覆盖生词本原始 JSON。")
        fields = ["word", "phonetic", "finance", "translation", "context", "book", "source", "created"]
        with filename.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(fields)
            for item in self.items.values():
                writer.writerow([safe_csv_cell(item.get(key, "")) for key in fields])
        return len(self.items)


def result_html(result: LookupResult, finance_first: bool = True, night: bool = False) -> str:
    """Render only escaped dictionary text; no remote images/scripts/resources."""
    fg, muted, accent, panel = (("#e3e9f0", "#a0acb9", "#86ccc2", "#242b35") if night
                               else ("#283838", "#647773", "#246b63", "#f0eee8"))
    esc = lambda text: html.escape(str(text), quote=True).replace("\n", "<br/>")
    pieces = [f"<html><body style='color:{fg};font-size:11pt;'>",
              f"<p style='color:{muted};'>{esc(result.match_note)}</p>"]
    if not result.entries:
        pieces.append(f"<h2>{esc(result.query)}</h2>")
        if result.suggestions:
            pieces.append("<p>相近词条：</p>")
            for word in result.suggestions:
                pieces.append(f'<p><a style="color:{accent};" href="lookup:///{quote(word, safe="")}">{esc(word)}</a></p>')
        pieces.append("<p>可以缩短选区，或通过底部「导入词库」添加自有词库。</p>")
    for index, entry in enumerate(result.entries):
        if index:
            pieces.append("<hr/>")
        pieces.append(f"<h2 style='font-size:22pt;color:{accent};'>{esc(entry.word)}</h2>")
        phonetic = entry.phonetic.strip().strip("/[]")
        pieces.append(f"<p style='font-size:14pt;'>/{esc(phonetic)}/</p>" if phonetic else "<p>此词条暂无音标。</p>")
        pieces.append(f"<p style='color:{muted};'>{esc(entry.phonetic_label)} · {esc(entry.category)}</p>")
        senses = [("金融释义", entry.finance), ("普通中文释义", entry.translation)]
        if not finance_first:
            senses.reverse()
        for title, content in senses:
            if content:
                pieces.append(f"<h3 style='color:{accent};'>{title}</h3><p>{esc(content)}</p>")
        if entry.definition:
            pieces.append(f"<h3>英文释义</h3><p>{esc(entry.definition)}</p>")
        for english, chinese in entry.examples:
            pieces.append(f"<h3>例句</h3><p>{esc(english)}</p><p>{esc(chinese)}</p>")
        pieces.append(f"<p style='font-size:9pt;color:{muted};'>来源：{esc(entry.source)}</p>")
    pieces.append(f"<p style='font-size:9pt;color:{muted};'>释义仅辅助阅读。内置音标为参考读音；短语不标注自然语流的连读。</p></body></html>")
    return "".join(pieces)


def main() -> int:
    parser = argparse.ArgumentParser(description="墨读离线金融英汉词典（无需安装 Qt）")
    parser.add_argument("word", nargs="?", default="leverage", help="单词或带引号的短语")
    parser.add_argument("--extra", type=Path, help="扩展词库 SQLite 路径")
    args = parser.parse_args()
    try:
        engine = DictionaryEngine(args.extra)
        result = engine.lookup(args.word)
        print(result.match_note)
        for entry in result.entries:
            print(f"\n{entry.word}  /{entry.phonetic}/")
            if entry.finance:
                print("金融：" + entry.finance)
            if entry.translation:
                print("中文：" + entry.translation)
            for en, zh in entry.examples:
                print(en + "\n" + zh)
        if result.suggestions:
            print("相近词条：" + ", ".join(result.suggestions))
        engine.close()
        return 0 if result.entries else 2
    except (DictionaryError, OSError, sqlite3.Error) as exc:
        print(f"词典错误：{exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
