# 墨读 · EPUB / PDF 阅读器 5.1 · 金融词典 + MDX / MDD

一个本地 Python 桌面阅读器：EPUB 用可调字号的阅读排版，PDF 按原页面显示；共用离线英汉金融词典、参考音标、中文释义、生词本、背景颜色和阅读记录；新增可并存的 MDX / MDD 本地词典库。

**这是完整源码运行包，不是补丁，也不是免安装 EXE。** 需要 Python 3.10+、图形桌面和能安装对应平台依赖的环境。项目不捆绑第三方二进制或字体文件。

## 5.1 修复：Windows 导入报 `[Errno 9] Bad file descriptor`

5.0 在 MDX/MDD 导入结束、保存 SQLite 索引时，用只读 `rb` 文件句柄调用 `os.fsync()`。
CSV/ECDICT 导入存在相同写法。本版将两处临时索引同步改为 **`r+b` + `flush()` + `fsync()`**，
同步完成后先关闭句柄再发布索引。`r+b` 不清空已生成的索引，原 MDX/MDD/CSV 仍只读。
真正的磁盘写入错误仍会终止导入，不会通过忽略异常来假装成功。

新增 MDX 索引验证 / 同步阶段提示；MDX 与 CSV 导入失败时，显示失败阶段与本地日志路径。
日志位于**原应用数据目录**下的 `logs/dictionary_import.log`，保留一个轮转副本 `.1`。
日志记录版本、Python / 平台、词典路径及异常调用链；不上传，不主动读取或转存整本书 / 整部词典，
也不转储局部变量。异常消息仍可能带文件名、片段或本机路径，分享前请检查。
普通主动取消不会记录成错误；同步完成后才提出的取消也会在发布前再检查。

**升级：** 关闭 5.0，完整解压新版到新目录，运行 `start_windows.bat`。
5.1 没有新增依赖或修改用户数据格式。不要只复制一个 Python 文件；新增的 `import_diagnostics.py` 必须在项目中。
继续使用原来的 `MoDuReader` 数据目录；此前指定过 `--data-dir` 时，继续指定同一路径。
不用删除 `state.json`、`vocabulary.json`、`dictionary_extra.sqlite`、`mdict_library.json` 或既有索引。
在「MDX 词典 → 导入 MDX / MDD」重试此前失败的 `.mdx` 即可；既有成功词典不必全部重导。

**验证边界：** 已在 Linux 用严格的“同步句柄必须可写”检查重现旧版同文报错，再通过新版回归测试。
这不是 Windows 实机运行；本次没有用户实际词典，也没有 Qt 桌面环境。截图本身无法排除其他文件句柄问题。
准确测试结果及限制见 `TEST_REPORT.md`，具体原因见 `FIX_5_1.md`。

## 5.0 新增：MDX / MDD 词典

右侧词典增加 **“MDX 词典”** 页签；没有显示词典时按 `Ctrl+J`。点击 **“导入 MDX / MDD”**，选择本机的 `.mdx` 文件。程序会同时寻找同目录的同名 `.mdd`、`.1.mdd`、`.2.mdd` 等分卷。MDD 是资源包，不是独立的词典正文。

```text
我的词典/
├── Dictionary.mdx
├── Dictionary.mdd        # 有资源时提供
├── Dictionary.1.mdd      # 分卷按实际文件提供
└── Dictionary.css        # 有独立样式文件时保留
```

导入只建立本地 SQLite 索引，**不会把整个词典复制到程序目录，也不解压整个 MDD**。请保留原 MDX / MDD 的位置和内容；移动、替换文件后需要重新导入。词典可放在自己的固定目录，不必放在阅读器目录。

| 功能 | 本版行为 |
| --- | --- |
| MDX 正文 | 支持 MDict 1.x / 2.x 的 HTML 或纯文本词条、常见文本编码、词头查询、内部词条跳转 |
| MDD 资源 | 图片按需读取、基础 CSS 样式、点击音频链接播放词典自带音频；支持同名数字分卷 |
| 多部词典 | MDX 词库相互并存；可切换单部或查询全部已启用词典，管理、停用、移除或重建索引 |
| 追加资源 | “补充 MDD”可为已导入词典追加资源，也可绑定不同文件名的配套 MDD |
| 阅读联动 | EPUB / 文字型 PDF 的原有划词查询，同时查内置 / CSV 词库和已启用的 MDX |
| 生词本 | 保存选中的 MDX 词条纯文本、可识别的原音标及阅读上下文；不复制图片或音频 |

**原有金融词条、CSV 扩展词库和生词本不会因导入 MDX 被替换。** 当内置金融词库和 MDX 都命中时，默认仍在原“查词”页查看金融释义，切换到“MDX”页查看导入词典；已选择 MDX 页时，会保留该页签。

**音标、中文释义和音频取决于原词典实际内容。** 没有中文或发音资源的词典不会被自动翻译或生成读音；本版没有在线发音或文字转语音。内置小词库的参考音标说明仍适用。

兼容范围：未压缩 / zlib 的 MDict 1.x、2.x；旧式 LZO 需要可用的 `python-lzo` 或系统 `liblzo2`。不支持 MDict 3.x、注册 / 设备绑定加密词典、JavaScript 交互和完整浏览器排版。复杂 CSS、嵌入字体、JS 折叠 / 发音按钮可能无法原样显示。音频解码取决于本机 Qt 多媒体后端。

包内有可导入的原创示例 **`examples/mdict_demo/FinanceDemo.mdx`**，配套 MDD 与分卷已一并提供。查询 `equity`、`cash flow` 或 `mdx test` 可检查中文、音标、图片和词条跳转。示例音频是明确标注的测试提示音，**不是英语发音**。

详细步骤和格式边界见 **[MDX_GUIDE.md](MDX_GUIDE.md)**。本包没有附带商业词典或第三方大词库。

## 快速启动

### Windows

关闭旧版，完整解压到一个新文件夹，双击 `start_windows.bat`。
启动脚本会建立本项目的 `.venv`，检查依赖并在需要时安装；**首次安装需要联网，之后本地阅读和内置查词可离线使用。**

### macOS / Linux

```bash
cd epub_pdf_reader_v5_1
sh start_macos_linux.sh pdf_demo.pdf
```

无图形桌面的服务器不是这个 GUI 程序的交互运行目标。部分 Linux 发行版需要先安装系统的 venv/ensurepip 和图形库组件。

### 手动运行

在项目目录执行：

```bash
python -m pip install -r requirements.txt
python epub_reader.py pdf_demo.pdf
```

也可以使用自己的 PDF 或 EPUB：

```bash
python epub_reader.py "你的财务报告.pdf"
python epub_reader.py "你的电子书.epub"
```

macOS / Linux 的命令可能是 `python3`。建议在虚拟环境中运行。主入口继续叫 `epub_reader.py`，但已同时支持两种格式。

## 4.0 新增：PDF 阅读

| 功能 | 本版行为 |
| --- | --- |
| 打开文件 | 选择文件、拖入窗口、命令行和最近阅读均支持 `.pdf` / `.epub`，扩展名不区分大小写 |
| 页面显示 | PDFium 在本机渲染原页面，保留文档中的文字排版、位图、矢量图表；不先转换成 HTML |
| 页面导航 | 上一页、下一页、输入物理页码跳转、PDF 内置目录；目录项跳到对应页面顶部 |
| 缩放旋转 | 适合宽度、适合整页、25%–400% 自定义缩放、90 度旋转；不改变源文件 |
| 文字选择 | 同页拖动划选、双击选词、右键查词、复制所选文字；需可提取的文字层 |
| 搜索 | 当前 PDF 页搜索，前后匹配与高亮；**不是全文件搜索** |
| 书签记录 | 页码、页内滚动比例、缩放、旋转、书签、本机最近阅读 |
| 扫描版 | 显示图片页面；没有文字层时不能自动划词、复制或搜索；不包含 OCR |
| 密码文件 | 提示输入打开密码，不保存密码；取消输入或文件验证失败时保留当前书籍 |
| 提取权限 | 文件限制复制/提取时，关闭文字提取、查词和搜索；仍可显示页面 |

**阅读方式为单页显示、页内滚动，不是整份 PDF 的连续长卷。**
鼠标滚轮仅在当前页滚动，不自动连跳多页；到页末后可点击“下一页”、按 `Alt+→`，或再按一次 `PageDown / → / Space` 进入下一页。

PDF 工具栏中的页码从 **1** 开始，表示文件中的物理页序；若 PDF 定义了其他页标，会在标题中附带显示。目录没有可用目的页的分组仍可展开，但不能直接跳转。

PDF 的字号按钮 `A− / A+` 改为缩小/放大整页，旁边显示实际百分比；不能像 EPUB 一样单独改变正文的字号或行距。窗口尺寸变化时，“适合宽度/整页”会重新计算尺寸。

## 打开位置：避免自动下滑

默认打开到**所记 EPUB 章节或 PDF 页的顶部**，不会自动使用旧的滚动偏移；没有记录的新书从第一章 / 第一页开始。

需要精确续读时，开启菜单 **阅读 → 打开时恢复上次阅读位置**。此设置影响下次打开时是否应用页内位置，不会删除已保存的记录。

`Ctrl+Home` 回到当前章节 / PDF 页顶部。“从全书开头阅读”回到第一章 / 第一页。

默认启动时仍会尝试打开最近阅读且路径有效的文件；禁用这个行为：

```bash
python epub_reader.py --no-restore
```

`--no-restore` 控制自动打开最近文件，与菜单里的页内位置开关不同。PDF 的页内位置按比例保存，窗口、缩放或设备变化后不保证精确落在同一行。

## 背景颜色与 PDF 原色

顶部 **背景颜色** 提供纸白、暖米、浅绿、柔灰、夜间，以及自定义颜色。颜色保存在本机，重启后继续使用。

EPUB：正文背景与文字对比色一起改变。

PDF：**默认只改变页面周围的背景，页面保持原色**。需要改变 PDF 纸张观感时，勾选 PDF 工具栏里的 **纸张护眼着色**；浅色主题使用着色滤镜，深色主题使用反色并调整底色。

**护眼着色也会改变照片、财务图表和标记的颜色。核对图表原色时请取消勾选。** 这是显示滤镜，不会改写 PDF 文件，不会自动导出修改后的 PDF。

`Ctrl+Shift+C` 打开自定义颜色选择器；`Ctrl+D` 切换夜间模式，切回时恢复原先的浅色背景。

## 金融英汉词典

内置 **453 条精选词条**：332 条金融词汇/短语、121 条基础通用词，全部带参考音标和中文释义，其中 30 条有原创双语例句。此词库不是完整通用大词典。

双击单词、选中短语后松开鼠标，或按 `Ctrl+E` 查询；`Ctrl+J` 显示 / 隐藏词典。默认开启“划词即查”和“金融释义优先”，可在词典中关闭。

可以尝试 `equity`、`duration`、`leverage`、`cash flow`、`interest rates`、`ETF`、`P/E`。选区最多 160 个字符、12 个英文单词；这不是整句翻译。

PDF 查词依赖真实文字层，不能识别纯图片里的字。PDF 缺少正确的字符映射、阅读顺序特殊或将字形转成矢量轮廓时，页面可能正常显示但选词内容不正确或不可提取。遇到这种情况可以在词典框手动输入。

内置小词库的参考音标采用常用美式读音，短语给出分词读音参考，未经过出版社或专业词典逐项审校；内置小词库不包含真人音频或语音朗读。MDX 页展示导入词典自己的音标、释义和可用音频。词库未收录时明确显示未找到，不凭空补写释义。

## 生词本与扩展词库

查询后点击“加入生词本”，保存英文、参考音标、中文释义、来源和上下文。PDF 还会在来源书名中附带当前物理页码。生词本支持筛选、删除和导出 UTF-8 BOM CSV；导出会处理潜在的表格公式注入字符。

支持导入 ECDICT 格式或自定义 UTF-8 CSV，以扩展本机词库。**完整 ECDICT 数据没有随包附带**，请自行取得有权使用的数据。

CSV 必须含 `word`、`translation` 列；可选 `phonetic`、`finance`、`definition`、`exchange`、`aliases`、`source`。`examples/custom_dictionary.csv` 是可直接导入的例子。扩展词库转换为本地 SQLite 索引库；再次导入会替换上一次扩展词库，但不会替换内置词条或删除生词本。

未提供音标的导入词条会标为“暂无音标”。词形推测与已收录词形关系会区分标注；缩写匹配到全称时，音标属于全称。

## EPUB 原有功能保留

EPUB 2/3 目录、spine 阅读顺序、章节内锚点、章节搜索、书内链接与返回、书签、12–36 pt 字号、常见位图和清理后的静态 SVG、夜间模式与自定义背景。

图片按正文宽度等比缩放；改变窗口或词典宽度时尽量不重建整章。仍不支持 DRM、完整固定版式、竖排、复杂出版商 CSS、CSS 背景图片、完整 SVG 特效、音视频和交互脚本。远程图片不自动下载。

## 快捷键

| 操作 | 快捷键 |
| --- | --- |
| 打开 EPUB / PDF | Ctrl+O |
| 前 / 后一屏，到边界可切章 / 页 | ← / →，PageUp / PageDown，Shift+Space / Space |
| 上一章 / 上一 PDF 页；下一章 / 下一 PDF 页 | Alt+← / Alt+→ |
| 返回上次导航位置 | Alt+↑ |
| 搜索当前章节 / PDF 页 | Ctrl+F；F3 下一个；Shift+F3 上一个 |
| PDF 页码输入框 | Ctrl+G |
| PDF 缩放 | Ctrl+滚轮；Ctrl+- / Ctrl+= |
| 查所选词；显示 / 隐藏词典 | Ctrl+E；Ctrl+J |
| 添加书签；显示 / 隐藏目录 | Ctrl+B；Ctrl+L |
| 回到当前章节 / 页顶部 | Ctrl+Home |
| 夜间模式；自定义颜色 | Ctrl+D；Ctrl+Shift+C |
| 复制 PDF 所选文字；取消选区 | Ctrl+C；Esc |
| 退出 | Ctrl+Q |

阅读快捷键需要正文 / PDF 画布获得焦点。macOS 上 Qt 可能将 Ctrl 映射为 Command，以实际系统显示为准。

## 升级与本地数据

建议先关闭旧版并备份数据目录，再完整解压新版，不要只替换一个 Python 文件。5.0 新增 `PySide6-Addons` 依赖，使用其中的 QtMultimedia 播放本地词典音频；保留 PDF 的 `pypdfium2` 依赖。旧环境必须重新执行 `python -m pip install -r requirements.txt`；使用启动脚本时会自动检查。程序不使用 WebEngine。

继续使用原有的 `MoDuReader` 应用标识和默认数据目录。相同系统账户下，旧版 EPUB 书签、阅读记录、背景设置、生词本与扩展词库可继续读取。

自定义数据目录：

```bash
python epub_reader.py --data-dir "./reader-data" pdf_demo.pdf
```

旧版使用过 `--data-dir` 时，请继续指定原来的目录。不要删除 `state.json`、`vocabulary.json` 或扩展词库来解决图片 / PDF 问题，也不要复制其他系统的 `.venv`。

这些记录仅保存在本机，不加密，可能包含书名、文件路径和阅读上下文。MDX 清单存放在 `mdict_library.json`，索引存放在数据目录下的 `mdict/`；其中包含词典路径、词头和压缩块偏移。PDF 密码不会写入记录。程序不会上传正文或自动联网查词；EPUB 外链仍需确认后交由系统应用打开。

本版不支持多个进程同时写入同一数据目录。PDF 标识由文件内容摘要生成；文件内容发生变化时会作为另一份文档保存阅读记录。

## PDF 范围与限制

本版是只读阅读器，不是完整 PDF 编辑工具。没有 PDF 批注编辑、表单交互、签名验证、打印、附件打开、文档内链接点击、OCR、全文件搜索或连续多页长卷；目录页跳转单独支持。目录中的精确页内目的坐标暂不恢复。

不会执行 PDF JavaScript、外部动作或自动打开附件，不尝试绕过 DRM 或打开密码。使用原生 PDFium 解析器不等于经过完整安全审计或提供进程沙箱；请避免打开来源不明的恶意文件，并按需要更新依赖。

为控制资源消耗：文件上限 512 MiB，页数上限 20,000，目录上限 10,000 项，文字层上限每页 200,000 个原生字符；超过文字上限时仍可读图但停用本页文字操作。渲染位图上限约 1,200 万像素 / 单边 8192 像素，过高分辨率会下调；单次选择上限 20,000 字符，本页搜索最多返回 5000 处。

仅缓存当前原生页面和文字层，不预先将整份 PDF 渲染成图片。打开、摘要计算和当前页渲染在 GUI 线程中进行；大文件、复杂矢量图或异常文件可能暂时阻塞界面。资源限制不是总内存或耗时的硬性上限。

## 项目文件

```text
epub_pdf_reader_v5_1/
├── epub_reader.py           # 共用窗口、EPUB 界面与程序入口
├── pdf_integration.py       # PDF 与窗口、词典、记录的集成
├── pdf_ui.py                # PDF 画布、缩放、选区与颜色滤镜
├── pdf_core.py              # PDFium 渲染、文字、坐标、目录与密码
├── epub_core.py             # EPUB 解析与状态文件
├── image_support.py         # EPUB 图片处理辅助
├── image_ui.py              # EPUB 图片解码与尺寸管理
├── dictionary_core.py       # 词库、词形、生词本与 CSV
├── dictionary_ui.py         # 共用词典界面
├── mdict_format.py          # MDX/MDD 1.x、2.x 二进制读取与边界检查
├── mdict_core.py            # SQLite 索引、资源读取、多部词典库
├── mdict_html.py            # HTML/CSS 白名单及虚拟资源链接
├── mdict_ui.py              # MDX 页签、导入、图片、词典管理和音频
├── mdict_audio.py           # 本地音频格式头校验
├── import_diagnostics.py    # 导入失败阶段、异常调用链与本地轮转日志
├── mdict_hash.py            # RIPEMD-128 / v2 索引编码兼容
├── make_mdict_demo.py       # 原创 MDX/MDD 示例生成器
├── examples/mdict_demo/     # FinanceDemo.mdx + .mdd + .1.mdd
├── reader_settings.py       # 背景及 EPUB 位置设置
├── data/finance_dictionary.json
├── pdf_demo.pdf             # 四页 PDF 示例：文字、图像、表格、扫描及旋转
├── finance_demo.epub        # 金融英文示例
├── image_test.epub          # EPUB 图片与滚动检查书
├── demo.epub                # 中文 EPUB 示例
├── make_pdf_demo.py         # 重建 PDF 示例与密码 / 权限测试文件
├── requirements.txt        # 运行依赖
├── requirements-dev.txt    # 可选的示例重建依赖
├── start_windows.bat
├── start_macos_linux.sh
├── bootstrap.py
├── tests/                  # 原有回归测试和 PDF 测试
├── verify_package.py       # 核对压缩包文件清单及摘要
├── MANIFEST.json
├── TEST_REPORT.md
├── MDX_GUIDE.md
└── README.md
```

## 验证与重建示例

```bash
python -m unittest discover -s tests -v
python verify_package.py
```

没有 Qt 时 GUI 测试会明确跳过，不能把跳过视为通过。本次实际结果和未验证范围见 `TEST_REPORT.md`。

示例 PDF 已包含，日常阅读不需要 ReportLab 或 Pillow。只有修改并重新生成示例文件时才需安装开发依赖：

```bash
python -m pip install -r requirements-dev.txt
python make_pdf_demo.py
```

测试目录中的 `password.pdf` 使用公开的测试密码 `demo123`；它不是用户数据。`restricted.pdf` 用来测试复制权限处理。
