"""Static, resource-allowlisted MDX HTML for QTextDocument (never WebEngine).

Remote URLs, file URLs, scripts, frames, external fonts, CSS URLs and interactive
controls are removed. A word can link to another word or a user-clicked audio
resource. This is deliberately not a full browser/CSS implementation.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import html
from html.parser import HTMLParser
import re
from typing import Callable
from urllib.parse import quote, unquote, urlsplit

from mdict_format import MdictError, resource_key

MAX_HTML = 2 * 1024**2
MAX_CSS = 512 * 1024
MAX_RESOURCES = 128
MAX_NODES = 50_000


def resource_url(value: str, identifier: str, kind: str = 'mdictres') -> str:
    """Resolve one HTML URL into a dictionary-scoped virtual URL; decode once."""
    value = value.strip().replace('\\', '/')
    if not value or len(value) > 4096 or any(ord(c) < 32 for c in value):
        raise MdictError('资源链接无效。')
    parts = urlsplit(value)
    if parts.scheme:
        if parts.scheme.lower() != 'sound' or kind != 'mdictaudio':
            raise MdictError('不加载网络或本地文件链接。')
        path = parts.netloc + parts.path
    else:
        if parts.netloc:
            raise MdictError('不加载网络资源。')
        path = parts.path
    path = unquote(path, errors='strict')
    resource_key(path)  # Reject traversal and drive names before URL construction.
    return f'{kind}://{identifier}/' + quote(path.replace('\\', '/').lstrip('/'), safe='/')


def split_virtual_url(value: str, scheme: str) -> tuple[str, str]:
    parts = urlsplit(value)
    if parts.scheme != scheme or not re.fullmatch('[0-9a-f]{24}', parts.netloc):
        raise MdictError('词典资源来源无效。')
    path = unquote(parts.path.lstrip('/'), errors='strict')
    resource_key(path)
    return parts.netloc, path


def _safe_declarations(style: str, night: bool = False) -> str:
    allowed = {'color', 'background-color', 'font-family', 'font-size', 'font-style', 'font-weight',
               'text-decoration', 'text-align', 'vertical-align', 'white-space', 'margin-left',
               'margin-right', 'margin-top', 'margin-bottom', 'padding', 'padding-left', 'padding-right',
               'padding-top', 'padding-bottom', 'border', 'border-color', 'border-width', 'border-style',
               'border-collapse', 'text-indent', 'line-height'}
    declarations = []
    for declaration in style[:8192].split(';'):
        if ':' not in declaration:
            continue
        name, value = (part.strip() for part in declaration.split(':', 1))
        name = name.lower()
        if name not in allowed or (night and name in {'color', 'background-color', 'border-color'}):
            continue
        if len(value) > 240 or any(c in value for c in '\\<>@{}'):
            continue
        if re.search(r'url\s*\(|expression|javascript|behavior|!important', value, re.I):
            continue
        if not re.fullmatch(r"[\w\s#.,%()+\-/'\"]+", value, re.U):
            continue
        declarations.append(f'{name}:{value}')
    return ';'.join(declarations)


def safe_css(css: str, namespace: str = 'mdx', night: bool = False) -> str:
    css = re.sub(r'/\*.*?\*/', '', css[:MAX_CSS], flags=re.S)
    rules = []
    for selector, declarations in re.findall(r'([^{}]+)\{([^{}]*)\}', css):
        if any(c in selector for c in '@\\<>[]') or len(selector) > 500:
            continue
        props = _safe_declarations(declarations, night)
        if not props:
            continue
        selectors = []
        for part in selector.split(','):
            part = part.strip()
            if not part or not re.fullmatch(r'[A-Za-z0-9_\-\s.#:>+*]+', part):
                continue
            part = re.sub(r'([.#])([\w-]+)', lambda m: m[1] + namespace + '_' + m[2], part)
            part = re.sub(r'\b(?:html|body)\b', f'#{namespace}', part)
            if not part.startswith('#' + namespace):
                part = f'#{namespace} ' + part
            selectors.append(part)
        if selectors:
            rules.append(','.join(selectors) + '{' + props + '}')
    return '\n'.join(rules)


@dataclass
class SafeArticle:
    markup: str
    resources: list[str] = field(default_factory=list)
    audio: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class _ArticleParser(HTMLParser):
    allowed = {'div', 'span', 'p', 'br', 'hr', 'b', 'strong', 'i', 'em', 'u', 's', 'small',
               'big', 'sub', 'sup', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li',
               'dl', 'dt', 'dd', 'table', 'tr', 'td', 'th', 'thead', 'tbody', 'tfoot',
               'blockquote', 'pre', 'code', 'a', 'img', 'font', 'center'}
    skip = {'script', 'iframe', 'frame', 'frameset', 'object', 'embed', 'svg', 'math', 'template',
            'form', 'input', 'button', 'textarea', 'video', 'noscript'}
    void = {'br', 'hr', 'img', 'input', 'embed', 'meta', 'link', 'source', 'area', 'wbr'}

    def __init__(self, identifier: str, css_loader: Callable[[str], bytes | None] | None,
                 namespace: str, night: bool):
        super().__init__(convert_charrefs=True)
        self.identifier, self.loader, self.namespace, self.night = identifier, css_loader, namespace, night
        self.parts: list[str] = []
        self.css: list[str] = []
        self.resources: list[str] = []
        self.audio: list[str] = []
        self.warnings: set[str] = set()
        self.blocked: list[str] = []
        self.style = False
        self.style_parts: list[str] = []
        self.stack: list[str] = []
        self.count = 0
        self.css_count = 0

    def _warning(self, text: str):
        if len(self.warnings) < 8:
            self.warnings.add(text)

    def _load_css(self, href: str):
        if not self.loader or self.css_count >= 12:
            return
        self.css_count += 1
        try:
            url = resource_url(href, self.identifier)
            _, path = split_virtual_url(url, 'mdictres')
            if not path.lower().endswith('.css'):
                return
            data = self.loader(path)
            if data:
                if len(data) > MAX_CSS:
                    raise MdictError('CSS 资源超过限制。')
                self.css.append(safe_css(data.decode('utf-8-sig', errors='replace'), self.namespace, self.night))
            else:
                self._warning(f'缺少样式资源：{path}')
        except (MdictError, OSError, ValueError) as exc:
            self._warning(str(exc))

    def _audio(self, value: str) -> str:
        url = resource_url(value, self.identifier, 'mdictaudio')
        _, path = split_virtual_url(url, 'mdictaudio')
        if not path.lower().endswith(('.wav', '.mp3', '.ogg', '.m4a', '.aac', '.flac', '.spx', '.oga')):
            raise MdictError('不支持此音频扩展名。')
        if len(self.audio) >= MAX_RESOURCES:
            raise MdictError('音频资源过多。')
        if url not in self.audio:
            self.audio.append(url)
        return url

    def handle_starttag(self, tag, attrs):
        self.count += 1
        if self.count > MAX_NODES:
            raise MdictError('词条 HTML 节点过多。')
        attrs = dict(attrs)
        if self.blocked:
            if tag not in self.void:
                self.blocked.append(tag)
            return
        if tag in self.skip:
            if tag not in self.void:
                self.blocked.append(tag)
            self._warning('交互脚本或不支持的嵌入内容已移除。')
            return
        if tag == 'style':
            self.style = True
            self.style_parts = []
            return
        if tag == 'link':
            if 'stylesheet' in (attrs.get('rel') or '').lower():
                self._load_css(attrs.get('href') or '')
            return
        if tag in {'audio', 'source'}:
            try:
                if attrs.get('src'):
                    url = self._audio(attrs['src'])
                    self.parts.append(f'<a href="{html.escape(url, quote=True)}">[播放词典音频]</a> ')
            except (MdictError, ValueError) as exc:
                self._warning(str(exc))
            return
        if tag not in self.allowed:
            return
        clean: list[tuple[str, str]] = []
        for name in ('class', 'id'):
            if attrs.get(name):
                tokens = re.findall(r'[A-Za-z0-9_-]+', attrs[name])[:12]
                if tokens:
                    clean.append((name, ' '.join(self.namespace + '_' + token for token in tokens)))
        if attrs.get('style'):
            style = _safe_declarations(attrs['style'], self.night)
            if style:
                clean.append(('style', style))
        for name in ('colspan', 'rowspan', 'border', 'cellspacing', 'cellpadding'):
            value = attrs.get(name) or ''
            if value.isdigit() and 0 <= int(value) <= 100:
                clean.append((name, value))
        for name in ('align', 'valign'):
            value = (attrs.get(name) or '').lower()
            if value in {'left', 'right', 'center', 'justify', 'top', 'middle', 'bottom'}:
                clean.append((name, value))
        if tag == 'font' and not self.night:
            color = attrs.get('color') or ''
            if re.fullmatch(r'#[0-9a-fA-F]{3,8}|[A-Za-z]{1,20}', color):
                clean.append(('color', color))
        if tag == 'a':
            href = attrs.get('href') or ''
            name = attrs.get('name')
            if name:
                clean.append(('name', self.namespace + '_' + re.sub(r'[^\w-]', '', name)[:160]))
            try:
                parts = urlsplit(href)
                if parts.scheme.lower() in {'entry', 'bword'}:
                    # netloc belongs to a word, not an Internet host.
                    word = unquote(parts.netloc + parts.path, errors='strict').lstrip('/')
                    if 0 < len(word) <= 160 and not any(ord(c) < 32 for c in word):
                        clean.append(('href', 'mdictlookup://' + self.identifier + '/' + quote(word, safe='')))
                elif href.startswith('#'):
                    clean.append(('href', '#' + self.namespace + '_' + re.sub(r'[^\w-]', '', unquote(href[1:]))))
                elif parts.scheme.lower() == 'sound':
                    clean.append(('href', self._audio(href)))
                elif href and not parts.scheme and not parts.netloc and parts.path.lower().endswith(('.wav', '.mp3', '.ogg', '.m4a', '.aac', '.flac', '.spx')):
                    clean.append(('href', self._audio(href)))
                elif href:
                    self._warning('书外链接已禁用；词典不会自动联网。')
            except (ValueError, MdictError) as exc:
                self._warning(str(exc))
        if tag == 'img':
            try:
                url = resource_url(attrs.get('src') or '', self.identifier)
                if len(self.resources) >= MAX_RESOURCES:
                    raise MdictError('单词条图片数量过多。')
                if url not in self.resources:
                    self.resources.append(url)
                clean.append(('src', url))
                # UI resolves actual pixel dimensions before passing markup to Qt.
                if attrs.get('alt'):
                    clean.append(('alt', attrs['alt'][:180]))
            except (ValueError, MdictError) as exc:
                self._warning(str(exc))
                self.parts.append('[图片不可用]')
                return
        attr_text = ''.join(f' {key}="{html.escape(value, quote=True)}"' for key, value in clean)
        self.parts.append('<' + tag + attr_text + '>')
        if tag not in self.void:
            self.stack.append(tag)

    def handle_endtag(self, tag):
        if self.blocked:
            if tag in self.blocked:
                index = len(self.blocked) - 1 - self.blocked[::-1].index(tag)
                del self.blocked[index:]
            return
        if tag == 'style':
            self.style = False
            self.css.append(safe_css(''.join(self.style_parts), self.namespace, self.night))
            self.style_parts.clear()
            return
        if tag in self.stack:
            while self.stack:
                current = self.stack.pop()
                self.parts.append('</' + current + '>')
                if current == tag:
                    break

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.void:
            self.handle_endtag(tag)

    def handle_data(self, data):
        if self.blocked:
            return
        if self.style:
            if sum(map(len, self.style_parts)) < MAX_CSS:
                self.style_parts.append(data)
        else:
            self.parts.append(html.escape(data))


def sanitize_article(body: str, identifier: str,
                     css_loader: Callable[[str], bytes | None] | None = None,
                     default_css: bytes | None = None, namespace: str = 'mdx', night: bool = False) -> SafeArticle:
    if len(body.encode('utf-8')) > MAX_HTML:
        raise MdictError('MDX 词条正文超过 2 MiB。')
    if not re.fullmatch('[0-9a-f]{24}', identifier) or not re.fullmatch('[A-Za-z][A-Za-z0-9_]*', namespace):
        raise MdictError('MDX 词典标识无效。')
    parser = _ArticleParser(identifier, css_loader, namespace, night)
    if default_css:
        parser.css.append(safe_css(default_css[:MAX_CSS].decode('utf-8-sig', errors='replace'), namespace, night))
    parser.feed(body)
    parser.close()
    while parser.stack:
        parser.parts.append('</' + parser.stack.pop() + '>')
    markup = '<style>' + '\n'.join(parser.css) + '</style>'
    markup += '<div id="' + namespace + '">' + ''.join(parser.parts) + '</div>'
    return SafeArticle(markup, parser.resources, parser.audio, sorted(parser.warnings))


class _Snapshot(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.ipa: list[str] = []
        self.skip = 0
        self.phonetic = 0
        self.stack: list[tuple[bool, bool]] = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        skip = tag in {'script', 'style', 'iframe', 'object', 'template'}
        phonetic = bool(re.search(r'\b(?:ipa|phonetic|phonetics|pron|pronunciation|phon|pron-us|pron-uk)\b',
                                  ' '.join((attrs.get('class') or '', attrs.get('id') or '')), re.I))
        if tag in {'p', 'div', 'li', 'br', 'h1', 'h2', 'h3', 'tr'}:
            self.parts.append('\n')
        if tag not in {'br', 'img', 'hr', 'input', 'meta', 'link', 'source'}:
            self.stack.append((skip, phonetic))
            self.skip += skip
            self.phonetic += phonetic

    def handle_endtag(self, tag):
        if self.stack:
            skip, phonetic = self.stack.pop()
            self.skip -= skip
            self.phonetic -= phonetic

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)
            if self.phonetic:
                self.ipa.append(data)


def text_snapshot(body: str) -> tuple[str, str]:
    parser = _Snapshot()
    parser.feed(body[:MAX_HTML])
    parser.close()
    text = '\n'.join(' '.join(line.split()) for line in ''.join(parser.parts).splitlines() if line.strip())
    phonetic = ' '.join(''.join(parser.ipa).split()).strip(' /[]')[:240]
    # Only extract literal IPA-looking bracket/slash text; never synthesize IPA.
    if not phonetic:
        for candidate in re.findall(r'[/\[]([^/\[\]\n]{1,120})[/\]]', text):
            if re.search(r'[ɑɐɒæəɛɜɪʊʌɔɚɝθðŋʃʒˈˌː]', candidate):
                phonetic = candidate.strip()
                break
    return text, phonetic
