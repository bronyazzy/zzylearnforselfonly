"""Validated reader appearance and saved viewport helpers, without Qt."""
from __future__ import annotations

from dataclasses import dataclass
import math
import re

PRESET_BACKGROUNDS = (
    ('纸白', '#ffffff'), ('暖米', '#faf8f3'), ('浅绿', '#e6f1e7'),
    ('柔灰', '#e8eaed'), ('夜间', '#1b2028'),
)
DEFAULT_BACKGROUND = '#faf8f3'
NIGHT_BACKGROUND = '#1b2028'


def normalize_background(value: object, default: str = DEFAULT_BACKGROUND) -> str:
    return value.lower() if isinstance(value, str) and re.fullmatch(r'#[0-9a-fA-F]{6}', value) else default


def luminance(color: str) -> float:
    color = normalize_background(color)
    rgb = [int(color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    linear = [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in rgb]
    return sum(a * b for a, b in zip(linear, (0.2126, 0.7152, 0.0722)))


def theme_colors(background: str) -> tuple[str, str, str, str, str, str]:
    background = normalize_background(background)
    # Pick the text pair by luminance rather than an arbitrary RGB average.
    white_contrast = 1.05 / (luminance(background) + 0.05)
    dark_contrast = (luminance(background) + 0.05) / (luminance('#161c20') + 0.05)
    dark = white_contrast > dark_contrast
    if dark:
        return background, '#242b35', '#ffffff', '#b8c2ce', '#485566', '#b6eee5'
    return background, '#f0eee8', '#161c20', '#465953', '#c0ccc5', '#124b43'


@dataclass(frozen=True)
class ViewPosition:
    position: int = 0       # QTextDocument UTF-16 cursor offset, not a Python string index.
    offset: int = 0         # Cursor y inside viewport; may be negative.
    ratio: float = 0.0      # Old records and boundary fallback.
    at_top: bool = False
    at_bottom: bool = False

    def as_dict(self) -> dict:
        return dict(position=self.position, offset=self.offset, ratio=self.ratio,
                    at_top=self.at_top, at_bottom=self.at_bottom)

    @classmethod
    def from_dict(cls, value: object):
        if not isinstance(value, dict):
            return None
        try:
            p, y, r = int(value['position']), int(value.get('offset', 0)), float(value.get('ratio', 0))
            if not (0 <= p <= 50_000_000 and abs(y) <= 1_000_000 and math.isfinite(r)):
                return None
            return cls(p, y, min(1.0, max(0.0, r)), value.get('at_top') is True, value.get('at_bottom') is True)
        except (KeyError, TypeError, ValueError, OverflowError):
            return None
