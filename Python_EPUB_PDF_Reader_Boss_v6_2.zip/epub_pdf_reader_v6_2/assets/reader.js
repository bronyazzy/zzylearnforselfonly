/* Host-owned isolated-world helpers. No publication scripts are executed. */
(() => {
  'use strict';
  if (window.__modu) return;
  const clamp = (x,a,b) => Math.min(b,Math.max(a,Number(x)||0));
  let revision = 0, lastAnchor = null, resizeTicket = 0;
  const savedFontSizes = new Map();
  function uniformFont(enabled) {
    if (!enabled) {
      for (const [node, old] of savedFontSizes) {
        if (old.value) node.style.setProperty('font-size', old.value, old.priority);
        else node.style.removeProperty('font-size');
        if (!node.getAttribute('style')) node.removeAttribute('style');
      }
      savedFontSizes.clear();
      return;
    }
    // Prose shares the selected body size. Keep formula graphics, ruby and
    // sub/superscripts intact; do not rewrite the source book or the DOM text.
    for (const node of document.body.querySelectorAll('*')) {
      if (node.closest('svg,math,sub,sup,rt,rp') ||
          ['STYLE','SCRIPT','BR','HR','IMG','COL','WBR'].includes(node.tagName)) continue;
      if (!savedFontSizes.has(node)) savedFontSizes.set(node, {
        value:node.style.getPropertyValue('font-size'),
        priority:node.style.getPropertyPriority('font-size')});
      node.style.setProperty('font-size','1rem','important');
    }
  }
  const maxY = () => Math.max(0,document.documentElement.scrollHeight-innerHeight);
  function snapshot() {
    let node = null;
    // Read the content column, not a fixed sidebar. Prefer a visible text landmark.
    for (const x of [innerWidth*.3, innerWidth*.6, 32]) {
      const hit = document.elementFromPoint(x,32);
      const candidate = hit && hit.closest('[data-mr-id]');
      if (candidate && candidate.getBoundingClientRect().height > 0) { node = candidate; break; }
    }
    const m=maxY();
    return {id:node?node.dataset.mrId:'',offset:node?node.getBoundingClientRect().top:0,
            ratio:m?scrollY/m:0,top:scrollY<=1,bottom:m>0&&scrollY>=m-1,x:scrollX,y:scrollY};
  }
  function restore(s) {
    if (!s) return;
    let y = clamp(s.ratio,0,1)*maxY();
    const id=String(s.id||'');
    let node = /^\d+$/.test(id)?document.querySelector('[data-mr-id="'+id+'"]'):null;
    if(node && !node.getClientRects().length)node=node.closest('[data-mr-pair]');
    if (s.top) y=0;
    else if (s.bottom) y=maxY();
    else if(node && node.getClientRects().length) y=scrollY+node.getBoundingClientRect().top-(Number(s.offset)||0);
    scrollTo({left:Math.max(0,Number(s.x)||0),top:clamp(y,0,maxY()),behavior:'instant'});
    lastAnchor=snapshot();
  }
  function settings(s, keep=true) {
    const anchor=keep?snapshot():null, token=revision;
    const mode=['publisher','parallel','stack','en','zh'].includes(s.mode)?s.mode:'publisher';
    document.documentElement.dataset.mrLayout=mode;
    const english=clamp(s.english_percent,30,70), gap=clamp(s.gutter,8,64)/2;
    const background=/^#[0-9a-f]{6}$/i.test(s.background)?s.background:'#f7f2e8';
    const foreground=/^#[0-9a-f]{6}$/i.test(s.foreground)?s.foreground:'#202020';
    const border=/^#[0-9a-f]{6}$/i.test(s.border)?s.border:'#aaaaaa';
    const accent=/^#[0-9a-f]{6}$/i.test(s.accent)?s.accent:'#236897';
    // CSS table cells keep spans valid inside paragraph/headings, while an actual
    // CSS grid here would change nested table min-content geometry unnecessarily.
    const root='html[data-mr-layout="'+mode+'"]';
    let css=`html {font-size:${clamp(s.fontSize,12,36)}pt !important;scroll-behavior:auto!important;}
      body {font-size:1rem!important;box-sizing:border-box;}
      img {max-width:100%;height:auto;}
      html,body {animation:none!important;}
      * {scroll-behavior:auto!important;}
      [data-mr-pair] > [data-mr-lang] {overflow-wrap:anywhere;}
    `;
    if (s.content_width>0) css+=`body {width:auto!important;max-width:${clamp(s.content_width,640,2400)}px!important;margin-left:auto!important;margin-right:auto!important;}`;
    else css+='body {max-width:none!important;}';
    if (s.use_theme) css+=`html,body {background:${background}!important;color:${foreground}!important;}
      body :not(svg):not(svg *) {color:inherit;}
      body p, body div, body section, body article, body span, body td, body th, body li,
      body h1,body h2,body h3,body h4,body h5,body h6 {color:${foreground}!important;background-color:transparent!important;}
      body a,body a * {color:${accent}!important;}
      body [data-mr-lang="zh"] {border-color:${border}!important;}
    `;
    if (mode==='parallel'||mode==='stack'||mode==='en'||mode==='zh') {
      css+=`${root} [data-mr-pair] {display:table!important;width:100%!important;table-layout:fixed!important;border-collapse:separate!important;border-spacing:0!important;text-indent:0!important;}
       ${root} [data-mr-pair] > [data-mr-lang] {display:table-cell!important;vertical-align:top!important;box-sizing:border-box!important;white-space:normal!important;text-indent:0!important;margin:0!important;}
       ${root} [data-mr-pair] > [data-mr-lang="en"] {width:${english}%!important;padding-left:0!important;padding-right:${gap}px!important;}
       ${root} [data-mr-pair] > [data-mr-lang="zh"] {width:${100-english}%!important;padding-left:${gap}px!important;padding-right:0!important;border-left:1px solid ${border}!important;}
       ${root} [data-mr-pair] > [data-mr-lang]::before {content:none!important;}
      `;
      if(mode!=='parallel') css+=`${root} [data-mr-pair],${root} [data-mr-pair] > [data-mr-lang] {display:block!important;width:auto!important;min-width:0!important;padding-left:0!important;padding-right:0!important;border-left:none!important;}`;
      if(mode==='stack') css+=`${root} [data-mr-pair] > [data-mr-lang="zh"] {margin-top:.65em!important;}`;
      if(mode==='en'||mode==='zh') css+=`${root} [data-mr-pair] > [data-mr-lang="${mode==='en'?'zh':'en'}"] {display:none!important;}`;
    }
    if(s.line_height>0) css+=`body p,body li,body [data-mr-pair] > [data-mr-lang] {line-height:${clamp(s.line_height,1.2,2.8)}!important;}`;
    if (s.uniform_titles) css+='body h1,body h2,body h3,body h4,body h5,body h6 {margin-top:.75em!important;margin-bottom:.6em!important;}';
    if (s.boss_mode) css+='html,body {scrollbar-width:none!important;} ::-webkit-scrollbar{width:0!important;height:0!important;}';
    uniformFont(s.uniform_titles === true);
    let style=document.getElementById('mr-reader-style');
    if (!style) {style=document.createElement('style');style.id='mr-reader-style';document.head.append(style);}
    style.textContent=css;
    if(anchor) requestAnimationFrame(()=>{if(token===revision)restore(anchor);});
    return {pairs:document.querySelectorAll('[data-mr-pair]').length,mode};
  }
  function goTo(fragment, ratio, anchor) {
    const target=fragment&&(document.getElementById(fragment)||document.getElementsByName(fragment)[0]);
    if(target) target.scrollIntoView({block:'start',behavior:'instant'});
    else if(anchor) restore(anchor);
    else scrollTo({top:clamp(ratio,0,1)*maxY(),left:0,behavior:'instant'});
    lastAnchor=snapshot(); return snapshot();
  }
  function selection() {
    const s=getSelection();
    if(!s || !s.rangeCount)return {text:'',context:''};
    const text=s.toString().trim().slice(0,20000);
    let n=s.anchorNode;
    if(n && n.nodeType!==1)n=n.parentElement;
    n=n&&(n.closest('[data-mr-lang]')||n.closest('p,li,td,th,figcaption,blockquote')||n);
    return {text,context:n?(n.innerText||n.textContent||'').slice(0,1000):''};
  }
  function turn(direction) {
    const edge=direction>0?scrollY>=maxY()-2:scrollY<=2;
    if(!edge)scrollBy({top:direction*Math.max(40,innerHeight*.88),behavior:'instant'});
    return edge;
  }
  function interaction(){revision++;}
  for(const name of ['wheel','pointerdown','keydown','touchstart'])addEventListener(name,interaction,{passive:true,capture:true});
  addEventListener('scroll',()=>{lastAnchor=snapshot();},{passive:true});
  addEventListener('resize',()=>{
    const saved=lastAnchor, token=revision;
    cancelAnimationFrame(resizeTicket);
    resizeTicket=requestAnimationFrame(()=>{if(saved&&token===revision)restore(saved);});
  });
  window.__modu={snapshot,restore,settings,goTo,selection,turn,maxY,
    info:()=>({hasContent:!!(document.body && ((document.body.innerText||'').trim() || document.querySelector('img,svg,math'))),pairs:document.querySelectorAll('[data-mr-pair]').length,
      missingImages:[...document.images].filter(x=>x.complete&&!x.naturalWidth).length})};
})();
