@echo off
chcp 65001 >nul
setlocal
call "%~dp0start_windows_compatible.bat" --boss-mode %*
exit /b %ERRORLEVEL%
