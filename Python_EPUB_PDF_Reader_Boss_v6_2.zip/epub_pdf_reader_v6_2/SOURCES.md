# 资料来源与词库说明

整理日期：2026-09-09。

## 内置内容

`data/finance_dictionary.json` 是为本项目自主编写的精选学习词库，不是从某部商业词典复制的数据库。
包含 453 个独立词头（332 个金融词条、121 个基础通用词），以及词形、缩写别名和 30 组原创双语例句。
别名不重复计入词条数。`finance_demo.epub` 的文字和教学数字为本项目编写，不对应真实公司或市场报价。

中文释义为简化阅读解释。各机构、市场、会计准则和合约的正式定义可能不同。
金融、会计或法律判断应回到适用原文；本词库不是专业意见。

音标由本项目自主整理，以常用美式读音为参考，未逐条经过专业语音学校对。
短语为分词读音参考，不提供完整连读、弱读或语调。多个发音变体不保证穷尽。
缩写命中全称时，音标对应全称而非缩写本身；界面会显示匹配关系。

## 金融概念参考资料

以下为概念核对与延伸阅读的一手资料。仅以简短释义自主转述相关通用概念，未将网站正文或其整套词库打包。
并非每一词条的每一细节都已由下列资料逐条审定；尤其不能把本词库视为这些机构发布或认可的词典。

- SEC Investor.gov — Glossary：
  https://www.investor.gov/introduction-investing/investing-basics/glossary
  用于投资、资产配置、证券和基金等概念范围参考。
- SEC Investor.gov — Bonds - FAQs：
  https://www.investor.gov/introduction-investing/investing-basics/investment-products/bonds-or-fixed-income-products/bonds
  用于债券、本金、票息、到期以及信用和利率风险等概念参考。
- European Central Bank — Glossary：
  https://www.ecb.europa.eu/services/glossary/html/glossa.en.html
  用于货币金融、资产、抵押与支付相关概念参考。
- CME Group — Definition of a Futures Contract：
  https://www.cmegroup.com/education/courses/introduction-to-futures/definition-of-a-futures-contract
  用于期货标准化合约概念参考。

## 可选扩展格式

ECDICT 官方仓库与格式文档：
https://github.com/skywind3000/ECDICT

导入器参考其 `word`、`phonetic`、`translation`、`definition` 和 `exchange` 字段说明实现。
本包**没有附带 ECDICT 数据库**，也没有把可选导入能力说成内置几十万词。
本次只用人工编写的受控 CSV 验证字段、词形关系和原子替换，没有实际导入完整 ECDICT 数据。
用户自行取得并导入第三方数据时，应遵守其许可证和相关内容权利要求。

## 技术文档

Qt for Python 官方文档：
https://doc.qt.io/qtforpython-6/index.html

QTextEdit（包括选区和双击事件）：
https://doc.qt.io/qtforpython-6/PySide6/QtWidgets/QTextEdit.html

QTextBrowser：
https://doc.qt.io/qtforpython-6/PySide6/QtWidgets/QTextBrowser.html

PySide6-Essentials 包元数据：
https://pypi.org/pypi/PySide6-Essentials/json

运行时使用第三方依赖 PySide6-Essentials（及其 shiboken6 依赖）、defusedxml 和 pypdfium2。
它们不随本压缩包分发，授权条款以相应发行包附带许可为准。
本包不分发系统字体文件或字体二进制。


## 3.0 图片与阅读定位实现参考

核对日期：2026-09-11。以下官方 API 文档用于实现接口核对，不代表桌面行为已经在本环境验证。

- Qt QTextDocument：`addResource`、`setHtml`、资源缓存与文档布局。
  https://doc.qt.io/qtforpython-6/PySide6/QtGui/QTextDocument.html
- Qt QImageReader：内容识别、读取、缩放与自动方向转换。
  https://doc.qt.io/qtforpython-6/PySide6/QtGui/QImageReader.html
- Qt QSvgRenderer：将经过清理的静态 SVG 绘制到内存 QImage。
  https://doc.qt.io/qtforpython-6/PySide6/QtSvg/QSvgRenderer.html
- Qt QColorDialog：自定义背景颜色选择。
  https://doc.qt.io/qtforpython-6/PySide6/QtWidgets/QColorDialog.html
- Qt QTextCursor：文字位置与字符格式更新。
  https://doc.qt.io/qt-6/qtextcursor.html

本项目的 SVG 清理是主动限制功能，不是 Qt 原生完整安全隔离，也不构成完整安全审计。
检查书 `image_test.epub` 及其图片由本项目程序化生成，不含外部图片或字体文件。


## 4.0 PDF 实现参考

核对日期：2026-09-16。接口来源为项目官方文档/原生头文件；测试环境实际使用 pypdfium2 5.8.0。

- pypdfium2 官方 API：`PdfDocument`、`PdfPage.render`、`PdfTextPage`、目录与权限。
  https://pypdfium2.readthedocs.io/en/stable/python_api.html
- PDFium 官方 `fpdfview.h`：单线程要求、打开错误、权限、`FPDF_PageToDevice` / `FPDF_DeviceToPage`。
  https://pdfium.googlesource.com/pdfium/+/refs/heads/main/public/fpdfview.h
- Qt QImage 与 QPainter：像素格式、图像绘制与组合模式。
  https://doc.qt.io/qtforpython-6/PySide6/QtGui/QImage.html
  https://doc.qt.io/qtforpython-6/PySide6/QtGui/QPainter.html

PDFium 调用保持在 GUI 线程，不在词库导入线程中使用；这避免并发调用，不代表渲染永不阻塞。
源文件以只读方式打开；不执行 PDF 脚本、表单动作和附件，也不加载 PDF 超链接。

pypdfium2 及其 PDFium 二进制由用户通过 pip 安装，不随本项目压缩包分发；各依赖的许可与第三方公告以发行包为准。可选开发依赖 ReportLab、Pillow 用于重建原创示例，也不随包分发。

`pdf_demo.pdf`、`tests/fixtures/password.pdf` 和 `restricted.pdf` 均为本项目生成的测试内容，非外部出版物。测试密码是公开的示例数据，不是用户凭证。PDF 示例采用标准字体引用或栅格化测试图片，项目不分发字体文件。


## 5.0：MDX / MDD 格式与音频（核对日期：2026-09-19）

本版的 MDX / MDD 解析器、RIPEMD-128 实现、SQLite 索引、HTML 安全阅读模式、界面集成及样例生成器是本项目为格式互操作编写的源码，没有将 readmdict / mdict-analysis / mdict-utils 的源码或二进制作为 vendored 模块分发。以下是格式及 API 参考，不是第三方词典内容来源。

- MDX/MDD 2.0 文件结构分析： https://github.com/zhansliu/writemdict/blob/master/fileformat.md 。该资料自身说明是逆向分析，可能存在遗漏，并非官方完整规范。用于核对头部、关键字索引、记录块、文本编码、校验值及资源关联。
- mdict-analysis： https://github.com/liuyug/mdict-analysis 。用于核对 1.x / 2.x 与 3.x 的兼容边界、MDD 资源用途和旧式 LZO 压缩背景；本包未复制其 GPL 源码。
- RIPEMD 家族作者研究资料及公开测试向量： https://homes.esat.kuleuven.be/~bosselae/ripemd160.html 。本项目使用 RIPEMD-128 处理 v2 的校验值派生索引编码，拒绝需要注册 / 设备密码的头部；不提供密码猜测。
- Qt QMediaPlayer： https://doc.qt.io/qtforpython-6/PySide6/QtMultimedia/QMediaPlayer.html 。显式点击后使用 QBuffer / setSourceDevice 播放本地资源，不自动联网或合成语音。
- Qt QTextBrowser： https://doc.qt.io/qtforpython-6/PySide6/QtWidgets/QTextBrowser.html 。本版仍为富文本 HTML 子集，不使用 WebEngine 运行词典脚本。
- Qt for Python 模块分包： https://doc.qt.io/qtforpython-6/package_details.html 。5.0 新增 PySide6-Addons 以提供 QtMultimedia，依赖的实际许可遵循各上游组件；程序不分发 Qt 二进制或字体。

`examples/mdict_demo` 的金融词条文字、PNG 示意图和 WAV 测试提示音均为本次原创示例。词条音标为参考写法，不是经专业词典审定的新词库。没有附带第三方商业 MDX / MDD、真人发音数据或任何字体文件。WAV 仅为 440 Hz 测试音，不是发音。

可选 LZO 使用用户环境已经提供的 python-lzo 或系统 liblzo2；默认安装文件不捆绑这些组件，其许可及安装由实际使用的上游发行物决定。默认 zlib / 未压缩路径不需要它们。


## 5.1 Windows 文件同步修复参考（核对日期：2026-09-20）

- Python 标准库 `os.fsync`：Windows 调用 MS `_commit()`，Python 缓冲文件应先 `flush()` 再 `fsync()`。
  https://docs.python.org/3/library/os.html#os.fsync
- Microsoft Win32 `FlushFileBuffers`：文件句柄须具备 `GENERIC_WRITE` 访问权。
  https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-flushfilebuffers
- Microsoft CRT `_commit`：同步文件及错误返回行为。
  https://learn.microsoft.com/en-us/cpp/c-runtime-library/reference/commit?view=msvc-170

上述资料支持文件同步的访问权要求；不代表已在用户机器定位到具体调用栈。


## 6.0 原书内核与验证工具（2026-09-22 查询）

- Qt QWebEngineUrlSchemeHandler：自定义书包资源与 QIODevice 生命周期。
  https://doc.qt.io/qtforpython-6/PySide6/QtWebEngineCore/QWebEngineUrlSchemeHandler.html
- Qt QWebEngineScript：DocumentReady、ApplicationWorld，与作者脚本隔离。
  https://doc.qt.io/qtforpython-6/PySide6/QtWebEngineCore/QWebEngineScript.html
- Qt QWebEngineSettings：JavascriptEnabled 作用于主世界；独立世界宿主脚本可执行。
  https://doc.qt.io/qt-6/qwebenginesettings.html
- Qt QWebEnginePage：导航、滚动信号、findText 回调及页面生命周期。
  https://doc.qt.io/qtforpython-6/PySide6/QtWebEngineCore/QWebEnginePage.html
- lxml 用于本地 HTML 结构解析，Playwright 仅用于可选的真实 Chromium 测试，不参与运行时查词或联网。

本项目本次自行编写新原书适配层、JS 辅助和测试样例；不复制用户上传书籍内容作为分发示例。第三方库由安装工具取得并遵循各自许可证。QtWebEngine、PDFium 与其他库的许可和随附通知应按各自发行包保留，尤其在另行打包二进制发行时。


## 6.1 内部地址修复的官方依据（2026-09-22 核对）

Qt 6.8 `qurlidna.cpp`：`MaxDomainLabelLength`、`validateAsciiLabel`、`checkAsciiDomainName`。
https://raw.githubusercontent.com/qt/qtbase/6.8/src/corelib/io/qurlidna.cpp

Qt 6.8 `qurl.cpp`：主机 IDNA 校验及 `InvalidRegNameError`。
https://raw.githubusercontent.com/qt/qtbase/6.8/src/corelib/io/qurl.cpp

Qt 富文本 HTML 子集：原生兼容双栏采用真实 table / tr / td 及有界 width/valign，而不是依赖不支持的完整 CSS display 模型。
https://doc.qt.io/qt-6/richtext-html-subset.html

QWebEngineUrlRequestJob::reply：设备的读取与生命周期要求，不能在请求读取完成前销毁或关闭。
https://doc.qt.io/qt-6/qwebengineurlrequestjob.html


## 6.2 · 界面显示与字体覆盖 API

- Qt 官方 QDockWidget 文档（停靠、features、自定义标题栏）：https://doc.qt.io/qtforpython-6/PySide6/QtWidgets/QDockWidget.html
- Qt 官方 QMainWindow 文档（工具栏、菜单、停靠布局）：https://doc.qt.io/qtforpython-6/PySide6/QtWidgets/QMainWindow.html
- Qt 官方 QAction 文档（窗口级快捷键与启用状态）：https://doc.qt.io/qt-6/qaction.html
- Qt 官方 QTextFormat 文档（富文本格式属性）：https://doc.qt.io/qt-6/qtextformat.html

访问日期：2026-09-24。本次新增内容为界面与显示代码，没有引入第三方词库、字体或发音数据。
