"""Small, Qt-free presentation helpers for definition-only and boss views.

These operate on escaped dictionary text or ALREADY SANITIZED reader HTML; they
are not replacements for the EPUB/MDX security filters. Source files stay intact.
"""
from __future__ import annotations

import html
import math
from lxml import html as LH
from dictionary_core import LookupResult, normalize


def point_size(value: object, default: float = 12) -> float:
    try:
        number = float(value)
        return min(36.0, max(8.0, number)) if math.isfinite(number) else default
    except (TypeError, ValueError, OverflowError):
        return default


def entry_index(result: LookupResult | None, value: object = 0) -> int:
    if result is None or not result.entries:
        return 0
    try:
        return min(len(result.entries) - 1, max(0, int(value)))
    except (ValueError, TypeError, OverflowError):
        return 0


def compact_entry_html(result: LookupResult, finance_first: bool = True,
                       night: bool = False, font_pt: float = 12, index: int = 0) -> str:
    """One selected entry, all its senses/examples, no management or source chrome."""
    size = point_size(font_pt)
    foreground = '#e3e9f0' if night else '#283838'
    esc = lambda s: html.escape(str(s), quote=True).replace('\n', '<br/>')
    parts = [f'<html><body style="color:{foreground};font-size:{size:g}pt;">']
    if not result.entries:
        parts += [f'<p><b>{esc(result.query)}</b></p>', '<p>本地词库未收录此词。</p>']
    else:
        entry = result.entries[entry_index(result, index)]
        phonetic = entry.phonetic.strip().strip('/[]')
        label = f'<b>{esc(entry.word)}</b>'
        if phonetic:
            label += ' &nbsp; /' + esc(phonetic) + '/'
        parts.append('<p>' + label + '</p>')
        if normalize(result.query) != normalize(entry.word):
            # An abbreviation/inflection must not silently mislabel the phonetic.
            parts.append(f'<p>{esc(result.query)} → {esc(entry.word)}</p>')
        if '词形推测' in result.match_note:
            parts.append('<p>词形推测，请结合语境。</p>')
        senses = [entry.finance, entry.translation]
        if not finance_first:
            senses.reverse()
        seen = set()
        for text in [*senses, entry.definition]:
            if text and text.strip() not in seen:
                parts.append('<p>' + esc(text) + '</p>')
                seen.add(text.strip())
        for english, chinese in entry.examples:
            parts.append('<p>' + esc(english) + '<br/>' + esc(chinese) + '</p>')
    parts.append('</body></html>')
    return ''.join(parts)


def uniform_markup(markup: str, font_pt: float) -> str:
    """Give native rich-text prose one absolute size, including nested headings.

    Keep text, links, tables, anchors, images and all non-size styles. Math/SVG,
    ruby annotations and sub/superscripts are intentionally not flattened.
    Never write this view back to the original EPUB/MDX or the cached source HTML.
    """
    size = point_size(font_pt)
    parser = LH.HTMLParser(no_network=True, recover=True, remove_comments=False)
    root = LH.document_fromstring(markup, parser=parser)
    excluded = {'head', 'style', 'script', 'svg', 'math', 'sub', 'sup', 'rt', 'rp'}
    void = {'img', 'hr', 'br', 'meta', 'link', 'col', 'wbr'}
    body = root.find('body')
    if body is None:
        return markup
    for node in body.iter():
        if not isinstance(node.tag, str):
            continue
        tag = node.tag.lower()
        if tag in excluded | void or any(str(a.tag).lower() in excluded for a in node.iterancestors()):
            continue
        # Last declaration wins in Qt's supported inline CSS subset, even when
        # the dictionary used <font size> or a heading with a large nested span.
        original = node.get('style', '').rstrip('; \t\r\n')
        node.set('style', (original + ';' if original else '') + f'font-size:{size:g}pt;font-size:{size:g}pt !important;')
        if tag == 'font':
            node.attrib.pop('size', None)
    return LH.tostring(root, encoding='unicode', method='html')
