#!/bin/sh
# Windowed, dictionary-only chrome; compatible EPUB avoids a browser startup.
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 1
exec sh "$DIR/start_macos_linux_compatible.sh" --boss-mode "$@"
