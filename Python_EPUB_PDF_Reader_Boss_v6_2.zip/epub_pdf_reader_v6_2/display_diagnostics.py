"""Small, best-effort local display log. No book text or image payloads recorded."""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import os
import sys
import threading
import traceback

VERSION = '6.2'
MAX_BYTES = 512 * 1024
_LOCK = threading.Lock()


def write_display_log(data_dir: Path, phase: str, message: str, *, error: Exception | None = None) -> str:
    """Return the log path or a visible failure message, never masking the error."""
    try:
        path = Path(data_dir).expanduser().resolve() / 'logs' / 'reader_display.log'
        details = ''.join(traceback.format_exception(type(error), error, error.__traceback__)) if error else ''
        entry = (f'\n[{datetime.now(timezone.utc).isoformat()}] MoDu {VERSION} '
                 f'Python {sys.version.split()[0]} / {sys.platform}\n'
                 f'Stage: {str(phase)[:200]}\n{str(message)[:8000]}\n{details[-24000:]}')
        with _LOCK:
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists() and path.stat().st_size + len(entry.encode('utf-8')) > MAX_BYTES:
                os.replace(path, path.with_name(path.name + '.1'))
            with path.open('a', encoding='utf-8') as stream:
                stream.write(entry)
        return str(path)
    except Exception as exc:
        return f'日志未能保存：{type(exc).__name__}: {exc}'
