"""Windowed boss mode: document + current definition, with reversible UI state.

No fullscreen/frameless flag is used. EPUB typography is a view-only override;
PDF remains a fixed-layout document. Esc/F9 and the definition context menu are
available even while menus and toolbars are hidden.
"""
from __future__ import annotations

from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QKeySequence
from PySide6.QtWidgets import (
    QAbstractScrollArea, QDockWidget, QInputDialog, QMenu, QToolBar,
)
from quiet_content import uniform_markup


class QuietReaderMixin:
    def __init__(self, state):
        self.boss_active = False
        self._boss_snapshot = None
        self._boss_hidden = []
        self._equal_titles = state.data['preferences'].get('uniform_titles', False) is True
        super().__init__(state)

    @property
    def uniform_titles(self) -> bool:
        return self.boss_active or self._equal_titles

    def _build_ui(self):
        super()._build_ui()
        toolbar = self.findChild(QToolBar, 'readerToolbar')
        self.boss_action = self._action('老板模式', self.set_boss_mode, 'F9', checkable=True)
        self.boss_action.setToolTip('保留窗口边框，内部只显示书本和释义；EPUB 标题同正文大小。F9 / Esc 退出。')
        self._boss_exit_action = self._action('退出老板模式', lambda: self.set_boss_mode(False), 'Esc')
        self._boss_exit_action.setEnabled(False)
        self.equal_titles_action = self._action('EPUB 标题与正文同字号', self.set_equal_titles, checkable=True)
        self.equal_titles_action.setChecked(self._equal_titles)
        self.equal_titles_action.setToolTip('仅调整显示；标准标题及普通文字同字号，公式/上标/图片保留。不改写 PDF。')
        menu = self.menuBar().addMenu('界面')
        dock = self.dictionary_dock
        before = toolbar.actions()[1] if len(toolbar.actions()) > 1 else None
        if dock is not None:
            dock.compact_action.setShortcut(QKeySequence('F8'))
            self.addAction(dock.compact_action)
            toolbar.insertAction(before, dock.compact_action)
            menu.addAction(dock.compact_action)
            menu.addAction(self._action('临时查词…', dock.prompt_query, 'Ctrl+Shift+E'))
        toolbar.insertAction(before, self.boss_action)
        menu.addAction(self.boss_action)
        menu.addAction(self.equal_titles_action)
        menu.addSeparator()
        menu.addAction(self._boss_exit_action)

    def _chrome_widgets(self):
        widgets = [self.menuBar(), self.statusBar(), self.sidebar, self.reading_header,
                   self.findChild(QToolBar, 'readerToolbar'), self.layout_toolbar, self.pdf_toolbar]
        if hasattr(self, '_display_banner'):
            widgets.append(self._display_banner)
        return widgets

    def _scroll_areas(self):
        # WebEngine uses the host-owned CSS override instead of Qt scrollbars.
        areas = [self.browser, self.pdf_view]
        if self.dictionary_dock is not None:
            areas += [self.dictionary_dock.result_view, self.dictionary_dock.mdict_panel.browser]
        return [area for area in areas if isinstance(area, QAbstractScrollArea)]

    def set_boss_mode(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if enabled == self.boss_active:
            return
        if enabled and self._focus_states is not None:
            # Boss mode is deliberately windowed; the old F11 mode is separate.
            self.exit_focus()
        target = self._appearance_view() if self.book is not None and not self._using_publication() else None
        dock = self.dictionary_dock
        if enabled:
            controls = [(widget, not widget.isHidden()) for widget in self._chrome_widgets()]
            actions = [self.sidebar_action]
            if dock is not None:
                actions.append(dock.toggleViewAction())
            actions += [a for a in self.actions() if a.shortcut() == QKeySequence('F11')]
            state = {
                'controls': controls,
                'actions': [(action, action.isEnabled()) for action in actions],
                'window_state': self.windowState(),
                'splitter': list(self.splitter.sizes()),
                'format': (self.book is not None, self.pdf_book is not None),
                'scrolls': [(area, area.horizontalScrollBarPolicy(), area.verticalScrollBarPolicy())
                            for area in self._scroll_areas()],
            }
            if dock is not None:
                state['dock'] = (not dock.isHidden(), dock.isFloating(), dock.geometry(),
                                 self.dockWidgetArea(dock), dock.features(), dock.width())
            self._boss_snapshot = state
            self.boss_active = True
            if self.isFullScreen():
                self.showNormal()
            self._boss_hidden = [widget for widget, _ in controls]
            for widget, _ in controls:
                widget.installEventFilter(self)
                widget.hide()
            for action, _ in state['actions']:
                action.setEnabled(False)
            for area, _, _ in state['scrolls']:
                area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
                area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            if dock is not None:
                dock._normal_dock_visibility = state['dock'][0]
                if dock.isFloating():
                    dock.setFloating(False)
                if self.dockWidgetArea(dock) == Qt.DockWidgetArea.NoDockWidgetArea:
                    self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
                dock.setFeatures(QDockWidget.DockWidgetFeature.NoDockWidgetFeatures)
                dock.set_boss_compact(True, self.font_size)
                dock.show()
            self._boss_exit_action.setEnabled(True)
        else:
            state = self._boss_snapshot
            self.boss_active = False
            self._boss_snapshot = None
            self._boss_exit_action.setEnabled(False)
            for widget, visible in state['controls']:
                widget.removeEventFilter(self)
                widget.setVisible(visible)
            self._boss_hidden = []
            for action, enabled_before in state['actions']:
                action.setEnabled(enabled_before)
            for area, horizontal, vertical in state['scrolls']:
                area.setHorizontalScrollBarPolicy(horizontal)
                area.setVerticalScrollBarPolicy(vertical)
            if dock is not None and 'dock' in state:
                visible, floating, geometry, area, features, width = state['dock']
                dock.set_boss_compact(False, self.font_size)
                dock.setFeatures(features)
                if area != Qt.DockWidgetArea.NoDockWidgetArea:
                    self.addDockWidget(area, dock)
                dock.setFloating(floating)
                if floating:
                    dock.setGeometry(geometry)
                else:
                    self.resizeDocks([dock], [max(310, width)], Qt.Orientation.Horizontal)
                dock.setVisible(visible)
                dock._normal_dock_visibility = None
            self.splitter.setSizes(state['splitter'])
            if state['format'] != (self.book is not None, self.pdf_book is not None):
                self.layout_toolbar.setVisible(self.book is not None)
                self.pdf_toolbar.setVisible(self.pdf_book is not None)
            # Reflect a diagnostic that happened while chrome was hidden.
            self._display_banner.setVisible(bool(self._display_label.text()) and self.book is not None)
            if state['window_state'] & Qt.WindowState.WindowFullScreen:
                self.setWindowState(state['window_state'])
        self.boss_action.setChecked(self.boss_active)
        self.equal_titles_action.setEnabled(not self.boss_active)
        self._refresh_typography(target)
        self._focus_document()
        self._save_timer.start()

    def eventFilter(self, obj, event):
        # No polling timer: suppress later toolbar/banner Show events in boss mode
        # (for example after opening a PDF or an asynchronous EPUB recovery).
        if self.boss_active and event.type() == QEvent.Type.Show and obj in self._boss_hidden:
            obj.hide()
            return True
        return super().eventFilter(obj, event)

    def _focus_document(self):
        if hasattr(self, 'document_stack'):
            self.document_stack.currentWidget().setFocus(Qt.FocusReason.OtherFocusReason)

    def set_equal_titles(self, enabled: bool) -> None:
        if self.boss_active:
            return
        self._equal_titles = bool(enabled)
        self.equal_titles_action.setChecked(self._equal_titles)
        self._refresh_typography()
        self._save_timer.start()

    def _prepare_reading_html(self, markup: str) -> str:
        return uniform_markup(markup, self.font_size) if self.uniform_titles else markup

    def _payload(self):
        payload = super()._payload()
        payload['uniform_titles'] = self.uniform_titles
        payload['boss_mode'] = self.boss_active
        return payload

    def document_css(self):
        css = super().document_css()
        if self.uniform_titles:
            css += f'\nh1,h2,h3,h4,h5,h6 {{ font-size:{self.font_size}pt; margin-top:10px; margin-bottom:10px; }}'
        return css

    def _refresh_typography(self, target=None):
        if self.pdf_book is not None:
            return  # Never rescale individual PDF headings or rewrite the PDF.
        if self._using_publication():
            self.publication_view.apply_settings(self._payload())
        elif self.book is not None and self.current_path:
            view, ratio, fragment = target or self._appearance_view()
            self.render(ratio, fragment, view=view)
        elif hasattr(self, 'browser'):
            self.show_welcome()

    def change_font(self, delta):
        result = super().change_font(delta)
        if self.boss_active and self.dictionary_dock is not None:
            self.dictionary_dock.set_boss_compact(True, self.font_size)
        return result

    def toggle_focus(self):
        if self.boss_active:
            return
        return super().toggle_focus()

    def toggle_sidebar(self, checked):
        if self.boss_active:
            return
        return super().toggle_sidebar(checked)

    def focus_search(self):
        if not self.boss_active:
            return super().focus_search()
        if self.book is None and self.pdf_book is None:
            return
        text, accepted = QInputDialog.getText(self, '搜索当前章 / 页', '查找文字：', text=self.search_edit.text())
        if accepted and text.strip():
            self.search_edit.setText(text)
            self.find_text(False)
        self._focus_document()

    def _focus_pdf_page(self):
        if not self.boss_active:
            return super()._focus_pdf_page()
        if self.pdf_book is not None:
            page, accepted = QInputDialog.getInt(self, '跳转 PDF 页', '物理页码：',
                                                self.pdf_page_spin.value(), 1, self.pdf_page_spin.maximum())
            if accepted:
                self._goto_pdf(page - 1)
            self._focus_document()

    def lookup_selection(self):
        if self.dictionary_dock is None:
            return
        if self._using_publication():
            selection = self.publication_view.selectedText()
        elif self.pdf_book is not None:
            selection = self.pdf_view.selected_text()
        else:
            selection = self.browser.textCursor().selectedText()
        from dictionary_core import valid_query
        if valid_query(selection) or not self.dictionary_dock.compact_active:
            return super().lookup_selection()
        self.dictionary_dock.prompt_query()
        self._focus_document()

    def createPopupMenu(self):
        if not self.boss_active:
            return super().createPopupMenu()
        menu = QMenu(self)
        menu.addAction('退出老板模式  F9 / Esc', lambda: self.set_boss_mode(False))
        if self.dictionary_dock is not None:
            menu.addAction('临时查词…', self.dictionary_dock.prompt_query)
        return menu

    def _extend_saved_state(self):
        super()._extend_saved_state()
        self.store.data['preferences']['uniform_titles'] = self._equal_titles
        # boss_active is intentionally NOT persisted: next normal launch always
        # has visible controls. --boss-mode is the explicit startup opt-in.
