"""Definition-only presentation for the existing dictionary browsers.

Hide chrome in place: no second dictionary engine, no duplicated resource loader,
no replacement of the MDX browser (so links, pictures and audio keep working).
"""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import QInputDialog, QWidget
from quiet_content import compact_entry_html, entry_index, point_size


class CompactDictionaryMixin:
    @property
    def compact_active(self) -> bool:
        return getattr(self, '_compact_preference', False) or getattr(self, '_boss_compact', False)

    @property
    def compact_font_size(self) -> float:
        return point_size(getattr(self, '_boss_font_size', 12)) if getattr(self, '_boss_compact', False) else 12.0

    def _init_compact(self, preferences: dict) -> None:
        self._compact_preference = False
        self._boss_compact = False
        self._compact_applied = False
        self._compact_entry_index = 0
        self._normal_compact_state = None
        self._normal_dock_visibility = None
        self._blank_title_bar = QWidget(self)
        self._blank_title_bar.setFixedHeight(0)
        self.compact_action = QAction('简洁查词', self)
        self.compact_action.setCheckable(True)
        self.compact_action.setToolTip('只显示当前词的音标、释义与例句；右键切换词典或恢复完整面板。F8 切换。')
        self.compact_action.toggled.connect(self.set_compact)
        self.tabs.currentChanged.connect(self._compact_tab_changed)
        for browser in (self.result_view, self.mdict_panel.browser):
            browser.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            browser.customContextMenuRequested.connect(
                lambda point, view=browser: self._dictionary_context_menu(view, point))
        self.compact_action.setChecked(preferences.get('dictionary_compact', False) is True)

    def selected_entry(self):
        result = self.current_result
        if result is None or not result.entries:
            return None
        index = entry_index(result, getattr(self, '_compact_entry_index', 0)) if self.compact_active else 0
        return result.entries[index]

    def set_compact(self, enabled: bool) -> None:
        self._compact_preference = bool(enabled)
        self.compact_action.blockSignals(True)
        self.compact_action.setChecked(self._compact_preference)
        self.compact_action.blockSignals(False)
        self._apply_compact_view()
        parent = self.parentWidget()
        if parent is not None and hasattr(parent, '_save_timer'):
            parent._save_timer.start()

    def set_boss_compact(self, enabled: bool, font_size: float = 18) -> None:
        self._boss_compact = bool(enabled)
        self._boss_font_size = point_size(font_size, 18)
        self.compact_action.setEnabled(not enabled)
        self._apply_compact_view()

    def _compact_chrome(self):
        mdx = self.mdict_panel
        return [self.query_edit, self.query_button, self.finance_check, self.auto_check,
                self.save_button, self.copy_button, self.message, self.stats,
                self.import_button, self.about_button, self.mdx_button, self.tabs.tabBar(),
                mdx.dictionaries, mdx.manage_button, mdx.import_button, mdx.attach_button,
                mdx.entries, mdx.save_button, mdx.copy_button, mdx.stop_button, mdx.hint]

    def _apply_compact_view(self) -> None:
        enabled = self.compact_active
        bars = [(b.verticalScrollBar(), b.verticalScrollBar().value())
                for b in (self.result_view, self.mdict_panel.browser)]
        if enabled and not self._compact_applied:
            controls = [(widget, not widget.isHidden()) for widget in self._compact_chrome()]
            # Walk only permanent layout objects, not widget descendants. An
            # import progress dialog is a temporary child of the MDX panel and
            # may be destroyed before the user exits compact mode.
            layouts = []
            def remember_layout(layout):
                layouts.append((layout, layout.contentsMargins(), layout.spacing()))
                for index in range(layout.count()):
                    child = layout.itemAt(index).layout()
                    if child is not None:
                        remember_layout(child)
            for layout in (self.widget().layout(), self.tabs.widget(0).layout(),
                           self.mdict_panel.layout()):
                remember_layout(layout)
            self._normal_compact_state = (controls, layouts, self.titleBarWidget())
            for widget, _ in controls:
                widget.hide()
            for layout, _, _ in layouts:
                layout.setContentsMargins(0, 0, 0, 0)
                layout.setSpacing(0)
            self.setTitleBarWidget(self._blank_title_bar)
            self._compact_applied = True
            self._compact_tab_changed(self.tabs.currentIndex())
        elif not enabled and self._compact_applied:
            controls, layouts, title_bar = self._normal_compact_state
            self._compact_applied = False
            self._normal_compact_state = None
            self.setTitleBarWidget(title_bar)
            for widget, visible in controls:
                widget.setVisible(visible)
            for layout, margin, spacing in layouts:
                layout.setContentsMargins(margin)
                layout.setSpacing(spacing)
        self.render_current()
        self.mdict_panel.show_current()
        if self.current_result is None and enabled:
            self.result_view.setPlainText('双击或划选英文，即可查看释义。')
        elif self.current_result is None:
            self.welcome()
        for bar, value in bars:
            bar.setValue(min(value, bar.maximum()))

    def _compact_tab_changed(self, index: int) -> None:
        if self.compact_active and index == 1:
            # The wordbook is a management page, not the current lookup result.
            self.tabs.setCurrentIndex(2 if self.mdict_panel.current_article else 0)

    def compact_html(self) -> str:
        return compact_entry_html(self.current_result, self.finance_check.isChecked(),
                                  self.night, self.compact_font_size,
                                  getattr(self, '_compact_entry_index', 0))

    def prompt_query(self) -> None:
        text, accepted = QInputDialog.getText(self, '临时查词', '单词或短语：',
                                              text=self.query_edit.text())
        if accepted and text.strip():
            self.show()
            self.lookup(text, context='', book='')

    def _choose_compact_result(self, mdx: bool, index: int) -> None:
        if mdx:
            self.tabs.setCurrentWidget(self.mdict_panel)
            self.mdict_panel.entries.setCurrentIndex(index)
            self.mdict_panel.show_current()
        else:
            self._compact_entry_index = index
            self.tabs.setCurrentIndex(0)
            self.render_current()

    def _dictionary_context_menu(self, browser, point) -> None:
        menu = browser.createStandardContextMenu()
        menu.addSeparator()
        menu.addAction('临时查词…  Ctrl+Shift+E', self.prompt_query)
        choices = menu.addMenu('选择词典 / 当前词的其他结果')
        if self.current_result:
            for index, entry in enumerate(self.current_result.entries):
                action = choices.addAction(f'英汉 / CSV · {entry.word} · {entry.source[:45]}')
                action.setCheckable(True)
                action.setChecked(self.tabs.currentIndex() == 0 and index == getattr(self, '_compact_entry_index', 0))
                action.triggered.connect(lambda _=False, i=index: self._choose_compact_result(False, i))
        for index, article in enumerate(self.mdict_panel.articles):
            action = choices.addAction(f'{article.title[:60]} · {article.word}')
            action.setCheckable(True)
            action.setChecked(self.tabs.currentIndex() == 2 and self.mdict_panel.entries.currentIndex() == index)
            action.triggered.connect(lambda _=False, i=index: self._choose_compact_result(True, i))
        choices.setEnabled(bool(choices.actions()))
        mdx = self.tabs.currentWidget() is self.mdict_panel
        target = self.mdict_panel if mdx else self
        has_entry = bool(self.mdict_panel.current_article if mdx else self.selected_entry())
        action = menu.addAction('加入生词本', target.save_current)
        action.setEnabled(has_entry and not self.busy and not self.vocabulary.read_only)
        menu.addAction('复制当前释义', target.copy_current).setEnabled(has_entry)
        if mdx:
            menu.addAction('停止音频', self.mdict_panel.stop_audio)
        source = (self.mdict_panel.current_article.as_entry() if has_entry else None) if mdx else self.selected_entry()
        if source:
            def show_source():
                from PySide6.QtWidgets import QMessageBox
                QMessageBox.information(self, '当前词条来源', source.source or '源词库未提供来源。')
            menu.addAction('查看词条来源…', show_source)
        menu.addSeparator()
        menu.addAction(self.compact_action)
        window = self.parentWidget()
        if window is not None and getattr(window, 'boss_active', False):
            menu.addAction('退出老板模式  F9 / Esc', lambda: window.set_boss_mode(False))
        menu.exec(browser.mapToGlobal(point))
        menu.deleteLater()
