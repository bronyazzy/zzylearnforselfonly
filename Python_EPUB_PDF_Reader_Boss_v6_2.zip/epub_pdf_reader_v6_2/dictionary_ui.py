"""Dockable dictionary and wordbook UI. Network-free; CSV import uses a worker thread."""
from __future__ import annotations

from pathlib import Path
import sqlite3

from PySide6.QtCore import QByteArray, QThread, Qt, Signal, Slot
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QDockWidget, QFileDialog, QHBoxLayout, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QProgressDialog,
    QPushButton, QTabWidget, QTextBrowser, QVBoxLayout, QWidget,
)

from mdict_ui import MdictPanel
from compact_dictionary import CompactDictionaryMixin
from import_diagnostics import report_import_failure

from dictionary_core import (
    DictionaryEngine, DictionaryError, Entry, LookupResult, VocabularyStore,
    import_csv, normalize, result_html, ImportCancelled,
)


class LocalTextBrowser(QTextBrowser):
    """Dictionary content never loads file-system or network resources."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setOpenLinks(False)
        self.setOpenExternalLinks(False)
        self.setReadOnly(True)
        self.document().setDocumentMargin(16)

    def loadResource(self, resource_type, name):
        return QByteArray()


class CsvImportThread(QThread):
    processed = Signal(int)
    completed = Signal(int, str)

    def __init__(self, source: Path, destination: Path, parent=None):
        super().__init__(parent)
        self.source = source
        self.destination = destination

    def run(self):
        try:
            count = import_csv(self.source, self.destination, self.processed.emit, self.isInterruptionRequested)
            self.completed.emit(count, "")
        except ImportCancelled as exc:
            self.completed.emit(0, str(exc))
        except Exception as exc:
            self.completed.emit(0, report_import_failure(
                exc, self.destination.parent, self.source, 'CSV 转换与索引保存'))


class DictionaryDock(CompactDictionaryMixin, QDockWidget):
    def __init__(self, data_directory: Path, preferences: dict, parent=None):
        super().__init__("英汉词典 · 金融", parent)
        self.setObjectName("financialDictionaryDock")
        self.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)
        self.setMinimumWidth(310)
        self.data_directory = Path(data_directory)
        self.engine = DictionaryEngine(self.data_directory / "dictionary_extra.sqlite")
        self.vocabulary = VocabularyStore(self.data_directory / "vocabulary.json")
        self.current_result: LookupResult | None = None
        self.context = ""
        self.book_title = ""
        self.night = False
        self._thread: CsvImportThread | None = None
        self._progress: QProgressDialog | None = None
        self._build_ui(preferences)
        self.refresh_vocabulary()
        self.update_stats()
        self.welcome()
        self._init_compact(preferences)
        warnings = "\n".join(x for x in (self.engine.warning, self.vocabulary.warning) if x)
        if warnings:
            self.message.setText(warnings)

    @property
    def busy(self) -> bool:
        return ((self._thread is not None and self._thread.isRunning())
                or (hasattr(self, "mdict_panel") and self.mdict_panel.busy))

    def preferences(self) -> dict:
        return {"dictionary_visible": (not self.isHidden() if self._normal_dock_visibility is None else self._normal_dock_visibility),
                "dictionary_compact": self._compact_preference,
                "dictionary_finance_first": self.finance_check.isChecked(),
                "dictionary_auto": self.auto_check.isChecked()}

    def _build_ui(self, preferences: dict):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(12, 8, 12, 10)
        row = QHBoxLayout()
        self.query_edit = QLineEdit()
        self.query_edit.setPlaceholderText("输入英文单词、金融短语或缩写…")
        self.query_edit.setClearButtonEnabled(True)
        self.query_edit.setMaxLength(160)
        self.query_edit.returnPressed.connect(self.query_from_edit)
        row.addWidget(self.query_edit, 1)
        self.query_button = QPushButton("查询")
        self.query_button.clicked.connect(self.query_from_edit)
        row.addWidget(self.query_button)
        layout.addLayout(row)
        checks = QHBoxLayout()
        self.finance_check = QCheckBox("金融释义优先")
        self.finance_check.setChecked(preferences.get("dictionary_finance_first", True) is True)
        self.finance_check.toggled.connect(self.refresh_result)
        checks.addWidget(self.finance_check)
        self.auto_check = QCheckBox("划词即查")
        self.auto_check.setChecked(preferences.get("dictionary_auto", True) is True)
        self.auto_check.setToolTip("鼠标选中英文并松开后查词；关闭后仍可双击、右键或 Ctrl+E 查询。")
        checks.addWidget(self.auto_check)
        layout.addLayout(checks)
        self.tabs = QTabWidget()
        lookup_page = QWidget()
        lookup_layout = QVBoxLayout(lookup_page)
        lookup_layout.setContentsMargins(0, 4, 0, 0)
        self.result_view = LocalTextBrowser()
        self.result_view.setObjectName("dictionaryResults")
        self.result_view.anchorClicked.connect(self.follow_lookup_link)
        lookup_layout.addWidget(self.result_view, 1)
        action_row = QHBoxLayout()
        self.save_button = QPushButton("加入生词本")
        self.save_button.setToolTip("保存首条结果的音标、释义和最近一次划词所在段落。")
        self.save_button.clicked.connect(self.save_current)
        self.save_button.setEnabled(False)
        self.copy_button = QPushButton("复制释义")
        self.copy_button.clicked.connect(self.copy_current)
        self.copy_button.setEnabled(False)
        action_row.addWidget(self.save_button)
        action_row.addWidget(self.copy_button)
        lookup_layout.addLayout(action_row)
        self.tabs.addTab(lookup_page, "查词")
        vocabulary_page = QWidget()
        vocabulary_layout = QVBoxLayout(vocabulary_page)
        vocabulary_layout.setContentsMargins(0, 4, 0, 0)
        self.vocab_filter = QLineEdit()
        self.vocab_filter.setPlaceholderText("筛选生词或中文释义…")
        self.vocab_filter.textChanged.connect(self.filter_vocabulary)
        vocabulary_layout.addWidget(self.vocab_filter)
        self.vocab_list = QListWidget()
        self.vocab_list.currentItemChanged.connect(self.preview_vocabulary)
        self.vocab_list.itemActivated.connect(self.lookup_saved)
        vocabulary_layout.addWidget(self.vocab_list, 2)
        self.vocab_preview = LocalTextBrowser()
        self.vocab_preview.setMinimumHeight(100)
        vocabulary_layout.addWidget(self.vocab_preview, 2)
        buttons = QHBoxLayout()
        self.remove_button = QPushButton("删除所选")
        self.remove_button.clicked.connect(self.delete_selected)
        self.export_button = QPushButton("导出 CSV")
        self.export_button.clicked.connect(self.export_vocabulary)
        buttons.addWidget(self.remove_button)
        buttons.addWidget(self.export_button)
        vocabulary_layout.addLayout(buttons)
        self.tabs.addTab(vocabulary_page, "生词本")
        self.mdict_panel = MdictPanel(self)
        self.mdict_panel.lookupRequested.connect(self.lookup)
        self.mdict_panel.libraryChanged.connect(self.update_stats)
        self.tabs.addTab(self.mdict_panel, "MDX 词典")
        layout.addWidget(self.tabs, 1)
        self.message = QLabel("双击单词 · 划选短语 · Ctrl+E 查词")
        self.message.setTextFormat(Qt.TextFormat.PlainText)
        self.message.setWordWrap(True)
        self.message.setObjectName("dictionaryHint")
        layout.addWidget(self.message)
        self.stats = QLabel()
        self.stats.setWordWrap(True)
        self.stats.setObjectName("dictionaryHint")
        layout.addWidget(self.stats)
        tools = QHBoxLayout()
        self.import_button = QPushButton("导入词库 CSV")
        self.import_button.clicked.connect(self.choose_import)
        tools.addWidget(self.import_button)
        about_button = self.about_button = QPushButton("词库说明")
        about_button.clicked.connect(self.show_about)
        tools.addWidget(about_button)
        mdx_button = self.mdx_button = QPushButton("MDX / MDD")
        mdx_button.clicked.connect(lambda: self.tabs.setCurrentWidget(self.mdict_panel))
        tools.addWidget(mdx_button)
        layout.addLayout(tools)
        self.setWidget(container)

    def update_stats(self):
        if not hasattr(self, "stats"):
            return
        total, finance = len(self.engine.entries), self.engine.finance_count
        self.stats.setText(f"离线词库：内置 {total:,} 条（金融 {finance:,} 条）\n扩展 {self.engine.extra_count:,} 条 · MDX {len(self.mdict_panel.library.items)} 部 · 生词 {len(self.vocabulary.items):,} 条")

    def welcome(self):
        self.result_view.setHtml("""<h2>边读，边理解。</h2>
            <p>双击正文中的英文单词，或划选金融短语，即可查看音标与中文释义。</p>
            <p>也可直接在上方输入：<b>leverage</b>、<b>duration</b>、<b>cash flow</b>、<b>ETF</b>。</p>
            <p>内置为精选金融学习词库，不是完整通用大词典。全部内置内容均可离线查询。</p>
            <p>短语请选中完整词组；缩写匹配后会显示其全称和全称的读音。</p>
            <p>Ctrl+E 查询所选文字<br/>Ctrl+J 显示或隐藏词典</p>""")

    def query_from_edit(self):
        # Manual input must not inherit an unrelated book excerpt.
        self.lookup(self.query_edit.text(), context="", book="")

    def lookup(self, text: str, context: str = "", book: str = ""):
        if self.busy:
            self.message.setText("正在导入词库；完成或取消后可以继续查词。")
            if self.compact_active:
                self.tabs.setCurrentIndex(0)
                self.result_view.setPlainText("正在导入词库；完成或取消后可以继续查词。")
            return
        self.context, self.book_title = context, book
        self._compact_entry_index = 0
        self.query_edit.setText(text.strip()[:160])
        try:
            preferred_mdx = self.tabs.currentWidget() is self.mdict_panel
            self.current_result = self.engine.lookup(text, self.finance_check.isChecked())
            self.render_current()
            mdx_count = self.mdict_panel.lookup(text, context, book)
            self.tabs.setTabText(2, f"MDX ({mdx_count})" if mdx_count else "MDX 词典")
            if (preferred_mdx and (mdx_count or not self.compact_active)) or (mdx_count and not self.current_result.entries):
                self.tabs.setCurrentWidget(self.mdict_panel)
            else:
                self.tabs.setCurrentIndex(0)
            self.message.setText("结果与音标均来自本地词库；未向任何网站发送正文。")
        except (DictionaryError, sqlite3.Error, OSError) as exc:
            self.current_result = None
            self.save_button.setEnabled(False)
            self.copy_button.setEnabled(False)
            self.result_view.setPlainText(f"查词失败：{exc}")

    def render_current(self):
        if self.current_result is not None:
            markup = self.compact_html() if self.compact_active else result_html(
                self.current_result, self.finance_check.isChecked(), self.night)
            self.result_view.setHtml(markup)
        has_entry = bool(self.current_result and self.current_result.entries)
        self.save_button.setEnabled(has_entry and not self.vocabulary.read_only and not self.busy)
        self.copy_button.setEnabled(has_entry)

    def refresh_result(self, _checked=False):
        if self.current_result is not None:
            self.lookup(self.current_result.query, self.context, self.book_title)

    def set_night(self, night: bool):
        self.night = night
        self.mdict_panel.set_night(night)
        self.render_current()
        self.preview_vocabulary(self.vocab_list.currentItem())

    def follow_lookup_link(self, url):
        if url.scheme() == "lookup":
            # QUrl.path is already decoded; never percent-decode it a second time.
            self.lookup(url.path().lstrip("/"))

    def save_current(self):
        if not self.current_result or not self.current_result.entries:
            return
        try:
            added = self.vocabulary.add(self.selected_entry(), self.context, self.book_title)
            self.refresh_vocabulary()
            self.update_stats()
            self.message.setText("已加入生词本。" if added else "该词已存在，已更新释义和上下文。")
        except (DictionaryError, OSError, ValueError) as exc:
            QMessageBox.warning(self, "生词未能保存", str(exc))

    def copy_current(self):
        if not self.current_result or not self.current_result.entries:
            return
        entry = self.selected_entry()
        text = f"{entry.word} /{entry.phonetic}/\n{entry.finance}\n{entry.translation}".strip()
        QApplication.clipboard().setText(text)
        self.message.setText("首条词条及释义已复制。")

    def refresh_vocabulary(self):
        self.vocab_list.clear()
        for key, record in reversed(list(self.vocabulary.items.items())):
            meaning = record.get("finance") or record.get("translation") or ""
            item = QListWidgetItem(f"{record['word']}  ·  {meaning[:45]}")
            item.setData(Qt.ItemDataRole.UserRole, key)
            item.setToolTip(meaning)
            self.vocab_list.addItem(item)
        self.tabs.setTabText(1, f"生词本 ({len(self.vocabulary.items)})")
        self.filter_vocabulary(self.vocab_filter.text())

    def filter_vocabulary(self, text: str):
        needle = text.strip().casefold()
        for index in range(self.vocab_list.count()):
            item = self.vocab_list.item(index)
            record = self.vocabulary.items.get(item.data(Qt.ItemDataRole.UserRole), {})
            full_text = " ".join(str(record.get(k, "")) for k in ("word", "finance", "translation"))
            item.setHidden(needle not in full_text.casefold())

    def _saved_entry(self, item) -> Entry | None:
        if item is None:
            return None
        record = self.vocabulary.items.get(item.data(Qt.ItemDataRole.UserRole))
        if not record:
            return None
        return Entry(word=record["word"], phonetic=record.get("phonetic", ""),
                     finance=record.get("finance", ""), translation=record.get("translation", ""),
                     source=record.get("source", ""), category="生词本快照")

    def preview_vocabulary(self, item, _previous=None):
        entry = self._saved_entry(item)
        if entry is None:
            self.vocab_preview.setPlainText("选择一个生词查看释义；双击可重新查询。")
            return
        record = self.vocabulary.items[item.data(Qt.ItemDataRole.UserRole)]
        result = LookupResult(entry.word, [entry], "已保存的词条")
        rendered = result_html(result, True, self.night)
        # Source text is plain text escaped by result_html, never executable HTML.
        if record.get("context"):
            import html
            extra = "<h3>阅读上下文</h3><p>" + html.escape(record["context"]) + "</p>"
            extra += "<p>书籍：" + html.escape(record.get("book", "")) + "</p>"
            rendered = rendered.replace("</body>", extra + "</body>")
        self.vocab_preview.setHtml(rendered)

    def lookup_saved(self, item):
        entry = self._saved_entry(item)
        if entry:
            self.lookup(entry.word)

    def delete_selected(self):
        item = self.vocab_list.currentItem()
        entry = self._saved_entry(item)
        if entry is None:
            return
        answer = QMessageBox.question(self, "删除生词", f"从生词本删除“{entry.word}”？",
                                      QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                      QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self.vocabulary.delete(entry.word)
            self.refresh_vocabulary()
            self.update_stats()
            self.message.setText("生词已删除。")
        except (DictionaryError, OSError) as exc:
            QMessageBox.warning(self, "删除失败", str(exc))

    def export_vocabulary(self):
        filename, _ = QFileDialog.getSaveFileName(self, "导出生词本", str(Path.home() / "finance_vocabulary.csv"), "CSV 文件 (*.csv)")
        if not filename:
            return
        try:
            count = self.vocabulary.export_csv(Path(filename))
            self.message.setText(f"已导出全部 {count} 个生词，包含音标、中文释义、上下文和书名。")
        except (OSError, DictionaryError) as exc:
            QMessageBox.warning(self, "导出失败", str(exc))

    def choose_import(self):
        if self.busy:
            return
        filename, _ = QFileDialog.getOpenFileName(self, "导入 ECDICT / 自定义词库 CSV", str(Path.home()), "CSV 文件 (*.csv)")
        if not filename:
            return
        if self.engine.extra_count:
            answer = QMessageBox.question(self, "替换扩展词库", "这会替换之前导入的扩展词库。内置金融词库和生词本不受影响。继续吗？",
                                          QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                          QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                return
        self.start_import(Path(filename))

    def start_import(self, filename: Path):
        if self.busy:
            return
        self.engine.close_extra()  # Necessary for atomic replacement on Windows.
        self.query_edit.setEnabled(False)
        self.query_button.setEnabled(False)
        self.import_button.setEnabled(False)
        self.save_button.setEnabled(False)
        self.finance_check.setEnabled(False)
        self._progress = QProgressDialog("正在建立离线索引…", "取消", 0, 0, self)
        self._progress.setWindowTitle("导入词库")
        self._progress.setWindowModality(Qt.WindowModality.NonModal)
        self._progress.setMinimumDuration(0)
        self._progress.setAutoClose(False)
        self._thread = CsvImportThread(filename, self.data_directory / "dictionary_extra.sqlite", self)
        self._thread.processed.connect(self.import_progress)
        self._thread.completed.connect(self.import_completed)
        self._thread.finished.connect(self.import_thread_finished)
        self._progress.canceled.connect(self.cancel_import)
        self._progress.show()
        self._thread.start()

    def cancel_import(self):
        self.mdict_panel.cancel_import()
        if self._thread is not None:
            self._thread.requestInterruption()
        self.message.setText("已请求取消导入；原扩展词库不会被未完成的导入覆盖。")

    @Slot(int)
    def import_progress(self, count: int):
        if self._progress is not None:
            self._progress.setLabelText(f"已处理 {count:,} 行；正在建立离线查询索引…")

    @Slot(int, str)
    def import_completed(self, count: int, error: str):
        if self._progress is not None:
            self._progress.close()
            self._progress.deleteLater()
            self._progress = None
        self.engine.reopen_extra()
        self.update_stats()
        self.query_edit.setEnabled(True)
        self.query_button.setEnabled(True)
        self.import_button.setEnabled(True)
        self.finance_check.setEnabled(True)
        if error:
            self.message.setText(error)
            if not error.startswith("已取消"):
                QMessageBox.warning(self, "导入未完成", error)
        else:
            self.message.setText(f"已导入 {count:,} 条扩展词条。内置金融释义保留。")

    @Slot()
    def import_thread_finished(self):
        thread = self._thread
        self._thread = None
        if thread is not None:
            thread.deleteLater()
        # Use the newly opened database and enable save after the worker is finished.
        if self.current_result:
            context, book, query = self.context, self.book_title, self.current_result.query
            self.lookup(query, context, book)
        else:
            self.render_current()

    def show_about(self):
        QMessageBox.information(self, "离线词库与隐私", (
            f"内置 {len(self.engine.entries)} 条精选词条，其中 {self.engine.finance_count} 条有金融释义。\n\n"
            "内置音标为自主整理的常用美式参考读音，短语音标按分词读音给出，并非出版社审定音标。"
            "缩写命中全称时显示全称读音。未收录词不会自动联网翻译。\n\n"
            "扩展支持 UTF-8 CSV（含 ECDICT）：word、translation 为必需列；可选 phonetic、finance、definition、exchange。"
            "另外支持 MDX 词典与 MDD 资源包；可在 MDX 页导入及管理多部词典。\n"
            "扩展词库不包含在本包内，须使用你有权使用的数据。\n\n"
            "查词与生词本仅在本机处理，不上传书籍。生词本上下文为所选词所在段落的前 1000 字符。\n\n"
            f"数据目录：{self.data_directory}\n参考资料见项目 SOURCES.md。"
        ))

    def shutdown(self):
        if not self.busy:
            self.engine.close()
            self.mdict_panel.shutdown()
