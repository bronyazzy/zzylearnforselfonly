# 实际测试记录 · 墨读 6.2 · 简洁查词与老板模式

日期：2026-09-24。此前 6.1 报告保存为 `TEST_REPORT_V6_1_HISTORY.md`，不是本轮结果。

## 环境与结果

Linux，Python 3.13.5，SQLite 3.46.1。defusedxml、lxml、pypdfium2、Playwright 可用。
当前执行环境依然没有 PySide6；对默认包源与公开 PyPI 的安装尝试均未取得发行包，见 `diagnostics/QT_INSTALL_V6_2.txt`。
没有在 Windows/macOS 实机运行，也没有启动 PySide6/Qt6 主窗口。不能把 Python 控制替身或浏览器排版当作原生 Qt 测试。

实际执行：

```bash
python -m unittest discover -s tests -v
```

```text
Ran 567 tests
OK (skipped=129)
```

**438 项实际通过，129 项原生 Qt GUI 测试跳过；0 项失败，0 项错误。不是 567 项全部通过。** 原始逐项输出保存在 `TEST_OUTPUT.txt`。

| 组别 | 数量 | 实际验证方式 |
| --- | ---: | --- |
| 6.1 已有非 Qt 测试（含 16 项 Chromium） | 400 | 重新运行，不沿用历史通过数 |
| `test_quiet_content.py` | 19 | 真实词库、HTML 解析、纯内容输出与原文件摘要 |
| `test_quiet_browser.py` | 8 | 真实 Chromium 执行生产 JS / HTML |
| `test_quiet_control.py` | 11 | 从生产类加载实际控制方法，窗口 / 控件使用替身 |
| 6.1 已有 Qt GUI 测试 | 108 | 缺少 PySide6，跳过 |
| `test_quiet_gui.py` | 21 | 缺少 PySide6，跳过；脚本已随包提供 |

438 个通过项中包含 **24 项实际 Chromium 测试**。浏览器使用生产 HTML/CSS/JS，通过项目已有 harness 将受限本地资源内联到测试页面；不验证 Qt 的自定义 URL 投递、窗口布局或 Windows 显卡。

## 本次新功能已执行的验证

**简洁释义内容：** 一次只生成选中的一个词条；保留该词的所有不同义项、已有音标和例句；金融义 / 普通义顺序切换；消除完全重复的义项；缺词不显示无关候选词；缩写全称和词形推测标记；词库文字 HTML 转义；索引和字号输入边界；原 453 条内置词库仍可使用。

**标题同字号：** 兼容 HTML 的文字、双栏宽度、链接、锚点和图片 URL 保持不变；不处理公式、SVG、上标、下标及注音的字号。真实 Chromium 验证了嵌套大标题、作者 inline `!important`、字号更新、重复开关、精确恢复原 inline 字号与优先级、DOM 不重建、附近阅读标记恢复、滚动条 CSS 开关。

**模式控制：** 实际 `set_boss_mode` 方法的窗口 / 控件替身验证了进入与退出、重复调用不覆盖快照、词典浮动状态 / features 恢复、用户原简洁偏好和可见性保留、滚动条策略恢复、工具栏的迟到 Show 事件拦截、切换到 PDF 后恢复对应工具栏、只保存独立字号偏好而不固化老板模式、原生阅读位置传入刷新逻辑。**这些替身不调用 Qt，不证明实际像素布局或键盘事件。**

代码复核另外限制了简洁模式仅记录永久布局对象，不把可销毁的 MDX 导入进度对话框布局保存在恢复快照中，避免导入完成后恢复已删除的 Qt 布局对象。

## 对此前上传的左右对照书的检查

本次再次读取用户此前上传的 EPUB。源文件 SHA-256：

`53907d30624348142876a61fedfef7d1bd068f8b61a28a61bc5c06de936b2303`

- 全部 **27 个 spine 阅读项**分别生成兼容 HTML 和统一字号 HTML，解析后的文字内容、图片 URL、两列宽度属性相同。共有 **3,134 个明确配对单元**，包括前后资料；这不是自然段或新增翻译计数。
- 浏览器抽查 **第 1、2、16 章**，分别 1440px / 600px，共 **6 个章节 / 宽度组合**。统一字号后检查到的 h1–h6 计算字号均为 24px（所选 18pt）；左右对齐错误与缺失图片均为零，正文文字一致，关闭覆盖后标题字号恢复。
- 原 EPUB 检查前后字节摘要一致。没有修改、重译或把用户书籍打包分发。

输出在 `diagnostics/QUIET_BOOK_CHECK_V6_2.json`。上述浏览器检查并非全书 16 章的本轮穷尽检查，也不是 Qt 桌面截图或 EPUBCheck 认证。

## 代码、回归与完整包

全部 **58 个 Python 文件**通过语法编译及 Python 3.10 语法级 AST 检查；不等同于在 Python 3.10 解释器运行。生产 JS 通过 `node --check`；三个 macOS/Linux 脚本通过 `sh -n`。Windows `.bat` 没有实机执行。

本版没有新增运行依赖，没有修改原词典数据、书签数据格式、PDF 阅读后端或 MDX/MDD 二进制解析。原 EPUB/PDF/MDX/CSV 测试实际重新运行。日志版本标识更新为 6.2，对应的两个版本断言也已更新；历史日志不重新标记为本轮运行。

最终压缩包进行 ZIP CRC 检查，重新解压后用 `verify_package.py` 按 `MANIFEST.json` 逐文件检查 SHA-256，并在独立解压副本重跑全部测试。清单用于发现损坏，不是数字签名。分发包不包含 `.venv`、Python 缓存、用户书籍、个人阅读记录、商业词典或字体文件。

## 尚未实机验证

21 项新增 GUI 测试计划覆盖 F8/F9/Esc、释义区域实际高度、标题的 QTextCharFormat 字号、布局显隐、MDX 图片控件、PDF/EPUB 切换、迟到提示、浮动词典、隐藏状态持久化以及多次开关。这些在本环境均跳过，不能声称按钮、键盘、窗口排版或语音播放已经实测成功。

实际 Windows/macOS 桌面、高 DPI、不同 Qt 版本、WebEngine 子进程与大型商业词库仍需在目标环境检查。PDF 内的标题不能独立改字号；图像、SVG、公式等保留其原生显示限制。老板模式不提供全局热键或任何系统级隐私保证。

## 本机复查

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python verify_package.py
python epub_reader.py --compatible-epub parallel_demo.epub
```

打开后查询 `equity`，按 F8 检查只有释义，右键选择词典结果并加入生词。按 F9 检查窗口边框仍在，内部只见书本与释义，标题同字号；按 Esc 恢复。再测试原书模式、PDF、切换章节、关闭重开，以及 `start_windows_boss.bat` 的兼容入口。不要为排查界面而删除旧词库或阅读记录。
