#!/usr/bin/env python3
"""Validate local EPUB delivery URLs and fallback output without starting WebEngine.

When PySide6 is installed this calls the real QUrl parser. No book text is
written in the report. Exit 2 means checks failed; Qt absence is reported, not
counted as a native pass. This is not a substitute for GUI operation tests.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit
from epub_core import EpubBook
from compatible_layout import compatible_chapter
from publisher_core import PublisherResources

def check(path: Path) -> dict:
    try:
        from PySide6.QtCore import QUrl, qVersion
    except (ImportError,OSError):
        QUrl=None;qVersion=None
    rows=[]
    with EpubBook(path) as book:
        r=PublisherResources(book)
        old='epub://'+book.book_id+'/example.xhtml'
        report={'version':'6.2','python':sys.version.split()[0],
                'qt':qVersion() if qVersion else 'unavailable: native QUrl check skipped',
                'legacy_qurl_valid':QUrl(old).isValid() if QUrl else None,
                'book_id':book.book_id,'new_host':book.url_host,'chapters':rows}
        for chapter in book.chapters:
            url=book.url(chapter.path);host=urlsplit(url).hostname
            try:
                assert host.encode('idna').decode()==host
                if QUrl:
                    qturl=QUrl(url)
                    assert qturl.isValid() and qturl.host()==host,qturl.errorString()
                mime,data=r.serve(url)
                assert mime=='text/html' and data
                native=compatible_chapter(book,chapter.path)
                assert native.html.strip()
                rows.append({'path':chapter.path,'ok':True,'original_html_bytes':len(data),
                             'compatible_html_chars':len(native.html),'explicit_pairs':native.pairs})
            except Exception as exc:
                rows.append({'path':chapter.path,'ok':False,'error':f'{type(exc).__name__}: {exc}'})
        report['ok']=all(row['ok'] for row in rows)
        return report

def main() -> int:
    p=argparse.ArgumentParser(description='EPUB 本地地址与兼容双栏检查（不启动浏览器）')
    p.add_argument('book',type=Path,nargs='?',default=Path(__file__).parent/'parallel_demo.epub')
    p.add_argument('--output',type=Path,help='可选 JSON 日志路径；不包含书籍正文')
    args=p.parse_args()
    try:report=check(args.book)
    except Exception as exc:report={'ok':False,'error':f'{type(exc).__name__}: {exc}'}
    text=json.dumps(report,ensure_ascii=False,indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text+'\n',encoding='utf-8')
    print(text)
    return 0 if report['ok'] else 2

if __name__=='__main__':raise SystemExit(main())
