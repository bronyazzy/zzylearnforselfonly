"""6.1 core and real-method control regressions; control widgets are test doubles.

IDNA tests use Python's codec, not QUrl. Native QUrl tests are separate and
explicitly skipped when Qt is absent. No browser/desktop result is inferred.
"""
from __future__ import annotations
import ast
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
from urllib.parse import urlsplit
from lxml import html as LH
from epub_core import EpubBook, EpubError, StateStore
from publisher_core import LayoutSettings, PublisherResources
from compatible_layout import compatible_chapter
from display_diagnostics import write_display_log
from image_support import ImageColumnContext, image_column_width
from make_demo import sample_files, write_epub

ROOT=Path(__file__).resolve().parents[1]

class EpubUrlTests(unittest.TestCase):
    def setUp(self):
        self.book=EpubBook(ROOT/'parallel_demo.epub');self.addCleanup(self.book.close)
    def test_old_single_label_is_invalid_idna(self):
        self.assertEqual(len(self.book.book_id),64)
        with self.assertRaises(UnicodeError):self.book.book_id.encode('idna')
    def test_new_labels_accepted_idna(self):
        host=self.book.url_host
        self.assertTrue(all(0<len(s)<=63 for s in host.split('.')))
        self.assertEqual(host.encode('idna').decode(),host)
    def test_entire_identity_retained_not_truncated(self):
        labels=self.book.url_host.split('.')
        self.assertEqual(labels[0][1:]+labels[1][1:],self.book.book_id)
    def test_document_url_roundtrip_unicode_percent(self):
        for path in ['OPS/first.xhtml','OPS/中文 空格%20.xhtml']:
            url=self.book.url(path,'注释 1')
            self.assertEqual(urlsplit(url).hostname,self.book.url_host)
            self.assertEqual(self.book.resolve('OPS/first.xhtml',url),(path,'注释 1'))
    def test_source_id_and_state_are_stable(self):
        with EpubBook(ROOT/'parallel_demo.epub') as b:
            self.assertEqual(b.book_id,self.book.book_id)
        with tempfile.TemporaryDirectory() as d:
            s=StateStore(Path(d)/'state.json');s.data['books'][self.book.book_id]={'marker':'keep'};s.save()
            self.assertEqual(StateStore(s.filename).data['books'][self.book.book_id]['marker'],'keep')
    def test_legacy_same_book_links_resolve(self):
        self.assertEqual(self.book.resolve('OPS/first.xhtml',f'epub://{self.book.book_id}/OPS/second.xhtml#note'),('OPS/second.xhtml','note'))
    def test_foreign_book_legacy_host_rejected(self):
        with self.assertRaises(EpubError):self.book.resolve('OPS/first.xhtml','epub://'+'f'*64+'/OPS/a.xhtml')
    def test_resources_accept_only_new_origin(self):
        r=PublisherResources(self.book)
        self.assertTrue(r.accepts(self.book.url('OPS/first.xhtml')))
        self.assertFalse(r.accepts(f'epub://{self.book.book_id}/OPS/first.xhtml'))
        self.assertFalse(r.accepts(f'epub://{self.book.url_host}.evil/OPS/first.xhtml'))
        mime,data=r.serve(self.book.url('OPS/first.xhtml'))
        self.assertEqual(mime,'text/html');self.assertIn(b'Parallel reading',data)
    def test_embedded_image_host_is_valid(self):
        url=self.book.register_image(b'original image bytes')
        self.assertEqual(urlsplit(url).hostname,self.book.url_host)
        self.assertEqual(urlsplit(url).hostname.encode('idna').decode(),self.book.url_host)
        self.assertEqual(self.book.embedded_images[url],b'original image bytes')

class CompatibleLayoutTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.file=Path(self.temp.name)/'book.epub'
    def view(self,body,percent=50):
        files=sample_files();files['OPS/Text/chapter3.xhtml']=body
        write_epub(self.file,files)
        with EpubBook(self.file) as b:
            c=compatible_chapter(b,'OPS/Text/chapter3.xhtml',percent)
        return c,LH.fromstring(c.html)
    def test_explicit_pairs_become_real_cells(self):
        c,d=self.view('<p><span class="parallel-row"><span class="bi-en">English</span><span class="bi-zh">中文</span></span></p>',43)
        self.assertEqual(c.pairs,1);self.assertEqual(d.xpath('//td/@width'),['43%','57%'])
        self.assertEqual(d.xpath('//td/@valign'),['top','top']);self.assertEqual(d.xpath('//td/span/text()'),[])
        self.assertFalse(d.xpath('//p//table|//span//table'))
        self.assertIn('English',d.text_content());self.assertIn('中文',d.text_content())
    def test_lang_only_pairs_supported(self):
        c,d=self.view('<div><p lang="en">A</p><p lang="zh-CN">甲</p></div>')
        self.assertEqual(c.pairs,1);self.assertEqual(len(d.xpath('//table')),1)
    def test_reversed_marked_languages_reordered(self):
        c,d=self.view('<div><span lang="zh">中文</span><span lang="en">English</span></div>')
        self.assertEqual([x.text_content() for x in d.xpath('//td')],['English','中文'])
    def test_unmarked_text_not_guessed_or_removed(self):
        c,d=self.view('<div><p>English</p><p>中文</p></div><p>Shared 100</p>')
        self.assertEqual(c.pairs,0);self.assertEqual(len(d.xpath('//table')),0)
        self.assertEqual(''.join(d.text_content().split()),'English中文Shared100')
    def test_mixed_interstitial_text_preserved_not_forced_pair(self):
        c,d=self.view('<div>prefix <span lang="en">English</span> / <span lang="zh">中文</span> suffix</div>')
        self.assertEqual(c.pairs,0);self.assertIn('prefix',d.text_content());self.assertIn('suffix',d.text_content())
    def test_heading_semantics_preserved_in_cells(self):
        c,d=self.view('<h2><span class="parallel-row"><span class="bi-en">Title</span><span class="bi-zh">标题</span></span></h2>')
        self.assertEqual(len(d.xpath('//td/h2')),2);self.assertFalse(d.xpath('//h2//table'))
    def test_pair_links_and_anchors_remain(self):
        c,d=self.view('<a id="heading" href="chapter2.xhtml#half"><span lang="en">Go</span><span lang="zh">跳转</span></a>')
        self.assertEqual(len(d.xpath('//td//a[@href]')),2)
        self.assertTrue(all('chapter2.xhtml#half' in u for u in d.xpath('//td//a/@href')))
        self.assertIn('heading',d.xpath('//a/@name'))
    def test_malicious_elements_and_remote_images_stripped(self):
        c,d=self.view('<script>alert(1)</script><img src="file:///secret"/><p onclick="bad()">Safe</p><iframe src="https://example.com"/>')
        self.assertFalse(d.xpath('//script|//iframe|//*[@onclick]|//img[@src]'));self.assertIn('Safe',d.text_content())
    def test_image_references_survive(self):
        c,d=self.view('<p>Shared</p><img src="../Images/banner.png"/>')
        self.assertEqual(len(d.xpath('//img')),1);self.assertIn('banner.png',d.xpath('//img/@src')[0])
    def test_percent_bounds_and_invalid_inputs(self):
        source='<div><span lang="en">A</span><span lang="zh">甲</span></div>'
        for value,expected in [(999,'70%'),(-1,'30%'),(None,'50%'),(float('nan'),'50%')]:
            c,d=self.view(source,value);self.assertEqual(d.xpath('//td/@width')[0],expected)
    def test_empty_page_has_explanation_not_blank(self):
        c,d=self.view('<html><body> </body></html>')
        self.assertIn('本章没有可显示',d.text_content());self.assertEqual(c.pairs,0)
    def test_table_attributes_bounded(self):
        c,d=self.view('<table width="999999%" cellpadding="999" border="0"><tr><td width="45%" valign="top">A</td></tr></table>')
        self.assertFalse(d.xpath('//table/@width|//table/@cellpadding'))
        self.assertEqual(d.xpath('//td/@width'),['45%']);self.assertEqual(d.xpath('//table/@border'),['0'])
    def test_example_pairs_and_source_bytes_unchanged(self):
        path=ROOT/'parallel_demo.epub';digest=hashlib.sha256(path.read_bytes()).digest()
        with EpubBook(path) as b:
            c=compatible_chapter(b,'OPS/first.xhtml');self.assertEqual(c.pairs,41)
            self.assertEqual(len(LH.fromstring(c.html).xpath('//table')),41)
            for chapter in b.chapters:
                self.assertTrue(LH.fromstring(compatible_chapter(b,chapter.path).html).text_content().strip())
        self.assertEqual(hashlib.sha256(path.read_bytes()).digest(),digest)
    def test_compatible_setting_roundtrip(self):
        s=LayoutSettings(mode='compatible',english_percent=44)
        self.assertEqual(LayoutSettings.from_dict(s.as_dict()),s)

class ColumnAndLogTests(unittest.TestCase):
    def test_full_width_image_keeps_original_available(self):
        c=ImageColumnContext();self.assertEqual(image_column_width(800,*c.current()),800)
    def test_image_fits_inside_half_width_cell(self):
        c=ImageColumnContext();c.start('table',{'width':'100%','cellpadding':'8'});c.start('td',{'width':'50%'})
        self.assertEqual(image_column_width(800,*c.current()),376)
    def test_next_cell_does_not_multiply_previous_width(self):
        c=ImageColumnContext();c.start('table',{});c.start('td',{'width':'40%'});c.end('td');c.start('td',{'width':'60%'})
        self.assertEqual(c.current()[0],.6)
    def test_nested_table_context_restored(self):
        c=ImageColumnContext();c.start('table',{});c.start('td',{'width':'50%'});before=c.current()
        c.start('table',{});c.start('td',{'width':'50%'});self.assertEqual(c.current()[0],.25)
        c.end('table');self.assertEqual(c.current(),before)
        c.end('td');c.end('table');self.assertEqual(c.current(),(1.,0.))
    def test_malformed_percent_is_not_executed(self):
        for s in ['javascript:bad','nan%','inf%','30%;color:red']:
            self.assertEqual(ImageColumnContext.percentage(s),1.)
        self.assertEqual(image_column_width(10,.3,1000),1)
    def test_log_appends_phase_and_not_source_text(self):
        with tempfile.TemporaryDirectory() as d:
            p=write_display_log(Path(d),'load-failure','bad URL')
            write_display_log(Path(d),'fallback','native mode')
            s=Path(p).read_text();self.assertIn('MoDu 6.2',s);self.assertIn('fallback',s);self.assertIn('load-failure',s)
    def test_log_error_does_not_mask_original(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'not_directory';p.write_text('keep')
            self.assertIn('日志未能保存',write_display_log(p,'test','bad'))
            self.assertEqual(p.read_text(),'keep')
    def test_log_rotation(self):
        with tempfile.TemporaryDirectory() as d, patch('display_diagnostics.MAX_BYTES',250):
            p=Path(write_display_log(Path(d),'first','x'*180));write_display_log(Path(d),'second','y'*180)
            self.assertTrue(p.with_name(p.name+'.1').exists());self.assertIn('second',p.read_text())

# Exercise actual production method bodies with a minimal native-superclass
# double. This checks control flow, not Qt event delivery or visual layout.
class NativeBase:
    def current_ratio(self):return .25
    def navigate(self,path,fragment='',ratio=0.,record_history=True,prepared_html=None,view=None):
        self.current_path=path
        self.last_target=(path,fragment,ratio,record_history)
        self._cached_html=prepared_html if prepared_html is not None else self.book.chapter_html(path)
        self._loading=False
        return True


def method_class(filename,name,base=object,environment=None):
    node=next(n for n in ast.parse((ROOT/filename).read_text()).body if isinstance(n,ast.ClassDef) and n.name==name)
    node.bases=[ast.Name(id='Base',ctx=ast.Load())]
    # Signals require Qt at class construction; methods do not.
    node.body=[n for n in node.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),node],type_ignores=[])
    ast.fix_missing_locations(module)
    env={'Base':base,**(environment or {})};exec(compile(module,str(ROOT/filename),'exec'),env)
    return env[name],env

class RecoveryControlTests(unittest.TestCase):
    def setUp(self):
        self.cls,self.env=method_class('publisher_integration.py','PublisherReaderMixin',NativeBase,{
            'replace':replace,'LayoutSettings':LayoutSettings,'PublisherResources':PublisherResources,
            'compatible_chapter':compatible_chapter,'PublicationView':None,'WEBENGINE_ERROR':'test unavailable'})
        self.w=w=self.cls.__new__(self.cls);w.book=EpubBook(ROOT/'parallel_demo.epub');self.addCleanup(w.book.close)
        w.pdf_book=None;w.current_path='OPS/first.xhtml';w._layout_book_id=w.book.book_id
        w.layout_settings=LayoutSettings();w.publication_view=Mock();w._publication_resources=None
        w._force_simple=w._force_compatible=w._recovering=False;w._display_note='';w._loading=True;w._ready_ratio=.37
        w._web_recovery_target=(.37,'pair-20');w._next_web_anchor=None;w._cached_html=''
        w.browser=Mock();w.document_stack=Mock();w.statusBar=Mock(return_value=Mock())
        for name in ['_record_display','_show_display_status','cancel_pending_position','_sync_layout_controls','scrolled','_layout_notice']:
            setattr(w,name,Mock())
    def test_failed_web_load_builds_actual_nonempty_native_content(self):
        w=self.w;w._publication_loaded(False,'load failed')
        self.assertEqual(w.layout_settings.mode,'compatible');self.assertIn('Parallel reading',w._cached_html)
        self.assertEqual(len(LH.fromstring(w._cached_html).xpath('//table')),41)
        w.document_stack.setCurrentWidget.assert_called_with(w.browser)
    def test_failure_preserves_pending_anchor_and_ratio(self):
        w=self.w;w._publication_loaded(False,'timeout')
        self.assertEqual(w.last_target,('OPS/first.xhtml','pair-20',.37,False))
    def test_fallback_stops_old_view_and_exits_loading(self):
        w=self.w;w._activate_compatible('process exited')
        w.publication_view.clear_publication.assert_called_once();self.assertFalse(w._recovering);self.assertFalse(w._loading)
    def test_late_failure_after_switch_to_native_is_ignored(self):
        w=self.w;w.layout_settings=replace(w.layout_settings,mode='compatible');w._activate_compatible=Mock()
        w._publication_loaded(False,'stale cancelled load');w._activate_compatible.assert_not_called()
    def test_pdf_does_not_enter_epub_fallback(self):
        w=self.w;w.pdf_book=object();w._activate_compatible=Mock()
        w._publication_loaded(False,'old epub');w._activate_compatible.assert_not_called()
    def test_success_clears_status_only_not_book(self):
        w=self.w;old=w.book;w._publication_loaded(True,'')
        self.assertIs(w.book,old);self.assertFalse(w._loading);w._show_display_status.assert_called_with('')
    def test_missing_webengine_selects_compatible_without_starting_view(self):
        w=self.w;w.publication_view=None;w.navigate(w.current_path)
        self.assertEqual(w.layout_settings.mode,'compatible');self.assertIn('<table',w._cached_html)
    def test_webengine_constructor_error_is_caught(self):
        w=self.w;w.publication_view=None;self.env['PublicationView']=Mock(side_effect=RuntimeError('DLL error'))
        self.assertFalse(w._ensure_publication());self.assertIn('DLL error',w._display_note)
    def test_prepare_failure_falls_back_before_empty_html_reaches_native(self):
        w=self.w;w._publication_resources=Mock(book=w.book);w._publication_resources.chapter.side_effect=EpubError('CSS parser')
        w.navigate(w.current_path);self.assertEqual(w.layout_settings.mode,'compatible');self.assertIn('<table',w._cached_html)
    def test_parser_failure_is_visible_not_silent(self):
        w=self.w;w.navigate=Mock(side_effect=EpubError('<bad>'))
        w._activate_compatible('test');self.assertFalse(w._recovering)
        text=w.browser.setHtml.call_args.args[0];self.assertIn('&lt;bad&gt;',text);self.assertIn('本章暂时无法显示',text)
    def test_explicit_compatible_mode_does_not_create_engine(self):
        w=self.w;w.publication_view=None;w.layout_settings=LayoutSettings(mode='compatible');w._ensure_publication=Mock()
        w.navigate(w.current_path);w._ensure_publication.assert_not_called();self.assertTrue(w._cached_html)

class LoadWatchdogControlTests(unittest.TestCase):
    def setUp(self):
        cls,_=method_class('publisher_ui.py','PublicationView',environment={'encoded':lambda url:url,'json':json})
        self.v=v=cls.__new__(cls);v._closing=False;v.active_path='OPS/first.xhtml';v._failure_reported=False;v.ready=False
        v._load_watchdog=Mock();v.diagnostic=Mock();v.loaded=Mock();v.page=Mock(return_value=SimpleNamespace(allowed_url='epub://valid/a'))
        v.url=Mock(return_value='epub://valid/a');v._load_error='';v._settings={};v._pending=None;v.request_snapshot=Mock()
    def test_failure_emits_once(self):
        v=self.v;v._fail_load('timeout');v._fail_load('duplicate');v.loaded.emit.assert_called_once_with(False,'timeout')
        v._load_watchdog.stop.assert_called_once()
    def test_cleared_or_closed_view_does_not_fallback(self):
        v=self.v;v.active_path='';v._fail_load('stale');v.active_path='a';v._closing=True;v._fail_load('late');v.loaded.emit.assert_not_called()
    def test_renderer_exit_reports_status(self):
        v=self.v;v._renderer_stopped(SimpleNamespace(name='CrashedTerminationStatus'),9)
        self.assertIn('9',v.loaded.emit.call_args.args[1])
    def test_load_failed_at_about_blank_uses_loading_info(self):
        v=self.v;v.url=Mock(return_value='about:blank')
        info=Mock();info.url.return_value='epub://valid/a';info.status.return_value=SimpleNamespace(name='LoadFailedStatus')
        info.errorCode.return_value=-6;info.errorString.return_value='not found';v._load_info(info)
        self.assertFalse(v.loaded.emit.call_args.args[0])
    def test_unrelated_cancel_does_not_emit_current_failure(self):
        v=self.v;v.url=Mock(return_value='about:blank');v._load_finished(False);v.loaded.emit.assert_not_called()
    def test_missing_helper_falls_back(self):
        v=self.v;v.js=lambda expression,callback:callback(None);v._load_finished(True)
        self.assertFalse(v.loaded.emit.call_args.args[0])
    def test_blank_success_falls_back(self):
        v=self.v;v.js=lambda expression,callback:callback({'hasContent':False});v._load_finished(True)
        self.assertFalse(v.loaded.emit.call_args.args[0])
    def test_cancelled_link_on_good_page_does_not_fallback(self):
        v=self.v;v.ready=True;v._load_finished(False);v.loaded.emit.assert_not_called()
    def test_rejected_navigation_loading_info_keeps_good_page(self):
        v=self.v;v.ready=True;info=Mock();info.url.return_value='epub://valid/a'
        info.status.return_value=SimpleNamespace(name='LoadFailedStatus');v._load_info(info)
        v.loaded.emit.assert_not_called()
    def test_good_page_stops_watchdog_and_is_ready(self):
        v=self.v;v.js=lambda expression,callback:callback({'hasContent':True});v._load_finished(True)
        self.assertTrue(v.ready);v._load_watchdog.stop.assert_called_once();v.loaded.emit.assert_called_once_with(True,'')

if __name__=='__main__':unittest.main()
