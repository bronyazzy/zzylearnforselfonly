"""Execute the real mode controller with small widget doubles, NOT real Qt.

Content/CSS tests use actual parsers and Chromium; GUI tests are kept separate.
These tests cover transitions, state restoration and late-show suppression only.
"""
import ast
from pathlib import Path
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parents[1]


class Widget:
    def __init__(self, visible=True):
        self.visible = visible
        self.enabled = True
        self.checked = False
        self.h = 1
        self.v = 2
        self.filters = []
        self._text = ''

    def isHidden(self): return not self.visible
    def isVisible(self): return self.visible
    def hide(self): self.visible = False
    def show(self): self.visible = True
    def setVisible(self, visible): self.visible = visible
    def setEnabled(self, enabled): self.enabled = enabled
    def isEnabled(self): return self.enabled
    def setChecked(self, checked): self.checked = checked
    def isChecked(self): return self.checked
    def installEventFilter(self, value): self.filters.append(value)
    def removeEventFilter(self, value): self.filters.remove(value)
    def horizontalScrollBarPolicy(self): return self.h
    def verticalScrollBarPolicy(self): return self.v
    def setHorizontalScrollBarPolicy(self, value): self.h = value
    def setVerticalScrollBarPolicy(self, value): self.v = value
    def shortcut(self): return ''
    def text(self): return self._text
    def start(self): pass


class Dock(Widget):
    def __init__(self):
        super().__init__()
        self.floating = False
        self.f = 7
        self.g = (100, 200, 300, 400)
        self.toggle = Widget()
        self.preference = False
        self.forced = False
        self._normal_dock_visibility = None

    def isFloating(self): return self.floating
    def setFloating(self, value): self.floating = value
    def geometry(self): return self.g
    def setGeometry(self, value): self.g = value
    def features(self): return self.f
    def setFeatures(self, value): self.f = value
    def width(self): return 390
    def toggleViewAction(self): return self.toggle
    def set_boss_compact(self, forced, size): self.forced = forced


class Splitter:
    def __init__(self): self.value = [260, 900]
    def sizes(self): return self.value[:]
    def setSizes(self, value): self.value = list(value)


Qt = SimpleNamespace(
    WindowState=SimpleNamespace(WindowFullScreen=4),
    DockWidgetArea=SimpleNamespace(NoDockWidgetArea=0, RightDockWidgetArea=2),
    ScrollBarPolicy=SimpleNamespace(ScrollBarAlwaysOff=0),
    Orientation=SimpleNamespace(Horizontal=1),
)
QEvent = SimpleNamespace(Type=SimpleNamespace(Show=1))
ns = {'Qt': Qt, 'QEvent': QEvent, 'QKeySequence': lambda x:x,
      'QDockWidget': SimpleNamespace(DockWidgetFeature=SimpleNamespace(NoDockWidgetFeatures=0))}
source = ast.parse((ROOT / 'quiet_ui.py').read_text())
node = next(n for n in source.body if isinstance(n, ast.ClassDef) and n.name == 'QuietReaderMixin')
exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])), 'quiet_ui.py', 'exec'), ns)
Controller = ns['QuietReaderMixin']


class Base:
    def eventFilter(self, obj, event): return False
    def _extend_saved_state(self): self.saved_super = True
    def _payload(self): return {'mode':'parallel', 'fontSize':self.font_size}


class Harness(Controller, Base):
    def __init__(self):
        self.boss_active = False
        self._boss_snapshot = None
        self._boss_hidden = []
        self._focus_states = None
        self._equal_titles = False
        self.book = object()
        self.pdf_book = None
        self.current_path = 'OPS/first.xhtml'
        self.font_size = 18
        self.dictionary_dock = Dock()
        self.sidebar_action = Widget()
        self.boss_action = Widget()
        self._boss_exit_action = Widget(False)
        self.equal_titles_action = Widget()
        self._save_timer = Widget()
        self.layout_toolbar = Widget()
        self.pdf_toolbar = Widget(False)
        self._display_banner = Widget(False)
        self._display_label = Widget()
        self.header = Widget()
        self.sidebar = Widget()
        self.status = Widget()
        self.menubar = Widget()
        self.splitter = Splitter()
        self.areas = [Widget(), Widget(), Widget(), Widget()]
        self.mode = 0
        self.show_normal_calls = 0
        self.refresh_calls = []
        self.area = 2
        self.store = SimpleNamespace(data={'preferences':{}})
        self.target = (object(), .3, 'anchor')

    def _chrome_widgets(self):
        return [self.header, self.sidebar, self.status, self.menubar,
                self.layout_toolbar, self.pdf_toolbar, self._display_banner]
    def _scroll_areas(self): return self.areas
    def _appearance_view(self): return self.target
    def _using_publication(self): return False
    def _refresh_typography(self, target=None): self.refresh_calls.append((self.uniform_titles, target))
    def _focus_document(self): pass
    def actions(self): return []
    def windowState(self): return self.mode
    def isFullScreen(self): return bool(self.mode & 4)
    def showNormal(self): self.mode = 0; self.show_normal_calls += 1
    def setWindowState(self, state): self.mode = state
    def dockWidgetArea(self, dock): return self.area
    def addDockWidget(self, area, dock): self.area = area
    def resizeDocks(self, docks, widths, orientation): self.widths = widths


class QuietControlTests(unittest.TestCase):
    def setUp(self): self.window = Harness()

    def test_windowed_enter_hides_chrome_and_keeps_document_dock(self):
        w = self.window
        w.set_boss_mode(True)
        self.assertTrue(all(widget.isHidden() for widget in w._chrome_widgets()))
        self.assertTrue(w.dictionary_dock.visible)
        self.assertTrue(w.dictionary_dock.forced)
        self.assertEqual(w.show_normal_calls, 0)
        self.assertTrue(w.uniform_titles)

    def test_reenter_is_idempotent_and_exit_restores_explicit_states(self):
        w = self.window
        w.sidebar.hide()
        states = [x.visible for x in w._chrome_widgets()]
        w.set_boss_mode(True)
        snapshot = w._boss_snapshot
        w.set_boss_mode(True)
        self.assertIs(w._boss_snapshot, snapshot)
        w.set_boss_mode(False)
        self.assertEqual([x.visible for x in w._chrome_widgets()], states)
        self.assertFalse(w.uniform_titles)
        self.assertFalse(w.dictionary_dock.forced)

    def test_floating_dock_and_features_roundtrip(self):
        w = self.window
        w.dictionary_dock.floating = True
        w.set_boss_mode(True)
        self.assertFalse(w.dictionary_dock.floating)
        self.assertEqual(w.dictionary_dock.f, 0)
        w.set_boss_mode(False)
        self.assertTrue(w.dictionary_dock.floating)
        self.assertEqual(w.dictionary_dock.f, 7)

    def test_user_compact_and_dictionary_visibility_not_overwritten(self):
        w = self.window
        w.dictionary_dock.preference = True
        w.dictionary_dock.hide()
        w.set_boss_mode(True)
        self.assertIs(w.dictionary_dock._normal_dock_visibility, False)
        w.set_boss_mode(False)
        self.assertTrue(w.dictionary_dock.preference)
        self.assertFalse(w.dictionary_dock.visible)
        self.assertIsNone(w.dictionary_dock._normal_dock_visibility)

    def test_late_show_is_suppressed_without_polling_timer(self):
        w = self.window
        w.set_boss_mode(True)
        w.header.show()
        self.assertTrue(w.eventFilter(w.header, SimpleNamespace(type=lambda:1)))
        self.assertFalse(w.header.visible)
        self.assertFalse(w.eventFilter(Widget(), SimpleNamespace(type=lambda:1)))

    def test_scroll_policies_and_disabled_actions_restore(self):
        w = self.window
        before = [(x.h, x.v) for x in w.areas]
        w.set_boss_mode(True)
        self.assertTrue(all((x.h, x.v) == (0, 0) for x in w.areas))
        self.assertFalse(w.sidebar_action.enabled)
        self.assertFalse(w.dictionary_dock.toggle.enabled)
        w.set_boss_mode(False)
        self.assertEqual([(x.h, x.v) for x in w.areas], before)
        self.assertTrue(w.sidebar_action.enabled)

    def test_opening_pdf_while_quiet_restores_correct_toolbar(self):
        w = self.window
        w.set_boss_mode(True)
        w.book = None
        w.pdf_book = object()
        w.set_boss_mode(False)
        self.assertFalse(w.layout_toolbar.visible)
        self.assertTrue(w.pdf_toolbar.visible)

    def test_saved_settings_keep_independent_title_preference(self):
        w = self.window
        w.set_boss_mode(True)
        self.assertTrue(w._payload()['uniform_titles'])
        self.assertTrue(w._payload()['boss_mode'])
        w._extend_saved_state()
        self.assertTrue(w.saved_super)
        self.assertEqual(w.store.data['preferences'], {'uniform_titles':False})

    def test_boss_exit_restores_user_uniform_setting(self):
        w = self.window
        w.set_equal_titles(True)
        w.set_boss_mode(True)
        w.set_boss_mode(False)
        self.assertTrue(w.uniform_titles)
        self.assertTrue(w._equal_titles)

    def test_existing_native_position_passed_to_refresh(self):
        w = self.window
        w.set_boss_mode(True)
        self.assertIs(w.refresh_calls[-1][1], w.target)
        self.assertTrue(w.refresh_calls[-1][0])
        w.set_boss_mode(False)
        self.assertFalse(w.refresh_calls[-1][0])

    def test_exit_disabled_when_mode_off_and_multiple_cycles(self):
        w = self.window
        for _ in range(5):
            w.set_boss_mode(True)
            self.assertTrue(w._boss_exit_action.enabled)
            w.set_boss_mode(False)
            self.assertFalse(w._boss_exit_action.enabled)
        self.assertEqual(w._boss_hidden, [])
        self.assertTrue(all(not x.filters for x in w._chrome_widgets()))


if __name__ == '__main__':
    unittest.main()
