"""Real Qt widgets/key events; explicitly skipped when PySide6 is unavailable."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
try:
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QTextCursor
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication, QToolBar
    from epub_core import StateStore
    from epub_reader import EnhancedReaderWindow
    from mdict_core import build_index
    QT = True
except (ImportError, OSError, SystemExit):
    QT = False

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(QT, '缺少 PySide6；未执行真实老板模式/简洁查词 GUI 测试')
class QuietGuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)
        cls.app.setStyle('Fusion')

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        with patch.dict(os.environ, {'MODU_COMPATIBLE_EPUB':'1'}):
            self.window = EnhancedReaderWindow(StateStore(self.directory / 'state.json'))
        self.window.show()
        self.assertTrue(self.window.open_book(str(ROOT / 'parallel_demo.epub')))
        QTest.qWait(200)
        self.dock = self.window.dictionary_dock
        self.dock.lookup('equity')

    def tearDown(self):
        self.window.close()
        QTest.qWait(50)
        self.temp.cleanup()

    def hidden_chrome(self):
        self.assertTrue(all(not w.isVisible() for w in self.window._chrome_widgets()))
        self.assertTrue(all(not w.isVisible() for w in self.dock._compact_chrome()))
        self.assertTrue(self.dock.isVisible())
        self.assertTrue(self.window.document_stack.isVisible())

    def test_compact_button_hides_controls_and_gives_result_more_height(self):
        height = self.dock.result_view.height()
        self.dock.compact_action.trigger()
        QTest.qWait(100)
        self.assertTrue(self.dock.compact_active)
        self.assertTrue(all(not w.isVisible() for w in self.dock._compact_chrome()))
        self.assertGreater(self.dock.result_view.height(), height + 50)
        self.assertIn('所有者权益', self.dock.result_view.toPlainText())
        self.assertNotIn('来源：', self.dock.result_view.toPlainText())

    def test_f8_toggles_without_hiding_book_toolbar(self):
        self.window.browser.setFocus()
        QTest.keyClick(self.window.browser, Qt.Key.Key_F8)
        self.assertTrue(self.dock.compact_active)
        self.assertTrue(self.window.findChild(QToolBar, 'readerToolbar').isVisible())
        QTest.keyClick(self.window.browser, Qt.Key.Key_F8)
        self.assertFalse(self.dock.compact_active)
        self.assertTrue(self.dock.query_edit.isVisible())

    def test_compact_preference_persists(self):
        self.dock.set_compact(True)
        self.window.save_state()
        self.assertIs(StateStore(self.directory / 'state.json').data['preferences']['dictionary_compact'], True)

    def test_f9_shows_only_book_and_definition_not_fullscreen(self):
        self.window.browser.setFocus()
        flags = self.window.windowFlags()
        QTest.keyClick(self.window.browser, Qt.Key.Key_F9)
        QTest.qWait(100)
        self.hidden_chrome()
        self.assertTrue(self.window.boss_active)
        self.assertFalse(self.window.isFullScreen())
        self.assertEqual(flags, self.window.windowFlags())

    def test_escape_restores_chrome(self):
        self.window.set_boss_mode(True)
        QTest.qWait(80)
        QTest.keyClick(self.window.browser, Qt.Key.Key_Escape)
        QTest.qWait(80)
        self.assertFalse(self.window.boss_active)
        self.assertTrue(self.window.menuBar().isVisible())
        self.assertTrue(self.window.reading_header.isVisible())
        self.assertFalse(self.dock.compact_active)

    def test_prior_compact_preference_survives_boss_roundtrip(self):
        self.dock.set_compact(True)
        self.window.set_boss_mode(True)
        self.window.set_boss_mode(False)
        self.assertTrue(self.dock.compact_active)
        self.assertTrue(self.dock.compact_action.isEnabled())

    def test_previously_hidden_dictionary_and_sidebar_restore(self):
        self.dock.hide()
        self.window.sidebar.hide()
        self.window.set_boss_mode(True)
        self.assertTrue(self.dock.isVisible())
        self.window.set_boss_mode(False)
        self.assertTrue(self.dock.isHidden())
        self.assertTrue(self.window.sidebar.isHidden())

    def test_title_character_size_matches_body_in_native_view(self):
        self.window.set_boss_mode(True)
        QTest.qWait(100)
        doc = self.window.browser.document()
        title = doc.find('Parallel reading check')
        self.assertFalse(title.isNull())
        self.assertAlmostEqual(title.charFormat().fontPointSize(), self.window.font_size, delta=.01)

    def test_font_change_updates_book_and_dictionary_in_boss(self):
        self.window.set_boss_mode(True)
        self.window.change_font(2)
        QTest.qWait(100)
        self.assertEqual(self.dock.compact_font_size, self.window.font_size)
        title = self.window.browser.document().find('Parallel reading check')
        self.assertAlmostEqual(title.charFormat().fontPointSize(), self.window.font_size, delta=.01)

    def test_lookup_and_wordbook_work_without_controls(self):
        self.window.set_boss_mode(True)
        self.window.lookup_text('leverage')
        self.assertIn('杠杆', self.dock.result_view.toPlainText())
        self.dock.save_current()
        self.assertIn('leverage', self.dock.vocabulary.items)
        self.hidden_chrome()

    def test_chapter_switch_does_not_reveal_header(self):
        self.window.set_boss_mode(True)
        self.window.change_chapter(1)
        QTest.qWait(150)
        self.hidden_chrome()
        self.assertIn('Pictures', self.window.browser.toPlainText())

    def test_pdf_switch_keeps_mode_and_does_not_reveal_pdf_toolbar(self):
        self.window.set_boss_mode(True)
        self.assertTrue(self.window.open_book(str(ROOT / 'pdf_demo.pdf')))
        QTest.qWait(200)
        self.hidden_chrome()
        self.assertIsNotNone(self.window.pdf_book)
        self.window.set_boss_mode(False)
        self.assertTrue(self.window.pdf_toolbar.isVisible())
        self.assertFalse(self.window.layout_toolbar.isVisible())

    def test_hidden_ui_does_not_return_after_async_status(self):
        self.window.set_boss_mode(True)
        self.window._show_display_status('test diagnostic')
        QTest.qWait(50)
        self.hidden_chrome()
        self.window.set_boss_mode(False)
        self.assertTrue(self.window._display_banner.isVisible())

    def test_scrollbar_policies_restore(self):
        before = [(a.horizontalScrollBarPolicy(), a.verticalScrollBarPolicy()) for a in self.window._scroll_areas()]
        self.window.set_boss_mode(True)
        self.assertTrue(all(a.verticalScrollBarPolicy() == Qt.ScrollBarPolicy.ScrollBarAlwaysOff for a in self.window._scroll_areas()))
        self.window.set_boss_mode(False)
        after = [(a.horizontalScrollBarPolicy(), a.verticalScrollBarPolicy()) for a in self.window._scroll_areas()]
        self.assertEqual(before, after)

    def test_source_view_cache_not_replaced_with_flattened_content(self):
        before = self.window._cached_html
        self.window.set_boss_mode(True)
        self.window.set_boss_mode(False)
        self.assertEqual(self.window._cached_html, before)

    def test_no_boss_flag_or_forced_visibility_saved(self):
        self.dock.hide()
        self.window.set_boss_mode(True)
        self.window.save_state()
        prefs = StateStore(self.directory / 'state.json').data['preferences']
        self.assertFalse(prefs['dictionary_visible'])
        self.assertFalse(prefs['dictionary_compact'])
        self.assertNotIn('boss_active', prefs)
        self.assertNotIn('boss_mode', prefs)

    def test_standalone_equal_titles_not_lost_after_boss(self):
        self.window.set_equal_titles(True)
        self.window.set_boss_mode(True)
        self.window.set_boss_mode(False)
        self.assertTrue(self.window.uniform_titles)
        self.assertTrue(self.window.equal_titles_action.isChecked())

    def test_repeated_roundtrip_and_lookup_does_not_destroy_widgets(self):
        result = self.dock.result_view
        mdx = self.dock.mdict_panel.browser
        for _ in range(4):
            self.window.set_boss_mode(True)
            self.dock.lookup('duration')
            self.window.set_boss_mode(False)
        self.assertIs(result, self.dock.result_view)
        self.assertIs(mdx, self.dock.mdict_panel.browser)
        self.assertIn('久期', result.toPlainText())

    def test_mdx_compact_shows_only_article_and_keeps_image_loader(self):
        mdx = self.dock.mdict_panel
        plan = build_index(ROOT / 'examples/mdict_demo/FinanceDemo.mdx', mdx.library.directory)
        mdx.library.commit(plan)
        mdx.refresh_dictionaries()
        self.dock.tabs.setCurrentWidget(mdx)
        self.dock.set_compact(True)
        self.dock.lookup('equity')
        self.assertIs(self.dock.tabs.currentWidget(), mdx)
        self.assertIn('股权', mdx.browser.toPlainText())
        self.assertIsNotNone(mdx.browser.images)
        self.assertTrue(all(not w.isVisible() for w in self.dock._compact_chrome()))
        self.assertFalse(mdx.hint.isVisible())

    def test_compact_mdx_miss_falls_back_to_existing_local_meaning(self):
        self.dock.set_compact(True)
        self.dock.tabs.setCurrentWidget(self.dock.mdict_panel)
        self.dock.lookup('equity')
        self.assertEqual(self.dock.tabs.currentIndex(), 0)
        self.assertIn('股权', self.dock.result_view.toPlainText())

    def test_floating_dictionary_embedded_only_during_boss(self):
        self.dock.setFloating(True)
        QTest.qWait(50)
        self.window.set_boss_mode(True)
        self.assertFalse(self.dock.isFloating())
        self.window.set_boss_mode(False)
        self.assertTrue(self.dock.isFloating())


if __name__ == '__main__':
    unittest.main()
