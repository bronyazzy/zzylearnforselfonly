"""Actual Qt-free rendering helpers and source invariants, not widget tests."""
import hashlib
from pathlib import Path
import unittest
from lxml import html as LH
from dictionary_core import DictionaryEngine, Entry, LookupResult
from epub_core import EpubBook
from compatible_layout import compatible_chapter
from quiet_content import compact_entry_html, entry_index, point_size, uniform_markup

ROOT = Path(__file__).resolve().parents[1]


class CompactContentTests(unittest.TestCase):
    def setUp(self):
        self.a = Entry('equity', 'ˈekwəti', '股权；所有者权益', '公平', 'category-private',
                       'source-private', definition='An ownership interest.',
                       examples=(('Equity can fall.', '股权价值可能下跌。'),))
        self.b = Entry('other result', 'ˈʌðər', translation='其他结果不应同时显示')
        self.result = LookupResult('equity', [self.a, self.b], '精确匹配')

    def text(self, **kwargs):
        return LH.fromstring(compact_entry_html(self.result, **kwargs)).text_content()

    def test_one_result_not_all_candidates(self):
        self.assertIn('股权', self.text())
        self.assertNotIn('其他结果', self.text())
        self.assertNotIn('source-private', self.text())
        self.assertNotIn('category-private', self.text())

    def test_selected_alternative_is_the_only_entry(self):
        text = self.text(index=1)
        self.assertIn('其他结果', text)
        self.assertNotIn('所有者权益', text)

    def test_all_selected_senses_examples_and_phonetic_preserved(self):
        text = self.text()
        for expected in ['ˈekwəti', '股权；所有者权益', '公平', 'An ownership interest.',
                         'Equity can fall.', '股权价值可能下跌。']:
            self.assertIn(expected, text)

    def test_finance_order_switch(self):
        first = self.text()
        second = self.text(finance_first=False)
        self.assertLess(first.index('股权'), first.index('公平'))
        self.assertLess(second.index('公平'), second.index('股权'))

    def test_no_header_or_global_boilerplate(self):
        markup = compact_entry_html(self.result)
        self.assertFalse(LH.fromstring(markup).xpath('//h1|//h2|//h3|//h4|//h5|//h6'))
        for phrase in ['相近词条', '导入词库', '释义仅辅助', '金融释义', '精确匹配']:
            self.assertNotIn(phrase, markup)

    def test_unlisted_does_not_display_other_suggestions(self):
        text = LH.fromstring(compact_entry_html(LookupResult('unlistedzz', suggestions=['equity']))).text_content()
        self.assertIn('未收录', text)
        self.assertNotIn('equity', text)

    def test_markup_is_escaped(self):
        e = Entry('<img src="bad">', translation='<script>attack</script> & text')
        root = LH.fromstring(compact_entry_html(LookupResult('query', [e])))
        self.assertFalse(root.xpath('//img|//script'))
        self.assertIn('<script>attack</script>', root.text_content())

    def test_abbreviation_points_to_pronounced_full_word(self):
        result = LookupResult('ETF', [Entry('exchange traded fund', 'example', translation='基金')])
        text = LH.fromstring(compact_entry_html(result)).text_content()
        self.assertIn('ETF → exchange traded fund', text)

    def test_inferred_word_form_remains_marked(self):
        result = LookupResult('margins', [self.a], '词形推测，请结合语境')
        self.assertIn('词形推测', compact_entry_html(result))

    def test_same_sense_is_not_duplicated(self):
        e = Entry('risk', finance='风险', translation='风险', definition='风险')
        self.assertEqual(LH.fromstring(compact_entry_html(LookupResult('risk', [e]))).text_content().count('风险'), 1)

    def test_index_is_bounded(self):
        for bad in ['bad', None, float('inf')]:
            self.assertEqual(entry_index(self.result, bad), 0)
        self.assertEqual(entry_index(self.result, 100), 1)
        self.assertEqual(entry_index(self.result, -1), 0)
        self.assertEqual(entry_index(None, 9), 0)

    def test_font_size_clamped_without_css_injection(self):
        self.assertEqual(point_size('12;url(x)'), 12)
        self.assertEqual(point_size(float('nan')), 12)
        self.assertEqual(point_size(800), 36)
        self.assertEqual(point_size(-9), 8)

    def test_real_finance_lexicon_remains_unchanged(self):
        engine = DictionaryEngine()
        try:
            result = engine.lookup('leverage')
            self.assertIn('杠杆', compact_entry_html(result))
            self.assertIn('ˈlevərɪdʒ', compact_entry_html(result))
            self.assertEqual(len(engine.entries), 453)
        finally:
            engine.close()


class UniformMarkupTests(unittest.TestCase):
    def test_nested_headings_get_absolute_prose_size(self):
        root = LH.fromstring(uniform_markup('<h1 style="font-size:80pt !important"><span>大标题</span></h1><p>正文</p>', 18))
        for node in root.xpath('//h1|//h1/span|//p'):
            self.assertTrue(node.get('style').endswith('font-size:18pt !important;'))

    def test_links_anchors_images_and_columns_survive(self):
        original = '<table width="100%"><tr><td width="43%"><h2 id="a"><a href="epub://book/path#b">English</a></h2></td><td width="57%">中文<img src="epubimg://book/1" width="100"/></td></tr></table>'
        root = LH.fromstring(uniform_markup(original, 18))
        self.assertEqual(root.xpath('//td/@width'), ['43%', '57%'])
        self.assertEqual(root.xpath('//a/@href'), ['epub://book/path#b'])
        self.assertEqual(root.xpath('//h2/@id'), ['a'])
        self.assertEqual(root.xpath('//img/@src'), ['epubimg://book/1'])
        self.assertEqual(root.text_content(), LH.fromstring(original).text_content())

    def test_keep_superscript_and_math_size(self):
        root = LH.fromstring(uniform_markup('<p>Rate<sup><span>2</span></sup></p><math><mi>x</mi></math><svg><text>graph</text></svg>', 18))
        self.assertIsNone(root.xpath('//sup/span')[0].get('style'))
        self.assertIsNone(root.xpath('//mi')[0].get('style'))
        self.assertIsNone(root.xpath('//svg/text')[0].get('style'))

    def test_font_size_attribute_removed_without_removing_word(self):
        root = LH.fromstring(uniform_markup('<font size="7" color="red">term</font>', 14))
        self.assertIsNone(root.xpath('//font')[0].get('size'))
        self.assertEqual(root.text_content(), 'term')

    def test_preserve_non_font_styles(self):
        root = LH.fromstring(uniform_markup('<h2 style="color:red;padding-left:8px">term</h2>', 14))
        self.assertIn('color:red;padding-left:8px', root.xpath('//h2/@style')[0])

    def test_compatible_book_text_and_images_unchanged(self):
        source = ROOT / 'parallel_demo.epub'
        before = hashlib.sha256(source.read_bytes()).hexdigest()
        with EpubBook(source) as book:
            for chapter in book.chapters:
                original = compatible_chapter(book, chapter.path).html
                flat = uniform_markup(original, 18)
                a, b = LH.fromstring(original), LH.fromstring(flat)
                self.assertEqual(a.text_content(), b.text_content())
                self.assertEqual(a.xpath('//img/@src'), b.xpath('//img/@src'))
                self.assertEqual(a.xpath('//td/@width'), b.xpath('//td/@width'))
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), before)


if __name__ == '__main__':
    unittest.main()
