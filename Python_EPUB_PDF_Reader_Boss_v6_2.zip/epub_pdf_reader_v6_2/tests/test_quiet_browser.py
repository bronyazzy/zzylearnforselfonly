"""Actual Chromium production-script checks; NOT a Qt desktop/window test."""
import os
from pathlib import Path
import shutil
import unittest
from epub_core import EpubBook
from publisher_core import PublisherResources, LayoutSettings, appearance_payload
from quiet_content import uniform_markup
from browser_harness import ROOT, load, GEOMETRY
try:
    from playwright.sync_api import sync_playwright
    AVAILABLE = True
except ImportError:
    AVAILABLE = False


@unittest.skipUnless(AVAILABLE, 'Playwright 不可用，未运行浏览器测试')
class QuietBrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw = sync_playwright().start()
        executable = os.environ.get('MODU_CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser')
        try:
            cls.browser = cls.pw.chromium.launch(
                **({'executable_path': executable} if executable else {}), headless=True,
                args=['--no-sandbox'] if hasattr(os, 'geteuid') and os.geteuid() == 0 else [])
        except Exception as exc:
            cls.pw.stop()
            raise unittest.SkipTest('无法启动 Chromium：' + str(exc)[:180])

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()

    def setUp(self):
        self.page = self.browser.new_page(viewport={'width':1080, 'height':800})
        self.addCleanup(self.page.close)
        self.page.route('**/*', lambda route: route.abort())
        self.book = EpubBook(ROOT / 'parallel_demo.epub')
        self.addCleanup(self.book.close)
        self.settings = appearance_payload(LayoutSettings(mode='parallel'), '#f7f2e8', 18)
        load(self.page, PublisherResources(self.book), 'OPS/first.xhtml', self.settings)

    def apply(self, **changes):
        self.settings.update(changes)
        self.page.evaluate('(s)=>window.__modu.settings(s,true)', self.settings)
        self.page.wait_for_timeout(80)

    def test_nested_big_titles_same_as_body_and_restore_exact_inline(self):
        self.page.evaluate('''()=>{let h=document.querySelector('h1');
            h.style.setProperty('font-size','71px','important');
            h.firstElementChild.style.setProperty('font-size','59px','important');}''')
        before = self.page.locator('h1').evaluate('e=>[e.style.cssText,e.firstElementChild.style.cssText]')
        self.apply(uniform_titles=True, boss_mode=True)
        sizes = self.page.locator('h1, h1 *').evaluate_all('ns=>ns.map(n=>getComputedStyle(n).fontSize)')
        self.assertTrue(all(size == '24px' for size in sizes), sizes)
        self.apply(uniform_titles=False, boss_mode=False)
        after = self.page.locator('h1').evaluate('e=>[e.style.cssText,e.firstElementChild.style.cssText]')
        self.assertEqual(before, after)

    def test_uniform_mode_preserves_bilingual_rows_and_text(self):
        before = self.page.locator('body').text_content()
        self.apply(uniform_titles=True, boss_mode=True, english_percent=43)
        for row in self.page.evaluate(GEOMETRY):
            self.assertAlmostEqual(row['ey'], row['zy'], delta=1)
            self.assertGreater(row['zx'], row['ex'])
        self.assertEqual(self.page.locator('body').text_content(), before)

    def test_font_changes_update_uniform_titles_not_dom(self):
        self.page.evaluate('window.savedHeading = document.querySelector("h1")')
        self.apply(uniform_titles=True, boss_mode=True)
        self.apply(fontSize=21)
        self.assertTrue(self.page.evaluate('window.savedHeading === document.querySelector("h1")'))
        self.assertEqual(self.page.locator('h1').evaluate('e=>getComputedStyle(e).fontSize'), '28px')

    def test_repeated_toggle_restores_author_style_and_no_scroll_loop(self):
        original = self.page.locator('h1').evaluate('e=>getComputedStyle(e).fontSize')
        for _ in range(4):
            self.apply(uniform_titles=True, boss_mode=True)
            self.apply(uniform_titles=False, boss_mode=False)
        self.assertEqual(self.page.locator('h1').evaluate('e=>getComputedStyle(e).fontSize'), original)
        y = self.page.evaluate('scrollY')
        self.page.wait_for_timeout(350)
        self.assertEqual(self.page.evaluate('scrollY'), y)

    def test_mode_switch_keeps_reading_anchor(self):
        self.page.evaluate('window.__modu.goTo("",.4,null)')
        self.page.wait_for_timeout(80)
        anchor = self.page.evaluate('window.__modu.snapshot()')
        self.apply(uniform_titles=True, boss_mode=True)
        delta = self.page.evaluate('(a)=>document.querySelector(`[data-mr-id="${a.id}"]`).getBoundingClientRect().top-a.offset', anchor)
        self.assertAlmostEqual(delta, 0, delta=1)

    def test_boss_scrollbar_css_removed_on_exit(self):
        self.apply(boss_mode=True)
        self.assertEqual(self.page.locator('html').evaluate('e=>getComputedStyle(e).scrollbarWidth'), 'none')
        self.apply(boss_mode=False)
        self.assertNotEqual(self.page.locator('html').evaluate('e=>getComputedStyle(e).scrollbarWidth'), 'none')

    def test_inline_math_not_resized(self):
        self.page.evaluate('''()=>{const n=document.createElement('div');n.innerHTML='<p>X<sup style="font-size:10px"><span>2</span></sup></p><svg><text style="font-size:9px">graph</text></svg>';document.body.append(n);}''')
        self.apply(uniform_titles=True)
        self.assertEqual(self.page.locator('sup').evaluate('e=>e.style.fontSize'), '10px')
        self.assertEqual(self.page.locator('svg text').evaluate('e=>e.style.fontSize'), '9px')

    def test_native_markup_resists_nested_important_heading(self):
        markup = uniform_markup('<h1 style="font-size:70pt !important"><span style="font-size:45pt !important">Title</span></h1><p>Body</p>', 18)
        self.page.set_content(markup)
        sizes = self.page.locator('h1, h1 span, p').evaluate_all('ns=>ns.map(n=>getComputedStyle(n).fontSize)')
        self.assertEqual(sizes, ['24px','24px','24px'])


if __name__ == '__main__':
    unittest.main()
