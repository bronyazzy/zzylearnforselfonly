#!/usr/bin/env python3
"""Create an isolated environment, install missing requirements, launch the reader.

The first dependency installation needs Internet access. Subsequent reading and
built-in dictionary lookups are offline. No book text is sent by this launcher.
"""
from __future__ import annotations

from pathlib import Path
import os
import subprocess
import sys
import venv

ROOT = Path(__file__).resolve().parent


def main() -> int:
    if sys.version_info < (3, 10):
        print("需要 Python 3.10 或更新版本。")
        return 1
    environment = ROOT / ".venv"
    executable = environment / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    try:
        if not executable.is_file():
            print("正在建立项目专用 Python 环境（.venv）…", flush=True)
            venv.EnvBuilder(with_pip=True).create(environment)
        check = subprocess.run(
            [str(executable), "-c", "import PySide6.QtWidgets, PySide6.QtSvg, PySide6.QtMultimedia, PySide6.QtWebEngineWidgets, lxml, defusedxml, pypdfium2; assert tuple(map(int, pypdfium2.PYPDFIUM_INFO.version.split('.')[:2])) >= (5, 8)"],
            cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            check=False,
        )
        if check.returncode:
            print("正在安装运行依赖。首次安装需要网络；后续阅读和内置查词可离线。", flush=True)
            subprocess.run([str(executable), "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")],
                           cwd=str(ROOT), check=True)
        return subprocess.call([str(executable), str(ROOT / "epub_reader.py"), *sys.argv[1:]], cwd=str(ROOT))
    except (OSError, subprocess.CalledProcessError) as exc:
        print(f"启动失败：{exc}\n请查看 README.md 的手动安装说明。", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
