"""Bounded, offline EPUB image utilities. No Qt or network/file-system loader.

SVG is reduced to a static subset before reaching Qt. Local raster references
are embedded from the already validated EPUB archive; all other references go.
"""
from __future__ import annotations

import base64
import binascii
import math
from pathlib import PurePosixPath
import re
from typing import Callable
from urllib.parse import unquote_to_bytes
from xml.etree import ElementTree as ET

from defusedxml import ElementTree as SafeET
from defusedxml.common import DefusedXmlException

MAX_EMBEDDED_BYTES = 8 * 1024 * 1024
MAX_SVG_BYTES = 4 * 1024 * 1024
MAX_SVG_NODES = 20_000
MAX_SVG_DEPTH = 64
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.svg'}
IMAGE_TYPES = {'image/png', 'image/x-png', 'image/jpeg', 'image/jpg', 'image/pjpeg',
               'image/gif', 'image/webp', 'image/bmp', 'image/x-ms-bmp', 'image/svg+xml'}
SVG_NS = 'http://www.w3.org/2000/svg'
XLINK_NS = 'http://www.w3.org/1999/xlink'


class ImageError(ValueError):
    """A readable explanation for an unavailable/unsafe image."""


def is_image_candidate(path: str, media_type: str = '') -> bool:
    return (media_type.split(';', 1)[0].strip().lower() in IMAGE_TYPES
            or PurePosixPath(path).suffix.lower() in IMAGE_EXTENSIONS)


def raster_mime(data: bytes) -> str:
    if data.startswith(b'\x89PNG\r\n\x1a\n'):
        return 'image/png'
    if data.startswith(b'\xff\xd8\xff'):
        return 'image/jpeg'
    if data[:6] in (b'GIF87a', b'GIF89a'):
        return 'image/gif'
    if data.startswith(b'BM'):
        return 'image/bmp'
    if data.startswith(b'RIFF') and data[8:12] == b'WEBP':
        return 'image/webp'
    return ''


def decode_data_image(uri: str) -> bytes:
    """Only raster data images. No network, SVG data documents, or arbitrary XML."""
    if len(uri) > MAX_EMBEDDED_BYTES * 4 + 256:
        raise ImageError('内嵌图片数据过大')
    header, separator, payload = uri.partition(',')
    if not separator or not header.lower().startswith('data:image/'):
        raise ImageError('内嵌图片格式无效')
    try:
        raw = unquote_to_bytes(payload)
        if header.lower().endswith(';base64'):
            raw = base64.b64decode(re.sub(rb'\s+', b'', raw), validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ImageError('内嵌图片编码损坏') from exc
    if len(raw) > MAX_EMBEDDED_BYTES or not raster_mime(raw):
        raise ImageError('内嵌图片不是支持的位图或超过 8 MiB')
    return raw


def fit_image_size(width: float, height: float, available: int,
                   width_hint: str = '', height_hint: str = '') -> tuple[int, int]:
    """Keep aspect ratio; never overflow the column. Only numeric px/% hints."""
    if not all(math.isfinite(x) and x > 0 for x in (width, height)):
        raise ImageError('图片尺寸无效')
    available = max(1, int(available))

    def dimension(value: str, reference: float) -> float | None:
        match = re.fullmatch(r'\s*(\d+(?:\.\d+)?)\s*(px|%)?\s*', value or '', re.I)
        if not match:
            return None
        amount = float(match[1])
        if not 0 < amount <= 100_000:
            return None
        return reference * amount / 100 if match[2] == '%' else amount

    requested_width = dimension(width_hint, available)
    requested_height = dimension(height_hint, height)
    target = requested_width or (requested_height * width / height if requested_height else width)
    target = max(1, min(available, target))
    return max(1, round(target)), max(1, round(target * height / width))


# Deliberately excludes script, animation, foreignObject, filters, style sheets,
# external use references and embedded SVG-in-SVG image documents.
SVG_TAGS = {
    'svg', 'g', 'defs', 'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon',
    'text', 'tspan', 'title', 'desc', 'image', 'linearGradient', 'radialGradient', 'stop',
    'clipPath', 'mask', 'symbol', 'use',
}
SVG_ATTRS = {
    'id', 'x', 'y', 'x1', 'x2', 'y1', 'y2', 'cx', 'cy', 'r', 'rx', 'ry', 'width', 'height',
    'viewBox', 'preserveAspectRatio', 'd', 'points', 'transform', 'fill', 'fill-opacity',
    'fill-rule', 'stroke', 'stroke-width', 'stroke-opacity', 'stroke-dasharray', 'stroke-linecap',
    'stroke-linejoin', 'opacity', 'font-family', 'font-size', 'font-weight', 'font-style',
    'text-anchor', 'dominant-baseline', 'dx', 'dy', 'offset', 'stop-color', 'stop-opacity',
    'gradientUnits', 'gradientTransform', 'spreadMethod', 'fx', 'fy', 'fr', 'clip-path',
    'clipPathUnits', 'mask', 'maskUnits', 'maskContentUnits', 'display', 'visibility',
}
TAG_CASE = {x.lower(): x for x in SVG_TAGS}
ATTR_CASE = {x.lower(): x for x in SVG_ATTRS}
LOCAL_URL = re.compile(r'url\(\s*[\'\"]?#[\w.:-]+[\'\"]?\s*\)', re.I)


def sanitize_svg(data: bytes, read_local: Callable[[str], bytes] | None = None) -> bytes:
    """Return static self-contained SVG, or raise ImageError. No trusted-mode flags."""
    if len(data) > MAX_SVG_BYTES:
        raise ImageError('SVG 超过 4 MiB')
    # Inline SVG may inherit these namespaces from its XHTML ancestor.
    try:
        text = data.decode('utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig', errors='strict')
    except UnicodeError as exc:
        raise ImageError('SVG 文本编码无效') from exc
    # Allow common inert SVG public/system DOCTYPEs by removing the declaration
    # before parsing. Internal subsets/entities remain forbidden. Nothing is fetched.
    text = re.sub(r"<!DOCTYPE\s+svg(?:\s+(?:PUBLIC\s+['\"][^'\"]*['\"]\s+['\"][^'\"]*['\"]|SYSTEM\s+['\"][^'\"]*['\"]))?\s*>", '', text, flags=re.I)
    match = re.search(r'<svg\b[^>]*>', text, re.I)
    if match:
        extra = ''
        if not re.search(r'\bxmlns\s*=', match[0]):
            extra += f' xmlns="{SVG_NS}"'
        if not re.search(r'\bxmlns:xlink\s*=', match[0]):
            extra += f' xmlns:xlink="{XLINK_NS}"'
        if extra:
            at = match.end() - (2 if match[0].endswith('/>') else 1)
            text = text[:at] + extra + text[at:]
    try:
        root = SafeET.fromstring(text, forbid_dtd=True, forbid_entities=True, forbid_external=True)
    except (ET.ParseError, DefusedXmlException, ValueError) as exc:
        raise ImageError('SVG XML 无效或包含不安全的声明') from exc
    if root.tag.rsplit('}', 1)[-1].lower() != 'svg':
        raise ImageError('不是 SVG 图片')
    count = 0
    embedded_total = 0

    def clean(node, depth: int = 0):
        nonlocal count, embedded_total
        count += 1
        if count > MAX_SVG_NODES or depth > MAX_SVG_DEPTH:
            raise ImageError('SVG 结构过于复杂')
        tag = TAG_CASE.get(node.tag.rsplit('}', 1)[-1].lower())
        if tag is None:
            return None
        out = ET.Element(f'{{{SVG_NS}}}{tag}')
        attributes = dict(node.attrib)
        for part in attributes.pop('style', '').split(';'):
            key, sep, value = part.partition(':')
            if sep and key.strip() in SVG_ATTRS:
                attributes.setdefault(key.strip(), value.strip())
        for original, value in attributes.items():
            key = ATTR_CASE.get(original.rsplit('}', 1)[-1].lower())
            if key is None or len(value) > 300_000:
                continue
            # URL-bearing values are restricted to same-document fragment links.
            remaining = LOCAL_URL.sub('', value)
            if any(x in remaining.lower() for x in ('url', 'javascript:', 'data:', 'file:', 'http:', 'https:', '@', '\\')):
                continue
            out.set(key, value)
        href = attributes.get(f'{{{XLINK_NS}}}href') or attributes.get('href', '')
        if tag == 'image':
            try:
                if href.lower().startswith('data:'):
                    raw = decode_data_image(href)
                elif read_local is not None:
                    raw = read_local(href)
                else:
                    raise ImageError('SVG 图片引用不可用')
                mime = raster_mime(raw)
                if not mime or len(raw) > MAX_EMBEDDED_BYTES:
                    raise ImageError('SVG 只允许引用本地位图')
                embedded_total += len(raw)
                if embedded_total > MAX_EMBEDDED_BYTES:
                    raise ImageError('SVG 内嵌图片总量过大')
                out.set(f'{{{XLINK_NS}}}href', f'data:{mime};base64,' + base64.b64encode(raw).decode('ascii'))
            except (ImageError, OSError, ValueError):
                return None
        elif tag in {'use', 'linearGradient', 'radialGradient'} and re.fullmatch(r'#[\w.:-]+', href):
            out.set(f'{{{XLINK_NS}}}href', href)
        out.text = node.text
        out.tail = node.tail
        for child in node:
            cleaned = clean(child, depth + 1)
            if cleaned is not None:
                out.append(cleaned)
        return out

    result = clean(root)
    ET.register_namespace('', SVG_NS)
    ET.register_namespace('xlink', XLINK_NS)
    return ET.tostring(result, encoding='utf-8', xml_declaration=True)
