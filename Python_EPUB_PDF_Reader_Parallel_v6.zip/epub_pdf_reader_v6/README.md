# 墨读 6.0 · 原书排版 / 中英左右对照 / EPUB / PDF

完整 Python 桌面阅读器源码包。默认使用原书排版显示 EPUB，不再把出版方 CSS、样式类与双语结构全部删掉；PDF、金融英汉词典、音标、生词本、CSV、MDX/MDD 与 5.1 的 Windows 导入修复保留。

**不是免安装 EXE，不是补丁。** 需要 Python 3.10+、桌面环境，以及可在本机安装的 Qt / PDFium 发行包。完整解压后运行，不能仅复制一个 Python 文件。本包不附用户上传的电子书、商业词典、字体文件或第三方运行库二进制。

## 先运行

Windows：关闭旧版，解压到新文件夹，双击 `start_windows.bat`。脚本创建本项目 `.venv`，检查依赖，并在缺失时安装。首次安装需要联网；读本地书和使用本地词典不需要联网。

手动运行：

```bash
python -m pip install -r requirements.txt
python epub_reader.py parallel_demo.epub
```

打开自己的文件：

```bash
python epub_reader.py "你的中英对照.epub"
python epub_reader.py "你的财务报告.pdf"
```

macOS / Linux：

```bash
sh start_macos_linux.sh parallel_demo.epub
```

某些系统使用 `python3`。建议使用虚拟环境。没有桌面的服务器不是交互运行目标。旧版本环境必须重新安装本版 `requirements.txt`：本版需要 QtWebEngine 和 lxml；仅安装旧的基础 Qt Widgets 不足以启动。Qt 库可能较大，第一次下载需要时间。

## 6.0 排版变化

| 选项 | 行为 |
| --- | --- |
| 原书排版（默认） | 保留原 CSS、class、语言标记、表格、图题及左右对照结构，由 QtWebEngine 渲染；不是把两页并排 |
| 左右对照 | 对明确配对的中英单元逐组顶端对齐；英文栏可设为 30%–70%，中文占余下宽度 |
| 上下对照 | 对同一组双语内容改为上下排列，适合较窄窗口 |
| 只看英文 / 只看中文 | 隐藏明确配对中的另一语言；没有语言标记的图表、数值、公式及其他共用内容仍保留 |
| 简化阅读 | 保留原 QTextBrowser 轻量路径作为兼容选择；不能复刻复杂双栏 CSS |

**不是自动翻译或自动配对工具。** 左右/上下/单语模式只操作源文件中已有明确标记的配对，例如 `bi-en` / `bi-zh`，或同一容器中仅有相邻的 `lang="en"` 与 `lang="zh"` 两块内容。没有这种结构时显示提示并保留原文；不会凭文字长度猜测对应关系。原书排版不要求存在这些标记。

顶部新增“EPUB 排版”工具栏：模式、英文栏宽、正文最大宽度、原书或 1.5 / 1.8 / 2.1 行距，以及“应用阅读背景”。这些排版选择按书保存。原书模式保留出版方的实际分栏；英文比例滑块仅在“左右对照”模式启用。

使用你自己的左右对照书时：先选“原书排版”；需要调节两栏比例时改为“左右对照”。窗口窄时可按 `Ctrl+L` 隐藏目录、`Ctrl+J` 收起词典，或按 `F11` 进入专注阅读。专注模式用 `F11` 或 `Esc` 退出。

“原书排版”仍是受控阅读视图：禁用出版方脚本和动画；按设置应用阅读字号、背景和宽度，不承诺像素级复刻出版商页面。取消“应用阅读背景”保留原来的文字颜色和底色，不会对图片进行反色。

## 阅读体验与定位

调整字号、颜色、栏宽和对照方式时只更新样式，不整章重复加载；保存当前可见内容附近的 DOM 标记及偏移，尽量维持阅读段落。窗口变化也采用一次性重定位，没有周期性自动下滑或强制复位定时器。

默认打开到上次章节 / PDF 页的顶部，不使用旧滚动偏移。需要续读到上次段落时，勾选“阅读 → 打开时恢复上次阅读位置”。新原书模式书签带段落定位；旧书签仍可按比例跳转。跨显示引擎切换、单语隐藏内容、字体替换或文档变化时仍可能产生位置偏差。

- 当前章节搜索支持中文、英文，匹配数由原书内核返回；不是全书搜索。
- 双击英文、划选短语、右键查询或 `Ctrl+E` 沿用原词典。生词上下文尽量来自选中语言块，而不是混入左右两栏。
- 图片保持长宽比。包内图片可右键“放大查看图片…”，弹窗支持适合窗口、100% 和缩放；这是显示副本，不修改源图片。该弹窗使用原有安全图片解码器，复杂矢量图或超限图片仍可能无法放大。
- 原 HTML 数据表保留行列；给较宽的表格单独提供横向滚动，不把左右正文一起撑宽。
- 静态 SVG、浏览器可渲染的 MathML 和 CSS Grid/Flex 等布局由新 EPUB 视图处理，特殊 SVG/MathML 变体仍需按书检查。

## 背景、PDF 和词典

原有“背景颜色”提供纸白、暖米、浅绿、柔灰、夜间和自定义颜色。原书 EPUB 中勾选“应用阅读背景”时应用这些设置；取消可保留原书配色。

PDF 继续按原页面、单页页内滚动显示：目录、页码、缩放、旋转、当前页搜索、书签、文字选择和密码输入保留。扫描 PDF 可看图，没有文字层时不能搜索或划词，本版没有 OCR。PDF 原色默认不变，“纸张护眼着色”可能影响图表色彩。

金融词典仍有 453 条精选词条，含 332 条金融词汇/短语和 121 条基础通用词；内置音标为未经专业逐条审校的参考音标，不是完整通用词库。支持 ECDICT / 自定义 UTF-8 CSV（`word`、`translation` 必需，`phonetic` 等可选）。

MDX/MDD 可多部并存、资源分卷、内部跳转、播放已有音频、加入生词。导入只建索引，原文件需留在原路径。MDD 不能单独当词典正文。音标、中文和发音以原词典有无为准；没有自动翻译或生成朗读。详见 `MDX_GUIDE.md`。

**本次升级的是 EPUB 正文视图，不是 MDX 词条的完整浏览器排版。** MDX 仍使用原安全富文本路径，其 JavaScript、复杂 CSS、特殊字体及 MDict 3.x / 注册绑定等限制不变。音频解码依赖本机 Qt 后端。保留 5.1 的 `r+b` 索引同步、失败保护及 `dictionary_import.log` 诊断。

## 升级及数据

完整解压到新目录，不要复制别的系统或旧版本的 `.venv`。可先备份数据目录。应用标识继续是 `MoDuReader`，读取已有阅读记录、书签、生词本、CSV 索引和 MDX 清单；不需要清空数据。

此前使用过 `--data-dir` 的，继续指定原目录：

```bash
python epub_reader.py --data-dir "./reader-data" "你的书籍.epub"
```

`--no-restore` 表示启动时不自动打开最近文件，与菜单里的“恢复具体阅读位置”不是同一开关。

原书新偏好写入现有 `state.json` 的 `epub_layout`，DOM 定位存为 `epub_web_anchor`。旧源码不知道这些字段时可能忽略它们；不要同时运行不同版本写入同一数据目录。保存的路径和上下文只留本机，但并不加密。

## 安全边界与资源

原书通过当前 EPUB 独享的 `epub://` 内存资源处理器按需读取，不将 ZIP 解压到用户目录。只接受当前书包资源。阻断网络和磁盘 URL 的资源请求，书中 HTTP/HTTPS/mailto 外链仅在用户确认后交系统应用打开。

原书 HTML 删除脚本、事件、外部框架、表单和活动媒体；再用 CSP 和 Qt 主世界 JavaScript 禁用形成多层约束。阅读器自己的选区/定位代码在独立 ApplicationWorld 执行，不运行原作者脚本。使用临时 WebEngine 配置，不留浏览器历史、Cookie 或持久 Web 存储，不提供网站登录或任意网页浏览功能。

可按需使用合法 EPUB 中可直接读取的本地字体资源，但本包不附字体，也不解密混淆/加密字体。没有 DRM 绕过、动画/视频/交互脚本、完整固定版式或完整 EPUB 规范一致性保证。本程序不构成经过审计的进程沙箱；请使用来源可信的书，及时维护依赖。

保留 EPUB ZIP 检查及资源大小限制；新增单章最多 120,000 个元素、CSS 每文件最多 4 MiB 等边界。图片在新内核原生解码，不等于继承旧 QImage 的所有内存限制。浏览器原生进程会增加内存消耗；既有文件/块上限不是整个程序的内存与耗时硬上限。

## 原书内核空白或退出

先确认依赖完整安装，并用包内 `parallel_demo.epub` 检查，不要因此删除原书或阅读记录。

显卡兼容排查：

```bash
python epub_reader.py --software-rendering parallel_demo.epub
```

该选项只禁用 GPU 绘图，不关闭浏览器沙箱。生产启动脚本不设置 `--no-sandbox`。Linux 请以普通桌面用户运行。

临时使用简化 EPUB 渲染：

```bash
python epub_reader.py --simple-epub "你的书籍.epub"
```

简化路径仍属于同一程序，仍需完整安装依赖；它是渲染兼容选择，不是缺少 QtWebEngine 时的免依赖启动器。简化路径不能恢复原书复杂左右 CSS。

## 常用按键

| 按键 | 操作 |
| --- | --- |
| Ctrl+O | 打开 EPUB / PDF |
| PageUp / PageDown，← / →，Shift+Space / Space | 上一屏 / 下一屏，到边界后可换章/页；正文获得焦点时有效 |
| Alt+← / Alt+→；Alt+↑ | 上一章/页，下一章/页；返回 |
| Ctrl+Home | 回到当前章节/页顶部 |
| Ctrl+F，F3 / Shift+F3 | 当前章节/页搜索，后/前匹配 |
| Ctrl+E；Ctrl+J | 查所选英文；显示/隐藏词典 |
| Ctrl+L；Ctrl+B | 目录；添加书签 |
| Ctrl+- / Ctrl+= | EPUB 字号；PDF 整页缩放 |
| Ctrl+D；Ctrl+Shift+C | 夜间切换；自定义背景 |
| F11；专注模式中的 Esc | 进入/退出专注；退出专注 |

## 源码与示例

- `publisher_core.py`：出版方结构保留、主动内容过滤、双语标记及受限资源。
- `publisher_ui.py`：QtWebEngine、离线 URI、选区、放大图、生命周期。
- `publisher_integration.py`：新排版工具栏、旧功能联动、书签与状态。
- `assets/reader.js`：独立世界的排版与段落定位代码。
- `parallel_demo.epub`：原创两章示例，含逐组中英对照、CSS Grid、宽表、PNG、SVG 和 MathML；`make_parallel_demo.py` 可重建。
- 原 `epub_core.py`、`pdf_*.py`、`dictionary_*.py`、`mdict_*.py` 等仍在。
- 原始 `demo.epub`、`finance_demo.epub`、`image_test.epub`、`pdf_demo.pdf`、`examples/mdict_demo/` 保留。

## 测试与实际验证

```bash
python -m unittest discover -s tests -v
python verify_package.py
```

可选浏览器排版测试依赖：

```bash
python -m pip install -r requirements-test.txt
python -m playwright install chromium
python -m unittest discover -s tests -p "test_publisher_browser.py" -v
```

未安装 Qt / 浏览器时相关测试会跳过，跳过不等于通过。本次 **348 项实际通过，94 项 Qt GUI 测试跳过**；通过中有 **16 项真实 Chromium 排版测试**。另用用户上传书的 16 个正文章节，在 1440px 和 600px 两种宽度验证 1,991 个明确配对单元的左右几何、文字与图片情况。用户的书没有打包。

浏览器验证使用生产 HTML/CSS/JS，仅将本地资源内联到测试页面；它不是原生 Qt 窗口，也不能验证 Qt 自定义 URI、桌面鼠标/音频或 Windows 显卡。详见 `TEST_REPORT.md`。

`validate_epub_layout.py` 可对自己的双语书做同类本地检查：

```bash
python validate_epub_layout.py "你的书籍.epub" --output ./layout-check
```

检查输出可能包含书名、文件摘要及预览图片，请按个人资料保护。历史 5.x 文档保留为带 `HISTORY` 的文件，不代表 6.0 当前行为。
