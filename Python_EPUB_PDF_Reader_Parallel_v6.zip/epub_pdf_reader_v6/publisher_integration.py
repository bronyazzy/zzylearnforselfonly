"""Original-layout EPUB mode layered over the established EPUB/PDF reader."""
from __future__ import annotations

import os
from dataclasses import replace
from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtWidgets import QCheckBox, QComboBox, QLabel, QSlider, QToolBar, QMessageBox
from PySide6.QtWebEngineCore import QWebEnginePage  # provided by existing Qt Addons dependency

from dictionary_core import valid_query
from epub_core import EpubBook, EpubError
from pathlib import Path
from publisher_core import LayoutSettings, MODE_NAMES, PublisherResources, appearance_payload, clean_anchor
from publisher_ui import PublicationView, register_epub_scheme
from reader_settings import ViewPosition, normalize_background, theme_colors

register_epub_scheme()


class PublisherReaderMixin:
    def __init__(self, state):
        self.publication_view=None
        self.layout_settings=LayoutSettings.from_dict(state.data['preferences'].get('epub_layout'))
        self._layout_book_id=''
        self._publication_resources=None
        self._opening_publication=False
        self._next_web_anchor=None
        self._focus_states=None
        self._force_simple=os.environ.get('MODU_SIMPLE_EPUB')=='1'
        super().__init__(state)
        self.setWindowTitle('墨读 6.0 · 原书排版 / 双语对照 / EPUB / PDF')

    def _build_ui(self):
        super()._build_ui()
        self.publication_view=PublicationView(self)
        self.document_stack.addWidget(self.publication_view)
        self.publication_view.loaded.connect(self._publication_loaded)
        self.publication_view.positionChanged.connect(self.scrolled)
        self.publication_view.lookupRequested.connect(self._publication_lookup)
        self.publication_view.linkRequested.connect(self.link_activated)
        self.publication_view.pageRequested.connect(lambda d:self.change_chapter(d,from_end=d<0))
        self.publication_view.message.connect(lambda t:self.statusBar().showMessage(t,8000))
        self.publication_view.userInteracted.connect(self._publication_interacted)
        self.addToolBarBreak()
        self.layout_toolbar=QToolBar('EPUB 排版',self)
        self.layout_toolbar.setObjectName('publicationLayoutToolbar')
        self.layout_toolbar.setMovable(False);self.addToolBar(self.layout_toolbar)
        self.layout_toolbar.addWidget(QLabel('EPUB 排版 '))
        self.layout_combo=QComboBox()
        for mode,label in MODE_NAMES.items():self.layout_combo.addItem(label,mode)
        self.layout_combo.setToolTip('原书排版保留书内 CSS；左右/上下/单语模式只作用于明确配对的中英单元，不生成翻译。')
        self.layout_combo.activated.connect(lambda i:self.set_layout(mode=self.layout_combo.itemData(i)))
        self.layout_toolbar.addWidget(self.layout_combo)
        self.layout_toolbar.addSeparator()
        self.ratio_label=QLabel('英文 50% ');self.layout_toolbar.addWidget(self.ratio_label)
        self.ratio_slider=QSlider(Qt.Orientation.Horizontal)
        self.ratio_slider.setRange(30,70);self.ratio_slider.setFixedWidth(100)
        self.ratio_slider.setToolTip('左右对照模式下的英文栏宽比例，中文栏使用剩余宽度。')
        self.ratio_slider.valueChanged.connect(self._ratio_changed)
        self.layout_toolbar.addWidget(self.ratio_slider)
        self.width_combo=QComboBox()
        for text,value in [('铺满阅读区',0),('舒适宽度 960',960),('宽幅 1280',1280),('宽幅 1600',1600)]:self.width_combo.addItem(text,value)
        self.width_combo.activated.connect(lambda i:self.set_layout(content_width=self.width_combo.itemData(i)))
        self.layout_toolbar.addWidget(self.width_combo)
        self.line_combo=QComboBox()
        for text,value in [('原书行距',0),('行距 1.5',1.5),('行距 1.8',1.8),('行距 2.1',2.1)]:self.line_combo.addItem(text,value)
        self.line_combo.activated.connect(lambda i:self.set_layout(line_height=self.line_combo.itemData(i)))
        self.layout_toolbar.addWidget(self.line_combo)
        self.theme_check=QCheckBox('应用阅读背景')
        self.theme_check.setToolTip('取消时保留原书文字/底色；不对图片执行反色。')
        self.theme_check.toggled.connect(lambda v:self.set_layout(use_theme=v))
        self.layout_toolbar.addWidget(self.theme_check)
        self.layout_toolbar.addAction(self._action('专注阅读',self.toggle_focus,'F11'))
        menu=self.menuBar().addMenu('排版')
        for mode,label in MODE_NAMES.items():
            action=menu.addAction(label)
            action.triggered.connect(lambda _c=False,m=mode:self.set_layout(mode=m))
        menu.addSeparator();menu.addAction(self._action('专注阅读 / 退出专注',self.toggle_focus))
        self._focus_exit_action=self._action('退出专注阅读',self.exit_focus,'Esc')
        self._focus_exit_action.setEnabled(False)
        self._sync_layout_controls();self.layout_toolbar.hide()

    def show_welcome(self):
        super().show_welcome()
        text=self.browser.toHtml().replace('EPUB 使用阅读排版；PDF 保留原页面、图片和图表。',
            'EPUB 默认保留原书排版，支持中英左右对照；PDF 保留原页面。')
        text=text.replace('finance_demo.epub、image_test.epub 和 pdf_demo.pdf',
            'parallel_demo.epub、finance_demo.epub、image_test.epub 和 pdf_demo.pdf')
        self.browser.setHtml(text)

    def _using_publication(self):
        return (self.publication_view is not None and self.book is not None and self.pdf_book is None
                and self.layout_settings.mode!='simple' and not self._force_simple)

    def _payload(self):
        return appearance_payload(self.layout_settings,self.background,self.font_size)

    def _sync_layout_controls(self):
        if not hasattr(self,'layout_combo'):return
        for widget,value in [(self.layout_combo,self.layout_settings.mode),(self.width_combo,self.layout_settings.content_width),
                             (self.line_combo,self.layout_settings.line_height)]:
            widget.blockSignals(True);widget.setCurrentIndex(widget.findData(value));widget.blockSignals(False)
        self.ratio_slider.blockSignals(True);self.ratio_slider.setValue(self.layout_settings.english_percent);self.ratio_slider.blockSignals(False)
        self.ratio_label.setText(f'英文 {self.layout_settings.english_percent}% ')
        self.ratio_slider.setEnabled(self.layout_settings.mode=='parallel')
        self.theme_check.blockSignals(True);self.theme_check.setChecked(self.layout_settings.use_theme);self.theme_check.blockSignals(False)

    def _ratio_changed(self,value):
        self.set_layout(english_percent=value)

    def set_layout(self,**values):
        old=self._using_publication();ratio=self.current_ratio() if self.book else 0
        self.layout_settings=LayoutSettings.from_dict({**self.layout_settings.as_dict(),**values})
        self._force_simple=False
        self._sync_layout_controls()
        if self.book:
            new=self._using_publication()
            if new and old:
                self.publication_view.apply_settings(self._payload())
                self._layout_notice()
            else:
                self.cancel_pending_position()
                if old and not new:
                    self.publication_view.clear_publication()
                # Cross-engine mode changes use a ratio, not incompatible QTextCursor offsets.
                self.navigate(self.current_path,ratio=ratio,record_history=False)
        self._save_timer.start()

    def _layout_notice(self):
        if self._publication_resources is None:return
        n=self._publication_resources.pair_counts.get(self.current_path,0)
        if self.layout_settings.mode in {'parallel','stack','en','zh'}:
            text=f'本章识别到 {n} 组明确中英配对。' if n else '本章未识别到明确的中英配对；保留原文，不猜测左右对应关系。可用“原书排版”。'
            self.statusBar().showMessage(text,8000)

    def open_book(self,filename):
        # Preflight original HTML before the legacy opener replaces the old book.
        if Path(filename).suffix.lower()=='.epub' and not self._force_simple:
            try:
                with EpubBook(filename) as candidate:
                    record=self.store.data['books'].get(candidate.book_id,{})
                    record=record if isinstance(record,dict) else {}
                    settings=LayoutSettings.from_dict(record.get('epub_layout',self.layout_settings.as_dict()))
                    path=record.get('path')
                    if not isinstance(path,str) or not candidate.is_document(path):path=candidate.chapters[0].path
                    if settings.mode!='simple':PublisherResources(candidate).chapter(path)
            except (EpubError,OSError,ValueError) as exc:
                QMessageBox.warning(self,'原书排版无法打开',str(exc)+'\n原来的书籍保持不变。也可先切换简化阅读后重试。')
                return False
        self._opening_publication=True
        try:
            success=super().open_book(filename)
        finally:
            self._opening_publication=False
        if success:
            self.layout_toolbar.setVisible(self.book is not None and self._focus_states is None)
            if self._using_publication():
                self.document_stack.setCurrentWidget(self.publication_view)
                self.publication_view.setFocus()
            elif self.pdf_book is not None:
                self.publication_view.clear_publication();self._publication_resources=None
        if not success and self._using_publication():
            self.document_stack.setCurrentWidget(self.publication_view)
        return success

    def navigate(self,path,fragment='',ratio=0.0,record_history=True,prepared_html=None,view=None):
        if self.book is not None and self.pdf_book is None:
            if self._layout_book_id!=self.book.book_id:
                self._layout_book_id=self.book.book_id
                record=self.store.data['books'].get(self.book.book_id,{})
                self.layout_settings=LayoutSettings.from_dict(record.get('epub_layout',self.layout_settings.as_dict()) if isinstance(record,dict) else None)
                if self._force_simple:self.layout_settings=replace(self.layout_settings,mode='simple')
                self._sync_layout_controls()
            if self._using_publication():
                if self._publication_resources is None or self._publication_resources.book is not self.book:
                    self._publication_resources=PublisherResources(self.book)
                try:
                    self._publication_resources.chapter(path)
                except (EpubError,OSError,ValueError) as exc:
                    QMessageBox.warning(self,'原书章节无法显示',str(exc))
                    return
                if (self.publication_view.ready and self.publication_view.resources is self._publication_resources
                        and self.publication_view.active_path==path and self.current_path==path):
                    if record_history:
                        self.history.append((path,self.current_ratio()));self.history=self.history[-128:]
                    anchor,self._next_web_anchor=self._next_web_anchor,None
                    self.publication_view.go_to(fragment,ratio,anchor)
                    self.update_controls();self.publication_view.setFocus()
                    return
                prepared_html=''  # do not flatten/pre-decode every image via the legacy path
        result=super().navigate(path,fragment,ratio,record_history,prepared_html,view)
        if self._using_publication():
            self.document_stack.setCurrentWidget(self.publication_view)
            self.publication_view.setFocus()
        return result

    def render(self,ratio,fragment='',view=None):
        if not self._using_publication():return super().render(ratio,fragment,view)
        self._restore_timer.stop();self._resize_timer.stop();self._pending_target=None;self._reflow_anchor=None
        self._generation+=1;self._loading=True;self._ready_ratio=ratio
        if self._publication_resources is None or self._publication_resources.book is not self.book:
            self._publication_resources=PublisherResources(self.book)
        anchor,self._next_web_anchor=self._next_web_anchor,None
        if self._opening_publication and self.restore_position:
            record=self.store.data['books'].get(self.book.book_id,{})
            if isinstance(record,dict):anchor=clean_anchor(record.get('epub_web_anchor'))
        try:
            self.publication_view.set_chapter(self._publication_resources,self.current_path,self._payload(),ratio,fragment,anchor)
            self.document_stack.setCurrentWidget(self.publication_view)
        except (EpubError,ValueError,OSError) as exc:
            self._publication_loaded(False,str(exc))

    def _publication_loaded(self,success,message):
        if not self._using_publication():return
        self._loading=False
        if not success:
            self.statusBar().showMessage(message,30000)
            return
        self._layout_notice();self.scrolled()

    def _publication_interacted(self):
        if self._using_publication():
            self._restore_timer.stop();self._pending_target=None;self._reflow_anchor=None

    def remember_view_before_resize(self):
        if not self._using_publication():return super().remember_view_before_resize()

    def schedule_reflow(self):
        if not self._using_publication():return super().schedule_reflow()

    def reflow(self):
        if not self._using_publication():return super().reflow()

    def current_ratio(self):
        if self._using_publication():
            return self._ready_ratio if self._loading else self.publication_view.current_ratio()
        return super().current_ratio()

    def capture_view(self):
        if self._using_publication():
            a=self.publication_view.anchor or {};r=self.current_ratio()
            return ViewPosition(0,0,r,a.get('top',r==0),a.get('bottom',r==1))
        return super().capture_view()

    def turn_page(self,direction):
        if self._using_publication():return self.publication_view.turn(direction)
        return super().turn_page(direction)

    def go_to_chapter_start(self):
        if self._using_publication():return self.publication_view.go_to()
        return super().go_to_chapter_start()

    def change_font(self,delta):
        if not self._using_publication():return super().change_font(delta)
        self.font_size=max(12,min(36,self.font_size+delta));self.font_label.setText(f'{self.font_size} pt')
        self.publication_view.apply_settings(self._payload());self._save_timer.start()

    def set_background(self,color):
        if not self._using_publication():return super().set_background(color)
        normalized=normalize_background(color,'')
        if not normalized:return
        self.background=normalized;self.night=theme_colors(normalized)[2]=='#ffffff'
        if not self.night:self.day_background=normalized
        self.apply_theme();self.publication_view.apply_settings(self._payload());self.save_state()

    def lookup_selection(self):
        if not self._using_publication():return super().lookup_selection()
        if valid_query(self.publication_view.selectedText()):self.publication_view.lookup(True)
        elif self.dictionary_dock is not None:
            self.dictionary_dock.show();self.dictionary_dock.query_edit.setFocus()

    def _publication_lookup(self,text,context,explicit):
        if not self._using_publication() or self.dictionary_dock is None or not valid_query(text):return
        if not explicit and not self.dictionary_dock.auto_check.isChecked():return
        self.dictionary_dock.show();self.dictionary_dock.raise_()
        self.dictionary_dock.lookup(text,context,self.book.title)
        self.publication_view.setFocus(Qt.FocusReason.OtherFocusReason)

    def lookup_text(self,text):
        if self._using_publication():
            self._publication_lookup(text,self.publication_view._context,True)
        else:super().lookup_text(text)

    def find_text(self,backward=False):
        if not self._using_publication():return super().find_text(backward)
        query=self.search_edit.text().strip()
        flags=QWebEnginePage.FindFlag.FindBackward if backward else QWebEnginePage.FindFlag(0)
        generation=self.publication_view._generation
        def done(result):
            if not self._using_publication() or generation!=self.publication_view._generation:return
            # PySide callback is QWebEngineFindTextResult in Qt 6.
            if hasattr(result,'numberOfMatches'):
                count=result.numberOfMatches();index=result.activeMatch()
                text=f'本章匹配 {index}/{count}' if count else '当前章节没有找到。'
            else:text='已定位本章匹配。' if result else '当前章节没有找到。'
            self.statusBar().showMessage(text,4500)
        self.publication_view.page().findText(query,flags,done)

    def add_bookmark(self):
        if not self._using_publication():return super().add_bookmark()
        generation=self.publication_view._generation;book_id=self.book.book_id
        def add(value):
            if not self._using_publication() or book_id!=self.book.book_id or generation!=self.publication_view._generation:return
            anchor=clean_anchor(value);ratio=anchor['ratio'] if anchor else self.current_ratio()
            if len(self.bookmarks)>=200:
                self.statusBar().showMessage('每本书最多 200 个书签。',5000);return
            if any(x['path']==self.current_path and abs(x['ratio']-ratio)<.005 for x in self.bookmarks):
                self.statusBar().showMessage('此处已有书签。',3500);return
            label=f'{self.title_for(self.current_path)} · {ratio:.0%}'
            selection=self.publication_view.selectedText().strip()
            if selection:label+='\n'+selection[:45]
            self.bookmarks.append({'path':self.current_path,'ratio':ratio,'label':label,'web_anchor':anchor})
            self.populate_bookmarks();self.save_state();self.statusBar().showMessage('段落书签已保存。',3500)
        self.publication_view.js('window.__modu.snapshot()',add)

    def open_bookmark(self,item):
        mark=item.data(Qt.ItemDataRole.UserRole)
        self._next_web_anchor=clean_anchor(mark.get('web_anchor')) if isinstance(mark,dict) else None
        return super().open_bookmark(item)

    def scrolled(self,_value=0):
        if not self._using_publication():return super().scrolled(_value)
        if self._loading or not self.current_path:return
        count=len(self.book.chapters);r=self.current_ratio()
        self.progress_label.setText(f'章节 {self.chapter_index+1}/{count} · 本章 {r:.0%} · {MODE_NAMES[self.layout_settings.mode]}')
        self._save_timer.start()

    def _extend_saved_state(self):
        self.store.data['preferences']['epub_layout']=self.layout_settings.as_dict()
        if self.book is not None and self.current_path:
            record=self.store.data['books'].get(self.book.book_id)
            if isinstance(record,dict):
                record['epub_layout']=self.layout_settings.as_dict()
                if self._using_publication():
                    record['epub_web_anchor']=clean_anchor(self.publication_view.anchor)
                    record.pop('viewport',None)  # not a QTextDocument cursor location

    def toggle_focus(self):
        if self._focus_states is not None:return self.exit_focus()
        widgets=[self.sidebar,*self.findChildren(QToolBar)]
        if self.dictionary_dock is not None:widgets.append(self.dictionary_dock)
        self._focus_states=(self.isFullScreen(),[(w,w.isVisible()) for w in widgets])
        for w in widgets:w.hide()
        self._focus_exit_action.setEnabled(True)
        self.showFullScreen()
        self.statusBar().showMessage('专注阅读：F11 或 Esc 退出；Ctrl+J 临时打开词典。',8000)

    def exit_focus(self):
        if self._focus_states is None:return
        was_full,states=self._focus_states;self._focus_states=None
        self._focus_exit_action.setEnabled(False)
        if not was_full:self.showNormal()
        for w,visible in states:w.setVisible(visible)
        self.layout_toolbar.setVisible(self.book is not None)
        self.pdf_toolbar.setVisible(self.pdf_book is not None)

    def closeEvent(self,event):
        super().closeEvent(event)
        if event.isAccepted() and self.publication_view is not None:self.publication_view.shutdown()
